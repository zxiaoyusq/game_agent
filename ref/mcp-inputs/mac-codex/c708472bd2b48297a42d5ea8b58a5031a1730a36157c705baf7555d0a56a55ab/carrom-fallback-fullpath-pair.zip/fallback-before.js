var _0x4a128a = _0x3797;
(function (_0x1b9558, _0x56bdef) {
  var _0x27297a = _0x3797,
    _0x352452 = _0x1b9558();
  while (!![]) {
    try {
      var _0x217a46 =
        -parseInt(_0x27297a(0x1d3)) / 0x1 +
        parseInt(_0x27297a(0x1fd)) / 0x2 +
        (parseInt(_0x27297a(0x2c4)) / 0x3) *
          (parseInt(_0x27297a(0x4ce)) / 0x4) +
        -parseInt(_0x27297a(0xf7)) / 0x5 +
        parseInt(_0x27297a(0x406)) / 0x6 +
        (parseInt(_0x27297a(0x4b2)) / 0x7) *
          (parseInt(_0x27297a(0x331)) / 0x8) +
        -parseInt(_0x27297a(0x139)) / 0x9;
      if (_0x217a46 === _0x56bdef) break;
      else _0x352452["push"](_0x352452["shift"]());
    } catch (_0x222727) {
      _0x352452["push"](_0x352452["shift"]());
    }
  }
})(_0x3f3a, 0x283e4);
var src = {
    bitmaps: {
      text_spin_now_pressed: _0x4a128a(0x419),
      xxspin_now_basexxx: _0x4a128a(0x490),
      button_video: _0x4a128a(0x11e),
      button_video_pressed: "assets/update/button_video_pressed.png",
      button_claimx2: "assets/update/button_claimx2.png",
      button_claimx2_pressed: "assets/update/button_claimx2_pressed.png",
      text_free_spin: _0x4a128a(0xe7),
      text_free_spin_pressed: _0x4a128a(0x247),
      text_spin_now: _0x4a128a(0x20c),
      Carrom_black: "assets/Carrom_black.png",
      Carrom_circle_around_strike: _0x4a128a(0x33d),
      Carrom_coins_light: _0x4a128a(0x1ca),
      Carrom_coins_symbol: _0x4a128a(0x239),
      Carrom_line: _0x4a128a(0x1bb),
      Carrom_player_black: "assets/Carrom_player_black.png",
      Carrom_player_frame: _0x4a128a(0x3e9),
      Carrom_player_white: _0x4a128a(0x186),
      Carrom_red: _0x4a128a(0x240),
      Carrom_strike: _0x4a128a(0x396),
      Carrom_white: _0x4a128a(0x3b4),
      striker_overlay: _0x4a128a(0x449),
      check_unfilled: "assets/check_unfilled.png",
      check_filled: _0x4a128a(0x319),
      arrow_motion: _0x4a128a(0x258),
      arrow_outline: "assets/arrow_outline.png",
      notification_dot: "assets/notification_dot.png",
      foul_background: "assets/foul_background.png",
      foul_base: _0x4a128a(0x15e),
      label_carrom: _0x4a128a(0x10c),
      label_discpool: "assets/label_discpool.png",
      label_freestyle: _0x4a128a(0xf0),
      striker_highlight_5: _0x4a128a(0x165),
      lobby_bg: "assets/lobby/lobby_bg.png",
      lobby_button_carrom: _0x4a128a(0x1b8),
      lobby_button_carrom_hover: "assets/lobby/lobby_button_carrom_hover.png",
      lobby_button_discpool: _0x4a128a(0x4af),
      lobby_button_discpool_hover: _0x4a128a(0x2b5),
      lobby_button_freestyle: "assets/lobby/lobby_button_freestyle.png",
      lobby_button_freestyle_hover: _0x4a128a(0x334),
      lobby_button_shop_hover_v02: _0x4a128a(0x43a),
      lobby_button_shop_v02: "assets/lobby/lobby_button_shop_v02.png",
      lobby_button_dailybonus: _0x4a128a(0x11b),
      lobby_button_dailybonus_hover:
        "assets/lobby/lobby_button_free_spin_hover.png",
      lobby_title: _0x4a128a(0x150),
      button_settings: _0x4a128a(0x4b8),
      button_settings_hover: _0x4a128a(0x112),
      button_settings_hover_v02: _0x4a128a(0x191),
      button_settings_v02: "assets/shop/button_settings_v02.png",
      shop_button_buy: _0x4a128a(0x493),
      shop_button_buy_hover: "assets/shop/shop_button_buy_hover.png",
      shop_button_upgrade: _0x4a128a(0x4a9),
      shop_button_upgrade_hover: _0x4a128a(0x1fb),
      shop_coins_cointer_base: _0x4a128a(0x2a1),
      shop_header_base: _0x4a128a(0x2bb),
      shop_single_coin: _0x4a128a(0x2dd),
      shop_tab_stones: "assets/shop/shop_tab_stones.png",
      shop_tab_stones_hover: _0x4a128a(0x1f4),
      shop_tab_strikers: _0x4a128a(0x36d),
      shop_tab_strikers_hover: _0x4a128a(0x157),
      shop_tick: _0x4a128a(0xf1),
      strike_blue_bit: _0x4a128a(0xf5),
      strike_yellow_bit: _0x4a128a(0x301),
      strike_green_stroke: _0x4a128a(0x49a),
      strike_module_base: _0x4a128a(0x3e8),
      strike_01: _0x4a128a(0x2ec),
      strike_02: _0x4a128a(0x2fe),
      strike_03: "assets/shop/strike_03.png",
      strike_04: _0x4a128a(0x3c4),
      strike_05: "assets/shop/strike_05.png",
      strike_06: _0x4a128a(0x140),
      strike_07: _0x4a128a(0x24f),
      strike_08: "assets/shop/strike_08.png",
      strike_09: _0x4a128a(0x2ca),
      shop_bg: "assets/shop/shop_bg.png",
      shop_stones_module_dimmed: _0x4a128a(0x22f),
      shop_strikers_module_dimmed: _0x4a128a(0x3b1),
      shop_button_upgrade_arrow: _0x4a128a(0x384),
      shop_button_upgrade_arrow_hover:
        "assets/shop/stones/shop_button_upgrade_arrow_hover.png",
      stone_green_stroke: _0x4a128a(0x4be),
      stone_module_base: _0x4a128a(0x3fd),
      stone_00: "assets/shop/stones/stone_00.png",
      stone_01: _0x4a128a(0x2b0),
      stone_02: _0x4a128a(0x46c),
      stone_03: _0x4a128a(0x206),
      stone_04: _0x4a128a(0x1d1),
      stone_05: _0x4a128a(0x41a),
      stone_06: _0x4a128a(0x210),
      stone_08: _0x4a128a(0x250),
      stone_09: _0x4a128a(0x4aa),
      tut_1_6: _0x4a128a(0x2aa),
      tut_2_6: _0x4a128a(0x380),
      tut_3_6: _0x4a128a(0xe2),
      tut_4_6: _0x4a128a(0xe3),
      tut_5_6: "assets/tutorial/5_6.png",
      tut_6_6: "assets/tutorial/6_6.png",
      tut_1_4: _0x4a128a(0x496),
      tut_2_4: _0x4a128a(0x42d),
      tut_3_4: _0x4a128a(0x3d9),
      tut_4_4: _0x4a128a(0x455),
      tut_ARROW_LEFT: _0x4a128a(0x174),
      tut_ARROW_RIGHT: _0x4a128a(0x364),
      tut_hand: "assets/tutorial/hand.png",
      tut_01_screen_design: _0x4a128a(0x3bd),
      tut_01_title: _0x4a128a(0x329),
      tut_02_screen_design: _0x4a128a(0x4ca),
      tut_02_title: _0x4a128a(0x327),
      tut_03_screen_design: _0x4a128a(0xda),
      tut_03_title: "assets/tutorial/tut_03_title.png",
      tut_04_screen_design: _0x4a128a(0x45c),
      tut_04_title: _0x4a128a(0x326),
      tut_05_screen_design: "assets/tutorial/tut_05_screen_design.png",
      tut_06_screen_design: "assets/tutorial/tut_06_screen_design.png",
      tut_WOODEN_BASE: _0x4a128a(0x3aa),
      back_button: _0x4a128a(0x21d),
      back_button_hover: _0x4a128a(0x18b),
      coin_counter_base: _0x4a128a(0x3d3),
      tableselect_arrow_left: "assets/select/tableselect_arrow_left.png",
      tableselect_arrow_right: _0x4a128a(0x407),
      tableselect_coins: _0x4a128a(0x479),
      tableselect_delhilounge_base:
        "assets/select/tableselect_delhilounge_base.png",
      tableselect_delhilounge_title: _0x4a128a(0xf2),
      tableselect_goldencity_base:
        "assets/select/tableselect_goldencity_base.png",
      tableselect_goldencity_title: _0x4a128a(0xd7),
      tableselect_mahalpalace_base:
        "assets/select/tableselect_mahalpalace_base.png",
      tableselect_mahalpalace_title: _0x4a128a(0x1a3),
      tableselect_mumbaiplaza_base: _0x4a128a(0x39e),
      tableselect_mumbaiplaza_title:
        "assets/select/tableselect_mumbaiplaza_title_with_glow.png",
      tableselect_royalarena_base: _0x4a128a(0x226),
      tableselect_royalarena_title: _0x4a128a(0x33f),
      tableselect_select_button: _0x4a128a(0x4c2),
      tableselect_select_button_hover: _0x4a128a(0x446),
      tableselect_prize_base: _0x4a128a(0x3d5),
      tableselect_fee_base: _0x4a128a(0x355),
      matchmaking_bg_delhilounge_slices:
        "assets/matchmaking/matchmaking_bg_delhilounge_slices.png",
      matchmaking_bg_goldencity_slices: _0x4a128a(0xd2),
      matchmaking_bg_mahalpalace_slices: _0x4a128a(0x133),
      matchmaking_bg_mumbaiplaza_slices: _0x4a128a(0x46d),
      matchmaking_bg_royalarena_slices: _0x4a128a(0x34b),
      Carrom_coins_light: _0x4a128a(0x30e),
      carrom_spinning_wheel_base_brights: _0x4a128a(0x317),
      reward_pot_coins: _0x4a128a(0x345),
      single_coin: _0x4a128a(0x1e1),
      results_claim_button: _0x4a128a(0x42e),
      results_claim_button_hover:
        "assets/result/results_claim_button_hover.png",
      try_button: "assets/result/try_button.png",
      try_button_hover: _0x4a128a(0x14e),
      results_claimx2_button: _0x4a128a(0x24e),
      results_claimx2_button_hover:
        "assets/result/results_claimx2_button_hover.png",
      results_coins: _0x4a128a(0x18e),
      results_opponent_profile: _0x4a128a(0x1d9),
      results_title: _0x4a128a(0x17b),
      results_title_stones: _0x4a128a(0x349),
      results_you_profile: _0x4a128a(0x3de),
      text_opponent: _0x4a128a(0x34c),
      text_you: _0x4a128a(0x2b3),
      results_opponent_profile_win:
        "assets/result/results_opponent_profile_win.png",
      results_you_profile_lose: _0x4a128a(0x158),
      loser_01: _0x4a128a(0x33b),
      loser_02: _0x4a128a(0x1ab),
      loser_03: _0x4a128a(0x2da),
      loser_04: _0x4a128a(0x2d6),
      loser_05: _0x4a128a(0x113),
      results_win_stones: _0x4a128a(0x214),
      results_win_title: "assets/result/results_win_title.png",
      winner_outer_glow: _0x4a128a(0x1b0),
      winner_background: _0x4a128a(0x289),
      winner_glow: "assets/result/winner_glow.png",
      close_button: _0x4a128a(0x20b),
      close_button_hover: _0x4a128a(0x2ed),
      home_button: "assets/pause/home_button.png",
      home_button_sfx: _0x4a128a(0x209),
      music_button: _0x4a128a(0x1df),
      music_button_sfx: _0x4a128a(0x259),
      music_button_off: "assets/pause/music_button_off.png",
      sfx_button: _0x4a128a(0x136),
      sfx_button_hover: _0x4a128a(0x260),
      sfx_button_off: "assets/pause/sfx_button_off.png",
      tutorial_button: "assets/pause/tutorial_button.png",
      tutorial_button_hover: _0x4a128a(0x37e),
      pause_button: "assets/pause/pause_button.png",
      pause_button_hover: "assets/pause/pause_button_hover.png",
      settings_pause_base: _0x4a128a(0x391),
      settings_text: "assets/pause/settings_text.png",
      pause_text: _0x4a128a(0x3a6),
      pause_play_button: _0x4a128a(0x401),
      pause_play_button_hover: _0x4a128a(0x29c),
      button_yes_hover: _0x4a128a(0x287),
      button_yes: _0x4a128a(0x452),
      button_no_hover: _0x4a128a(0x456),
      button_no: _0x4a128a(0x3ee),
      exit_question: _0x4a128a(0x3ff),
      button_home: _0x4a128a(0x413),
      button_home_pressed: _0x4a128a(0x4c8),
      button_play: "assets/settings/button_play.png",
      button_play_pressed: _0x4a128a(0x37c),
      button_tutorial: "assets/settings/button_tutorial.png",
      button_tutorial_pressed: "assets/settings/button_tutorial_pressed.png",
      lobby_button_tutorial: _0x4a128a(0x249),
      lobby_button_tutorial_pressed: _0x4a128a(0x2cd),
      pause_base: _0x4a128a(0x145),
      brights_behind_numbers: _0x4a128a(0x266),
      carrom_spin_button: "assets/wheel/carrom_spin_button.png",
      carrom_spin_button_hover: "assets/wheel/carrom_spin_button_hover.png",
      carrom_spinning_wheel_arrow: _0x4a128a(0x270),
      carrom_spinning_wheel_background: _0x4a128a(0x4c6),
      carrom_spinning_wheel_base: _0x4a128a(0x44e),
      carrom_spinning_wheel_base_bright: _0x4a128a(0x14f),
      carrom_spinning_wheel_base_brights: _0x4a128a(0x161),
      carrom_spinning_wheel_shadow:
        "assets/wheel/carrom_spinning_wheel_shadow.png",
      coins: _0x4a128a(0x4ba),
      coins_big: _0x4a128a(0x153),
      cpx_0: _0x4a128a(0x332),
      cpx_1: _0x4a128a(0x3b9),
      cpx_2: _0x4a128a(0xd5),
      cpx_3: _0x4a128a(0x24a),
      cpx_4: _0x4a128a(0x367),
      cpx_5: "assets/wheel/confetti_06.png",
      cpx_6: _0x4a128a(0x2a3),
      cpx_7: "assets/wheel/confetti_08.png",
      cpx_8: "assets/wheel/confetti_09.png",
      Congratulations: _0x4a128a(0x1d2),
      numbers_shadow: _0x4a128a(0x23f),
      purple_lights_behind: "assets/wheel/purple_lights_behind.png",
      text_good_luck: _0x4a128a(0x3af),
      test_you_won: _0x4a128a(0x121),
      corner_bl_0: "assets/tables/0/delhi_lounge_corner_BL.png",
      corner_br_0: _0x4a128a(0x1e5),
      corner_tl_0: _0x4a128a(0x3dc),
      corner_tr_0: _0x4a128a(0x368),
      corner_striker_base_0: _0x4a128a(0x2ff),
      corner_striker_0: _0x4a128a(0x356),
      table_0: _0x4a128a(0x416),
      bg_0: "assets/tables/0/delhi_lounge_table_01_background.png",
      logo_0: _0x4a128a(0x141),
      corners_0: _0x4a128a(0x222),
      corner_bl_1: "assets/tables/1/golden_city_corner_BL.png",
      corner_br_1: _0x4a128a(0x17d),
      corner_tl_1: _0x4a128a(0x1b4),
      corner_tr_1: _0x4a128a(0x376),
      corner_striker_base_1: _0x4a128a(0xef),
      corner_striker_1: _0x4a128a(0x488),
      table_1: _0x4a128a(0x173),
      bg_1: "assets/tables/1/golden_city_table_01_background.png",
      logo_1: _0x4a128a(0x460),
      corners_1: _0x4a128a(0x1ef),
      corner_bl_2: _0x4a128a(0x395),
      corner_br_2: _0x4a128a(0x26e),
      corner_tl_2: _0x4a128a(0x478),
      corner_tr_2: _0x4a128a(0x3a4),
      corner_striker_base_2: _0x4a128a(0x14b),
      corner_striker_2: _0x4a128a(0x233),
      table_2: "assets/tables/2/mahal_palace_table.png",
      bg_2: _0x4a128a(0x3e4),
      logo_2: _0x4a128a(0x12b),
      corners_2: "assets/tables/2/mahal_palace_corners.png",
      corner_bl_3: _0x4a128a(0x44b),
      corner_br_3: _0x4a128a(0x22b),
      corner_tl_3: "assets/tables/3/Carrom_corner_TL.png",
      corner_tr_3: "assets/tables/3/Carrom_corner_TR.png",
      corner_striker_base_3: _0x4a128a(0x373),
      corner_striker_3: _0x4a128a(0x11f),
      table_3: _0x4a128a(0x30b),
      bg_3: _0x4a128a(0x3d1),
      logo_3: _0x4a128a(0x248),
      corners_3: "assets/tables/3/mumbai_plaza_corners.png",
      corner_bl_4: _0x4a128a(0x442),
      corner_br_4: _0x4a128a(0x2c7),
      corner_tl_4: _0x4a128a(0x154),
      corner_tr_4: _0x4a128a(0x108),
      corner_striker_base_4: "assets/tables/4/royal_arena_strike_base.png",
      corner_striker_4: _0x4a128a(0x2f5),
      table_4: _0x4a128a(0x104),
      bg_4: "assets/tables/4/royal_arena_table_01_background.png",
      logo_4: _0x4a128a(0x31d),
      corners_4: _0x4a128a(0x13e),
      Simonetta_white2: "assets/fonts/Simonetta_white2.fnt",
      avatar_blue_bg: _0x4a128a(0x3e7),
      avatar_frame_empty: _0x4a128a(0x344),
      avatar_frame_filled: _0x4a128a(0x201),
      frame_black_filled: _0x4a128a(0x202),
      frame_red_filled: _0x4a128a(0x244),
      frame_white_filled: _0x4a128a(0x1f6),
      avatar_red_bg: _0x4a128a(0x353),
      avatar_silhouette_cha01: _0x4a128a(0x26f),
      avatar_silhouette_cha02: _0x4a128a(0x439),
      avatar_silhouette_cha03: "assets/avatars/silhouette_cha03.png",
      avatar_silhouette_cha04: "assets/avatars/silhouette_cha04.png",
      avatar_silhouette_cha05: _0x4a128a(0x3cb),
      starting_1: "assets/starting/1.png",
      starting_2: _0x4a128a(0x18a),
      starting_arrow: _0x4a128a(0x4bc),
      starting_player_base: "assets/starting/starting_player_base.png",
      impact_a_sprite: _0x4a128a(0x35f),
      impact_b_sprite: _0x4a128a(0x2a6),
      puck_sprite: "assets/sprites/puck.png",
      stone_pot_sprite: "assets/sprites/stone_pot.png",
      title_sprite: _0x4a128a(0x271),
    },
    sprites: {
      impact_a: {
        source: _0x4a128a(0x303),
        frames: 0x6,
        frameWidth: 0x68,
        frameHeight: 0x74,
      },
      impact_b: {
        source: _0x4a128a(0x1c2),
        frames: 0x5,
        frameWidth: 0x68,
        frameHeight: 0x74,
      },
      puck: {
        source: _0x4a128a(0x4a5),
        frames: 0xf,
        frameWidth: 0x7f,
        frameHeight: 0x85,
      },
      stone_pot: {
        source: _0x4a128a(0x2dc),
        frames: 0x8,
        frameWidth: 0x68,
        frameHeight: 0x74,
      },
      title: {
        source: _0x4a128a(0x281),
        frames: 0x19,
        frameWidth: 0xdb,
        frameHeight: 0xbd,
      },
    },
  },
  box2d = planck,
  game = (function () {
    var _0x157421 = _0x4a128a,
      _0x5568a2 = 0x280,
      _0x27ae22 = 0x471,
      _0x24b13c = 0x0,
      _0x376ce3 = 0x0,
      _0x125d76 = {
        init: function () {
          _0xc37276();
        },
        test: function (_0x546d47, _0x2893c3, _0x26c072, _0x19de5a) {
          var _0x1582bf = _0x3797;
          _0x47e567(!![]);
          return;
          _0x27e1b4[_0x1582bf(0x152)]();
          let _0x31fd70 = _0x52106f(_0x2fc10d[0x0], _0x2a9c75, !![]),
            _0x28bb0a = _0x25af2a(_0x2fc10d[0x1], _0x2a9c75, !![]),
            _0x1026e9 = _0x521eef(_0x2fc10d[0x2], _0x2a9c75, !![]),
            _0x1273a7 = _0x30849b(_0x2fc10d[0x3], _0x2a9c75, !![]),
            _0x4995ef = [][_0x1582bf(0x1c0)](
              _0x31fd70,
              _0x28bb0a,
              _0x1026e9,
              _0x1273a7,
            );
          if (_0x4995ef[_0x1582bf(0x182)]) {
            _0x4995ef["sort"](
              (_0x24c4b4, _0x5be1e3) =>
                _0x5be1e3[_0x1582bf(0x3f0)] - _0x24c4b4[_0x1582bf(0x3f0)],
            );
            let _0x48ca25 = _0x4995ef[0x0][_0x1582bf(0x32c)];
            _0xd6b627(_0x4995ef[0x0], (_0x48ca25 / 0x64) * 0x3c * 0.2 * 1.1);
          } else
            (console[_0x1582bf(0xd9)](_0x1582bf(0x472)),
              _0xd6b627(_0x3d12d7(), 0x64));
        },
        test2: function () {
          _0x27e1b4["test2"]();
        },
        mute: function () {},
        unmute: function () {},
        pause: function () {
          if (_carromHostPaused) return;
          _carromHostPaused = true;
          _0x990fb7 = 0;
          _carromPauseMatchTimers();
          _carromSyncMute();
          _carromCancelAim();
          if (_0x147a99 && _0x147a99._sliding) {
            if (_0x3fddb3 && _0x55e693 && _0x209883 && _0x27e1b4) _0x41684e();
            _0x147a99._sliding = false;
          }
          if (_0x423f7f && _0x423f7f.view && _0x423f7f.view.style) {
            _carromHostPointerEvents = _0x423f7f.view.style.pointerEvents;
            _0x423f7f.view.style.pointerEvents = 'none';
          }
        },
        resume: function () {
          if (!_carromHostPaused) return;
          _carromHostPaused = false;
          _carromResumeMatchTimers();
          _carromSyncMute();
          try { if (window.CarromLocalSave && typeof window.CarromLocalSave.flush === 'function') window.CarromLocalSave.flush(); } catch (_) {}
          if (_0x423f7f && _0x423f7f.view && _0x423f7f.view.style && _carromHostPointerEvents !== null)
            _0x423f7f.view.style.pointerEvents = _carromHostPointerEvents;
          _carromHostPointerEvents = null;
        },
        restart: function () {
          _0x5480e3();
        },
      },
      _0x1392b5,
      _0x5dde87,
      _0x23207e = {
        tables: [
          _0x157421(0x434),
          _0x157421(0x2c8),
          "locked",
          "locked",
          _0x157421(0x2c8),
        ],
        upgrades: [0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0],
        strikers: [
          _0x157421(0x16d),
          "locked",
          "locked",
          _0x157421(0x2c8),
          _0x157421(0x2c8),
          "locked",
          _0x157421(0x2c8),
          "locked",
          "locked",
        ],
        stones: [
          _0x157421(0x16d),
          _0x157421(0x2c8),
          "locked",
          _0x157421(0x2c8),
          _0x157421(0x2c8),
          _0x157421(0x2c8),
          "locked",
          _0x157421(0x2c8),
          "locked",
        ],
        coins: 0x0,
        tutorial: !![],
        lastRewardTime: 0x0,
      },
      _0x5858ba = null,
      _0x3af7cd = ![],
      _0x5de003 = ![],
      _0x25199a,
      _0x423f7f,
      _0xbf118 = {},
      _0x476683 = {},
      _0xa07851 = 0x3e8,
      _0x375a5a = 0x0,
      _0x408018 = 0x0,
      _0x4b3012 = 0x0,
      _0x3e9ee1 = -0x1,
      _0x5d148e = 0x0,
      _0xf6d2ec = 0x0,
      _0x2799f0 = 0x0,
      _0x4bee00 = 0x0,
      _0x5ac2f9 = 0x0,
      _0x2102d7 = 0x0,
      _0x2706fd = 0x1,
      _0x183856 = !![],
      _0x14906d = ![],
      _0x14cbdd = 0x0,
      _0x6d1a83 = 0x0,
      _0x530cb1 = ![],
      _0xcf7ce5,
      _0x5939ae,
      _0x429f89,
      _0x5484bf,
      _0x50d6f7,
      _0x4865ce,
      _0x221209,
      _0x2b986d,
      _0x24c0ca,
      _0x2098e9,
      _0x2f4138,
      _0x27e1b4,
      _0x147a99,
      _0xc5bee4,
      _0x404020,
      _0x337f1a,
      _0x5ccb1e,
      _0xa07680,
      _0x310e61,
      _0x28036b,
      _0x2cf38a,
      _0x44d1ad,
      _0x539ff8,
      _0x25b85f,
      _0x27ee82,
      _0x458adc,
      _0x4149a7,
      _0x17296f,
      _0x21a97b,
      _0x3cba20,
      _0xb32d86,
      _0x5b3bc4,
      _0x3baf59 = [],
      _0x3e4566 = [],
      _0x2a9c75 = [],
      _0x3231b3 = [],
      _0x59d4ef = [],
      _0x49abc0 = [],
      _0x31089b = [],
      _0xf86500 = ![],
      _carromAimPointerId = null,
      _carromAimNativePointerId = null,
      _carromAimPointerType = null,
      _0x2b840a = { x: 0x0, y: 0x0 },
      _0x55e693 = ![],
      _0x209883 = ![],
      _0x4268e2 = ![],
      _carromQueenClearedThisShot = false,
      _0x3a1262,
      _0x153877 = 0xa0,
      _0x41f634 = 0x0,
      _0x4d3bf1 = 0x0,
      _0x5ebd99 = ![],
      _0x530863 = ![],
      _0x1a373b = 0x0,
      _0x1f57de = 0x3c,
      _0x178e84,
      _0x361d24 = ![],
      _0x3fddb3 = ![],
      _carromResultCommitted = false,
      _carromRoundId = 0,
      _carromTurnId = 0,
      _carromSettledTurn = -1,
      _carromTimeoutReady = null,
      _carromFreestyleHistory = [],
      _carromFreestyleQueenState = {phase: 'board', owner: null},
      _carromPendingPenalty = null,
      _carromPendingQueenPocket = null,
      _carromAiShotTurn = -1,
      _carromAiRetryTurn = -1,
      _carromAiRetryCount = 0,
      _0x19d995 = ![],
      _0x3e61d0 = !![],
      _carromHostPaused = false,
      _carromHostPointerEvents = null,
      _carromMatchTimers = [],
      _carromAdTokens = [],
      _carromActiveMatch = null,
      _carromPauseRegistered = false,
      _carromResumeRegistered = false,
      _0x3b3e21 = ![],
      _0x39ab6a = ![],
      _0x3e43c0 = !![],
      _0xcfa3ba = ![],
      _0xb768e8 = ![],
      _0x3768e7 = 0x0,
      _0x5ef04d = ![],
      _0x589270 = ![],
      _0x5c102b = ![],
      _0x7fd997 = ![],
      _0x1f977d = 0x78,
      _0xcd5b2f = ![],
      _0x420004 = null,
      _0x38b273 = null,
      _carromAdGeneration = 0,
      _0x2e2e88 = [
        _0x157421(0x434),
        _0x157421(0x2c8),
        "locked",
        "locked",
        "locked",
      ],
      _0x57e1d2 = [
        { state: "equiped", value: 0x0, upgrade: 0x0, upgradeCost: 0x14 },
        {
          state: _0x157421(0x2c8),
          value: 0x32,
          upgrade: 0x0,
          upgradeCost: 0x19,
        },
        {
          state: _0x157421(0x2c8),
          value: 0x64,
          upgrade: 0x0,
          upgradeCost: 0x32,
        },
        { state: "locked", value: 0xc8, upgrade: 0x0, upgradeCost: 0x64 },
        { state: "locked", value: 0x190, upgrade: 0x0, upgradeCost: 0xc8 },
        {
          state: _0x157421(0x2c8),
          value: 0x258,
          upgrade: 0x0,
          upgradeCost: 0x12c,
        },
        {
          state: _0x157421(0x2c8),
          value: 0x7d0,
          upgrade: 0x0,
          upgradeCost: 0x3e8,
        },
        { state: "locked", value: 0x1388, upgrade: 0x0, upgradeCost: 0x9c4 },
        {
          state: _0x157421(0x2c8),
          value: 0x2710,
          upgrade: 0x0,
          upgradeCost: 0x1388,
        },
      ],
      _0x75fa36 = [
        { state: _0x157421(0x16d), value: 0x0, upgrade: 0x0, upgradeCost: 0x0 },
        {
          state: _0x157421(0x2c8),
          value: 0x32,
          upgrade: 0x0,
          upgradeCost: 0x14,
        },
        { state: "locked", value: 0x32, upgrade: 0x0, upgradeCost: 0x19 },
        {
          state: _0x157421(0x2c8),
          value: 0x64,
          upgrade: 0x0,
          upgradeCost: 0x32,
        },
        { state: "locked", value: 0xc8, upgrade: 0x0, upgradeCost: 0x64 },
        {
          state: _0x157421(0x2c8),
          value: 0x190,
          upgrade: 0x0,
          upgradeCost: 0xc8,
        },
        {
          state: _0x157421(0x2c8),
          value: 0x258,
          upgrade: 0x0,
          upgradeCost: 0x12c,
        },
        { state: "locked", value: 0x320, upgrade: 0x0, upgradeCost: 0x12c },
        {
          state: _0x157421(0x2c8),
          value: 0x3e8,
          upgrade: 0x0,
          upgradeCost: 0x12c,
        },
      ];
    const _0x8b6dea = [_0x157421(0x178), _0x157421(0x134), _0x157421(0x447)],
      _0x66b857 = 0x4 * 0x3c * 0x3c * 0x3e8,
      _0x18e0e1 = [0.8, 0.7, 0.6, 0.35, 0.2],
      _0x3cbd63 = [
        0x64 * 0x3c,
        0x19 * 0x3c,
        0x14 * 0x3c,
        0xf * 0x3c,
        0xa * 0x3c,
      ],
      _0x2916e6 = {
        purple: 0xc8,
        blue: 0x32,
        green: 0x64,
        red: 0x32,
        yellow: 0x1f4,
      },
      _0x1c2aac = [0x32, 0x14, 0xa],
      _0x1ac80c = [
        {
          id: 0x0,
          base: "tableselect_delhilounge_base",
          logo: _0x157421(0x2b9),
          prize: 0x32,
          fee: 0x0,
        },
        {
          id: 0x1,
          base: _0x157421(0x40c),
          logo: "tableselect_goldencity_title",
          prize: 0x7d,
          fee: 0x32,
        },
        {
          id: 0x2,
          base: "tableselect_mahalpalace_base",
          logo: _0x157421(0x4b1),
          prize: 0x190,
          fee: 0xc8,
        },
        {
          id: 0x3,
          base: "tableselect_mumbaiplaza_base",
          logo: _0x157421(0xfc),
          prize: 0x5dc,
          fee: 0x2ee,
        },
        {
          id: 0x4,
          base: "tableselect_royalarena_base",
          logo: "tableselect_royalarena_title",
          prize: 0x2710,
          fee: 0x1388,
        },
      ],
      _0x2dad3f = [
        {
          id: 0x0,
          table: _0x157421(0x1a4),
          logo: _0x157421(0x2a9),
          bg: _0x157421(0x48d),
          corners: _0x157421(0x35a),
          bar: "corner_striker_base_0",
          bar_2: _0x157421(0x2af),
          cover: _0x157421(0xd8),
        },
        {
          id: 0x1,
          table: _0x157421(0x305),
          logo: _0x157421(0x3e3),
          bg: _0x157421(0x1b2),
          corners: _0x157421(0x4bd),
          bar: _0x157421(0x424),
          bar_2: _0x157421(0x49b),
          cover: _0x157421(0x4b5),
        },
        {
          id: 0x2,
          table: _0x157421(0x358),
          logo: _0x157421(0x212),
          bg: "bg_2",
          corners: _0x157421(0x23c),
          bar: _0x157421(0x22a),
          bar_2: "corner_striker_2",
          cover: _0x157421(0x3a7),
        },
        {
          id: 0x3,
          table: _0x157421(0x27c),
          logo: _0x157421(0x46f),
          bg: _0x157421(0x409),
          corners: "corners_3",
          bar: _0x157421(0x1b6),
          bar_2: _0x157421(0x48b),
          cover: _0x157421(0x32a),
        },
        {
          id: 0x4,
          table: _0x157421(0x39d),
          logo: _0x157421(0x169),
          bg: _0x157421(0x41b),
          corners: _0x157421(0x263),
          bar: _0x157421(0x2f0),
          bar_2: "corner_striker_4",
          cover: _0x157421(0x4b6),
        },
      ],
      _0x4537e2 = [
        {
          id: 0x0,
          icon: _0x157421(0x1e3),
          name: _0x157421(0x318),
          upgrade: 0x3,
          aim: 0x0,
          force: 0x0,
          time: 0x0,
          upgrades: [0x0, 0x1, 0x2],
        },
        {
          id: 0x1,
          icon: "strike_01",
          name: _0x157421(0x15f),
          upgrade: 0x3,
          aim: 0x1,
          force: 0x1,
          time: 0x0,
          upgrades: [0x2, 0x0, 0x1],
        },
        {
          id: 0x2,
          icon: _0x157421(0x24c),
          name: _0x157421(0x48a),
          upgrade: 0x3,
          aim: 0x1,
          force: 0x2,
          time: 0x1,
          upgrades: [0x2, 0x0, 0x1],
        },
        {
          id: 0x3,
          icon: _0x157421(0x276),
          name: _0x157421(0x3b6),
          upgrade: 0x4,
          aim: 0x2,
          force: 0x1,
          time: 0x2,
          upgrades: [0x0, 0x1, 0x2, 0x1],
        },
        {
          id: 0x4,
          icon: _0x157421(0x371),
          name: "VIOLET\x0aNIGHT",
          upgrade: 0x4,
          aim: 0x2,
          force: 0x2,
          time: 0x1,
          upgrades: [0x2, 0x0, 0x1, 0x2],
        },
        {
          id: 0x5,
          icon: _0x157421(0x459),
          name: _0x157421(0x3fb),
          upgrade: 0x4,
          aim: 0x2,
          force: 0x3,
          time: 0x1,
          upgrades: [0x2, 0x2, 0x0, 0x1],
        },
        {
          id: 0x6,
          icon: _0x157421(0xfb),
          name: _0x157421(0x308),
          upgrade: 0x5,
          aim: 0x3,
          force: 0x2,
          time: 0x3,
          upgrades: [0x1, 0x0, 0x2, 0x0, 0x2],
        },
        {
          id: 0x7,
          icon: _0x157421(0x3ab),
          name: _0x157421(0x2e0),
          upgrade: 0x5,
          aim: 0x4,
          force: 0x3,
          time: 0x3,
          upgrades: [0x1, 0x2, 0x0, 0x1, 0x2],
        },
        {
          id: 0x8,
          icon: _0x157421(0x13c),
          name: "RUBY\x0aROSE",
          upgrade: 0x3,
          aim: 0x4,
          force: 0x4,
          time: 0x4,
          upgrades: [0x1, 0x2, 0x0],
        },
      ],
      _0x4cd129 = [
        { id: 0x0, icon: _0x157421(0x2e4), name: _0x157421(0x318) },
        { id: 0x1, icon: _0x157421(0x1d8), name: _0x157421(0x15f) },
        { id: 0x2, icon: _0x157421(0x28f), name: _0x157421(0x48a) },
        { id: 0x3, icon: _0x157421(0x120), name: "EMERALD\x0aLOTUS" },
        { id: 0x4, icon: _0x157421(0x338), name: _0x157421(0x1ff) },
        { id: 0x5, icon: _0x157421(0x351), name: _0x157421(0x3fb) },
        { id: 0x6, icon: _0x157421(0x3e1), name: _0x157421(0x3fb) },
        { id: 0x7, icon: _0x157421(0x1eb), name: _0x157421(0x3fb) },
        { id: 0x8, icon: _0x157421(0x1b5), name: _0x157421(0x3fb) },
      ],
      _0x427440 = [
        { id: 0x0, texture: _0x157421(0x1e3) },
        { id: 0x1, texture: _0x157421(0x228) },
        { id: 0x2, texture: _0x157421(0x24c) },
        { id: 0x3, texture: _0x157421(0x276) },
        { id: 0x4, texture: _0x157421(0x371) },
        { id: 0x5, texture: _0x157421(0x459) },
        { id: 0x6, texture: _0x157421(0xfb) },
        { id: 0x7, texture: _0x157421(0x3ab) },
        { id: 0x8, texture: "strike_09" },
      ],
      _0x429ae3 = 0x1f4 - 0x27c / 0x2 + 0x73 + 0x7c,
      _0x55e1a0 = 0xa2,
      _0x187453 = 0xa2 + 0x141,
      _0x3ce1ab = 0xf,
      _0x133600 = 0x22 * 0.8 * 0.8,
      _0x5ccc96 = 0.5,
      _0x541423 = 0x64,
      _0xedead0 = 0xa;
    var _0x647bf3 = 0x96;
    const _0x301cde = 0x64,
      _0x4efd2a = { x: 0x13d, y: 0x13d },
      _0x1a9f0e = [
        { x: 0x13d, y: 0xfb },
        { x: 0xff, y: 0x11a },
        { x: 0x17b, y: 0x11a },
        { x: 0x11e, y: 0x12b },
        { x: 0x15c, y: 0x12b },
        { x: 0xff, y: 0x15e },
        { x: 0x13d, y: 0x15e },
        { x: 0x17b, y: 0x15e },
        { x: 0x13d, y: 0x17f },
      ],
      _0x45677e = [
        { x: 0x11e, y: 0x10b },
        { x: 0x15c, y: 0x10b },
        { x: 0x13d, y: 0x11c },
        { x: 0xff, y: 0x13b },
        { x: 0x17b, y: 0x13b },
        { x: 0x11e, y: 0x14d },
        { x: 0x15c, y: 0x14d },
        { x: 0x11e, y: 0x16e },
        { x: 0x15c, y: 0x16d },
      ],
      _0x2fc10d = [
        {
          x: 0x140 - 0x276 / 0x2 + 0x1a + 0x1e,
          y: 0x1f4 - 0x27c / 0x2 + 0x1a + 0x1e + 0x7c,
        },
        {
          x: 0x140 - 0x276 / 0x2 + 0x276 - 0x1a - 0x1e,
          y: 0x1f4 - 0x27c / 0x2 + 0x1a + 0x1e + 0x7c,
        },
        {
          x: 0x140 - 0x276 / 0x2 + 0x1a + 0x1e,
          y: 0x1f4 - 0x27c / 0x2 + 0x27c - 0x1a - 0x1e + 0x7c,
        },
        {
          x: 0x140 - 0x276 / 0x2 + 0x276 - 0x1a - 0x1e,
          y: 0x1f4 - 0x27c / 0x2 + 0x27c - 0x1a - 0x1e + 0x7c,
        },
      ];
    var _0x111100,
      _0x30b44c = _0x157421(0x131),
      _0x270daf = !![];
    function _0xc37276() {
      var _0x148317 = _0x157421;
      ((window[_0x148317(0x1c3)] = window[_0x148317(0x1c3)] || _0x434610),
        _0xa07a9b(),
        _0x358d16());
      if (_0x30b44c in document)
        document[_0x148317(0x4b3)](_0x148317(0x2e2), _0x4ad106);
      else {
        if ((_0x30b44c = _0x148317(0x464)) in document)
          document[_0x148317(0x4b3)](_0x148317(0x31e), _0x4ad106);
        else {
          if ((_0x30b44c = _0x148317(0x2f8)) in document)
            document[_0x148317(0x4b3)]("webkitvisibilitychange", _0x4ad106);
          else {
            if ((_0x30b44c = "msHidden") in document)
              document[_0x148317(0x4b3)](_0x148317(0x241), _0x4ad106);
            else {
              if (_0x148317(0x3f7) in document)
                document[_0x148317(0x3f7)] = document[_0x148317(0x33c)] =
                  _0x4ad106;
              else
                window[_0x148317(0x341)] =
                  window[_0x148317(0x1f0)] =
                  window[_0x148317(0x31c)] =
                  window[_0x148317(0x45f)] =
                    _0x4ad106;
            }
          }
        }
      }
      if (document[_0x30b44c] !== undefined)
        _0x4ad106({
          type: document[_0x30b44c] ? _0x148317(0x26b) : _0x148317(0x14d),
        });
    }
    function _0xa07a9b() {
      var _0x1fbd44 = _0x157421;
      ((_0x423f7f = new PIXI[_0x1fbd44(0x106)](_0x5568a2, _0x27ae22, {
        roundPixels: ![],
        resolution: 0x1,
        sharedTicker: !![],
        antialias: ![],
        transparent: !![],
      })),
        document[_0x1fbd44(0x1e9)]("gm4html5_div_id")[_0x1fbd44(0x1cb)](
          _0x423f7f["view"],
        ),
        (_0x423f7f[_0x1fbd44(0x378)][_0x1fbd44(0x19a)][_0x1fbd44(0x11c)][
          _0x1fbd44(0x100)
        ] = !![]),
        (_0x423f7f["ticker"][_0x1fbd44(0x3f2)] = ![]),
        _0x423f7f[_0x1fbd44(0x215)]["stop"](),
        _0x423f7f[_0x1fbd44(0x215)][_0x1fbd44(0x3d7)](_0x4bf21a),
        _0x4bf9dd(),
        (_0x25199a = new PIXI[_0x1fbd44(0x30a)]()),
        (_0x25199a["x"] = _0x24b13c / 0x2),
        (_0x25199a["y"] = _0x376ce3 / 0x2),
        _0x423f7f["stage"]["addChild"](_0x25199a));
      if (_carromHostPaused && _0x423f7f.view && _0x423f7f.view.style) {
        _carromHostPointerEvents = _0x423f7f.view.style.pointerEvents;
        _0x423f7f.view.style.pointerEvents = 'none';
      }
      var _0x5aa977 = PIXI[_0x1fbd44(0x385)][_0x1fbd44(0x3ec)](
        _0x1fbd44(0x3be),
      );
      ((_0x5aa977["anchor"]["x"] = 0.5),
        (_0x5aa977[_0x1fbd44(0x4a1)]["y"] = 0.5),
        (_0x5aa977["x"] = 0x140),
        (_0x5aa977["y"] = 0x10e),
        _0x25199a[_0x1fbd44(0x37b)](_0x5aa977),
        (_0x25199a[_0x1fbd44(0x180)] = PIXI[_0x1fbd44(0x385)][_0x1fbd44(0x3ec)](
          _0x1fbd44(0x41e),
        )),
        (_0x25199a[_0x1fbd44(0x180)]["x"] = 0x140 - 0x1a9 / 0x2),
        (_0x25199a[_0x1fbd44(0x180)]["width"] = 0x1),
        (_0x25199a["full"][_0x1fbd44(0x21c)] = 0x39),
        (_0x25199a["full"]["y"] =
          (0x320 / _0x27ae22) * (_0x27ae22 + _0x376ce3) - _0x376ce3 / 0x2),
        (_0x25199a["empty"] = PIXI[_0x1fbd44(0x385)]["fromImage"](
          "assets/preloader/loading_bar_base.png",
        )),
        (_0x25199a[_0x1fbd44(0x3a3)]["x"] = 0x140 - 0x1a9 / 0x2 - 0x14),
        (_0x25199a[_0x1fbd44(0x3a3)]["y"] =
          (0x320 / _0x27ae22) * (_0x27ae22 + _0x376ce3) -
          _0x376ce3 / 0x2 -
          0x12),
        _0x25199a[_0x1fbd44(0x37b)](_0x25199a[_0x1fbd44(0x180)]),
        _0x25199a[_0x1fbd44(0x37b)](_0x25199a[_0x1fbd44(0x3a3)]),
        _0x423f7f[_0x1fbd44(0x2c6)]());
    }
    function _0x358d16() {
      var _0x166567 = _0x157421;
      (_0x28fba8[_0x166567(0x314)](
        _0x166567(0x125),
        new Howl({
          src: [_0x166567(0x1db)],
          loop: !![],
          volume: 0.9,
          mute: !![],
        }),
        "Music",
      ),
        _0x28fba8[_0x166567(0x314)](
          "bigwin_a",
          new Howl({ src: [_0x166567(0x4c0)], volume: 0.5, mute: !![] }),
          "SFX",
        ),
        _0x28fba8["register"](
          "bigwin_b",
          new Howl({ src: [_0x166567(0x243)], volume: 0.5, mute: !![] }),
          _0x166567(0x285),
        ),
        _0x28fba8[_0x166567(0x314)](
          _0x166567(0x138),
          new Howl({ src: [_0x166567(0x29d)], volume: 0.3, mute: !![] }),
          _0x166567(0x285),
        ),
        _0x28fba8[_0x166567(0x314)](
          "ballstrike",
          new Howl({ src: [_0x166567(0x18d)], volume: 0x1, mute: !![] }),
          _0x166567(0x285),
        ),
        _0x28fba8[_0x166567(0x314)](
          "cast",
          new Howl({
            src: ["assets/sounds/cast.mp3"],
            volume: 0x1,
            mute: !![],
          }),
          _0x166567(0x285),
        ),
        _0x28fba8[_0x166567(0x314)](
          "Stone_Hit_1",
          new Howl({ src: [_0x166567(0x3dd)], volume: 0x1, mute: !![] }),
          _0x166567(0x285),
        ),
        _0x28fba8[_0x166567(0x314)](
          "Stone_Hit_2",
          new Howl({ src: [_0x166567(0x40d)], volume: 0x1, mute: !![] }),
          _0x166567(0x285),
        ),
        _0x28fba8[_0x166567(0x314)](
          _0x166567(0x1c1),
          new Howl({ src: [_0x166567(0x436)], volume: 0x1, mute: !![] }),
          _0x166567(0x285),
        ),
        _0x28fba8[_0x166567(0x314)](
          _0x166567(0x2b7),
          new Howl({ src: [_0x166567(0x45e)], volume: 0.5, mute: !![] }),
          _0x166567(0x285),
        ),
        _0x28fba8["register"](
          "RailHit05",
          new Howl({ src: [_0x166567(0x24b)], volume: 0.5, mute: !![] }),
          _0x166567(0x285),
        ),
        _0x28fba8[_0x166567(0x314)](
          _0x166567(0x29e),
          new Howl({ src: ["assets/sounds/pot.mp3"], volume: 0.5, mute: !![] }),
          _0x166567(0x285),
        ),
        _0x28fba8[_0x166567(0x314)](
          "puck",
          new Howl({ src: [_0x166567(0x440)], volume: 0.5, mute: !![] }),
          _0x166567(0x285),
        ),
        _0x28fba8[_0x166567(0x314)](
          "tap_wood5",
          new Howl({ src: [_0x166567(0x4c9)], volume: 0x1, mute: !![] }),
          _0x166567(0x285),
        ),
        _0x28fba8[_0x166567(0x314)](
          _0x166567(0x1a9),
          new Howl({ src: [_0x166567(0x2e7)], volume: 0x1, mute: !![] }),
          _0x166567(0x285),
        ),
        _0x28fba8["register"](
          "spin",
          new Howl({
            src: ["assets/sounds/wheel.mp3"],
            rate: 0.75,
            volume: 0x1,
            mute: !![],
          }),
          _0x166567(0x285),
        ),
        _0x28fba8[_0x166567(0x314)](
          _0x166567(0x21a),
          new Howl({ src: [_0x166567(0x330)], volume: 0x1, mute: !![] }),
          "SFX",
        ),
        _0x28fba8[_0x166567(0x314)](
          _0x166567(0x450),
          new Howl({
            src: ["assets/sounds/Purchase.mp3"],
            volume: 0x1,
            mute: !![],
          }),
          _0x166567(0x285),
        ),
        _0x28fba8[_0x166567(0x314)](
          _0x166567(0x1c5),
          new Howl({
            src: ["assets/sounds/lose.mp3"],
            volume: 0x1,
            mute: !![],
          }),
          _0x166567(0x285),
        ),
        _0x28fba8[_0x166567(0x314)](
          _0x166567(0x49c),
          new Howl({ src: [_0x166567(0x23d)], volume: 0x1, mute: !![] }),
          _0x166567(0x285),
        ));
      for (var _0x35ec1b in src["bitmaps"]) {
        PIXI[_0x166567(0x27d)][_0x166567(0x3d7)](
          _0x35ec1b,
          src["bitmaps"][_0x35ec1b],
        );
      }
      (PIXI[_0x166567(0x27d)]["on"](_0x166567(0x2f7), _0x18076e),
        PIXI[_0x166567(0x27d)][_0x166567(0x1e0)](_0x16b945));
    }
    function _carromConnectLifecycle() {
      try {
        var hostGame = typeof GameSnacks !== 'undefined' && GameSnacks.game;
        if (!hostGame) return;
        if (!_carromPauseRegistered && typeof hostGame.onPause === 'function') {
          hostGame.onPause(_0x125d76.pause);
          _carromPauseRegistered = true;
        }
        if (!_carromResumeRegistered && typeof hostGame.onResume === 'function') {
          hostGame.onResume(_0x125d76.resume);
          _carromResumeRegistered = true;
        }
      } catch (_) { console.warn('Carrom host lifecycle registration failed'); }
    }
    function _0x3690db() {
      var _0x3bdcb6 = _0x157421;
      _carromConnectLifecycle();
      (_0x5ecd40(),
        _0xf8ddc7(),
        _0x1d7cac(),
        window["addEventListener"](_0x3bdcb6(0x366), function (_0x16c2cc) {
          var _0x5f1894 = _0x3bdcb6;
          (_0x4bf9dd(),
            (_0xcf7ce5["x"] = _0x24b13c / 0x2),
            (_0xcf7ce5["y"] = _0x376ce3 / 0x2),
            _0x21a97b[_0x5f1894(0x29f)](),
            _0x21a97b[_0x5f1894(0x339)](0x0, 0.7),
            _0x21a97b[_0x5f1894(0x26a)](
              0x0,
              0x0,
              _0x5568a2 + _0x24b13c,
              _0x27ae22 + _0x376ce3,
            ),
            (_0x21a97b["x"] = -_0x24b13c / 0x2),
            (_0x21a97b["y"] = -_0x376ce3 / 0x2),
            _0x4149a7[_0x5f1894(0x29f)](),
            _0x4149a7[_0x5f1894(0x339)](0x0, 0.8),
            _0x4149a7[_0x5f1894(0x26a)](
              0x0,
              0x0,
              _0x5568a2 + _0x24b13c,
              _0x27ae22 + _0x376ce3,
            ),
            (_0x50d6f7["x"] = _0x24b13c / 0x2),
            (_0x50d6f7["y"] = _0x376ce3 / 0x2),
            (_0x5484bf["x"] = _0x24b13c / 0x2),
            (_0x5484bf["y"] = _0x376ce3 / 0x2),
            (_0x4865ce["x"] = _0x24b13c / 0x2),
            (_0x4865ce["y"] = _0x376ce3 / 0x2),
            (_0x429f89["x"] = _0x24b13c / 0x2),
            (_0x429f89["y"] = _0x376ce3 / 0x2));
        }),
        GameSnacks[_0x3bdcb6(0x394)][_0x3bdcb6(0x4c7)]((_0x273535) => {
          (_0x273535 ? (_0x7fd997 = ![]) : (_0x7fd997 = !![]), _0x522c35());
        }),
        (_0x7fd997 = !GameSnacks["audio"][_0x3bdcb6(0x41c)]()),
        _0x522c35(),
        _0x28fba8["unmuteGroup"]("SFX"),
        _0x28fba8[_0x3bdcb6(0x302)](_0x3bdcb6(0x278)));
    }
    function _0x5ecd40() {
      var _0x1a5cb0 = _0x157421;
      for (let _0x114e8d in _0x23207e) {
        try {
          let _0x3b80f0 =
            GameSnacks[_0x1a5cb0(0x3e5)][_0x1a5cb0(0x492)](_0x114e8d);
          if (_0x3b80f0) {
            _0x23207e[_0x114e8d] = window.CarromLocalSave.recover(
              _0x3b80f0, _0x23207e[_0x114e8d], _0x114e8d,
              _0x114e8d === 'upgrades' ? _0x4537e2.map(function (item) { return item.upgrade; }) : undefined,
            );
          }
        } catch (_0xsaveReadError) {
          console.warn('Carrom save read failed:', _0x114e8d);
        }
      }
      _0x13b722();
    }
    function _0x13b722() {
      var _0x7b53ab = _0x157421;
      ((_0xa07851 = _0x23207e[_0x7b53ab(0x465)]),
        (_0x183856 = _0x23207e[_0x7b53ab(0x24d)]),
        (_0x6d1a83 = Number(_0x23207e["lastRewardTime"])));
      for (
        let _0x5a558a = 0x0;
        _0x5a558a < _0x23207e["tables"][_0x7b53ab(0x182)];
        _0x5a558a++
      )
        _0x2e2e88[_0x5a558a] = _0x23207e[_0x7b53ab(0x4bf)][_0x5a558a];
      for (
        let _0x42125d = 0x0;
        _0x42125d < _0x23207e[_0x7b53ab(0x315)][_0x7b53ab(0x182)];
        _0x42125d++
      ) {
        _0x57e1d2[_0x42125d]["upgrade"] = Number(
          _0x23207e[_0x7b53ab(0x315)][_0x42125d],
        );
      }
      for (
        let _0x2e66eb = 0x0;
        _0x2e66eb < _0x23207e[_0x7b53ab(0x412)][_0x7b53ab(0x182)];
        _0x2e66eb++
      ) {
        (_0x23207e[_0x7b53ab(0x412)][_0x2e66eb] == _0x7b53ab(0x16d) &&
          (_0x4b3012 = _0x2e66eb),
          (_0x57e1d2[_0x2e66eb]["state"] = _0x23207e["strikers"][_0x2e66eb]));
      }
      for (
        let _0x54f03b = 0x0;
        _0x54f03b < _0x23207e["stones"][_0x7b53ab(0x182)];
        _0x54f03b++
      ) {
        (_0x23207e[_0x7b53ab(0x33a)][_0x54f03b] == _0x7b53ab(0x16d) &&
          (_0x3e9ee1 = _0x54f03b),
          (_0x75fa36[_0x54f03b][_0x7b53ab(0x43f)] =
            _0x23207e[_0x7b53ab(0x33a)][_0x54f03b]));
      }
    }
    function _0x9b0cd() {
      var _0x9b4c5 = _0x157421;
      ((_0x23207e[_0x9b4c5(0x465)] = _0xa07851),
        (_0x23207e[_0x9b4c5(0x24d)] = _0x183856),
        (_0x23207e[_0x9b4c5(0x2ee)] = _0x6d1a83));
      for (let _0x105684 = 0x0; _0x105684 < _0x2e2e88["length"]; _0x105684++)
        _0x23207e[_0x9b4c5(0x4bf)][_0x105684] = _0x2e2e88[_0x105684];
      for (
        let _0x243a0f = 0x0;
        _0x243a0f < _0x57e1d2[_0x9b4c5(0x182)];
        _0x243a0f++
      ) {
        ((_0x23207e["strikers"][_0x243a0f] = _0x57e1d2[_0x243a0f]["state"]),
          (_0x23207e[_0x9b4c5(0x315)][_0x243a0f] =
            _0x57e1d2[_0x243a0f][_0x9b4c5(0x1ea)]));
      }
      for (
        let _0x4179d9 = 0x0;
        _0x4179d9 < _0x75fa36[_0x9b4c5(0x182)];
        _0x4179d9++
      )
        _0x23207e[_0x9b4c5(0x33a)][_0x4179d9] =
          _0x75fa36[_0x4179d9][_0x9b4c5(0x43f)];
    }
    function _0x3a0318() {
      var _0x1a3450 = _0x157421;
      _0x9b0cd();
      for (let _0x2f6f95 in _0x23207e) {
        GameSnacks[_0x1a3450(0x3e5)][_0x1a3450(0x1cc)](
          _0x2f6f95,
          JSON[_0x1a3450(0x23a)](_0x23207e[_0x2f6f95]),
        );
      }
    }
    function _carromSyncMute() {
      if (typeof Howler !== 'undefined' && typeof Howler.mute === 'function')
        Howler.mute(!!(_0x7fd997 || !_0x270daf || _carromHostPaused || _carromAdTokens.length));
    }
    function _0x522c35() {
      var _0x157233 = _0x157421;
      (_carromSyncMute(),
        _0x178e84 && _0x178e84[_0x157233(0x198)](_0x7fd997));
    }
    function _0x4ad106(_0x16169d) {
      var _0x4245da = _0x157421;
      if (_0x111100)
        _0x111100[_0x4245da(0x1aa)] =
          _0x111100[_0x4245da(0x1aa)] + _0x4245da(0x425);
      let _0x2a834f = ![],
        _0x50fd60 = !![],
        _0x17cdfc = {
          focus: _0x2a834f,
          focusin: _0x2a834f,
          pageshow: _0x2a834f,
          blur: _0x50fd60,
          focusout: _0x50fd60,
          pagehide: _0x50fd60,
        };
      _0x16169d = _0x16169d || window["event"];
      let _0x19e4c7 = ![];
      _0x16169d[_0x4245da(0x12e)] in _0x17cdfc
        ? (_0x19e4c7 = _0x17cdfc[_0x16169d[_0x4245da(0x12e)]])
        : (_0x19e4c7 = this[_0x30b44c]);
      if (_0x19e4c7) ((_0x270daf = ![]), _0x522c35());
      else {
        if (!_0x270daf && _0x3fddb3) _0x5e0129();
        ((_0x270daf = !![]), _0x522c35());
      }
    }
    function _0x4bf9dd() {
      var _0x262b7b = _0x157421,
        _0x28fed6 = document["getElementById"](_0x262b7b(0x45a)),
        _0x3adfde = window["innerWidth"] / _0x5568a2,
        _0x3e82d6 = window[_0x262b7b(0x429)] / _0x27ae22;
      let _0x3cc125 = 0x1,
        _0x33d83e = 0x0,
        _0x4c735b = 0x0;
      var _0x6630d0 = 0x0,
        _0x328876 = 0x0;
      if (_0x3adfde < _0x3e82d6) {
        ((_0x6630d0 = _0x5568a2 * _0x3adfde),
          (_0x328876 = _0x27ae22 * _0x3adfde),
          (_0x3cc125 = _0x3adfde),
          (_0x33d83e = 0x0),
          (_0x4c735b = (window["innerHeight"] - _0x328876) / _0x3cc125));
      } else
        ((_0x6630d0 = _0x5568a2 * _0x3e82d6),
          (_0x328876 = _0x27ae22 * _0x3e82d6),
          (_0x3cc125 = _0x3e82d6),
          (_0x33d83e = (window[_0x262b7b(0x323)] - _0x6630d0) / _0x3cc125),
          (_0x4c735b = 0x0));
      ((_0x33d83e = Math[_0x262b7b(0x11d)](Math["min"](_0x33d83e, 0xd5), 0x0)),
        (_0x4c735b = Math[_0x262b7b(0x11d)](_0x4c735b, 0x0)),
        (_0x28fed6[_0x262b7b(0x298)]["width"] = _0x262b7b(0x1ae)),
        (_0x28fed6["style"]["height"] = _0x262b7b(0x1ae)),
        _0x423f7f[_0x262b7b(0x378)]["resize"](
          _0x5568a2 + _0x33d83e,
          _0x27ae22 + _0x4c735b,
        ),
        (_0x423f7f[_0x262b7b(0x1d7)][_0x262b7b(0x298)][_0x262b7b(0xfd)] =
          _0x6630d0 + _0x33d83e * _0x3cc125 + "px"),
        (_0x423f7f["view"][_0x262b7b(0x298)][_0x262b7b(0x21c)] =
          _0x328876 + _0x4c735b * _0x3cc125 + "px"),
        _0x33d83e &&
          ((_0x423f7f["view"][_0x262b7b(0x298)][_0x262b7b(0x361)] =
            (window[_0x262b7b(0x323)] - (_0x6630d0 + _0x33d83e * _0x3cc125)) /
              0x2 +
            "px"),
          (_0x423f7f["view"]["style"][_0x262b7b(0x25c)] = _0x262b7b(0x45b)),
          (_0x24b13c = _0x33d83e),
          (_0x376ce3 = 0x0)),
        _0x4c735b &&
          ((_0x423f7f["view"][_0x262b7b(0x298)][_0x262b7b(0x361)] =
            _0x262b7b(0x45b)),
          (_0x423f7f[_0x262b7b(0x1d7)][_0x262b7b(0x298)][_0x262b7b(0x25c)] =
            (window[_0x262b7b(0x429)] - (_0x328876 + _0x4c735b * _0x3cc125)) /
              0x2 +
            "px"),
          (_0x24b13c = 0x0),
          (_0x376ce3 = _0x4c735b)));
    }
    function _0x3b4d9f() {
      var _0x21b428 = _0x157421,
        _0x18c476 = document[_0x21b428(0x1e9)](_0x21b428(0x45a)),
        _0x211d20 = _0x5568a2 + _0x24b13c,
        _0x3113ba = _0x27ae22 + _0x376ce3,
        _0x52ab8a = window[_0x21b428(0x323)] / _0x211d20,
        _0x186e35 = window[_0x21b428(0x429)] / _0x3113ba,
        _0x381d5b = 0x0,
        _0x1babd7 = 0x0;
      (_0x52ab8a < _0x186e35
        ? ((_0x381d5b = _0x211d20 * _0x52ab8a),
          (_0x1babd7 = _0x3113ba * _0x52ab8a))
        : ((_0x381d5b = _0x211d20 * _0x186e35),
          (_0x1babd7 = _0x3113ba * _0x186e35)),
        window["innerWidth"] > _0x381d5b
          ? (_0x18c476["style"]["left"] =
              (window[_0x21b428(0x323)] - _0x381d5b) / 0x2 + "px")
          : (_0x18c476[_0x21b428(0x298)]["left"] = _0x21b428(0x45b)),
        window[_0x21b428(0x429)] > _0x1babd7
          ? (_0x18c476[_0x21b428(0x298)][_0x21b428(0x3c7)] =
              (window["innerHeight"] - _0x1babd7) / 0x2 + "px")
          : (_0x18c476[_0x21b428(0x298)][_0x21b428(0x3c7)] = _0x21b428(0x45b)),
        (_0x18c476[_0x21b428(0x298)][_0x21b428(0xfd)] = _0x381d5b + "px"),
        (_0x18c476[_0x21b428(0x298)][_0x21b428(0x21c)] = _0x1babd7 + "px"),
        (_0x423f7f["view"][_0x21b428(0x298)][_0x21b428(0xfd)] =
          _0x381d5b + "px"),
        (_0x423f7f[_0x21b428(0x1d7)][_0x21b428(0x298)][_0x21b428(0x21c)] =
          _0x1babd7 + "px"));
    }
    function _0xf8ddc7(_0x1c8aef) {
      var _0x574bce = _0x157421;
      _0x2e33a4();
      for (var _0x16287a in src[_0x574bce(0x2cb)]) {
        var _0x4cc6fd = PIXI[_0x574bce(0x36e)](
          src[_0x574bce(0x2cb)][_0x16287a],
        );
        _0xbf118[_0x16287a] = _0x4cc6fd;
      }
      ((_0x1392b5 = new box2d["World"](
        new box2d[_0x574bce(0x462)](0x0, 0x0),
        ![],
      )),
        _0x1392b5["on"](_0x574bce(0x230), function (_0x15f0ca) {
          var _0x85bd83 = _0x574bce,
            _0x554f99 = _0x15f0ca[_0x85bd83(0x386)](),
            _0x2310ab = _0x15f0ca["getFixtureB"](),
            _0x354eea = _0x554f99["getBody"](),
            _0x1fa821 = _0x2310ab["getBody"]();
          if (_0x354eea[_0x85bd83(0x343)] && _0x1fa821[_0x85bd83(0x343)]) {
            let _0x50802f = _0x354eea[_0x85bd83(0x128)](),
              _0xf3021f = _0x1fa821[_0x85bd83(0x128)](),
              _0x4c2add =
                Math[_0x85bd83(0x322)](_0x50802f["x"]) +
                Math[_0x85bd83(0x322)](_0x50802f["y"]) +
                Math[_0x85bd83(0x322)](_0xf3021f["x"]) +
                Math[_0x85bd83(0x322)](_0xf3021f["y"]),
              _0x223857 = Math["min"](_0x4c2add / 0x14, 0x1),
              _0x1ffaf7 = _0x354eea[_0x85bd83(0x46a)](),
              _0x5acdfd = _0x1fa821[_0x85bd83(0x46a)](),
              _0x342fe0 = _0x8b2762(_0x1ffaf7, _0x5acdfd);
            _0x354eea[_0x85bd83(0x343)] == "puck" &&
              Tweener[_0x85bd83(0x3a0)](
                { value: 1.5 },
                { value: 0x4 },
                {
                  time: 0x64,
                  onUpdate: function (_0x3576aa) {
                    var _0x3ca32e = _0x85bd83;
                    _0x1fa821[_0x3ca32e(0xd1)](_0x3576aa[_0x3ca32e(0x4b7)]);
                  },
                },
              );
            _0x1fa821[_0x85bd83(0x343)] == "puck" &&
              Tweener[_0x85bd83(0x3a0)](
                { value: 1.5 },
                { value: 0x4 },
                {
                  time: 0x64,
                  onUpdate: function (_0x11a28a) {
                    _0x1fa821["setLinearDamping"](_0x11a28a["value"]);
                  },
                },
              );
            if (_0x223857 > 0.05) {
              if (
                _0x354eea["objectType"] == _0x85bd83(0x1e4) ||
                _0x1fa821[_0x85bd83(0x343)] == "edge"
              )
                _0x28fba8[_0x85bd83(0x383)](_0x85bd83(0x499), _0x223857);
              else {
                if (
                  _0x354eea["objectType"] == _0x85bd83(0x38a) ||
                  _0x1fa821[_0x85bd83(0x343)] == _0x85bd83(0x38a)
                ) {
                  _0x28fba8["play"](_0x85bd83(0x312), _0x223857);
                  if (_0x223857 > 0.5)
                    _0x4afbdc(
                      _0x1ffaf7["x"] * _0x541423 +
                        Math["cos"](_0x342fe0) * _0x3ce1ab,
                      _0x1ffaf7["y"] * _0x541423 +
                        Math[_0x85bd83(0x1c8)](_0x342fe0) * _0x3ce1ab,
                      _0x342fe0,
                    );
                } else {
                  _0x28fba8[_0x85bd83(0x383)](_0x85bd83(0x1a0), _0x223857);
                  if (_0x223857 > 0.5)
                    _0x4afbdc(
                      _0x1ffaf7["x"] * _0x541423 +
                        Math[_0x85bd83(0x430)](_0x342fe0) * _0x3ce1ab,
                      _0x1ffaf7["y"] * _0x541423 +
                        Math[_0x85bd83(0x1c8)](_0x342fe0) * _0x3ce1ab,
                      _0x342fe0,
                    );
                }
              }
            }
          }
        }),
        (_0xcf7ce5 = new _0x568fe1()),
        (_0xcf7ce5["x"] = _0x24b13c / 0x2),
        (_0xcf7ce5["y"] = _0x376ce3 / 0x2),
        _0x423f7f[_0x574bce(0x4cc)][_0x574bce(0x37b)](_0xcf7ce5),
        (_0x2b986d = PIXI["Sprite"][_0x574bce(0x348)](_0x574bce(0x1b2))),
        _0x2b986d["anchor"]["set"](0.5),
        (_0x2b986d["x"] = 0x140),
        (_0x2b986d["y"] = _0x27ae22 / 0x2),
        _0xcf7ce5[_0x574bce(0x37b)](_0x2b986d),
        (_0x5ccb1e = PIXI["Sprite"][_0x574bce(0x348)](_0x574bce(0x3e3))),
        _0x5ccb1e[_0x574bce(0x4a1)][_0x574bce(0x27e)](0.5),
        (_0x5ccb1e["x"] = 0x140),
        (_0x5ccb1e["y"] = 0x82),
        _0xcf7ce5[_0x574bce(0x37b)](_0x5ccb1e),
        (_0x5b3bc4 = PIXI[_0x574bce(0x385)][_0x574bce(0x348)](
          _0x574bce(0x134),
        )),
        _0x5b3bc4[_0x574bce(0x4a1)]["set"](0.5),
        (_0x5b3bc4["x"] = 0x50),
        (_0x5b3bc4["y"] = 0x28),
        _0xcf7ce5[_0x574bce(0x37b)](_0x5b3bc4),
        (_0xa07680 = new _0x378a7c()),
        (_0xa07680["x"] = 0x140),
        (_0xa07680["y"] = 0xf0),
        _0xcf7ce5["addChild"](_0xa07680),
        (_0xa07680["value"] = 0x3e8),
        (_0x310e61 = new PIXI["BitmapText"](_0x574bce(0x3ac), {
          font: _0x574bce(0x422),
          fill: 0xffffff,
          align: _0x574bce(0x221),
        })),
        _0x310e61[_0x574bce(0x4a1)][_0x574bce(0x27e)](0.5),
        (_0x310e61["x"] = 0x50),
        (_0x310e61["y"] = 0x73),
        _0xcf7ce5["addChild"](_0x310e61),
        (_0x2cf38a = new _0x3020e6(0x0)),
        _0x2cf38a[_0x574bce(0x231)][_0x574bce(0x27e)](0.85),
        (_0x2cf38a["x"] = 0x50),
        (_0x2cf38a["y"] = 0xb9),
        _0xcf7ce5[_0x574bce(0x37b)](_0x2cf38a));
      var _0x44982f = new _0x483e8b();
      (_0x44982f["scale"][_0x574bce(0x27e)](0.9),
        (_0x44982f["x"] = 0x50),
        (_0x44982f["y"] = 0xb9),
        _0xcf7ce5[_0x574bce(0x37b)](_0x44982f),
        (_0x2cf38a[_0x574bce(0x39a)] = _0x44982f),
        (_0x539ff8 = new _0x133fee(_0x574bce(0x486))),
        (_0x539ff8["x"] = 0x2d),
        (_0x539ff8["y"] = 0x109),
        _0xcf7ce5["addChild"](_0x539ff8),
        (_0x539ff8["visible"] = ![]),
        (_0x27ee82 = new _0x1eceb4(0x78)),
        (_0x27ee82["x"] = 0x41),
        (_0x27ee82["y"] = 0x109),
        _0xcf7ce5[_0x574bce(0x37b)](_0x27ee82),
        (_0x28036b = new PIXI["BitmapText"](_0x574bce(0x423), {
          font: "22px\x20Simonetta_white2",
          fill: 0xffffff,
          align: _0x574bce(0x221),
        })),
        _0x28036b[_0x574bce(0x4a1)]["set"](0.5),
        (_0x28036b["x"] = 0x230),
        (_0x28036b["y"] = 0x73),
        _0xcf7ce5[_0x574bce(0x37b)](_0x28036b),
        (_0x44d1ad = new _0x3020e6(0x1)),
        _0x44d1ad[_0x574bce(0x231)][_0x574bce(0x27e)](0.85),
        (_0x44d1ad["x"] = 0x230),
        (_0x44d1ad["y"] = 0xb9),
        _0xcf7ce5[_0x574bce(0x37b)](_0x44d1ad));
      var _0xa32e35 = new _0x483e8b();
      (_0xa32e35[_0x574bce(0x231)][_0x574bce(0x27e)](0.9),
        (_0xa32e35["x"] = 0x230),
        (_0xa32e35["y"] = 0xb9),
        _0xcf7ce5[_0x574bce(0x37b)](_0xa32e35),
        (_0x44d1ad[_0x574bce(0x39a)] = _0xa32e35),
        (_0x25b85f = new _0x133fee(_0x574bce(0x467))),
        (_0x25b85f["x"] = 0x20d),
        (_0x25b85f["y"] = 0x109),
        _0xcf7ce5[_0x574bce(0x37b)](_0x25b85f),
        (_0x25b85f[_0x574bce(0x197)] = ![]),
        (_0x458adc = new _0x1eceb4(0x78)),
        (_0x458adc["x"] = 0x221),
        (_0x458adc["y"] = 0x109),
        _0xcf7ce5[_0x574bce(0x37b)](_0x458adc),
        (_0x17296f = new _0x1c9a24()),
        (_0x17296f["x"] = 0xe6),
        (_0x17296f["y"] = 0x10e),
        _0xcf7ce5[_0x574bce(0x37b)](_0x17296f),
        (_0x337f1a = PIXI["Sprite"][_0x574bce(0x348)]("check_unfilled")),
        _0x337f1a[_0x574bce(0x4a1)][_0x574bce(0x27e)](0.5),
        _0xcf7ce5[_0x574bce(0x237)](_0x337f1a, 0x78),
        (_0x24c0ca = PIXI[_0x574bce(0x385)][_0x574bce(0x348)](
          _0x574bce(0x305),
        )),
        (_0x24c0ca["x"] = 0x140 - _0x24c0ca["width"] / 0x2),
        (_0x24c0ca["y"] = 0x270 - _0x24c0ca[_0x574bce(0x21c)] / 0x2),
        _0xcf7ce5[_0x574bce(0x37b)](_0x24c0ca),
        (_0x2098e9 = PIXI[_0x574bce(0x385)][_0x574bce(0x348)]("corners_0")),
        (_0x2098e9["x"] = 0x140 - _0x24c0ca[_0x574bce(0xfd)] / 0x2),
        (_0x2098e9["y"] = 0x270 - _0x24c0ca["height"] / 0x2),
        _0xcf7ce5["addChildZ"](_0x2098e9, 0x64),
        (_0xc5bee4 = new _0x902691()),
        (_0xc5bee4["x"] = 0x140),
        (_0xc5bee4["y"] = 0x2be),
        (_0xc5bee4[_0x574bce(0x197)] = ![]),
        _0xcf7ce5[_0x574bce(0x37b)](_0xc5bee4),
        (_0x27e1b4 = new _0x13fb80()),
        (_0x27e1b4["worldX"] = 0x140),
        (_0x27e1b4["worldY"] = 0x2be + 0x7c),
        _0xcf7ce5["addChildZ"](_0x27e1b4, 0xf),
        (_0x27e1b4["interactive"] = !![]),
        (_0x27e1b4[_0x574bce(0x2e6)] = !![]),
        _0x27e1b4["on"]("pointerdown", _0x36ab44),
        (_0x2f4138 = new _0x32d81c(
          PIXI["utils"][_0x574bce(0x299)][_0x574bce(0x16b)],
        )),
        _0x2f4138["anchor"][_0x574bce(0x27e)](0.5),
        _0x2f4138["scale"][_0x574bce(0x27e)](0.9),
        (_0x2f4138["x"] = 0x258),
        (_0x2f4138["y"] = 0x32),
        _0x2f4138[_0x574bce(0x3d4)](
          _0x574bce(0x444),
          PIXI[_0x574bce(0x304)][_0x574bce(0x299)][_0x574bce(0x295)],
        ),
        _0xcf7ce5[_0x574bce(0x237)](_0x2f4138, 0x64),
        _0x2f4138["on"](
          "pointertap",
          function () {
            _0x5e0129();
          }[_0x574bce(0x374)](this),
        ),
        (_0x147a99 = new _0x570109()),
        (_0x147a99["x"] = 0x55),
        (_0x147a99["y"] = 0x384 + 0x7c),
        _0xcf7ce5["addChild"](_0x147a99),
        _0x147a99["on"](_0x574bce(0x3c8), function () {
          var _0xf27bef = _0x574bce;
          if (_carromHostPaused || !_0x55e693 || !_0x209883) return;
          (_0x183856 && _0x14cbdd == 0x0 && _0x279414(0x0),
            (_0x27e1b4[_0xf27bef(0x294)] =
              _0x55e1a0 +
              (_0x187453 - _0x55e1a0) * _0x147a99[_0xf27bef(0x4b7)]),
            (_0x27e1b4[_0xf27bef(0x1dd)] = 0x2be + 0x7e),
            _0x23a7dc(_0x27e1b4, _0x133600 + 0x10)
              ? ((_0x27e1b4[_0xf27bef(0xe5)] = 0.7),
                (_0x27e1b4[_0xf27bef(0x3f1)][_0xf27bef(0x197)] = !![]))
              : ((_0x27e1b4[_0xf27bef(0xe5)] = 0x1),
                (_0x27e1b4[_0xf27bef(0x3f1)][_0xf27bef(0x197)] = ![])));
        }),
        _0x147a99["on"](_0x574bce(0x421), function () {
          if (_carromHostPaused || !_0x55e693 || !_0x209883) return;
          (_0x41684e(), _0x183856 && _0x14cbdd == 0x1 && _0x25e9ed(0x1));
        }),
        (_0x21a97b = new PIXI[_0x574bce(0x148)]()),
        (_0x21a97b[_0x574bce(0x197)] = ![]),
        _0x21a97b[_0x574bce(0x339)](0x0, 0.7),
        _0x21a97b[_0x574bce(0x26a)](
          0x0,
          0x0,
          _0x5568a2 + _0x24b13c,
          _0x27ae22 + _0x376ce3,
        ),
        (_0x21a97b["x"] = -_0x24b13c / 0x2),
        (_0x21a97b["y"] = -_0x376ce3 / 0x2),
        _0xcf7ce5["addChildZ"](_0x21a97b, 0x64),
        (_0x3cba20 = PIXI["Sprite"]["fromFrame"]("tut_hand")),
        (_0x3cba20[_0x574bce(0x197)] = ![]),
        _0xcf7ce5[_0x574bce(0x237)](_0x3cba20, 0x96),
        (_0xb32d86 = new PIXI[_0x574bce(0x190)]("---", {
          font: "42px\x20Simonetta",
          fill: 0xffffff,
          align: "center",
        })),
        (_0xb32d86[_0x574bce(0x197)] = ![]),
        _0xb32d86[_0x574bce(0x4a1)][_0x574bce(0x27e)](0.5),
        _0xcf7ce5[_0x574bce(0x237)](_0xb32d86, 0x96));
      let _0x59111c = new box2d["Vec2"](
          (_0x24c0ca["x"] + 0x1a) / 0x64,
          (_0x24c0ca["y"] + 0x1a) / 0x64,
        ),
        _0x49c284 = new box2d[_0x574bce(0x462)](
          (_0x24c0ca["x"] + _0x24c0ca[_0x574bce(0xfd)] - 0x1a) / 0x64,
          (_0x24c0ca["y"] + 0x1a) / 0x64,
        ),
        _0x14384f = new box2d[_0x574bce(0x462)](
          (_0x24c0ca["x"] + 0x1a) / 0x64,
          (_0x24c0ca["y"] + _0x24c0ca["height"] - 0x1a) / 0x64,
        ),
        _0x448ef8 = new box2d["Vec2"](
          (_0x24c0ca["x"] + _0x24c0ca[_0x574bce(0xfd)] - 0x1a) / 0x64,
          (_0x24c0ca["y"] + _0x24c0ca[_0x574bce(0x21c)] - 0x1a) / 0x64,
        );
      var _0x4e0606 = _0x1392b5["createBody"]({ type: "static" });
      (_0x4e0606[_0x574bce(0x471)](
        box2d[_0x574bce(0x20e)](_0x59111c, _0x49c284),
        0x1,
      ),
        (_0x4e0606[_0x574bce(0x343)] = _0x574bce(0x1e4)));
      var _0x210aaf = _0x1392b5[_0x574bce(0x203)]({ type: _0x574bce(0x15c) });
      (_0x210aaf["createFixture"](
        box2d[_0x574bce(0x20e)](_0x59111c, _0x14384f),
        0xa,
      ),
        (_0x210aaf[_0x574bce(0x343)] = _0x574bce(0x1e4)));
      var _0x216521 = _0x1392b5[_0x574bce(0x203)]({ type: "static" });
      (_0x216521[_0x574bce(0x471)](
        box2d[_0x574bce(0x20e)](_0x14384f, _0x448ef8),
        0x0,
      ),
        (_0x216521["objectType"] = _0x574bce(0x1e4)));
      var _0x1e3dc6 = _0x1392b5[_0x574bce(0x203)]({ type: "static" });
      (_0x1e3dc6[_0x574bce(0x471)](
        box2d[_0x574bce(0x20e)](_0x49c284, _0x448ef8),
        0x1,
      ),
        (_0x1e3dc6["objectType"] = _0x574bce(0x1e4)),
        (_0x4149a7 = new PIXI["Graphics"]()),
        _0x4149a7[_0x574bce(0x339)](0x0, 0.8),
        _0x4149a7[_0x574bce(0x26a)](
          0x0,
          0x0,
          _0x5568a2 + _0x24b13c,
          _0x27ae22 + _0x376ce3,
        ),
        (_0x4149a7[_0x574bce(0x445)] = !![]),
        (_0x4149a7[_0x574bce(0x197)] = ![]),
        _0x423f7f[_0x574bce(0x4cc)][_0x574bce(0x37b)](_0x4149a7),
        (_0x50d6f7 = new _0x28bd7a()),
        (_0x50d6f7[_0x574bce(0x197)] = ![]),
        (_0x50d6f7["x"] = _0x24b13c / 0x2),
        (_0x50d6f7["y"] = _0x376ce3 / 0x2),
        _0x423f7f["stage"][_0x574bce(0x37b)](_0x50d6f7),
        _0x50d6f7["on"]("ad", () => {
          _0x4d02b5((_0x14f43c) => {
            _0x14f43c && (_0x10184d(), _0x50f739());
          });
        }),
        _0x50d6f7["on"](_0x574bce(0x352), _0x10184d),
        _0x50d6f7["on"](_0x574bce(0x309), _0x411a1e),
        _0x50d6f7["on"](_0x574bce(0x383), function (_0x4bdb15) {
          var _0x1da261 = _0x574bce;
          (_0x4865ce[_0x1da261(0x261)](), _0x48e98f(_0x4bdb15));
        }),
        _0x50d6f7["on"](_0x574bce(0x252), _0x52b7f3),
        _0x50d6f7["on"](_0x574bce(0x463), function () {
          ((_0xa07851 += 0x1f4), _0x3771eb());
        }),
        (_0x5484bf = new _0x702477()),
        (_0x5484bf[_0x574bce(0x197)] = ![]),
        (_0x5484bf["x"] = _0x24b13c / 0x2),
        (_0x5484bf["y"] = _0x376ce3 / 0x2),
        _0x423f7f["stage"][_0x574bce(0x37b)](_0x5484bf),
        _0x5484bf["on"](_0x574bce(0x340), _0x50f739),
        _0x5484bf["on"](_0x574bce(0x3d2), _0x3771eb),
        (_0x4865ce = new _0x22a07c()),
        (_0x4865ce[_0x574bce(0x197)] = ![]),
        (_0x4865ce["x"] = _0x24b13c / 0x2),
        (_0x4865ce["y"] = _0x376ce3 / 0x2),
        _0x423f7f[_0x574bce(0x4cc)][_0x574bce(0x37b)](_0x4865ce),
        _0x4865ce["on"](_0x574bce(0x252), _0x52b7f3),
        _0x4865ce["on"]("shop", _0x411a1e),
        _0x4865ce["on"](_0x574bce(0x3d2), _0x3771eb),
        _0x4865ce["on"]("select", _0x4d0a10),
        (_0x429f89 = new _0x886cb6()),
        (_0x429f89[_0x574bce(0x197)] = ![]),
        (_0x429f89["x"] = _0x24b13c / 0x2),
        (_0x429f89["y"] = _0x376ce3 / 0x2),
        _0x423f7f[_0x574bce(0x4cc)]["addChild"](_0x429f89),
        _0x429f89["on"](_0x574bce(0x3d2), function () {
          if (_0x361d24) _0x48e98f(_0x5d148e);
          else _0x3771eb();
        }),
        _0x429f89["on"](_0x574bce(0x20f), _0x16f9d2),
        _0x429f89["on"](_0x574bce(0x2ba), _0x900aee),
        _0x429f89["on"](_0x574bce(0x448), _0x937251),
        _0x429f89["on"]("buy_stone", _0x3f64a2),
        _0x3771eb(),
        _0xa24bd4(),
        _0x423f7f["render"](),
        _0x28fba8[_0x574bce(0x188)](_0x574bce(0x125)),
        GameSnacks[_0x574bce(0x3cc)]["ready"]());
    }
    function _carromCancelAim() {
      if (!_0xf86500) return;
      _0xf86500 = false;
      _carromAimPointerId = null;
      _carromAimNativePointerId = null;
      _carromAimPointerType = null;
      _0xc5bee4.visible = false;
      _0xc5bee4.strength = 0;
      if (!_carromHostPaused && !_0x3e61d0 && _0x183856 && _0x14cbdd == 0x1 && _0x55e693 && _0x209883) _0x25e9ed(0x1);
    }
    function _carromTouchCancelled(_carromEvent) {
      if (_carromAimPointerType !== "touch") return;
      if ("ontouchstart" in window && _carromAimPointerId != null && _carromEvent.changedTouches) {
        for (var i = 0; i < _carromEvent.changedTouches.length; i++) {
          if ((_carromEvent.changedTouches[i].identifier || 0) === _carromAimPointerId) { _carromCancelAim(); return; }
        }
      }
      if (!_carromEvent.touches || !_carromEvent.touches.length) _carromCancelAim();
    }
    function _carromOutsideRelease(_carromEvent) {
      if (!_0xf86500 || _carromAimPointerId == null || !_carromEvent || _carromEvent.pointerId !== (_carromAimNativePointerId != null ? _carromAimNativePointerId : _carromAimPointerId)) return;
      if (_carromEvent.pointerType === "touch" && "ontouchstart" in window) return;
      if (_carromAimPointerType && _carromEvent.pointerType && _carromEvent.pointerType !== _carromAimPointerType) return;
      var _carromBounds = _0x423f7f.view.getBoundingClientRect();
      if (_carromEvent.clientX < _carromBounds.left || _carromEvent.clientX >= _carromBounds.right || _carromEvent.clientY < _carromBounds.top || _carromEvent.clientY >= _carromBounds.bottom) _carromCancelAim();
    }
    function _0xa24bd4() {
      var _0x21ceea = _0x157421;
      ((_0x423f7f[_0x21ceea(0x4cc)][_0x21ceea(0x1bf)] = !![]),
        _0x423f7f[_0x21ceea(0x4cc)]["on"](
          _0x21ceea(0x43e),
          function (_0x1504ff) {
            _0x152e94(_0x1504ff);
          },
        ),
        _0x423f7f["stage"]["on"](_0x21ceea(0x109), function (_0x806559) {
          _0x536112(_0x806559);
        }),
        _0x423f7f["stage"]["on"](_0x21ceea(0x39c), function (_0x5702d0) {
          _0x1e39ba(_0x5702d0);
        }),
        window.addEventListener("pointerup", _carromOutsideRelease),
        document.addEventListener("pointercancel", function (_carromEvent) {
          if (_carromEvent.pointerType === "touch" && "ontouchstart" in window) return;
          if (_carromAimPointerType && _carromEvent.pointerType && _carromEvent.pointerType !== _carromAimPointerType) return;
          if (_carromAimPointerId != null && _carromEvent.pointerId === (_carromAimNativePointerId != null ? _carromAimNativePointerId : _carromAimPointerId)) _carromCancelAim();
        }),
        document.addEventListener("touchcancel", _carromTouchCancelled),
        document[_0x21ceea(0x4b3)](_0x21ceea(0x1b9), function (_0x1d91a3) {
          _0x3154dc(_0x1d91a3);
        }),
        document[_0x21ceea(0x4b3)]("keyup", function (_0x31d1b4) {
          _0x3d59fa(_0x31d1b4);
        }));
    }
    function _0x5480e3() {
      var _0x48b12a = _0x157421;
      // A pointer held across a restart must not fire into the new round.
      _0xf86500 = false;
      _carromAimPointerId = null;
      _carromAimNativePointerId = null;
      _carromAimPointerType = null;
      if (_0xc5bee4) { _0xc5bee4.visible = false; _0xc5bee4.strength = 0; }
      _carromDiscardPendingPenalty();
      _carromDiscardPendingQueenPocket();
      _carromRoundId++;
      _carromTimeoutReady = null;
      _carromResultCommitted = false;
      _carromQueenClearedThisShot = false;
      _carromFreestyleHistory = [];
      _carromFreestyleQueenState = {phase: 'board', owner: null};
      Tweener.extract(_0x27e1b4);
      Tweener.extract(_0xc5bee4);
      if (_0x404020) {
        if (_0x404020[_0x48b12a(0x35d)])
          _0x404020[_0x48b12a(0x35d)]["removeChild"](_0x404020);
        _0x404020 = null;
      }
      ((_0x3a1262 = ![]),
        (_0x647bf3 = 0x4b + 0x19 * _0x2799f0),
        (_0x1a373b = 0x0),
        (_0x1f57de = window.CarromDiscRules.turnTicks(_0x5d148e, _0x408018, _0x3cbd63[_0x408018], _0x4bee00)),
        (_0x4149a7["visible"] = ![]),
        (_0x4d3bf1 = 0x0),
        (_0x41f634 = 0x0),
        (_0x539ff8[_0x48b12a(0x4b7)] = _0x4d3bf1),
        (_0x25b85f[_0x48b12a(0x4b7)] = _0x41f634),
        _carromReportScore(_0x4d3bf1),
        (_0x27ee82[_0x48b12a(0x4b7)] = 0x0),
        (_0x458adc[_0x48b12a(0x4b7)] = 0x0),
        (_0x27ee82["goal"] = _0x153877),
        (_0x458adc[_0x48b12a(0x275)] = _0x153877),
        (_0xc5bee4["aimFactor"] = 0.5 + 0.1 * _0xf6d2ec),
        (_0xc5bee4[_0x48b12a(0x197)] = ![]),
        _0x147a99[_0x48b12a(0x12d)](![]),
        (_0x27e1b4[_0x48b12a(0x197)] = ![]),
        (_0x55e693 = ![]),
        (_0x209883 = ![]),
        (_0x4268e2 = ![]),
        (_0x337f1a["visible"] = ![]),
        (_0x5ebd99 = !![]),
        (_0x530863 = ![]),
        (_0x3b3e21 = !![]),
        (_0x3e43c0 = ![]),
        (_0x3fddb3 = !![]),
        (_0x5ef04d = ![]),
        (_0x39ab6a = !![]),
        _0x547e1a(),
        (_0x3baf59 = _0x5c3d1d(_0x3baf59)),
        (_0x3e4566 = _0x5c3d1d(_0x3e4566)),
        (_0x2a9c75 = _0x5c3d1d(_0x2a9c75)),
        (_0x3231b3 = _0x5c3d1d(_0x3231b3)),
        (_0x59d4ef = _0x5c3d1d(_0x59d4ef)),
        (_0x49abc0 = _0x5c3d1d(_0x49abc0)),
        (_0x31089b = _0x5c3d1d(_0x31089b)),
        _0xd3d8fe(),
        _isPlayerStart
          ? ((_0x27e1b4[_0x48b12a(0x294)] = 0x140),
            (_0x27e1b4[_0x48b12a(0x1dd)] = 0x2be + 0x7c),
            _0x5e7a5f())
          : ((_0x27e1b4[_0x48b12a(0x294)] = 0x140),
            (_0x27e1b4[_0x48b12a(0x1dd)] = _0x429ae3),
            _0x50a0ff()),
        _0x2e33a4());
    }
    function _0x1260d2(_0x259626) {
      var _0x3dd3e7 = _0x157421;
      ((_0xf6d2ec = _0x4537e2[_0x4b3012]["aim"]),
        (_0x2799f0 = _0x4537e2[_0x4b3012][_0x3dd3e7(0x3a1)]),
        (_0x4bee00 = _0x4537e2[_0x4b3012][_0x3dd3e7(0x149)]));
      for (
        let _0x4cdd02 = 0x0;
        _0x4cdd02 < _0x57e1d2[_0x4b3012][_0x3dd3e7(0x1ea)];
        _0x4cdd02++
      ) {
        switch (_0x4537e2[_0x4b3012][_0x3dd3e7(0x315)][_0x4cdd02]) {
          case 0x0:
            _0xf6d2ec++;
            break;
          case 0x1:
            _0x2799f0++;
            break;
          case 0x2:
            _0x4bee00++;
            break;
        }
      }
      ((_0xa07680[_0x3dd3e7(0x4b7)] = _0x1ac80c[_0x408018][_0x3dd3e7(0x272)]),
        (_0x2b986d[_0x3dd3e7(0x335)] =
          PIXI["utils"][_0x3dd3e7(0x299)][_0x2dad3f[_0x408018]["bg"]]),
        (_0x5ccb1e[_0x3dd3e7(0x335)] =
          PIXI[_0x3dd3e7(0x304)]["TextureCache"][
            _0x2dad3f[_0x408018][_0x3dd3e7(0x1ee)]
          ]),
        _0x5ccb1e[_0x3dd3e7(0x231)][_0x3dd3e7(0x27e)](0.5),
        (_0x24c0ca[_0x3dd3e7(0x335)] =
          PIXI[_0x3dd3e7(0x304)][_0x3dd3e7(0x299)][
            _0x2dad3f[_0x408018][_0x3dd3e7(0x470)]
          ]),
        (_0x2098e9[_0x3dd3e7(0x335)] =
          PIXI[_0x3dd3e7(0x304)][_0x3dd3e7(0x299)][
            _0x2dad3f[_0x408018][_0x3dd3e7(0x17c)]
          ]),
        (_0x5b3bc4[_0x3dd3e7(0x335)] =
          PIXI["utils"][_0x3dd3e7(0x299)][_0x8b6dea[_0x5d148e]]),
        (_0x147a99["bg"][_0x3dd3e7(0x335)] =
          PIXI[_0x3dd3e7(0x304)][_0x3dd3e7(0x299)][
            _0x2dad3f[_0x408018][_0x3dd3e7(0x1c6)]
          ]),
        (_0x147a99["frame"][_0x3dd3e7(0x335)] =
          PIXI[_0x3dd3e7(0x304)]["TextureCache"][
            _0x2dad3f[_0x408018][_0x3dd3e7(0x25b)]
          ]),
        (_0x147a99[_0x3dd3e7(0x38a)][_0x3dd3e7(0x335)] =
          PIXI["utils"][_0x3dd3e7(0x299)][
            _0x427440[_0x4b3012][_0x3dd3e7(0x335)]
          ]),
        _0x147a99[_0x3dd3e7(0x38a)][_0x3dd3e7(0x231)][_0x3dd3e7(0x27e)](0.55),
        (_0x27e1b4[_0x3dd3e7(0x159)][_0x3dd3e7(0x335)] =
          PIXI[_0x3dd3e7(0x304)][_0x3dd3e7(0x299)][
            _0x427440[_0x4b3012][_0x3dd3e7(0x335)]
          ]),
        _0x5d148e == 0x2
          ? ((_0x539ff8["visible"] = ![]),
            (_0x25b85f[_0x3dd3e7(0x197)] = ![]),
            (_0x27ee82["visible"] = !![]),
            (_0x458adc[_0x3dd3e7(0x197)] = !![]),
            (_0x17296f[_0x3dd3e7(0x197)] = !![]),
            _0x17296f[_0x3dd3e7(0x3e0)](_0x3e9ee1),
            (_0x5ccb1e["y"] = 0x5a),
            _0x5ccb1e[_0x3dd3e7(0x231)]["set"](0.5 * 0.85),
            (_0xa07680["y"] = 0xbe),
            _0xa07680[_0x3dd3e7(0x231)][_0x3dd3e7(0x27e)](0.8))
          : (_0x539ff8[_0x3dd3e7(0x3e0)](_0x3e9ee1),
            (_0x539ff8[_0x3dd3e7(0x197)] = !![]),
            (_0x25b85f[_0x3dd3e7(0x197)] = !![]),
            (_0x27ee82[_0x3dd3e7(0x197)] = ![]),
            (_0x458adc[_0x3dd3e7(0x197)] = ![]),
            (_0x17296f[_0x3dd3e7(0x197)] = ![]),
            (_0x5ccb1e["y"] = 0x82),
            _0x5ccb1e["scale"][_0x3dd3e7(0x27e)](0.5),
            (_0xa07680["y"] = 0xf0),
            _0xa07680[_0x3dd3e7(0x231)][_0x3dd3e7(0x27e)](0x1)),
        (_0x44d1ad["avatar"][_0x3dd3e7(0x335)] =
          PIXI[_0x3dd3e7(0x304)]["TextureCache"][_0x3dd3e7(0x2c9)]),
        (_0xcf7ce5[_0x3dd3e7(0x197)] = !![]),
        _0x5480e3());
    }
    function _0x4e50de() {}
    function _0x25e9ed(_0x5e4418) {
      var _0x28d57e = _0x157421;
      _0x21a97b[_0x28d57e(0x197)] = !![];
      switch (_0x5e4418) {
        case 0x0:
          ((_0x21a97b[_0x28d57e(0x43d)] = 0x64),
            (_0x147a99["zOrder"] = 0x6e),
            (_0x27e1b4[_0x28d57e(0x43d)] = 0x6e),
            (_0x3cba20["x"] = 0x140),
            (_0x3cba20["y"] = 0x414),
            (_0x3cba20[_0x28d57e(0x197)] = !![]),
            Tweener[_0x28d57e(0x3a0)](
              _0x3cba20,
              {
                x: [
                  0x140, 0x140, 0x1a4, 0x208, 0x208, 0x208, 0x208, 0x208, 0x208,
                ],
                alpha: [0x1, 0x1, 0x1, 0x1, 0.5, 0x0, 0x0, 0x0, 0x0],
              },
              { time: 0x64, loop: -0x1 },
            ),
            (_0xb32d86["visible"] = !![]),
            (_0xb32d86["x"] = 0x140),
            (_0xb32d86["y"] = 0x276),
            (_0xb32d86[_0x28d57e(0x1aa)] = _0x28d57e(0x265)),
            (_0xb32d86[_0x28d57e(0xe5)] = 0x0),
            Tweener[_0x28d57e(0x3a0)](
              _0xb32d86,
              { alpha: 0x1 },
              { time: 0x32, transition: _0x28d57e(0x1f9) },
            ));
          break;
        case 0x1:
          ((_0x21a97b[_0x28d57e(0x43d)] = 0x9),
            (_0x147a99[_0x28d57e(0x43d)] = 0x8),
            (_0x27e1b4[_0x28d57e(0x43d)] = 0x6e),
            (_0x3cba20["x"] = 0x140),
            (_0x3cba20["y"] = 0x33c),
            (_0x3cba20[_0x28d57e(0x197)] = !![]),
            (_0xc5bee4["visible"] = !![]),
            (_0xc5bee4["strength"] = 0x0),
            (_0xc5bee4["x"] = _0x27e1b4["x"]),
            (_0xc5bee4["y"] = 0x33c),
            (_0xc5bee4[_0x28d57e(0x43d)] = 0x6d),
            Tweener[_0x28d57e(0x3a0)](
              _0x27e1b4,
              { scaleX: 1.1, scaleY: 1.1 },
              { time: 0x28, transition: _0x28d57e(0x205), loop: -0x1 },
            ),
            Tweener[_0x28d57e(0x3a0)](
              _0x3cba20,
              {
                x: [
                  _0x27e1b4["x"],
                  _0x27e1b4["x"],
                  _0x27e1b4["x"],
                  _0x27e1b4["x"],
                  _0x27e1b4["x"],
                  _0x27e1b4["x"] + 0x14,
                  _0x27e1b4["x"],
                  _0x27e1b4["x"] - 0x14,
                  _0x27e1b4["x"],
                  _0x27e1b4["x"],
                  _0x27e1b4["x"],
                  _0x27e1b4["x"],
                  _0x27e1b4["x"],
                ],
                y: [
                  0x33c, 0x33c, 0x36e, 0x3a0, 0x3a0, 0x3a0, 0x3a0, 0x3a0, 0x3a0,
                  0x3a0, 0x3a0, 0x3a0, 0x3a0,
                ],
                alpha: [
                  0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0.5, 0x0, 0x0, 0x0,
                  0x0,
                ],
              },
              {
                time: 0x82,
                loop: -0x1,
                onUpdate: function (_0x98bec1) {
                  var _0x375f16 = _0x28d57e;
                  ((_0xc5bee4[_0x375f16(0x2a0)] =
                    (_0x3cba20["y"] - 0x33c) / (_0x647bf3 * 1.5)),
                    (_0xc5bee4["angle"] = _0x8b2762(_0x27e1b4, _0x3cba20)));
                },
              },
            ),
            (_0xb32d86[_0x28d57e(0x197)] = !![]),
            (_0xb32d86["x"] = 0x140),
            (_0xb32d86["y"] = 0x190),
            (_0xb32d86[_0x28d57e(0x1aa)] = _0x28d57e(0x4cd)),
            (_0xb32d86[_0x28d57e(0xe5)] = 0x0),
            Tweener[_0x28d57e(0x3a0)](
              _0xb32d86,
              { alpha: 0x1 },
              { time: 0x32, transition: "easeOutQuad" },
            ));
          break;
        case 0x2:
          break;
      }
    }
    function _0x279414(_0xe2ea3e) {
      var _0x1e5dc5 = _0x157421;
      ((_0x21a97b["visible"] = ![]),
        (_0xb32d86[_0x1e5dc5(0x197)] = ![]),
        (_0x3cba20[_0x1e5dc5(0x197)] = ![]),
        Tweener["extract"](_0x3cba20),
        Tweener[_0x1e5dc5(0x469)](_0x27e1b4),
        Tweener[_0x1e5dc5(0x469)](_0xb32d86),
        (_0xc5bee4[_0x1e5dc5(0x43d)] = 0x9));
      switch (_0xe2ea3e) {
        case 0x0:
          _0x14cbdd = 0x1;
          break;
        case 0x1:
          ((_0x14cbdd = 0x2), (_0x183856 = ![]), _0x3a0318());
          break;
        case 0x2:
          break;
      }
    }
    function _0x30b1e3() {}
    function _0x1d7cac() {
      var _0x37fbd2 = _0x157421;
      if (!_0x3e61d0) return;
      ((_0x3e61d0 = ![]), _0x423f7f[_0x37fbd2(0x215)][_0x37fbd2(0x431)]());
    }
    function _0x5a2c78() {
      var _0x371641 = _0x157421;
      if (_0x3e61d0) return;
      ((_0x3e61d0 = !![]), _0x423f7f[_0x371641(0x215)][_0x371641(0x421)]());
    }
    function _0x3846bf() {
      _0x5480e3();
    }
    function _0x3771eb(_0x20c973) {
      var _0x31f75d = _0x157421;
      if (_carromActiveMatch) _carromCancelMatchTimers(_carromActiveMatch);
      _carromActiveMatch = null;
      _carromDiscardPendingPenalty();
      _carromDiscardPendingQueenPocket();
      
      ((_0x3fddb3 = ![]),
        (_0x361d24 = ![]),
        (_0xcf7ce5["visible"] = ![]),
        (_0x4865ce[_0x31f75d(0x197)] = ![]),
        (_0x429f89[_0x31f75d(0x197)] = ![]),
        (_0x50d6f7[_0x31f75d(0x197)] = !![]),
        (_0x5484bf[_0x31f75d(0x197)] = ![]),
        _0x4c7a25(),
        _0x50d6f7["setEnable"](!![]),
        _0x50d6f7[_0x31f75d(0x185)](
          _0x20c973 !== undefined ? _0x20c973 : _0xa07851,
        ),
        _0x50d6f7[_0x31f75d(0x162)](_0x232077()),
        _0x50d6f7[_0x31f75d(0x15a)](_0x530cb1),
        _0x530cb1
          ? (_0x50d6f7["_btnBonus"][_0x31f75d(0x441)][_0x31f75d(0x197)] = ![])
          : _0xcd5b2f
            ? (_0x50d6f7["_btnBonus"][_0x31f75d(0x441)][_0x31f75d(0x197)] =
                !![])
            : (_0x50d6f7[_0x31f75d(0x38e)][_0x31f75d(0x441)][_0x31f75d(0x197)] =
                ![]));
        console.log('完成初始化');


        window.parent.postMessage('gameLoadingCompleted','*');
        console.log("上报完成节点");
    }
    function _0x48e98f(_0xb7bbc5, _0x5edd1e) {
      var _0x1875e9 = _0x157421;
      _carromDiscardPendingPenalty();
      _carromDiscardPendingQueenPocket();
      ((_0x3fddb3 = ![]),
        (_0x361d24 = !![]),
        (_0x5d148e = _0xb7bbc5),
        (_0xcf7ce5[_0x1875e9(0x197)] = ![]),
        (_0x4865ce["visible"] = !![]),
        (_0x429f89[_0x1875e9(0x197)] = ![]),
        (_0x50d6f7[_0x1875e9(0x197)] = ![]),
        (_0x5484bf["visible"] = ![]),
        _0x4865ce["setCoins"](_0x5edd1e !== undefined ? _0x5edd1e : _0xa07851),
        _0x4865ce["updateStates"](_0x2e2e88),
        _0x4865ce[_0x1875e9(0x491)](_0x5d148e),
        _0x4865ce[_0x1875e9(0x162)](_0x232077()));
    }
    function _0x10184d() {
      var _0x467c1c = _0x157421;
      _carromDiscardPendingPenalty();
      _carromDiscardPendingQueenPocket();
      ((_0x3fddb3 = ![]),
        (_0xcf7ce5[_0x467c1c(0x197)] = ![]),
        (_0x4865ce[_0x467c1c(0x197)] = ![]),
        (_0x429f89["visible"] = ![]),
        (_0x50d6f7[_0x467c1c(0x197)] = ![]),
        (_0x5484bf[_0x467c1c(0x197)] = !![]),
        _0x5484bf[_0x467c1c(0x12d)](!![]));
    }
    function _0x411a1e() {
      var _0x122cf7 = _0x157421;
      _carromDiscardPendingPenalty();
      _carromDiscardPendingQueenPocket();
      ((_0x3fddb3 = ![]),
        (_0xcf7ce5[_0x122cf7(0x197)] = ![]),
        (_0x4865ce[_0x122cf7(0x197)] = ![]),
        (_0x429f89[_0x122cf7(0x197)] = !![]),
        (_0x50d6f7[_0x122cf7(0x197)] = ![]),
        (_0x5484bf[_0x122cf7(0x197)] = ![]),
        _0x429f89[_0x122cf7(0x185)](_0xa07851),
        _0x429f89[_0x122cf7(0xf6)](_0x57e1d2),
        _0x429f89[_0x122cf7(0x3f6)](_0x75fa36));
    }
    function _0x50f739() {
      var _0x29af98 = _0x157421;
      (_0x5484bf[_0x29af98(0x12d)](![]), _0x5484bf[_0x29af98(0x10b)]());
      let _0x54725a = _0x46c4a6({
          purple: 0x3,
          blue: 0xf,
          green: 0x6,
          red: 0xf,
          yellow: 0x1,
        }),
        _0x1ed6c7 =
          (_0x5484bf["wheel"][_0x29af98(0x1ec)] % (Math["PI"] * 0x2)) / 0.1,
        _0x53ae80 = 0x0;
      switch (_0x54725a) {
        case _0x29af98(0x246):
          _0x53ae80 = 0x0;
          break;
        case _0x29af98(0x292):
          _0x53ae80 = 0xc;
          break;
        case _0x29af98(0x3f4):
          _0x53ae80 = 0x19;
          break;
        case _0x29af98(0x399):
          _0x53ae80 = 0x25;
          break;
        case "yellow":
          _0x53ae80 = 0x32;
          break;
      }
      ((_0x53ae80 = _0x53ae80 - 0x2 + Math[_0x29af98(0xec)]() * 0x4),
        Tweener["addTween"](
          _0x5484bf,
          { speed: 0.1 },
          {
            time: 0x32,
            transition: _0x29af98(0x30c),
            onUpdate: function () {
              var _0x297607 = _0x29af98;
              _0x5484bf[_0x297607(0x2cf)]();
            },
            onComplete: function () {
              var _0x335147 = _0x29af98;
              (_0x28fba8["play"]("spin"),
                Tweener[_0x335147(0x3a0)](
                  _0x5484bf,
                  {},
                  {
                    time: 0x62 + _0x53ae80 - _0x1ed6c7,
                    onUpdate: function () {
                      var _0x351b4f = _0x335147;
                      _0x5484bf[_0x351b4f(0x2cf)]();
                    },
                    onComplete: function () {
                      var _0x3e4fd1 = _0x335147;
                      Tweener[_0x3e4fd1(0x3a0)](
                        _0x5484bf,
                        { speed: 0x0 },
                        {
                          time: 0xc8,
                          transition: "easeOutQuad",
                          onUpdate: function () {
                            var _0x113e75 = _0x3e4fd1;
                            _0x5484bf[_0x113e75(0x2cf)]();
                          },
                          onComplete: function () {
                            _0x5b20b9(_0x54725a);
                          },
                        },
                      );
                    },
                  },
                ));
            },
          },
        ),
        _0x50d6f7[_0x29af98(0x27a)](_0x66b857));
    }
    function _0x5b20b9(_0x52772a) {
      var _0x504362 = _0x157421;
      (_0x28fba8[_0x504362(0x383)]("spinwin"),
        setTimeout(function () {
          var _0x4ddfbc = _0x504362;
          _0x28fba8[_0x4ddfbc(0x383)](_0x4ddfbc(0x21a));
        }, 0xc8));
      var _0x2cd34a = _0xa07851;
      _0xa07851 += _0xffce48(_0x52772a);
      var _0xcb6539 = new Date();
      ((_0x6d1a83 = _0xcb6539["getTime"]()), (_0x530cb1 = ![]), _0x3a0318());
      var _0x11eeb5 = new PIXI[_0x504362(0x148)]();
      (_0x11eeb5["beginFill"](0x0, 0.9),
        _0x11eeb5[_0x504362(0x26a)](
          0x0,
          0x0,
          _0x5568a2 + _0x24b13c,
          _0x27ae22 + _0x376ce3,
        ),
        _0x423f7f[_0x504362(0x4cc)][_0x504362(0x37b)](_0x11eeb5),
        (_0x11eeb5[_0x504362(0xe5)] = 0x0),
        Tweener[_0x504362(0x3a0)](_0x11eeb5, { alpha: 0x1 }, { time: 0xa }));
      var _0x3b54b5 = new _0x3f0a26(_0xffce48(_0x52772a));
      ((_0x3b54b5["x"] = _0x24b13c / 0x2),
        (_0x3b54b5["y"] = _0x376ce3 / 0x2),
        _0x423f7f["stage"][_0x504362(0x37b)](_0x3b54b5),
        _0x3b54b5[_0x504362(0x369)](_0x504362(0x147), function () {
          var _0x585db5 = _0x504362;
          (_0x423f7f["stage"][_0x585db5(0x28c)](_0x11eeb5),
            _0x423f7f["stage"]["removeChild"](_0x3b54b5),
            _0x552ef6(0x140, 0x1f4),
            _0x3771eb(_0x2cd34a),
            Tweener[_0x585db5(0x3a0)](
              { value: _0x2cd34a },
              { value: _0xa07851 },
              {
                time: 0x14,
                delay: 0x32,
                transition: "easeOutQuad",
                onUpdate: function (_0x493331) {
                  var _0x24149a = _0x585db5;
                  _0x50d6f7[_0x24149a(0x185)](
                    Math[_0x24149a(0x167)](_0x493331[_0x24149a(0x4b7)]),
                  );
                },
              },
            ));
        }));
      _0xcd5b2f &&
        (_0x3b54b5[_0x504362(0x13d)](),
        _0x3b54b5[_0x504362(0x369)]("ad", function () {
          var _0x5e0f67 = _0x504362;
          (_0x423f7f[_0x5e0f67(0x4cc)][_0x5e0f67(0x28c)](_0x11eeb5),
            _0x423f7f["stage"][_0x5e0f67(0x28c)](_0x3b54b5),
            _0x4d02b5((_0x503082) => {
              var _0xae4012 = _0x5e0f67;
              (_0x503082 && ((_0xa07851 += _0xffce48(_0x52772a)), _0x3a0318()),
                _0x552ef6(0x140, 0x1f4),
                _0x3771eb(_0x2cd34a),
                Tweener[_0xae4012(0x3a0)](
                  { value: _0x2cd34a },
                  { value: _0xa07851 },
                  {
                    time: 0x14,
                    delay: 0x32,
                    transition: _0xae4012(0x1f9),
                    onUpdate: function (_0x385c01) {
                      var _0xf61ea7 = _0xae4012;
                      _0x50d6f7[_0xf61ea7(0x185)](
                        Math["round"](_0x385c01[_0xf61ea7(0x4b7)]),
                      );
                    },
                  },
                ));
            }));
        }));
      var _0x2dc850 = [];
      for (var _0x444d8f = 0x0; _0x444d8f < 0x14; _0x444d8f++) {
        let _0x4d0fcf = Math[_0x504362(0x167)](Math[_0x504362(0xec)]() * 0x8);
        var _0x3c4796 = new ParticleManager[_0x504362(0x16c)](
          PIXI[_0x504362(0x304)][_0x504362(0x299)]["cpx_" + _0x4d0fcf],
        );
        ((_0x3c4796["x"] = Math[_0x504362(0xec)]() * (_0x5568a2 + _0x24b13c)),
          (_0x3c4796["y"] = -0xa));
        let _0x306f84 = 0x3 + Math[_0x504362(0xec)]() * 0x4;
        ((_0x3c4796[_0x504362(0x1d4)] = Math["PI"] * 0x2),
          (_0x3c4796["angularSpeed"] = -0.1 + Math["random"]() * 0.2),
          (_0x3c4796[_0x504362(0xde)] = { x: 0x0, y: _0x306f84 }),
          (_0x3c4796[_0x504362(0x1a8)] = _0x444d8f * 0x5),
          (_0x3c4796["lifeTime"] = 0xfa),
          (_0x3c4796[_0x504362(0x347)] = 0x1),
          (_0x3c4796[_0x504362(0x2e3)] = 0x1),
          (_0x3c4796["startAlpha"] = 0x1),
          (_0x3c4796["endAlpha"] = 0x1),
          (_0x3c4796["order"] = _0x4d0fcf),
          _0x2dc850[_0x504362(0x3b0)](_0x3c4796),
          ParticleManager[_0x504362(0xfe)](_0x3c4796));
      }
      _0x2dc850["sort"](function (_0x123805, _0x315182) {
        var _0x30e479 = _0x504362;
        return _0x123805[_0x30e479(0x143)] - _0x315182[_0x30e479(0x143)];
      });
      for (
        let _0x5c2c5b = 0x0;
        _0x5c2c5b < _0x2dc850[_0x504362(0x182)];
        _0x5c2c5b++
      ) {
        _0x423f7f[_0x504362(0x4cc)][_0x504362(0x37b)](_0x2dc850[_0x5c2c5b]);
      }
      _0x2dc850 = [];
    }
    function _0x5e0129() {
      var _0x3e3c1b = _0x157421;
      if (_0x3e61d0) return;
      if (_0xf86500) { _0xf86500 = false; _carromAimPointerId = null; _carromAimNativePointerId = null; _carromAimPointerType = null; _0xc5bee4.visible = false; if (_0x183856 && _0x14cbdd == 0x1) _0x25e9ed(0x1); }
      ((_0x3e61d0 = !![]),
        (_0x2f4138[_0x3e3c1b(0x1bf)] = ![]),
        _0x50d6f7[_0x3e3c1b(0x12d)](![]));
      var _0x4959d4 = new PIXI[_0x3e3c1b(0x148)]();
      (_0x4959d4[_0x3e3c1b(0x339)](0x0, 0.9),
        _0x4959d4["drawRect"](
          0x0,
          0x0,
          _0x5568a2 + _0x24b13c,
          _0x27ae22 + _0x376ce3,
        ),
        _0x423f7f["stage"][_0x3e3c1b(0x37b)](_0x4959d4));
      var _0x42f3a4 = new _0x42b398(
        { music: _0x589270, sound: _0x5c102b },
        _0x5d148e,
      );
      ((_0x42f3a4["x"] = (_0x5568a2 + _0x24b13c) / 0x2),
        (_0x42f3a4["y"] = (_0x27ae22 + _0x376ce3) / 0x2 + 0x14),
        _0x423f7f[_0x3e3c1b(0x4cc)][_0x3e3c1b(0x37b)](_0x42f3a4),
        _0x42f3a4["on"](_0x3e3c1b(0x40f), function (_0x3896ea) {
          var _0x27b2c6 = _0x3e3c1b;
          _0x589270 = !_0x589270;
          if (_0x589270) _0x28fba8[_0x27b2c6(0x268)](_0x27b2c6(0x278));
          else _0x28fba8[_0x27b2c6(0x302)](_0x27b2c6(0x278));
        }),
        _0x42f3a4["on"](_0x3e3c1b(0x2de), function (_0x238f74) {
          var _0x5906ae = _0x3e3c1b;
          _0x5c102b = !_0x5c102b;
          if (_0x5c102b) _0x28fba8[_0x5906ae(0x268)]("SFX");
          else _0x28fba8[_0x5906ae(0x302)]("SFX");
        }),
        _0x42f3a4[_0x3e3c1b(0x369)](_0x3e3c1b(0x10a), function () {
          var _0x25069f = _0x3e3c1b;
          ((_0x3e61d0 = ![]),
            (_0x2f4138[_0x25069f(0x1bf)] = !![]),
            (_0x178e84 = null),
            _0x423f7f[_0x25069f(0x4cc)][_0x25069f(0x28c)](_0x4959d4),
            _0x3771eb(),
            GameSnacks["game"][_0x25069f(0x101)]());
        }),
        _0x42f3a4[_0x3e3c1b(0x369)](_0x3e3c1b(0x4c4), function () {
          var _0x4a75ff = _0x3e3c1b;
          ((_0x3e61d0 = ![]),
            (_0x2f4138[_0x4a75ff(0x1bf)] = !![]),
            (_0x178e84 = null),
            _0x423f7f[_0x4a75ff(0x4cc)][_0x4a75ff(0x28c)](_0x4959d4),
            _0x50d6f7["setEnable"](!![]));
        }));
    }
    function _0x52b7f3() {
      var _0x3411a7 = _0x157421;
      (_0x50d6f7[_0x3411a7(0x12d)](![]), _0x4865ce[_0x3411a7(0x12d)](![]));
      var _0x5e4241 = new PIXI[_0x3411a7(0x148)]();
      (_0x5e4241[_0x3411a7(0x339)](0x0, 0.9),
        _0x5e4241[_0x3411a7(0x26a)](
          0x0,
          0x0,
          _0x5568a2 + _0x24b13c,
          _0x27ae22 + _0x376ce3,
        ),
        _0x423f7f[_0x3411a7(0x4cc)][_0x3411a7(0x37b)](_0x5e4241));
      var _0x2924d9 = new _0x15504e();
      ((_0x2924d9["x"] = (_0x5568a2 + _0x24b13c) / 0x2),
        (_0x2924d9["y"] = (_0x27ae22 + _0x376ce3) / 0x2),
        _0x423f7f[_0x3411a7(0x4cc)][_0x3411a7(0x37b)](_0x2924d9),
        _0x2924d9[_0x3411a7(0x231)]["set"](0.8),
        Tweener["addTween"](
          _0x2924d9,
          { y: (_0x27ae22 + _0x376ce3) / 0x2 + 0x14, scaleX: 0x1, scaleY: 0x1 },
          { time: 0xf, transition: _0x3411a7(0x426) },
        ),
        _0x2924d9["once"](_0x3411a7(0x4c4), function () {
          var _0xa5aae = _0x3411a7;
          ((_0x178e84 = null),
            _0x423f7f[_0xa5aae(0x4cc)][_0xa5aae(0x28c)](_0x2924d9),
            _0x423f7f[_0xa5aae(0x4cc)][_0xa5aae(0x28c)](_0x5e4241),
            _0x50d6f7[_0xa5aae(0x12d)](!![]),
            _0x4865ce[_0xa5aae(0x12d)](!![]));
        }));
    }
    function _0x4e11dc() {
      var _0x1011d0 = _0x157421;
      _0x50d6f7[_0x1011d0(0x12d)](![]);
      var _0xf650c8 = new PIXI["Graphics"]();
      (_0xf650c8[_0x1011d0(0x339)](0x0, 0.9),
        _0xf650c8[_0x1011d0(0x26a)](
          0x0,
          0x0,
          _0x5568a2 + _0x24b13c,
          _0x27ae22 + _0x376ce3,
        ),
        _0x423f7f[_0x1011d0(0x4cc)][_0x1011d0(0x37b)](_0xf650c8));
      var _0x5974f1 = new _0x48223d({ music: _0x589270, sound: _0x5c102b });
      ((_0x5974f1["x"] = (_0x5568a2 + _0x24b13c) / 0x2),
        (_0x5974f1["y"] = (_0x27ae22 + _0x376ce3) / 0x2),
        _0x423f7f[_0x1011d0(0x4cc)][_0x1011d0(0x37b)](_0x5974f1),
        _0x5974f1[_0x1011d0(0x231)]["set"](0.8),
        Tweener[_0x1011d0(0x3a0)](
          _0x5974f1,
          { y: (_0x27ae22 + _0x376ce3) / 0x2 + 0x14, scaleX: 0x1, scaleY: 0x1 },
          { time: 0xf, transition: _0x1011d0(0x426) },
        ),
        _0x5974f1["on"](_0x1011d0(0x40f), function (_0x3a2ce7) {
          var _0x1a31d0 = _0x1011d0;
          _0x589270 = !_0x589270;
          if (_0x589270) _0x28fba8[_0x1a31d0(0x268)](_0x1a31d0(0x278));
          else _0x28fba8[_0x1a31d0(0x302)](_0x1a31d0(0x278));
        }),
        _0x5974f1["on"](_0x1011d0(0x2de), function (_0x1a77fd) {
          var _0x54ec7a = _0x1011d0;
          _0x5c102b = !_0x5c102b;
          if (_0x5c102b) _0x28fba8[_0x54ec7a(0x268)]("SFX");
          else _0x28fba8[_0x54ec7a(0x302)](_0x54ec7a(0x285));
        }),
        _0x5974f1[_0x1011d0(0x369)](_0x1011d0(0x10a), function () {
          var _0x4365ed = _0x1011d0;
          ((_0x178e84 = null),
            _0x423f7f[_0x4365ed(0x4cc)]["removeChild"](_0xf650c8),
            _0x3771eb());
        }),
        _0x5974f1["once"](_0x1011d0(0x4c4), function () {
          var _0x4e2a9a = _0x1011d0;
          ((_0x178e84 = null),
            _0x423f7f[_0x4e2a9a(0x4cc)]["removeChild"](_0xf650c8),
            _0x50d6f7[_0x4e2a9a(0x12d)](!![]));
        }));
    }
    function _0x3153fe() {
      var _0x4af288 = _0x157421;
      if (_carromActiveMatch) _carromCancelMatchTimers(_carromActiveMatch);
      _carromActiveMatch = null;
      _carromDiscardPendingPenalty();
      _carromDiscardPendingQueenPocket();
      ((_0x3fddb3 = ![]),
        (_0x4865ce[_0x4af288(0x197)] = ![]),
        (_0x429f89[_0x4af288(0x197)] = ![]),
        (_0x50d6f7["visible"] = ![]));
      var _0x2d2e1e = new _0x104b9b(
        _0x2dad3f[_0x408018],
        _0x3e9ee1,
        _0x1ac80c[_0x408018][_0x4af288(0x272)],
        _0x1ac80c[_0x408018][_0x4af288(0x177)],
      );
      _carromActiveMatch = _0x2d2e1e;
      ((_0x2d2e1e["x"] = _0x24b13c / 0x2),
        (_0x2d2e1e["y"] = _0x376ce3 / 0x2),
        _0x423f7f["stage"][_0x4af288(0x37b)](_0x2d2e1e),
        _0x2d2e1e["on"](_0x4af288(0x3a2), function () {
          if (_carromActiveMatch !== _0x2d2e1e) return;
          _0x2d2e1e["showStartingShuffle"](_isPlayerStart ? 0x0 : 0x1);
        }),
        _0x2d2e1e["on"](_0x4af288(0x431), function () {
          if (_carromActiveMatch !== _0x2d2e1e || _0x2d2e1e.parent !== _0x423f7f.stage) return;
          var _0x500d27 = _0x4af288;
          _carromActiveMatch = null;
          (_0x423f7f[_0x500d27(0x4cc)][_0x500d27(0x28c)](_0x2d2e1e),
            _0x1260d2());
        }));
    }
    function _0x4d0a10(_0x12ffd8) {
      var _0xa10f8 = _0x157421;
      if (_0x12ffd8 >= _0x2e2e88["length"]) return;
      ((_0x408018 = _0x12ffd8),
        (_isPlayerStart = Math[_0xa10f8(0xec)]() > 0.5 || _0x183856),
        (_0xa07851 -= _0x1ac80c[_0x408018][_0xa10f8(0x177)]),
        _0x3a0318(),
        _0x248455(_0xa10f8(0x273)),
        _0x3153fe(_0x408018));
    }
    function _0x16f9d2(_0x417584) {
      var _0x517e16 = _0x157421;
      if (_0x417584 >= _0x57e1d2["length"]) return;
      if (_0x57e1d2[_0x417584][_0x517e16(0x43f)] == _0x517e16(0x16d)) return;
      _0x28fba8[_0x517e16(0x383)](_0x517e16(0x16e));
      if (_0x57e1d2[_0x417584][_0x517e16(0x43f)] == _0x517e16(0x434)) {
        for (
          let _0x461785 = 0x0;
          _0x461785 < _0x57e1d2[_0x517e16(0x182)];
          _0x461785++
        ) {
          if (_0x57e1d2[_0x461785][_0x517e16(0x43f)] == "equiped")
            _0x57e1d2[_0x461785][_0x517e16(0x43f)] = _0x517e16(0x434);
        }
        ((_0x57e1d2[_0x417584]["state"] = _0x517e16(0x16d)),
          (_0x4b3012 = _0x417584));
      }
      (_0x429f89[_0x517e16(0x185)](_0xa07851),
        _0x429f89[_0x517e16(0xf6)](_0x57e1d2),
        _0x429f89["updateStoneStates"](_0x75fa36),
        _0x3a0318());
    }
    function _0x900aee(_0x18db55) {
      var _0x3255a8 = _0x157421;
      if (_0x18db55 >= _0x57e1d2["length"]) return;
      (_0x28fba8[_0x3255a8(0x383)](_0x3255a8(0x49c)),
        _0x28fba8[_0x3255a8(0x383)](_0x3255a8(0x450)));
      if (_0x57e1d2[_0x18db55][_0x3255a8(0x43f)] == _0x3255a8(0x2c8)) {
        _0x230373(_0x18db55);
        if (_0x57e1d2[_0x18db55][_0x3255a8(0x43f)] == _0x3255a8(0x434)) {
          for (
            let _0x1b84d0 = 0x0;
            _0x1b84d0 < _0x57e1d2["length"];
            _0x1b84d0++
          ) {
            if (_0x57e1d2[_0x1b84d0][_0x3255a8(0x43f)] == _0x3255a8(0x16d))
              _0x57e1d2[_0x1b84d0][_0x3255a8(0x43f)] = _0x3255a8(0x434);
          }
          ((_0x57e1d2[_0x18db55][_0x3255a8(0x43f)] = "equiped"),
            (_0x4b3012 = _0x18db55));
        }
      } else
        (_0x28fba8[_0x3255a8(0x383)](_0x3255a8(0x102), 0.5),
          _0x5a5b07(_0x18db55));
      (_0x429f89["setCoins"](_0xa07851),
        _0x429f89[_0x3255a8(0xf6)](_0x57e1d2),
        _0x429f89[_0x3255a8(0x3f6)](_0x75fa36),
        _0x3a0318());
    }
    function _0x5a5b07(_0x9b1d45) {
      var _0x481215 = _0x157421;
      if (_0x57e1d2[_0x9b1d45][_0x481215(0x2c1)] > _0xa07851) return;
      if (
        _0x57e1d2[_0x9b1d45][_0x481215(0x1ea)] >=
        _0x4537e2[_0x9b1d45][_0x481215(0x1ea)]
      )
        return;
      ((_0xa07851 -= _0x57e1d2[_0x9b1d45]["upgradeCost"]),
        _0x57e1d2[_0x9b1d45]["upgrade"]++);
    }
    function _0x230373(_0x281a07) {
      var _0x116065 = _0x157421;
      if (_0x57e1d2[_0x281a07][_0x116065(0x4b7)] > _0xa07851) return;
      ((_0xa07851 -= _0x57e1d2[_0x281a07][_0x116065(0x4b7)]),
        (_0x57e1d2[_0x281a07][_0x116065(0x43f)] = _0x116065(0x434)));
    }
    function _0x937251(_0xd5c91) {
      var _0x42bf3c = _0x157421;
      if (_0xd5c91 >= _0x75fa36["length"]) return;
      _0x28fba8["play"](_0x42bf3c(0x16e));
      if (_0x75fa36[_0xd5c91][_0x42bf3c(0x43f)] == _0x42bf3c(0x16d)) return;
      if (_0x75fa36[_0xd5c91][_0x42bf3c(0x43f)] == _0x42bf3c(0x16d))
        ((_0x75fa36[_0xd5c91][_0x42bf3c(0x43f)] = _0x42bf3c(0x434)),
          (_0x3e9ee1 = -0x1));
      else {
        if (_0x75fa36[_0xd5c91][_0x42bf3c(0x43f)] == _0x42bf3c(0x434)) {
          for (
            let _0xf58c74 = 0x0;
            _0xf58c74 < _0x75fa36[_0x42bf3c(0x182)];
            _0xf58c74++
          ) {
            if (_0x75fa36[_0xf58c74][_0x42bf3c(0x43f)] == _0x42bf3c(0x16d))
              _0x75fa36[_0xf58c74][_0x42bf3c(0x43f)] = _0x42bf3c(0x434);
          }
          ((_0x75fa36[_0xd5c91]["state"] = _0x42bf3c(0x16d)),
            (_0x3e9ee1 = _0xd5c91));
        }
      }
      (_0x429f89[_0x42bf3c(0x185)](_0xa07851),
        _0x429f89["updateStoneStates"](_0x75fa36),
        _0x429f89[_0x42bf3c(0xf6)](_0x57e1d2),
        _0x3a0318());
    }
    function _0x3f64a2(_0x9f19d0) {
      var _0x1b3cc5 = _0x157421;
      if (_0x9f19d0 >= _0x75fa36["length"]) return;
      if (_0x75fa36[_0x9f19d0][_0x1b3cc5(0x43f)] == _0x1b3cc5(0x16d)) return;
      if (_0x75fa36[_0x9f19d0][_0x1b3cc5(0x43f)] == "locked") {
        (_0x28fba8[_0x1b3cc5(0x383)](_0x1b3cc5(0x49c)),
          _0x28fba8[_0x1b3cc5(0x383)](_0x1b3cc5(0x450)),
          _0x1e3129(_0x9f19d0));
        if (_0x75fa36[_0x9f19d0][_0x1b3cc5(0x43f)] == _0x1b3cc5(0x434)) {
          for (
            let _0x2e6073 = 0x0;
            _0x2e6073 < _0x75fa36["length"];
            _0x2e6073++
          ) {
            if (_0x75fa36[_0x2e6073][_0x1b3cc5(0x43f)] == _0x1b3cc5(0x16d))
              _0x75fa36[_0x2e6073][_0x1b3cc5(0x43f)] = "unlocked";
          }
          ((_0x75fa36[_0x9f19d0][_0x1b3cc5(0x43f)] = _0x1b3cc5(0x16d)),
            (_0x3e9ee1 = _0x9f19d0));
        }
      } else {
        if (_0x75fa36[_0x9f19d0][_0x1b3cc5(0x43f)] == "equiped")
          ((_0x75fa36[_0x9f19d0]["state"] = "unlocked"), (_0x3e9ee1 = -0x1));
        else {
          if (_0x75fa36[_0x9f19d0][_0x1b3cc5(0x43f)] == _0x1b3cc5(0x434)) {
            for (
              let _0x27540c = 0x0;
              _0x27540c < _0x75fa36[_0x1b3cc5(0x182)];
              _0x27540c++
            ) {
              if (_0x75fa36[_0x27540c][_0x1b3cc5(0x43f)] == "equiped")
                _0x75fa36[_0x27540c][_0x1b3cc5(0x43f)] = _0x1b3cc5(0x434);
            }
            ((_0x75fa36[_0x9f19d0][_0x1b3cc5(0x43f)] = _0x1b3cc5(0x16d)),
              (_0x3e9ee1 = _0x9f19d0));
          }
        }
      }
      (_0x429f89[_0x1b3cc5(0x185)](_0xa07851),
        _0x429f89["updateStoneStates"](_0x75fa36),
        _0x429f89[_0x1b3cc5(0xf6)](_0x57e1d2),
        _0x3a0318());
    }
    function _0x1e3129(_0x416e39) {
      var _0x731216 = _0x157421;
      if (_0x75fa36[_0x416e39]["value"] > _0xa07851) return;
      ((_0xa07851 -= _0x75fa36[_0x416e39][_0x731216(0x4b7)]),
        (_0x75fa36[_0x416e39]["state"] = "unlocked"));
    }
    function _0x552ef6(_0x4534e2, _0x5025de) {
      var _0x23f991 = _0x157421;
      (_0x28fba8[_0x23f991(0x383)](_0x23f991(0x49c)),
        _0x28fba8[_0x23f991(0x383)](_0x23f991(0x450)));
      for (var _0x8bdb7a = 0x0; _0x8bdb7a < 0xa; _0x8bdb7a++) {
        var _0x51c02e = new ParticleManager["Particle"](
          PIXI[_0x23f991(0x304)]["TextureCache"][_0x23f991(0x38f)],
        );
        ((_0x51c02e["x"] = _0x4534e2 + _0x24b13c / 0x2),
          (_0x51c02e["y"] = _0x5025de + _0x376ce3 / 0x2),
          (_0x51c02e["tx"] = _0x51c02e["x"]),
          (_0x51c02e["ty"] = _0x51c02e["y"]),
          (_0x51c02e[_0x23f991(0x3ae)] = -0xc8 + Math["random"]() * 0xc8),
          _0x51c02e[_0x23f991(0x231)][_0x23f991(0x27e)](
            0.5 + Math[_0x23f991(0xec)]() * 0.2,
          ),
          (_0x51c02e[_0x23f991(0x1ec)] =
            -Math["PI"] / 0x2 + Math[_0x23f991(0xec)]() * Math["PI"] * 0x1),
          _0x423f7f[_0x23f991(0x4cc)][_0x23f991(0x37b)](_0x51c02e),
          Tweener["addTween"](
            _0x51c02e,
            {
              tx: 0x23a + _0x24b13c / 0x2,
              ty: 0x46 + _0x376ce3 / 0x2,
              scaleX: _0x51c02e["scaleX"] * 1.3,
              scaleY: _0x51c02e[_0x23f991(0x310)] * 1.3,
              rotation: 0x0,
            },
            {
              time: 0x32 + Math[_0x23f991(0xec)]() * 0x14,
              transition: _0x23f991(0x25d),
              onUpdate: function (_0x541876, _0x531e04) {
                var _0x5538da = _0x23f991;
                ((_0x541876["x"] =
                  _0x541876["tx"] +
                  (Tweener[_0x5538da(0x2f6)][_0x5538da(0x205)](_0x531e04) *
                    _0x541876[_0x5538da(0x3ae)]) /
                    0x2),
                  (_0x541876["y"] =
                    _0x541876["ty"] +
                    Tweener[_0x5538da(0x2f6)]["bow"](_0x531e04) *
                      Math[_0x5538da(0x322)](
                        _0x541876[_0x5538da(0x3ae)] / 0xa,
                      )));
              },
              onComplete: function (_0x56630f) {
                var _0x1bb5a8 = _0x23f991;
                (_0x28fba8[_0x1bb5a8(0x383)](_0x1bb5a8(0x450)),
                  _0x56630f[_0x1bb5a8(0x35d)]["removeChild"](_0x56630f),
                  _0x56630f[_0x1bb5a8(0x3bc)]());
              },
            },
          ));
      }
    }
    function _0x248455(_0x1c71a4, _0x2132c0) {
      var _carromAdPaused = false;
      var _carromAdToken = {};
      var _0x3a5106 = _0x157421;
      var _carromInterstitialDone = false;
      function _carromInterstitialContinue() {
        if (_carromInterstitialDone) return;
        _carromInterstitialDone = true;
        if (_0x2132c0) _0x2132c0();
      }
      try { GameSnacks["ad"][_0x3a5106(0x49d)]({
        type: _0x1c71a4,
        beforeReward: (_0x374172) => {},
        beforeAd: () => {
          if (_carromInterstitialDone) return;
          _carromAdPaused = true;
          _carromAdPause(_carromAdToken);
          var _0x2dbbb2 = _0x3a5106;
          (Howler[_0x2dbbb2(0x187)](!![]),
            _0x423f7f[_0x2dbbb2(0x215)]["stop"]());
        },
        adViewed: () => {},
        adDismissed: () => {},
        afterAd: () => {},
        adBreakDone: () => {
          if (_carromInterstitialDone) return;
          _carromAdResume(_carromAdToken);
          var _0x2f94a2 = _0x3a5106;
          (_carromSyncMute(),
            _0x423f7f[_0x2f94a2(0x215)][_0x2f94a2(0x431)]());
          _carromInterstitialContinue();
        },
      }); } catch (_carromInterstitialError) {
        _carromAdResume(_carromAdToken);
        if (_carromAdPaused) {
          try { _carromSyncMute(); _0x423f7f.ticker.start(); } catch (_) {}
        }
        console.warn('Carrom interstitial unavailable');
        _carromInterstitialContinue();
      }
    }
    function _0x2e33a4() {
      var _carromAdPaused = false;
      var _carromAdToken = {};
      var _carromAdFinished = false;
      var _0x1250db = _0x157421;
      if (_0xcd5b2f) return;
      var _carromThisAd = ++_carromAdGeneration;
      var _carromAdResolved = false;
      function _carromResolveAd(success) {
        if (_carromThisAd !== _carromAdGeneration || _carromAdResolved) return;
        _carromAdResolved = true;
        var callback = _0x38b273;
        _0x38b273 = null;
        if (callback) callback(success);
      }
      ((_0x1f977d = 0x3c * 0x14), (_0xcd5b2f = ![]));
      try {
        GameSnacks["ad"][_0x1250db(0x49d)]({
          type: _0x1250db(0x114),
          beforeReward: (_0x393556) => {
            if (_carromAdFinished || _carromThisAd !== _carromAdGeneration) return;
            _0x420004 = function () {
              try { _0x393556(); }
              catch (_carromAdShowError) {
                if (_carromAdResolved) throw _carromAdShowError;
                _carromAdFinished = true;
                if (_carromAdPaused) {
                  _carromAdResume(_carromAdToken);
                  try { _carromSyncMute(); _0x423f7f.ticker.start(); } catch (_) {}
                  _carromAdPaused = false;
                }
                _0xcd5b2f = false;
                _0x420004 = null;
                try { _carromResolveAd(false); }
                finally { if (_carromThisAd === _carromAdGeneration) _carromAdGeneration++; }
                console.warn('Carrom rewarded ad failed to show');
              }
            };
            _0xcd5b2f = true;
          },
          beforeAd: () => {
            if (_carromAdFinished || _carromThisAd !== _carromAdGeneration) return;
            _carromAdPaused = true;
            _carromAdPause(_carromAdToken);
            var _0x4619d5 = _0x1250db;
            (Howler[_0x4619d5(0x187)](!![]),
              _0x423f7f[_0x4619d5(0x215)]["stop"]());
          },
          adViewed: () => {
            _carromResolveAd(true);
          },
          adDismissed: () => {
            _carromResolveAd(false);
          },
          afterAd: () => {
            if (_carromAdFinished) return;
            _carromAdFinished = true;
            _carromAdResume(_carromAdToken);
            if (_carromThisAd !== _carromAdGeneration) return;
            var _0x12fe5b = _0x1250db;
            (_carromSyncMute(),
              _0x423f7f["ticker"][_0x12fe5b(0x431)](),
              (_0x3e43c0 = ![]),
              (_0x38b273 = null),
              _0x2e33a4());
          },
        });
      } catch (_carromAdPrepareError) {
        _carromAdFinished = true;
        _carromAdResume(_carromAdToken);
        if (_carromThisAd === _carromAdGeneration) _carromAdGeneration++;
        _0xcd5b2f = false;
        _0x420004 = null;
        if (_carromAdPaused) {
          try { _carromSyncMute(); _0x423f7f.ticker.start(); } catch (_) {}
        }
        console.warn('Carrom rewarded ad unavailable');
      }
    }
    function _0x4d02b5(_0xc3ac8a) {
      if (!_0x420004) return;
      var _carromShowAd = _0x420004;
      ((_0x420004 = null), (_0x38b273 = _0xc3ac8a), (_0xcd5b2f = ![]), _carromShowAd());
    }
    function _0x21acae() {
      var _0xaaa1ad = _0x157421,
        _0x357a18 = PIXI[_0xaaa1ad(0x385)][_0xaaa1ad(0x348)](_0xaaa1ad(0x32d));
      (_0x357a18[_0xaaa1ad(0x4a1)][_0xaaa1ad(0x27e)](0.5),
        (_0x357a18["x"] = 0x140),
        (_0x357a18["y"] = 0x258),
        _0xcf7ce5["addChild"](_0x357a18),
        (_0x357a18[_0xaaa1ad(0xe5)] = 0x0),
        Tweener["addTween"](
          _0x357a18,
          { alpha: 0x1 },
          { time: 0xf, transition: _0xaaa1ad(0x1f9) },
        ));
      var _0x20afd7 = PIXI["Sprite"][_0xaaa1ad(0x348)]("foul_base");
      (_0x20afd7[_0xaaa1ad(0x4a1)][_0xaaa1ad(0x27e)](0.5),
        (_0x20afd7["x"] = 0x140),
        (_0x20afd7["y"] = 0x258),
        _0xcf7ce5[_0xaaa1ad(0x37b)](_0x20afd7),
        _0x20afd7[_0xaaa1ad(0x231)]["set"](0x2),
        Tweener["addTween"](
          _0x20afd7,
          { scaleX: 0x1, scaleY: 0x1 },
          { time: 0xf, transition: "easeInQuad" },
        ),
        _0x338c29(function () {
          var _0x5a8284 = _0xaaa1ad;
          (Tweener[_0x5a8284(0x3a0)](
            _0x357a18,
            { alpha: 0x0 },
            {
              time: 0x14,
              transition: _0x5a8284(0x1f9),
              onComplete: function (_0x40e4f7) {
                var _0x2c9670 = _0x5a8284;
                if (_0x40e4f7["parent"])
                  _0x40e4f7["parent"][_0x2c9670(0x28c)](_0x40e4f7);
              },
            },
          ),
            Tweener[_0x5a8284(0x3a0)](
              _0x20afd7,
              { alpha: 0x0 },
              {
                time: 0x14,
                transition: _0x5a8284(0x1f9),
                onComplete: function (_0x43d9b4) {
                  var _0x2922ab = _0x5a8284;
                  if (_0x43d9b4[_0x2922ab(0x35d)])
                    _0x43d9b4[_0x2922ab(0x35d)]["removeChild"](_0x43d9b4);
                },
              },
            ));
        }, 0x3e8));
    }
    function _0x4afbdc(_0x459280, _0x391687, _0xdb4889) {
      var _0x1a73fc = _0x157421,
        _0x454ce1 = new Animable(_0xbf118[_0x1a73fc(0x200)][0x0]);
      (_0x454ce1[_0x1a73fc(0x231)][_0x1a73fc(0x27e)](0.7),
        _0x454ce1["anchor"][_0x1a73fc(0x27e)](0.5),
        (_0x454ce1["x"] = _0x459280),
        (_0x454ce1["y"] = _0x391687),
        (_0x454ce1[_0x1a73fc(0x1ec)] = _0xdb4889),
        _0xcf7ce5["addChild"](_0x454ce1),
        _0x454ce1[_0x1a73fc(0x320)]("fx", _0xbf118[_0x1a73fc(0x200)]),
        _0x454ce1["setAnimation"]("fx", 0x0, 0x14),
        _0x3eeb21["add"](null, _0x454ce1, !![]));
    }
    function _0x54f71d(_0x2efad8) {
      var _0x592e62 = _0x157421;
      _0x28fba8[_0x592e62(0x383)]("cast", 0.5);
      var _0x557fb6 = new Animable(_0xbf118[_0x592e62(0x1e8)][0x0]);
      (_0x557fb6[_0x592e62(0x231)][_0x592e62(0x27e)](0x1),
        _0x557fb6["anchor"]["set"](0.5),
        (_0x557fb6["x"] = _0x2fc10d[_0x2efad8]["x"]),
        (_0x557fb6["y"] = _0x2fc10d[_0x2efad8]["y"]),
        _0xcf7ce5[_0x592e62(0x37b)](_0x557fb6),
        _0x557fb6[_0x592e62(0x320)]("fx", _0xbf118[_0x592e62(0x1e8)]),
        _0x557fb6["setAnimation"]("fx", 0x0, 0x14),
        _0x3eeb21["add"](null, _0x557fb6, !![]));
    }
    function _0x47e567(_0x5d4255) {
      if (_carromResultCommitted) return;
      _carromResultCommitted = true;
      var _0x473454 = _0x157421,
        _0xe6d291 = _0xa07851,
        _carromResultRound = _carromRoundId,
        _carromResultPrize = _0x1ac80c[_0x408018]["prize"],
        _carromResultBonusGranted = false;
      if (_0x5d4255) {
        _0x28fba8["play"](_0x473454(0x21a), 0.5);
        _0x28fba8["play"]("bigwin_a", 0.5);
        try { GameSnacks[_0x473454(0x3cc)][_0x473454(0x483)](_0x408018 + 0x1); }
        catch (_0xresultSdkError) { console.warn('Carrom result SDK notification failed'); }
      } else {
        _0x28fba8[_0x473454(0x383)]("lose");
        try { GameSnacks["game"]["gameOver"](); }
        catch (_0xresultSdkError) { console.warn('Carrom result SDK notification failed'); }
      }
      _0x4149a7["visible"] = !![];
      var _0x84e6be = new _0x51b412(
        _0x5d4255,
        _0x5d4255 ? _0x1ac80c[_0x408018]["prize"] : 0x0,
        _0x3e9ee1,
        _0x4d3bf1,
        _0x41f634,
      );
      ((_0x84e6be["x"] = (_0x5568a2 + _0x24b13c) / 0x2),
        (_0x84e6be["y"] = (_0x27ae22 + _0x376ce3) / 0x2),
        _0x423f7f[_0x473454(0x4cc)][_0x473454(0x37b)](_0x84e6be),
        _0x84e6be["on"](_0x473454(0x4c4), function () {
          var _0x467634 = _0x473454;
          (_0x423f7f[_0x467634(0x4cc)]["removeChild"](_0x84e6be),
            (_0x4149a7["visible"] = ![]),
            _0xe6d291 != _0xa07851
              ? (_0x552ef6(0x140, 0x2bc),
                _0x48e98f(_0x5d148e, _0xe6d291),
                Tweener[_0x467634(0x3a0)](
                  { value: _0xe6d291 },
                  { value: _0xa07851 },
                  {
                    time: 0x14,
                    delay: 0x32,
                    transition: "easeOutQuad",
                    onUpdate: function (_0x4a8d7e) {
                      var _0x2f5334 = _0x467634;
                      _0x4865ce[_0x2f5334(0x185)](
                        Math[_0x2f5334(0x167)](_0x4a8d7e[_0x2f5334(0x4b7)]),
                      );
                    },
                  },
                ))
              : _0x48e98f(_0x5d148e));
        }),
        _0x84e6be[_0x473454(0x231)][_0x473454(0x27e)](0.1),
        Tweener[_0x473454(0x3a0)](
          _0x84e6be,
          { scaleX: 0x1, scaleY: 0x1 },
          { time: 0xf, transition: _0x473454(0x426) },
        ));
      if (_0x5d4255) {
        ((_0xa07851 += _0x1ac80c[_0x408018]["prize"]), _0x3a0318());
        _0xcd5b2f &&
          (_0x84e6be[_0x473454(0x13d)](),
          _0x84e6be["on"]("ad", () => {
            var _0x53377a = _0x473454;
            (_0x84e6be[_0x53377a(0x3d0)](),
              _0x4d02b5((_0x2c4f2f) => {
                var _0x2906e4 = _0x53377a;
                if (_0x2c4f2f) {
                  if (_carromResultBonusGranted) return;
                  _carromResultBonusGranted = true;
                  _0xa07851 += _carromResultPrize;
                  try { _0x3a0318(); }
                  catch (_carromRewardSaveError) { console.warn('Carrom reward save failed'); }
                }
                if (_carromResultRound !== _carromRoundId || !_0x84e6be || _0x84e6be.parent !== _0x423f7f.stage) return;
                if (_0x84e6be && _0x84e6be[_0x2906e4(0x35d)])
                  _0x423f7f["stage"]["removeChild"](_0x84e6be);
                ((_0x4149a7[_0x2906e4(0x197)] = ![]),
                  _0xe6d291 != _0xa07851
                    ? (_0x552ef6(0x140, 0x2bc),
                      _0x48e98f(_0x5d148e, _0xe6d291),
                      Tweener[_0x2906e4(0x3a0)](
                        { value: _0xe6d291 },
                        { value: _0xa07851 },
                        {
                          time: 0x14,
                          delay: 0x32,
                          transition: _0x2906e4(0x1f9),
                          onUpdate: function (_0x4d51d2) {
                            var _0x113b4c = _0x2906e4;
                            _0x4865ce["setCoins"](
                              Math["round"](_0x4d51d2[_0x113b4c(0x4b7)]),
                            );
                          },
                        },
                      ))
                    : _0x48e98f(_0x5d148e));
              }));
          }));
        var _0x4cf88e = [];
        for (var _0xc1850f = 0x0; _0xc1850f < 0x14; _0xc1850f++) {
          let _0x5e93bb = Math[_0x473454(0x167)](Math[_0x473454(0xec)]() * 0x8);
          var _0x5eb32c = new ParticleManager[_0x473454(0x16c)](
            PIXI["utils"][_0x473454(0x299)][_0x473454(0x181) + _0x5e93bb],
          );
          ((_0x5eb32c["x"] = Math["random"]() * (_0x5568a2 + _0x24b13c)),
            (_0x5eb32c["y"] = -0xa));
          let _0x36f91 = 0x3 + Math[_0x473454(0xec)]() * 0x4;
          ((_0x5eb32c[_0x473454(0x1d4)] = Math["PI"] * 0x2),
            (_0x5eb32c["angularSpeed"] = -0.1 + Math[_0x473454(0xec)]() * 0.2),
            (_0x5eb32c["startSpeed"] = { x: 0x0, y: _0x36f91 }),
            (_0x5eb32c[_0x473454(0x1a8)] = _0xc1850f * 0x5),
            (_0x5eb32c[_0x473454(0x4b0)] = 0xfa),
            (_0x5eb32c["startSize"] = 0x1),
            (_0x5eb32c["endSize"] = 0x1),
            (_0x5eb32c["startAlpha"] = 0x1),
            (_0x5eb32c[_0x473454(0x48f)] = 0x1),
            (_0x5eb32c["order"] = _0x5e93bb),
            _0x4cf88e[_0x473454(0x3b0)](_0x5eb32c),
            ParticleManager[_0x473454(0xfe)](_0x5eb32c));
        }
        _0x4cf88e[_0x473454(0x22d)](function (_0x200dbf, _0x33e777) {
          var _0x1e6231 = _0x473454;
          return _0x200dbf[_0x1e6231(0x143)] - _0x33e777[_0x1e6231(0x143)];
        });
        for (
          let _0x3c1108 = 0x0;
          _0x3c1108 < _0x4cf88e[_0x473454(0x182)];
          _0x3c1108++
        ) {
          _0x423f7f["stage"]["addChild"](_0x4cf88e[_0x3c1108]);
        }
        _0x4cf88e = [];
      }
    }
    function _0x52e61d() {
      var _carromOnQueenReturned = arguments[0];
      var _0x2dc4c8 = _0x157421,
        _0x42cef5 = _0x4efd2a["x"] + _0x24c0ca["x"],
        _0x3ed485 = _0x4efd2a["y"] + _0x24c0ca["y"];
      var _carromQueenRound = _carromRoundId;
      var _carromQueenSprite = _0x404020;
      var _carromQueenPosition = {worldX: _0x42cef5, worldY: _0x3ed485};
      _0x1f3ae5(_carromQueenPosition);
      _0x42cef5 = _carromQueenPosition.worldX;
      _0x3ed485 = _carromQueenPosition.worldY;
      _0x404020 &&
        Tweener["addTween"](
          _0x404020,
          { x: _0x42cef5, y: _0x3ed485 },
          {
            time: 0xf,
            transition: _0x2dc4c8(0x1f9),
            onComplete: function () {
              if (!_0x3fddb3 || _carromQueenRound !== _carromRoundId || _0x404020 !== _carromQueenSprite) {
                if (_carromQueenSprite && _carromQueenSprite.parent) _carromQueenSprite.parent.removeChild(_carromQueenSprite);
                return;
              }
              var _0x58dcda = _0x2dc4c8,
                _0x20c17b = new _0x54e9a5(0x0, _0x3e9ee1);
              ((_0x20c17b[_0x58dcda(0x294)] = _0x42cef5),
                (_0x20c17b["worldY"] = _0x3ed485),
                (_0x20c17b[_0x58dcda(0x12e)] = _0x58dcda(0xf8)),
                _0xcf7ce5[_0x58dcda(0x37b)](_0x20c17b),
                (_0x20c17b[_0x58dcda(0x43d)] = 0xa + _0x4efd2a["y"] / 0x64),
                _0x1f3ae5(_0x20c17b),
                _0x3231b3[_0x58dcda(0x3b0)](_0x20c17b));
              if (_carromQueenSprite[_0x58dcda(0x35d)])
                _carromQueenSprite["parent"][_0x58dcda(0x28c)](_carromQueenSprite);
              _0x404020 = null;
              if (typeof _carromOnQueenReturned === 'function') _carromOnQueenReturned();
            },
          },
        );
    }
    function _0xd3d8fe() {
      var _0x2d8bb1 = _0x157421;
      var _carromLayout = window.CarromDiscRules.layout(_0x5d148e, _0x408018);
      var _carromOpponentLayout = _carromLayout ? _carromLayout.opponent : _0x45677e;
      var _carromPlayerLayout = _carromLayout ? _carromLayout.player : _0x1a9f0e;
      var _carromDiscCount = window.CarromDiscRules.target(_0x5d148e, _0x408018);
      _0x547e1a();
      if (_0x5d148e != 0x0) {
        var _0x9a563e = new _0x54e9a5(0x0, _0x3e9ee1);
        ((_0x9a563e[_0x2d8bb1(0x294)] = _0x4efd2a["x"] + _0x24c0ca["x"]),
          (_0x9a563e[_0x2d8bb1(0x1dd)] = _0x4efd2a["y"] + _0x24c0ca["y"]),
          (_0x9a563e[_0x2d8bb1(0x12e)] = _0x2d8bb1(0xf8)),
          _0xcf7ce5[_0x2d8bb1(0x37b)](_0x9a563e),
          (_0x9a563e[_0x2d8bb1(0x43d)] = 0xa + _0x4efd2a["y"] / 0x64),
          _0x3231b3[_0x2d8bb1(0x3b0)](_0x9a563e));
      }
      for (let _0x49e692 = 0x0; _0x49e692 < _carromDiscCount; _0x49e692++) {
        var _0xa237e1 = new _0x54e9a5(0x2, _0x3e9ee1);
        ((_0xa237e1[_0x2d8bb1(0x294)] =
          _carromOpponentLayout[_0x49e692]["x"] + _0x24c0ca["x"]),
          (_0xa237e1[_0x2d8bb1(0x1dd)] =
            _carromOpponentLayout[_0x49e692]["y"] + _0x24c0ca["y"]),
          (_0xa237e1["id"] = _0x49e692),
          (_0xa237e1[_0x2d8bb1(0x12e)] = _0x2d8bb1(0x393)),
          _0xcf7ce5[_0x2d8bb1(0x37b)](_0xa237e1),
          (_0xa237e1["zOrder"] = 0xa + (_carromLayout ? _carromOpponentLayout : _0x1a9f0e)[_0x49e692]["y"] / 0x64),
          _0x2a9c75["push"](_0xa237e1));
      }
      for (let _0x1baea4 = 0x0; _0x1baea4 < _carromDiscCount; _0x1baea4++) {
        var _0xa237e1 = new _0x54e9a5(0x1, _0x3e9ee1);
        ((_0xa237e1[_0x2d8bb1(0x294)] =
          _carromPlayerLayout[_0x1baea4]["x"] + _0x24c0ca["x"]),
          (_0xa237e1["worldY"] = _carromPlayerLayout[_0x1baea4]["y"] + _0x24c0ca["y"]),
          (_0xa237e1["id"] = _0x1baea4),
          (_0xa237e1[_0x2d8bb1(0x12e)] = "player"),
          _0xcf7ce5["addChild"](_0xa237e1),
          (_0xa237e1[_0x2d8bb1(0x43d)] =
            0xa + _carromPlayerLayout[_0x1baea4]["y"] / 0x64),
          _0x3e4566["push"](_0xa237e1));
      }
      _0xcf7ce5["sortChildren"]();
    }
    function _0x547e1a() {
      var _0xf7673c = _0x157421,
        _0x238a46 = _0x3231b3[_0xf7673c(0x3c6)](0x0);
      for (
        let _0x3ac45d = 0x0;
        _0x3ac45d < _0x238a46[_0xf7673c(0x182)];
        _0x3ac45d++
      ) {
        let _0xdc62f0 = _0x238a46[_0x3ac45d];
        (_0xdc62f0[_0xf7673c(0x4a0)](), _0x253500(_0x3231b3, _0xdc62f0));
      }
      var _0x238a46 = _0x3e4566["slice"](0x0);
      for (
        let _0x2aa53f = 0x0;
        _0x2aa53f < _0x238a46[_0xf7673c(0x182)];
        _0x2aa53f++
      ) {
        let _0x31abd0 = _0x238a46[_0x2aa53f];
        (_0x31abd0[_0xf7673c(0x4a0)](), _0x253500(_0x3e4566, _0x31abd0));
      }
      var _0x238a46 = _0x2a9c75[_0xf7673c(0x3c6)](0x0);
      for (
        let _0x2ea6f0 = 0x0;
        _0x2ea6f0 < _0x238a46[_0xf7673c(0x182)];
        _0x2ea6f0++
      ) {
        let _0x38742f = _0x238a46[_0x2ea6f0];
        (_0x38742f[_0xf7673c(0x4a0)](), _0x253500(_0x2a9c75, _0x38742f));
      }
    }
    function _0x24bb4a() {
      var _0x53fb9f = _0x157421;
      ((_0xf86500 = ![]),
        (_0xc5bee4["visible"] = ![]),
        (_0x3a1262 = ![]),
        _0x1a373b - 0x1,
        (_0x44d1ad[_0x53fb9f(0x39a)][_0x53fb9f(0x4b7)] = 0x0),
        (_0x2cf38a["frame"][_0x53fb9f(0x4b7)] = 0x0),
        (_0x55e693 = ![]),
        _0x147a99[_0x53fb9f(0x12d)](![]),
        (_0x27e1b4["alpha"] = 0x1),
        (_0x27e1b4[_0x53fb9f(0x3f1)][_0x53fb9f(0x197)] = ![]));
    }
    function _carromReportScore(value) {
      try { GameSnacks.score.update(value); }
      catch (_carromScoreSdkError) { console.warn('Carrom score SDK notification failed'); }
    }
    function _0x464a16(_0xb9ea42) {
      var _0x24d5f5 = _0x157421;
      var _carromReturnRound = _carromRoundId;
      if (_0xb9ea42 && _0x4d3bf1 <= 0x0) return;
      else {
        if (!_0xb9ea42 && _0x41f634 <= 0x0) return;
      }
      var _0x4c35d7 = new _0x54e9a5(_0xb9ea42 ? 0x1 : 0x2, _0x3e9ee1);
      (_0x4c35d7[_0x24d5f5(0x4a0)](),
        _0xcf7ce5[_0x24d5f5(0x237)](_0x4c35d7, 0x6e),
        _0xb9ea42
          ? ((_0x4c35d7["x"] = _0x539ff8["x"]),
            (_0x4c35d7["y"] = _0x539ff8["y"]),
            (_0x4c35d7["type"] = "player"),
            _0x4d3bf1--,
            (_0x539ff8[_0x24d5f5(0x4b7)] = _0x4d3bf1),
            _carromReportScore(_0x4d3bf1))
          : ((_0x4c35d7["x"] = _0x25b85f["x"]),
            (_0x4c35d7["y"] = _0x25b85f["y"]),
            (_0x4c35d7[_0x24d5f5(0x12e)] = "oponent"),
            _0x41f634--,
            (_0x25b85f[_0x24d5f5(0x4b7)] = _0x41f634)),
        Tweener[_0x24d5f5(0x3a0)](
          _0x4c35d7,
          {
            x: _0x4efd2a["x"] + _0x24c0ca["x"],
            y: _0x4efd2a["y"] + _0x24c0ca["y"],
            scaleX: 0x1,
            scaleY: 0x1,
            alpha: 0x1,
          },
          {
            time: 0x14 + Math[_0x24d5f5(0xec)]() * 0xa,
            transition: _0x24d5f5(0x1f9),
            onComplete: function (_0x423f98) {
              if (!_0x3fddb3 || _carromReturnRound !== _carromRoundId) {
                if (_0x4c35d7.parent) _0x4c35d7.parent.removeChild(_0x4c35d7);
                return;
              }
              var _0x1b6afc = _0x24d5f5,
                _0x1496fe = new _0x54e9a5(
                  _0x423f98[_0x1b6afc(0x284)],
                  _0x3e9ee1,
                );
              ((_0x1496fe["worldX"] = _0x423f98["x"]),
                (_0x1496fe[_0x1b6afc(0x1dd)] = _0x423f98["y"]),
                (_0x1496fe["type"] = _0x423f98[_0x1b6afc(0x12e)]),
                _0xcf7ce5[_0x1b6afc(0x37b)](_0x1496fe),
                (_0x1496fe[_0x1b6afc(0x43d)] = 0xa + _0x4efd2a["y"] / 0x64),
                _0x1f3ae5(_0x1496fe));
              if (_0x423f98[_0x1b6afc(0x12e)] == "player")
                _0x3e4566[_0x1b6afc(0x3b0)](_0x1496fe);
              else
                _0x423f98["type"] == "oponent"
                  ? _0x2a9c75["push"](_0x1496fe)
                  : _0x3231b3[_0x1b6afc(0x3b0)](_0x1496fe);
              _0x4c35d7[_0x1b6afc(0x35d)][_0x1b6afc(0x28c)](_0x4c35d7);
            },
          },
        ));
    }
    function _carromFreestylePenalty(actor, onReturned, state) {
      var matches = _carromFreestyleHistory.filter(function (entry) {
        return entry.actor === actor && entry.round === _carromRoundId;
      });
      if ((actor !== 'player' && actor !== 'opponent') || !matches.length) return false;
      var entry = matches[0];
      var score = actor === 'player' ? _0x4d3bf1 : _0x41f634;
      if ((entry.type !== 1 && entry.type !== 2) || !Number.isFinite(entry.points) || entry.points <= 0 ||
          !matches.every(function (item) { return item.type === entry.type && item.points === entry.points; }) ||
          score !== entry.points * matches.length) return false;
      var round = _carromRoundId, returned = false;
      var disc = new _0x54e9a5(entry.type, _0x3e9ee1);
      disc.removeFromWorld();
      _0xcf7ce5.addChildZ(disc, 0x6e);
      var hud = actor === 'player' ? _0x27ee82 : _0x458adc;
      disc.x = hud.x; disc.y = hud.y;
      disc.type = entry.type === 1 ? 'player' : 'oponent';
      function restore(animated) {
        if (returned) return;
        returned = true;
        if (!_0x3fddb3 || round !== _carromRoundId) {
          if (disc.parent) disc.parent.removeChild(disc);
          return;
        }
        var restored = new _0x54e9a5(entry.type, _0x3e9ee1);
        restored.worldX = animated.x; restored.worldY = animated.y; restored.type = disc.type;
        _0xcf7ce5.addChild(restored);
        restored.zOrder = 0xa + _0x4efd2a.y / 0x64;
        _0x1f3ae5(restored);
        (entry.type === 1 ? _0x3e4566 : _0x2a9c75).push(restored);
        if (disc.parent) disc.parent.removeChild(disc);
        if (state && _carromPendingPenalty === state) _carromPendingPenalty = null;
        if (onReturned) onReturned();
      }
      if (state) {
        _carromPendingPenalty = state;
        state.cancel = function () {
          returned = true;
          Tweener.extract(disc);
          if (disc.parent) disc.parent.removeChild(disc);
          state.pending = false;
        };
        state.finish = function () {
        Tweener.extract(disc);
        disc.x = _0x4efd2a.x + _0x24c0ca.x;
        disc.y = _0x4efd2a.y + _0x24c0ca.y;
        restore(disc);
        };
      }
      Tweener.addTween(disc, {
        x: _0x4efd2a.x + _0x24c0ca.x, y: _0x4efd2a.y + _0x24c0ca.y,
        scaleX: 1, scaleY: 1, alpha: 1
      }, {time: 0x14 + Math.random() * 0xa, transition: 'easeOutQuad', onComplete: restore});
      _carromFreestyleHistory.splice(_carromFreestyleHistory.indexOf(entry), 1);
      if (actor === 'player') {
        _0x4d3bf1 -= entry.points; hud.value = _0x4d3bf1; _carromReportScore(_0x4d3bf1);
      } else {
        _0x41f634 -= entry.points; hud.value = _0x41f634;
      }
      return true;
    }
    // Provisional Freestyle policy: competitor edge cases need runtime evidence.
    function _carromReturnFreestyleQueen(owner) {
      if (_carromFreestyleQueenState.returnCommitted) return true;
      var index = _carromFreestyleHistory.findIndex(function (entry) {
        return entry.round === _carromRoundId && entry.actor === owner && entry.type === 0;
      });
      // The pending state keeps the awarded amount even if the history is damaged.
      var entry = index >= 0 ? _carromFreestyleHistory[index] : {points: _carromFreestyleQueenState.points || 0};
      var queen = new _0x54e9a5(0, _0x3e9ee1);
      queen.worldX = _0x4efd2a.x + _0x24c0ca.x;
      queen.worldY = _0x4efd2a.y + _0x24c0ca.y;
      queen.type = _0x157421(0xf8);
      _0xcf7ce5.addChild(queen);
      queen.zOrder = 0xa + _0x4efd2a.y / 0x64;
      _0x1f3ae5(queen);
      _0x3231b3.push(queen);
      if (index >= 0) _carromFreestyleHistory.splice(index, 1);
      _carromFreestyleQueenState.returnCommitted = true;
      if (owner === 'player') {
        _0x4d3bf1 -= entry.points;
        _0x27ee82.value = _0x4d3bf1;
        _carromReportScore(_0x4d3bf1);
      } else {
        _0x41f634 -= entry.points;
        _0x458adc.value = _0x41f634;
      }
      return true;
    }
    function _carromDiscardPendingQueenPocket() {
      var sprite = _carromPendingQueenPocket;
      _carromPendingQueenPocket = null;
      if (!sprite) return;
      Tweener.extract(sprite);
      if (sprite.parent) sprite.parent.removeChild(sprite);
    }
    function _carromDiscardPendingPenalty() {
      if (!_carromPendingPenalty) return;
      var pending = _carromPendingPenalty;
      _carromPendingPenalty = null;
      pending.cancel();
    }
    function _carromAwaitPenalty(state, done) {
      if (state.pending && (state.waits = (state.waits || 0) + 1) >= 20 && state.finish) state.finish();
      if (state.pending)
        return _0x338c29(function () { _carromAwaitPenalty(state, done); }, 50);
      done();
    }
    function _0x89ccbb() {
      var _0x184664 = _0x157421;
      for (let _0x5c4eac = 0x0; _0x5c4eac < _0x3231b3["length"]; _0x5c4eac++) {
        _0x3231b3[_0x5c4eac][_0x184664(0x142)](![]);
      }
      for (
        let _0x123c56 = 0x0;
        _0x123c56 < _0x3e4566[_0x184664(0x182)];
        _0x123c56++
      ) {
        _0x3e4566[_0x123c56]["setAwake"](![]);
      }
      for (
        let _0x19f515 = 0x0;
        _0x19f515 < _0x2a9c75[_0x184664(0x182)];
        _0x19f515++
      ) {
        _0x2a9c75[_0x19f515][_0x184664(0x142)](![]);
      }
      _0x27e1b4[_0x184664(0x142)](![]);
    }
    function _0x56abf7() {
      var _0x5c6e90 = _0x157421;
      for (
        let _0x272ef3 = 0x0;
        _0x272ef3 < _0x3231b3[_0x5c6e90(0x182)];
        _0x272ef3++
      ) {
        _0x3231b3[_0x272ef3]["trimVelocity"]();
        if (_0x3231b3[_0x272ef3]["isAwake"]()) return !![];
      }
      for (
        let _0x27d33f = 0x0;
        _0x27d33f < _0x3e4566[_0x5c6e90(0x182)];
        _0x27d33f++
      ) {
        _0x3e4566[_0x27d33f][_0x5c6e90(0x36a)]();
        if (_0x3e4566[_0x27d33f][_0x5c6e90(0x262)]()) return !![];
      }
      for (
        let _0x5c48b9 = 0x0;
        _0x5c48b9 < _0x2a9c75[_0x5c6e90(0x182)];
        _0x5c48b9++
      ) {
        _0x2a9c75[_0x5c48b9][_0x5c6e90(0x36a)]();
        if (_0x2a9c75[_0x5c48b9]["isAwake"]()) return !![];
      }
      _0x27e1b4[_0x5c6e90(0x36a)]();
      if (_0x27e1b4[_0x5c6e90(0x262)]()) return !![];
      return ![];
    }
    function _carromFlushTimeoutAfterScan() {
      if (!_carromTimeoutReady) return;
      if (!_0x3fddb3 || _carromTimeoutReady.round !== _carromRoundId || _carromTimeoutReady.turn !== _carromTurnId) { _carromTimeoutReady = null; return; }
      if (_carromTimeoutReady.armed === false) {
        if (_carromTimeoutReady.armWait > 0) { _carromTimeoutReady.armWait--; return; }
        _carromTimeoutReady.armed = true;
      }
      if (_carromTimeoutReady.wait > 0) { _carromTimeoutReady.wait--; return; }
      if (_0x56abf7()) { _carromTimeoutReady.wait = 2; return; }
      var turn = _carromTimeoutReady.turn;
      _carromTimeoutReady = null;
      _0xbdafb3(turn);
    }
    function _0xbdafb3(_carromExpectedTurn) {
      if (_carromExpectedTurn === undefined) _carromExpectedTurn = _carromTurnId;
      if (_carromExpectedTurn !== _carromTurnId || _carromSettledTurn === _carromExpectedTurn) return;
      if (typeof _carromTimeoutReady !== "undefined" && _carromTimeoutReady && _carromTimeoutReady.round === _carromRoundId && _carromTimeoutReady.turn === _carromExpectedTurn) return;
      var _0x5a7eab = _0x157421;
      var _carromSettlementRound = _carromRoundId;
      if (!_0x3fddb3) return;
      if (_0x56abf7())
        return _0x338c29(function () {
          _0xbdafb3(_carromExpectedTurn);
        }, 0x32);
      _carromSettledTurn = _carromExpectedTurn;
      ((_0x1a373b = -0x1), _0x89ccbb());
      let _0x4e7344 = 0x1f4;
      if (_0x5d148e == 0x2) {
        _0x4268e2 = ![];
        let _0x3daed1 = _0x31089b[_0x5a7eab(0x3c6)](0x0);
        let _carromScoreCallbacks = [], _carromFreestyleReturns = [];
        let _carromQueenShot = {
          actor: _0x209883 ? 'player' : 'opponent',
          foul: !!_0x530863,
          queen: _0x3daed1.some(function (disc) { return disc._type === 0; }),
          ordinary: _0x3daed1.filter(function (disc) { return disc._type === 1 || disc._type === 2; }).length
        };
        for (
          let _0x4ffc4e = 0x0;
          _0x4ffc4e < _0x3daed1[_0x5a7eab(0x182)];
          _0x4ffc4e++
        ) {
          let _0x34b477 = _0x3daed1[_0x4ffc4e];
          let _carromScoredDiscType = _0x34b477._type;
          let _carromScoredQueueIndex = _0x4ffc4e;
          let _carromReturnFinished = false, _carromReturnFinish;
          if (_0x530863)
            Tweener[_0x5a7eab(0x3a0)](
              _0x34b477,
              {
                x: _0x4efd2a["x"] + _0x24c0ca["x"],
                y: _0x4efd2a["y"] + _0x24c0ca["y"],
                scaleX: 0x1,
                scaleY: 0x1,
                alpha: 0x1,
              },
              {
                time: 0x14 + Math[_0x5a7eab(0xec)]() * 0xa,
                transition: _0x5a7eab(0x1f9),
                onComplete: _carromReturnFinish = function (_0x2dbf9d) {
                  if (_carromReturnFinished) return;
                  _carromReturnFinished = true;
                  if (!_0x3fddb3 || _carromSettlementRound !== _carromRoundId || _carromExpectedTurn !== _carromTurnId) {
                    if (_0x34b477.parent) _0x34b477.parent.removeChild(_0x34b477);
                    return;
                  }
                  var _0x4d0914 = _0x5a7eab,
                    _0x29b9e7 = new _0x54e9a5(_0x2dbf9d["_type"], _0x3e9ee1);
                  ((_0x29b9e7[_0x4d0914(0x294)] = _0x2dbf9d["x"]),
                    (_0x29b9e7[_0x4d0914(0x1dd)] = _0x2dbf9d["y"]),
                    (_0x29b9e7[_0x4d0914(0x12e)] = _0x2dbf9d[_0x4d0914(0x12e)]),
                    _0xcf7ce5[_0x4d0914(0x37b)](_0x29b9e7),
                    (_0x29b9e7[_0x4d0914(0x43d)] = 0xa + _0x4efd2a["y"] / 0x64),
                    _0x1f3ae5(_0x29b9e7));
                  if (_0x2dbf9d[_0x4d0914(0x12e)] == _0x4d0914(0x2e5))
                    _0x3e4566[_0x4d0914(0x3b0)](_0x29b9e7);
                  else
                    _0x2dbf9d[_0x4d0914(0x12e)] == _0x4d0914(0x393)
                      ? _0x2a9c75["push"](_0x29b9e7)
                      : _0x3231b3[_0x4d0914(0x3b0)](_0x29b9e7);
                  _0x34b477[_0x4d0914(0x35d)]["removeChild"](_0x34b477);
                },
              },
            );
          else {
            // Commit queen points once at settlement; the flying text is presentation only.
            let _carromQueenPrecredited = _carromScoredDiscType === 0;
            let _carromScoreFinished = false, _carromScoreFinish;
            if (_carromQueenPrecredited) {
              let points = _0x1c2aac[0], actor = _0x209883 ? 'player' : 'opponent';
              _carromFreestyleHistory.push({type: 0, points: points, actor: actor, round: _carromSettlementRound, turn: _carromExpectedTurn, queueIndex: _carromScoredQueueIndex});
              if (_0x209883) { _0x4d3bf1 += points; _0x27ee82.value = _0x4d3bf1; _carromReportScore(_0x4d3bf1); }
              else { _0x41f634 += points; _0x458adc.value = _0x41f634; }
            }
            var _0x2e1e8a = new PIXI[_0x5a7eab(0x190)](
              "+" + _0x1c2aac[_0x34b477[_0x5a7eab(0x284)]],
              {
                font: _0x5a7eab(0x2d1),
                fill: 0xffffff,
                align: "right",
                wordWrap: !![],
                wordWrapWidth: 0x96,
              },
            );
            (_0x2e1e8a[_0x5a7eab(0x4a1)]["set"](0.5),
              (_0x2e1e8a["alpha"] = 0x1),
              (_0x2e1e8a["x"] = _0x34b477["x"]),
              (_0x2e1e8a["y"] = _0x34b477["y"]),
              (_0x2e1e8a[_0x5a7eab(0x4b7)] =
                _0x1c2aac[_0x34b477[_0x5a7eab(0x284)]]),
              _0xcf7ce5[_0x5a7eab(0x237)](_0x2e1e8a, 0x64),
              _0x209883
                ? Tweener["addTween"](
                    _0x2e1e8a,
                    {
                      x: _0x27ee82["x"],
                      y: _0x27ee82["y"],
                      scaleX: 0.9,
                      scaleY: 0.9,
                      alpha: 0x1,
                    },
                    {
                      time: 0xf + Math[_0x5a7eab(0xec)]() * 0xa,
                      transition: _0x5a7eab(0x1f9),
                      onComplete: _carromScoreFinish = function (_0x5046e0) {
                        if (_carromScoreFinished) return;
                        _carromScoreFinished = true;
                        if (!_0x3fddb3 || _carromSettlementRound !== _carromRoundId || _carromExpectedTurn !== _carromTurnId) {
                          if (_0x5046e0.parent) _0x5046e0.parent.removeChild(_0x5046e0);
                          return;
                        }
                        if (_carromQueenPrecredited) { if (_0x5046e0.parent) _0x5046e0.parent.removeChild(_0x5046e0); return; }
                        var _0x2fc50e = _0x5a7eab;
                        ((_0x4d3bf1 += _0x5046e0[_0x2fc50e(0x4b7)]),
                          _carromFreestyleHistory.push({type: _carromScoredDiscType, points: _0x5046e0[_0x2fc50e(0x4b7)], actor: 'player', round: _carromSettlementRound, turn: _carromExpectedTurn, queueIndex: _carromScoredQueueIndex}),
                          (_0x27ee82[_0x2fc50e(0x4b7)] = _0x4d3bf1),
                          _carromReportScore(_0x4d3bf1),
                          _0x5046e0[_0x2fc50e(0x35d)][_0x2fc50e(0x28c)](
                            _0x5046e0,
                          ));
                      },
                    },
                  )
                : Tweener[_0x5a7eab(0x3a0)](
                    _0x2e1e8a,
                    {
                      x: _0x458adc["x"],
                      y: _0x458adc["y"],
                      scaleX: 0.9,
                      scaleY: 0.9,
                      alpha: 0x1,
                    },
                    {
                      time: 0xf,
                      transition: _0x5a7eab(0x1f9),
                      onComplete: _carromScoreFinish = function (_0x3a8ce7) {
                        if (_carromScoreFinished) return;
                        _carromScoreFinished = true;
                        if (!_0x3fddb3 || _carromSettlementRound !== _carromRoundId || _carromExpectedTurn !== _carromTurnId) {
                          if (_0x3a8ce7.parent) _0x3a8ce7.parent.removeChild(_0x3a8ce7);
                          return;
                        }
                        if (_carromQueenPrecredited) { if (_0x3a8ce7.parent) _0x3a8ce7.parent.removeChild(_0x3a8ce7); return; }
                        var _0x5f191c = _0x5a7eab;
                        ((_0x41f634 += _0x3a8ce7[_0x5f191c(0x4b7)]),
                          _carromFreestyleHistory.push({type: _carromScoredDiscType, points: _0x3a8ce7[_0x5f191c(0x4b7)], actor: 'opponent', round: _carromSettlementRound, turn: _carromExpectedTurn, queueIndex: _carromScoredQueueIndex}),
                          (_0x458adc[_0x5f191c(0x4b7)] = _0x41f634),
                          _0x3a8ce7[_0x5f191c(0x35d)][_0x5f191c(0x28c)](
                            _0x3a8ce7,
                          ));
                      },
                    },
                  ),
              _0x34b477[_0x5a7eab(0x35d)][_0x5a7eab(0x28c)](_0x34b477));
            _carromScoreCallbacks.push({target: _0x2e1e8a, finish: _carromScoreFinish});
          }
          if (_carromReturnFinish) _carromFreestyleReturns.push({target: _0x34b477, finish: _carromReturnFinish});
          (_0x253500(_0x31089b, _0x34b477, !![]), (_0x4e7344 = 0x3e8));
        }
        let _carromPenaltyState = {pending: false};
        if (_0x530863 && _0x3daed1.length === 0)
          _carromPenaltyState.pending = _carromFreestylePenalty(_0x209883 ? 'player' : 'opponent', function () { _carromPenaltyState.pending = false; }, _carromPenaltyState);
        (_0x530863 && (_0x5ebd99 = ![]),
          _0x338c29(function () {
            _carromAwaitPenalty(_carromPenaltyState, function () {
            var _0x54c991 = _0x5a7eab;
            if (!_0x3fddb3 || _carromSettlementRound !== _carromRoundId || _carromExpectedTurn !== _carromTurnId) return;
            _carromFreestyleReturns.forEach(function (item) {
              item.target.x = _0x4efd2a.x + _0x24c0ca.x;
              item.target.y = _0x4efd2a.y + _0x24c0ca.y;
              item.finish(item.target);
            });
            // Commit any delayed flying-score animation before deciding this turn.
            _carromScoreCallbacks.forEach(function (item) {
              item.finish(item.target);
            });
            var queenDecision = window.CarromDiscRules.freestyleQueen(_carromFreestyleQueenState, _carromQueenShot);
            if (queenDecision.returnQueen && !_carromReturnFreestyleQueen(queenDecision.revokeOwner)) return;
            if (queenDecision.state.phase === 'pending' && _carromQueenShot.queen) queenDecision.state.points = _0x1c2aac[0];
            _carromFreestyleQueenState = queenDecision.state;
            if (_carromFreestyleQueenState.phase !== 'pending' && (_0x4d3bf1 >= _0x153877 || _0x41f634 >= _0x153877)) {
              var playerQualified = _0x4d3bf1 >= _0x153877, opponentQualified = _0x41f634 >= _0x153877;
              _0x47e567(playerQualified && opponentQualified ? !!_0x209883 : playerQualified);
              return;
            }
            if (_0x4268e2 && !_0x5ebd99) {
              (_0x52e61d(), (_0x4268e2 = ![]));
              if (_0x209883) _0x4d3bf1 -= 0x32;
              else _0x41f634 -= 0x32;
              ((_0x458adc[_0x54c991(0x4b7)] = _0x41f634),
                (_0x27ee82["value"] = _0x4d3bf1),
                _0x209883 && _carromReportScore(_0x4d3bf1));
            }
            _0x55e693 = ![];
            if (_0x209883) {
              if (_0x5ebd99) _0x5e7a5f();
              else _0x50a0ff();
            } else {
              if (_0x5ebd99) _0x50a0ff();
              else _0x5e7a5f();
            }
            });
          }, _0x4e7344));
      } else {
        let _0xa4bcff = _0x31089b[_0x5a7eab(0x3c6)](0x0);
        let _carromNormalCallbacks = [], _carromNormalReturns = [];
        for (
          let _0x31a678 = 0x0;
          _0x31a678 < _0xa4bcff[_0x5a7eab(0x182)];
          _0x31a678++
        ) {
          let _0x2afb4d = _0xa4bcff[_0x31a678];
          let _carromNormalFinished = false, _carromNormalFinish, _carromNormalReturnFinish;
          if (
            _0x530863 &&
            (_0x2afb4d["type"] == _0x5a7eab(0xf8) ||
              (_0x209883 && _0x2afb4d[_0x5a7eab(0x12e)] == _0x5a7eab(0x2e5)) ||
              (!_0x209883 && _0x2afb4d[_0x5a7eab(0x12e)] == _0x5a7eab(0x393)))
          )
            Tweener[_0x5a7eab(0x3a0)](
              _0x2afb4d,
              {
                x: _0x4efd2a["x"] + _0x24c0ca["x"],
                y: _0x4efd2a["y"] + _0x24c0ca["y"],
                scaleX: 0x1,
                scaleY: 0x1,
                alpha: 0x1,
              },
              {
                time: 0x14 + Math[_0x5a7eab(0xec)]() * 0xa,
                transition: _0x5a7eab(0x1f9),
                onComplete: _carromNormalReturnFinish = function (_0x53eb5c) {
                  if (_carromNormalFinished) return;
                  _carromNormalFinished = true;
                  if (!_0x3fddb3 || _carromSettlementRound !== _carromRoundId || _carromExpectedTurn !== _carromTurnId) {
                    if (_0x2afb4d.parent) _0x2afb4d.parent.removeChild(_0x2afb4d);
                    return;
                  }
                  var _0x1c46c9 = _0x5a7eab,
                    _0x54e9c1 = new _0x54e9a5(_0x53eb5c["_type"], _0x3e9ee1);
                  ((_0x54e9c1[_0x1c46c9(0x294)] = _0x53eb5c["x"]),
                    (_0x54e9c1[_0x1c46c9(0x1dd)] = _0x53eb5c["y"]),
                    (_0x54e9c1[_0x1c46c9(0x12e)] = _0x53eb5c[_0x1c46c9(0x12e)]),
                    _0xcf7ce5["addChild"](_0x54e9c1),
                    (_0x54e9c1["zOrder"] = 0xa + _0x4efd2a["y"] / 0x64),
                    _0x1f3ae5(_0x54e9c1));
                  if (_0x53eb5c[_0x1c46c9(0x12e)] == _0x1c46c9(0x2e5))
                    _0x3e4566[_0x1c46c9(0x3b0)](_0x54e9c1);
                  else
                    _0x53eb5c[_0x1c46c9(0x12e)] == _0x1c46c9(0x393)
                      ? _0x2a9c75[_0x1c46c9(0x3b0)](_0x54e9c1)
                      : _0x3231b3["push"](_0x54e9c1);
                  _0x2afb4d["parent"][_0x1c46c9(0x28c)](_0x2afb4d);
                },
              },
            );
          else {
            if (_0x2afb4d[_0x5a7eab(0x12e)] == _0x5a7eab(0x2e5))
              ((_0x2afb4d[_0x5a7eab(0x43d)] = 0x6e),
                Tweener[_0x5a7eab(0x3a0)](
                  _0x2afb4d,
                  {
                    x: _0x539ff8["x"],
                    y: _0x539ff8["y"],
                    scaleX: 0.9,
                    scaleY: 0.9,
                    alpha: 0x1,
                  },
                  {
                    time: 0x14 + Math[_0x5a7eab(0xec)]() * 0xa,
                    transition: _0x5a7eab(0x1f9),
                    onComplete: _carromNormalFinish = function () {
                      if (_carromNormalFinished) return;
                      _carromNormalFinished = true;
                      if (!_0x3fddb3 || _carromSettlementRound !== _carromRoundId || _carromExpectedTurn !== _carromTurnId) {
                        if (_0x2afb4d.parent) _0x2afb4d.parent.removeChild(_0x2afb4d);
                        return;
                      }
                      var _0x2ef382 = _0x5a7eab;
                      (_0x4d3bf1++,
                        (_0x539ff8[_0x2ef382(0x4b7)] = _0x4d3bf1),
                        _carromReportScore(_0x4d3bf1),
                        _0x2afb4d[_0x2ef382(0x35d)][_0x2ef382(0x28c)](
                          _0x2afb4d,
                        ));
                    },
                  },
                ));
            else
              _0x2afb4d[_0x5a7eab(0x12e)] == "oponent" &&
                ((_0x2afb4d[_0x5a7eab(0x43d)] = 0x6e),
                Tweener[_0x5a7eab(0x3a0)](
                  _0x2afb4d,
                  {
                    x: _0x25b85f["x"],
                    y: _0x25b85f["y"],
                    scaleX: 0.9,
                    scaleY: 0.9,
                    alpha: 0x1,
                  },
                  {
                    time: 0x14,
                    transition: "easeOutQuad",
                    onComplete: _carromNormalFinish = function () {
                      if (_carromNormalFinished) return;
                      _carromNormalFinished = true;
                      if (!_0x3fddb3 || _carromSettlementRound !== _carromRoundId || _carromExpectedTurn !== _carromTurnId) {
                        if (_0x2afb4d.parent) _0x2afb4d.parent.removeChild(_0x2afb4d);
                        return;
                      }
                      var _0xb21829 = _0x5a7eab;
                      (_0x41f634++,
                        (_0x25b85f[_0xb21829(0x4b7)] = _0x41f634),
                        _0x2afb4d[_0xb21829(0x35d)][_0xb21829(0x28c)](
                          _0x2afb4d,
                        ));
                    },
                  },
                ));
          }
          if (_carromNormalReturnFinish) _carromNormalReturns.push({target: _0x2afb4d, finish: _carromNormalReturnFinish});
          if (_carromNormalFinish) _carromNormalCallbacks.push(_carromNormalFinish);
          (_0x253500(_0x31089b, _0x2afb4d, !![]), (_0x4e7344 = 0x3e8));
        }
        if (_0x530863) {
          if (_0x5d148e === 1 && _carromQueenClearedThisShot) _0x4268e2 = true;
          if (!_0x5ebd99) _0x464a16(_0x209883);
          _0x5ebd99 = ![];
        }
        _0x338c29(function () {
          var _0x5a144c = _0x5a7eab;
          if (!_0x3fddb3 || _carromSettlementRound !== _carromRoundId || _carromExpectedTurn !== _carromTurnId) return;
          _carromNormalReturns.forEach(function (item) {
            item.target.x = _0x4efd2a.x + _0x24c0ca.x;
            item.target.y = _0x4efd2a.y + _0x24c0ca.y;
            item.finish(item.target);
          });
          _carromNormalCallbacks.forEach(function (finish) { finish(); });
          if (window.CarromDiscRules.hasWon(_0x5d148e, _0x408018, _0x4d3bf1) || window.CarromDiscRules.hasWon(_0x5d148e, _0x408018, _0x41f634)) {
            _0x209883
              ? window.CarromDiscRules.hasWon(_0x5d148e, _0x408018, _0x4d3bf1) && !_0x3231b3[_0x5a144c(0x182)]
                ? _0x47e567(!![])
                : _0x47e567(![])
              : window.CarromDiscRules.hasWon(_0x5d148e, _0x408018, _0x41f634) && !_0x3231b3[_0x5a144c(0x182)]
                ? _0x47e567(![])
                : _0x47e567(!![]);
            return;
          }
          var _carromAdvanceNormalTurn = function () {
            if (!_0x3fddb3 || _carromSettlementRound !== _carromRoundId || _carromExpectedTurn !== _carromTurnId) return;
            _0x55e693 = ![];
            if (_0x209883) {
              if (_0x5ebd99) _0x5e7a5f();
              else _0x50a0ff();
            } else {
              if (_0x5ebd99) _0x50a0ff();
              else _0x5e7a5f();
            }
          };
          if (_0x5d148e === 1 && _0x4268e2 && !_0x5ebd99 && !_0x404020 && _carromPendingQueenPocket) {
            Tweener.extract(_carromPendingQueenPocket);
            _0x404020 = _carromPendingQueenPocket;
            _carromPendingQueenPocket = null;
          }
          if (_0x5d148e === 1 && _0x4268e2 && !_0x5ebd99 && _0x404020) {
            _0x52e61d(function () {
              if (!_0x3fddb3 || _carromSettlementRound !== _carromRoundId || _carromExpectedTurn !== _carromTurnId) return;
              _0x4268e2 = ![];
              _0x337f1a[_0x5a144c(0x197)] = ![];
              _carromAdvanceNormalTurn();
            });
            return;
          }
          _0x4268e2 &&
            !_0x5ebd99 &&
            (_0x52e61d(),
            (_0x4268e2 = ![]),
            (_0x337f1a[_0x5a144c(0x197)] = ![]));
          _carromAdvanceNormalTurn();
        }, _0x4e7344);
      }
    }
    function _0x1f3ae5(_0x3c8ca2) {
      var _0x5193b8 = _0x157421,
        _0x5561fc = _0x3c8ca2[_0x5193b8(0x294)],
        _0x19c2bb = _0x3c8ca2[_0x5193b8(0x1dd)];
      if (_0x23a7dc({ x: _0x5561fc, y: _0x19c2bb }, 0x20))
        for (let _0x289a75 = 0x0; _0x289a75 < 0x64; _0x289a75 += 0x2) {
          if (
            !_0x23a7dc(
              { x: _0x5561fc + _0x289a75, y: _0x19c2bb },
              0x20,
            )
          ) {
            _0x5561fc = _0x5561fc + _0x289a75;
            break;
          } else {
            if (
              !_0x23a7dc(
                { x: _0x5561fc - _0x289a75, y: _0x19c2bb },
                0x20,
              )
            ) {
              _0x5561fc = _0x5561fc - _0x289a75;
              break;
            }
          }
          if (
            !_0x23a7dc(
              { x: _0x5561fc, y: _0x19c2bb + _0x289a75 },
              0x20,
            )
          ) {
            _0x19c2bb = _0x19c2bb + _0x289a75;
            break;
          } else {
            if (
              !_0x23a7dc(
                { x: _0x5561fc, y: _0x19c2bb - _0x289a75 },
                0x20,
              )
            ) {
              _0x19c2bb = _0x19c2bb - _0x289a75;
              break;
            }
          }
        }
      // If all four axis searches are blocked, try nearby diagonal positions.
      if (_0x23a7dc({ x: _0x5561fc, y: _0x19c2bb }, 0x20)) {
        var _carromReturnFound = false;
        for (var _carromReturnOffset = 2; _carromReturnOffset < 100 && !_carromReturnFound; _carromReturnOffset += 2) {
          for (var _carromReturnX = -1; _carromReturnX <= 1 && !_carromReturnFound; _carromReturnX += 2) {
            for (var _carromReturnY = -1; _carromReturnY <= 1; _carromReturnY += 2) {
              var _carromReturnCandidate = {x: _0x5561fc + _carromReturnX * _carromReturnOffset, y: _0x19c2bb + _carromReturnY * _carromReturnOffset};
              if (!_0x23a7dc(_carromReturnCandidate, 0x20)) {
                _0x5561fc = _carromReturnCandidate.x;
                _0x19c2bb = _carromReturnCandidate.y;
                _carromReturnFound = true;
                break;
              }
            }
          }
        }
        // A bounded grid also checks gaps between the axis and diagonal rays.
        for (var _carromRing = 8; _carromRing <= 96 && !_carromReturnFound; _carromRing += 8) {
          for (var _carromGridX = -_carromRing; _carromGridX <= _carromRing && !_carromReturnFound; _carromGridX += 8) {
            for (var _carromGridY = -_carromRing; _carromGridY <= _carromRing; _carromGridY += 8) {
              if (Math.abs(_carromGridX) !== _carromRing && Math.abs(_carromGridY) !== _carromRing) continue;
              var _carromGridPoint = {x: _0x5561fc + _carromGridX, y: _0x19c2bb + _carromGridY};
              if (!_0x23a7dc(_carromGridPoint, 0x20)) {
                _0x5561fc = _carromGridPoint.x;
                _0x19c2bb = _carromGridPoint.y;
                _carromReturnFound = true;
                break;
              }
            }
          }
        }
      }
      ((_0x3c8ca2["worldX"] = _0x5561fc), (_0x3c8ca2["worldY"] = _0x19c2bb));
    }
    function _0x50a0ff() {
      _carromQueenClearedThisShot = false;
      var _carromAiTurn = ++_carromTurnId;
      var _0x50f23a = _0x157421;
      ((_0x3a1262 = !![]),
        (_0x1a373b = _0x1f57de),
        (_0x44d1ad["frame"][_0x50f23a(0x4b7)] = 0x64),
        (_0x530863 = ![]),
        (_0x5ebd99 = ![]),
        (_0x209883 = ![]),
        _0x147a99[_0x50f23a(0x12d)](![]),
        (_0x27e1b4[_0x50f23a(0x197)] = !![]),
        (_0x27e1b4[_0x50f23a(0xe5)] = 0x1),
        (_0x27e1b4[_0x50f23a(0x3f1)][_0x50f23a(0x197)] = ![]),
        _0x27e1b4[_0x50f23a(0x4c3)](!![]),
        (_0x27e1b4["sprite"][_0x50f23a(0x335)] =
          PIXI["utils"][_0x50f23a(0x299)][_0x427440[0x0]["texture"]]),
        (_0x27e1b4[_0x50f23a(0x294)] = 0x140),
        (_0x27e1b4[_0x50f23a(0x1dd)] = _0x429ae3 - 0xc8),
        (_0x27e1b4[_0x50f23a(0xe5)] = 0x0),
        Tweener["addTween"](
          _0x27e1b4,
          {
            worldX: 0x140,
            worldY: _0x429ae3,
            alpha: 0x1,
            scaleX: 0x1,
            scaleY: 0x1,
          },
          { time: 0xf, transition: _0x50f23a(0x1f9) },
        ),
        _0x338c29(function () {
          var _0x46f397 = _0x50f23a;
          if (!_0x3fddb3 || _carromAiTurn !== _carromTurnId) return;
          _0x27e1b4[_0x46f397(0x152)]();
          let _0x3a3b87, _0x28e19e, _0x51885a, _0x34f6fb;
          _0x5d148e == 0x2
            ? ((_0x3a3b87 = _0x52106f(
                _0x2fc10d[0x0],
                _0x2a9c75["concat"](_0x3e4566, _0x3231b3),
                !![],
              )),
              (_0x28e19e = _0x25af2a(
                _0x2fc10d[0x1],
                _0x2a9c75["concat"](_0x3e4566, _0x3231b3),
                !![],
              )),
              (_0x51885a = _0x521eef(
                _0x2fc10d[0x2],
                _0x2a9c75[_0x46f397(0x1c0)](_0x3e4566, _0x3231b3),
                !![],
              )),
              (_0x34f6fb = _0x30849b(
                _0x2fc10d[0x3],
                _0x2a9c75[_0x46f397(0x1c0)](_0x3e4566, _0x3231b3),
                !![],
              )))
            : _0x2a9c75["length"] == 0x1 && _0x3231b3[_0x46f397(0x182)]
              ? ((_0x3a3b87 = _0x52106f(_0x2fc10d[0x0], _0x3231b3, !![])),
                (_0x28e19e = _0x25af2a(_0x2fc10d[0x1], _0x3231b3, !![])),
                (_0x51885a = _0x521eef(_0x2fc10d[0x2], _0x3231b3, !![])),
                (_0x34f6fb = _0x30849b(_0x2fc10d[0x3], _0x3231b3, !![])))
              : ((_0x3a3b87 = _0x52106f(_0x2fc10d[0x0], _0x2a9c75, !![])),
                (_0x28e19e = _0x25af2a(_0x2fc10d[0x1], _0x2a9c75, !![])),
                (_0x51885a = _0x521eef(_0x2fc10d[0x2], _0x2a9c75, !![])),
                (_0x34f6fb = _0x30849b(_0x2fc10d[0x3], _0x2a9c75, !![])));
          let _0x17e77e = [][_0x46f397(0x1c0)](
            _0x3a3b87,
            _0x28e19e,
            _0x51885a,
            _0x34f6fb,
          );
          _0x17e77e = _0x17e77e.filter(function (candidate) {
            return candidate && candidate.pos && Number.isFinite(candidate.pos.x) &&
              Number.isFinite(candidate.pos.y) && Number.isFinite(candidate.dir) &&
              Number.isFinite(candidate.hDot) && Number.isFinite(candidate.dist) && candidate.dist >= 0 &&
              candidate.pos.x >= _0x55e1a0 && candidate.pos.x <= _0x187453 &&
              candidate.pos.y === _0x429ae3 &&
              !_0x23a7dc(candidate.pos, _0x133600 + 0x10);
          });
          if (_0x17e77e[_0x46f397(0x182)]) {
            _0x17e77e[_0x46f397(0x22d)](
              (_0x52fdd4, _0x196fad) =>
                _0x196fad[_0x46f397(0x3f0)] - _0x52fdd4[_0x46f397(0x3f0)],
            );
            let _0x321dde = _0x17e77e[0x0][_0x46f397(0x32c)];
            _0xd6b627(
              _0x17e77e[0x0],
              (_0x321dde / 0x64) * 0x3c * 0.2 * 1.1 * 1.25,
            );
          } else {
            var _carromFallback = _0x3d12d7();
            if (!_carromFallback) { _0x24bb4a(); if (((_0x5d148e === 1 && _0x4268e2) || (_0x5d148e === 2 && _carromFreestyleQueenState.phase === "pending"))) { _carromAiShotTurn = _carromTurnId; _0x5ebd99 = false; _0xbdafb3(_carromTurnId); } else _0x5e7a5f(); return; }
            _0xd6b627(_carromFallback, 0x64);
          }
        }, 0x1f4));
    }
    function _0x5e7a5f() {
      _carromQueenClearedThisShot = false;
      ++_carromTurnId;
      var _0x57aab0 = _0x157421;
      ((_0x3a1262 = !![]),
        (_0x1a373b = _0x1f57de),
        (_0x2cf38a[_0x57aab0(0x39a)][_0x57aab0(0x4b7)] = 0x64),
        (_0x530863 = ![]),
        (_0x5ebd99 = ![]),
        (_0x55e693 = !![]),
        (_0x209883 = !![]),
        _0x147a99["setEnable"](!![]),
        (_0x147a99[_0x57aab0(0x4b7)] = 0.5),
        (_0x27e1b4[_0x57aab0(0x197)] = !![]),
        (_0x27e1b4[_0x57aab0(0x43d)] = 0x32),
        (_0x27e1b4[_0x57aab0(0xe5)] = 0x1),
        (_0x27e1b4[_0x57aab0(0x3f1)][_0x57aab0(0x197)] = ![]),
        _0x27e1b4["setSensor"](!![]),
        (_0x27e1b4["sprite"][_0x57aab0(0x335)] =
          PIXI["utils"][_0x57aab0(0x299)][
            _0x427440[_0x4b3012][_0x57aab0(0x335)]
          ]),
        (_0x27e1b4[_0x57aab0(0x294)] = 0x140),
        (_0x27e1b4[_0x57aab0(0x1dd)] = 0x2be + 0x7e + 0xc8),
        (_0x27e1b4["alpha"] = 0x0),
        Tweener["addTween"](
          _0x27e1b4,
          {
            worldX: 0x140,
            worldY: 0x2be + 0x7e,
            alpha: 0x1,
            scaleX: 0x1,
            scaleY: 0x1,
          },
          {
            time: 0xf,
            transition: _0x57aab0(0x1f9),
            onComplete: function () {
              var _0x4e7759 = _0x57aab0;
              (_0x41684e(), (_0x27e1b4[_0x4e7759(0x325)]["visible"] = !![]));
            },
          },
        ),
        _0x183856 && _0x14cbdd == 0x0 && _0x25e9ed(0x0));
    }
    function _0x41684e() {
      var _0xfe66ed = _0x157421;
      if (_0x23a7dc(_0x27e1b4, _0x133600 + 0x10)) {
        let _0x3e8706 = _0x27e1b4["x"],
          _0xc9112e = _0x27e1b4["y"];
        for (
          let _0x4a1b72 = 0x0;
          _0x4a1b72 < _0x187453 - _0x55e1a0;
          _0x4a1b72 += 0x2
        ) {
          if (
            _0x3e8706 + _0x4a1b72 < _0x187453 &&
            !_0x23a7dc(
              { x: _0x3e8706 + _0x4a1b72, y: _0xc9112e },
              _0x133600 + 0x10,
            )
          ) {
            ((_0x27e1b4["worldX"] = _0x3e8706 + _0x4a1b72),
              (_0x147a99["value"] =
                (_0x27e1b4[_0xfe66ed(0x294)] - _0x55e1a0) /
                (_0x187453 - _0x55e1a0)),
              (_0x27e1b4[_0xfe66ed(0xe5)] = 0x1),
              (_0x27e1b4[_0xfe66ed(0x3f1)][_0xfe66ed(0x197)] = ![]));
            return;
          } else {
            if (
              _0x3e8706 - _0x4a1b72 > _0x55e1a0 &&
              !_0x23a7dc(
                { x: _0x3e8706 - _0x4a1b72, y: _0xc9112e },
                _0x133600 + 0x10,
              )
            ) {
              ((_0x27e1b4["worldX"] = _0x3e8706 - _0x4a1b72),
                (_0x147a99[_0xfe66ed(0x4b7)] =
                  (_0x27e1b4[_0xfe66ed(0x294)] - _0x55e1a0) /
                  (_0x187453 - _0x55e1a0)),
                (_0x27e1b4[_0xfe66ed(0xe5)] = 0x1),
                (_0x27e1b4["overlay"][_0xfe66ed(0x197)] = ![]));
              return;
            }
          }
        }
        var _carromPlayerOpenX = _carromFindOpenBaseline(_0xc9112e);
        if (_carromPlayerOpenX !== null) {
          _0x27e1b4.worldX = _carromPlayerOpenX;
          _0x147a99.value = (_carromPlayerOpenX - _0x55e1a0) / (_0x187453 - _0x55e1a0);
          _0x27e1b4.alpha = 1;
          _0x27e1b4.overlay.visible = false;
        }
      }
    }
    function _0x36ab44(_carromEvent) {
      var _0x29ef4e = _0x157421;
      if (_0x3e61d0 || _carromHostPaused) return;
      if (_0x183856 && _0x14cbdd == 0x0) return;
      if (!_0x55e693 || !_0x209883) return;
      if (_0xf86500) return;
      if (!_carromEvent || !_carromEvent.data || _carromEvent.data.identifier == null) return;
      _carromAimPointerId = _carromEvent.data.identifier;
      _carromAimNativePointerId = _carromEvent.data.originalEvent && typeof _carromEvent.data.originalEvent.pointerId === "number" ? _carromEvent.data.originalEvent.pointerId : null;
      _carromAimPointerType = _carromEvent.data.pointerType || null;
      ((_0xf86500 = !![]),
        _0x183856 && _0x14cbdd == 0x1 && _0x279414(0x2),
        (_0xc5bee4[_0x29ef4e(0x197)] = !![]),
        (_0xc5bee4[_0x29ef4e(0x2a0)] = 0x0),
        (_0xc5bee4["x"] = _0x27e1b4["x"]),
        (_0xc5bee4["y"] = _0x27e1b4["y"]));
    }
    function _carromFinishTutorialAfterShot() {
      if (!_0x183856 || _0x14cbdd != 0x1) return;
      try { _0x279414(0x1); }
      catch (_carromTutorialSaveError) { console.warn("Carrom tutorial completion failed"); }
    }
    function _0x1e39ba(_0x30192f) {
      var _carromPlayerShotTurn = _carromTurnId;
      var _0x10c900 = _0x157421;
      if (_0x3e61d0 || _carromHostPaused) { _0xf86500 = false; _carromAimPointerId = null; _carromAimNativePointerId = null; _carromAimPointerType = null; _0xc5bee4.visible = false; _0xc5bee4.strength = 0; return; }
      if (!_0xf86500) return;
      if (_carromAimPointerId != null && (!_0x30192f || !_0x30192f.data || _0x30192f.data.identifier !== _carromAimPointerId)) return;
      if (_carromAimPointerType && _0x30192f && _0x30192f.data && _0x30192f.data.pointerType && _0x30192f.data.pointerType !== _carromAimPointerType) return;
      _carromAimPointerId = null;
      _carromAimNativePointerId = null;
      _carromAimPointerType = null;
      ((_0xf86500 = ![]),
        (_0xc5bee4["visible"] = ![]),
        _0xc5bee4[_0x10c900(0x2a0)] >= 0.25 &&
          (_0x27e1b4[_0x10c900(0x1cd)](
            _0xc5bee4["strength"] * _0x301cde * 1.25,
            0x2 * Math["PI"] - _0xc5bee4[_0x10c900(0x1d4)],
          ),
          _carromFinishTutorialAfterShot(),
          _0x24bb4a(),
          _0x338c29(function () {
            _0xbdafb3(_carromPlayerShotTurn);
          }, 0x8fc)));
      if (_0x183856 && _0x14cbdd == 0x1 && _0xc5bee4.strength < 0.25) _0x25e9ed(0x1);
    }
    function _0x536112(_0x20d729) {
      var _0x4630df = _0x157421;
      if (!_0xf86500) return;
      if (_carromAimPointerId != null && (!_0x20d729 || !_0x20d729.data || _0x20d729.data.identifier !== _carromAimPointerId)) return;
      if (_carromAimPointerType && _0x20d729 && _0x20d729.data && _0x20d729.data.pointerType && _0x20d729.data.pointerType !== _carromAimPointerType) return;
      let _0x24dee2 = {
          x:
            _0x20d729[_0x4630df(0x3ca)][_0x4630df(0x192)]["x"] -
            _0x24b13c / 0x2,
          y: _0x20d729["data"][_0x4630df(0x192)]["y"] - _0x376ce3 / 0x2,
        },
        _0x26ab5d = _0x2bd695(_0x27e1b4, _0x24dee2),
        _0x1d5eea = _0x8b2762(_0x27e1b4, _0x24dee2);
      if (_0x26ab5d > _0x647bf3) _0x26ab5d = _0x647bf3;
      ((_0xc5bee4["strength"] = _0x26ab5d / _0x647bf3),
        (_0xc5bee4[_0x4630df(0x1d4)] = _0x1d5eea));
    }
    function _carromCaptureAiBoard() {
      var result = [];
      [_0x3e4566, _0x2a9c75, _0x3231b3].forEach(function (group, groupIndex) {
        group.forEach(function (disc) {
          result.push({disc: disc, group: groupIndex, x: disc && disc.x, y: disc && disc.y});
        });
      });
      return result;
    }
    function _carromAiBoardChanged(snapshot) {
      if (!snapshot) return true;
      var savedByDisc = new Map();
      for (var i = 0; i < snapshot.length; i++) {
        var saved = snapshot[i];
        if (!saved || !saved.disc || savedByDisc.has(saved.disc)) return true;
        savedByDisc.set(saved.disc, saved);
      }
      var groups = [_0x3e4566, _0x2a9c75, _0x3231b3], count = 0;
      for (var groupIndex = 0; groupIndex < groups.length; groupIndex++) {
        for (var j = 0; j < groups[groupIndex].length; j++) {
          var disc = groups[groupIndex][j], entry = savedByDisc.get(disc);
          if (!disc || !entry || entry.group !== groupIndex || !Number.isFinite(disc.x) || !Number.isFinite(disc.y) ||
              !Number.isFinite(entry.x) || !Number.isFinite(entry.y) ||
              Math.abs(disc.x - entry.x) > 1 || Math.abs(disc.y - entry.y) > 1) return true;
          savedByDisc.delete(disc);
          count++;
        }
      }
      return count !== snapshot.length;
    }
    function _0xd6b627(_0x232fd1, _0x1f0de3) {
      if (!_0x232fd1 || !_0x232fd1.pos || !Number.isFinite(_0x232fd1.pos.x) || !Number.isFinite(_0x232fd1.pos.y) || !Number.isFinite(_0x232fd1.dir) || !Number.isFinite(_0x1f0de3)) {
        if (_0x3fddb3 && _0x209883 === false && _carromAiShotTurn !== _carromTurnId) {
          _carromAiShotTurn = _carromTurnId; _0x24bb4a(); if (((_0x5d148e === 1 && _0x4268e2) || (_0x5d148e === 2 && _carromFreestyleQueenState.phase === "pending"))) { _carromAiShotTurn = _carromTurnId; _0x5ebd99 = false; _0xbdafb3(_carromTurnId); } else _0x5e7a5f();
        }
        return;
      }
      _0x232fd1._carromBoardSnapshot = _carromCaptureAiBoard();
      var _0x18b010 = _0x157421;
      ((_0x27e1b4[_0x18b010(0x1dd)] = _0x232fd1[_0x18b010(0x4cf)]["y"]),
        _0x4662ac(_0x232fd1, _0x1f0de3, 0x0));
      return;
      ((_0x27e1b4[_0x18b010(0x294)] = _0x232fd1[_0x18b010(0x4cf)]["x"]),
        (_0x27e1b4["worldY"] = _0x232fd1[_0x18b010(0x4cf)]["y"]),
        _0x27e1b4[_0x18b010(0x1cd)](
          _0x1f0de3,
          Math["PI"] - _0x232fd1[_0x18b010(0x2ae)],
        ),
        _0x24bb4a(),
        _0x338c29(function () {
          _0xbdafb3();
        }, 0x1388));
    }
    function _0x4662ac(_0x2c688c, _0x491246, _0x17bf57) {
      var _0x16cdcf = _0x157421;
      var _carromAiRound = _carromRoundId, _carromAiMoveTurn = _carromTurnId;
      let _0x37f716 = 0x0;
      if (Math["random"]() > 0.5 || _0x17bf57 > 0x2)
        ((_0x37f716 = _0x2c688c[_0x16cdcf(0x4cf)]["x"]),
          Tweener[_0x16cdcf(0x3a0)](
            _0x27e1b4,
            { x: _0x37f716 },
            {
              time: 0x14 + Math[_0x16cdcf(0xec)]() * 0xa,
              transition: _0x16cdcf(0x1a6),
              onComplete: function () {
                if (_0x3fddb3 && _carromAiRound === _carromRoundId && _carromAiMoveTurn === _carromTurnId) _0x223471(_0x2c688c, _0x491246);
              },
            },
          ));
      else {
        _0x37f716 =
          _0x2c688c["pos"]["x"] - 0x46 + Math[_0x16cdcf(0xec)]() * 0x8c;
        if (_0x37f716 < _0x55e1a0) _0x37f716 = _0x55e1a0;
        else {
          if (_0x37f716 > _0x187453) _0x37f716 = _0x187453;
        }
        Tweener["addTween"](
          _0x27e1b4,
          { x: _0x37f716 },
          {
            time: 0x14 + Math[_0x16cdcf(0xec)]() * 0xa,
            transition: _0x16cdcf(0x1a6),
            onComplete: function () {
              if (_0x3fddb3 && _carromAiRound === _carromRoundId && _carromAiMoveTurn === _carromTurnId) _0x4662ac(_0x2c688c, _0x491246, ++_0x17bf57);
            },
          },
        );
      }
    }
    function _0x223471(_0xcc3517, _0x464ba8) {
      var _0x34ee5c = _0x157421;
      var _carromAimRound = _carromRoundId, _carromAimTurn = _carromTurnId;
      // Keep the opponent's shot within the same maximum as the player's input.
      _0x464ba8 = Math.min(_0x464ba8, _0x301cde * 1.25);
      let _0x11e6d1 = _0x18e0e1[_0x408018];
      ((_0xc5bee4["visible"] = !![]),
        (_0xc5bee4["x"] = _0x27e1b4["x"]),
        (_0xc5bee4["y"] = _0x27e1b4["y"]));
      let _0x3de4be =
          (Math["PI"] - _0xcc3517[_0x34ee5c(0x2ae)] - 0x2 * Math["PI"]) * -0x1,
        _0x3c208d = _0x464ba8 / (_0x301cde * 1.25),
        _0x30de27 = 0x0;
      if (_0x3c208d > 0x1) _0x3c208d = 0x1;
      (Math[_0x34ee5c(0xec)]() < _0x11e6d1 &&
        (Math[_0x34ee5c(0xec)]() > 0.5
          ? (_0x30de27 = -0.05 - Math["random"]() * 0.05)
          : (_0x30de27 = 0.05 + Math["random"]() * 0.05)),
        (_0x3de4be -= _0x30de27),
        (_0xc5bee4[_0x34ee5c(0x1d4)] = _0x3de4be),
        (_0xc5bee4[_0x34ee5c(0x2a0)] = 0x0),
        Tweener["addTween"](
          _0xc5bee4,
          { strength: _0x3c208d, angle: _0x3de4be },
          {
            time: 0xa + Math[_0x34ee5c(0xec)]() * 0xa,
            transition: _0x34ee5c(0x1a6),
            onComplete: function () {
              if (_0x3fddb3 && _carromAimRound === _carromRoundId && _carromAimTurn === _carromTurnId)
                _0x338c29(function () {
                  if (!_0x3fddb3 || _carromAimTurn !== _carromTurnId) return;
                  _0x4b3cc6(_0xcc3517, _0x464ba8, _0x30de27);
                }, 0x1f4);
            },
          },
        ));
    }
    function _0x4b3cc6(_0x412177, _0x3e3780, _0x323212) {
      var _carromBotShotTurn = _carromTurnId;
      if (!_0x3fddb3 || _carromAiShotTurn === _carromTurnId) return;
      if (!_0x412177 || !_0x412177.pos || !Number.isFinite(_0x412177.pos.x) || !Number.isFinite(_0x412177.pos.y) || !Number.isFinite(_0x412177.dir) || !Number.isFinite(_0x3e3780) || !Number.isFinite(_0x323212)) {
        if (_0x209883 === false) { _carromAiShotTurn = _carromTurnId; _0x24bb4a(); if (((_0x5d148e === 1 && _0x4268e2) || (_0x5d148e === 2 && _carromFreestyleQueenState.phase === "pending"))) { _carromAiShotTurn = _carromTurnId; _0x5ebd99 = false; _0xbdafb3(_carromTurnId); } else _0x5e7a5f(); }
        return;
      }
      if ((_0x412177._carromBoardSnapshot && _carromAiBoardChanged(_0x412177._carromBoardSnapshot)) || _0x412177.pos.x < _0x55e1a0 || _0x412177.pos.x > _0x187453 || _0x412177.pos.y !== _0x429ae3 || _0x23a7dc(_0x412177.pos, _0x133600 + 0x10)) {
        if (_carromAiRetryTurn !== _carromTurnId) { _carromAiRetryTurn = _carromTurnId; _carromAiRetryCount = 0; }
        var _carromRetryShot = ++_carromAiRetryCount <= 2 ? _0x3d12d7() : null;
        if (_carromRetryShot) _0xd6b627(_carromRetryShot, 100);
        else { _0x24bb4a(); if (((_0x5d148e === 1 && _0x4268e2) || (_0x5d148e === 2 && _carromFreestyleQueenState.phase === "pending"))) { _carromAiShotTurn = _carromTurnId; _0x5ebd99 = false; _0xbdafb3(_carromTurnId); } else _0x5e7a5f(); }
        return;
      }
      _carromAiShotTurn = _carromTurnId;
      var _0x2643c5 = _0x157421;
      ((_0xc5bee4[_0x2643c5(0x197)] = ![]),
        (_0x27e1b4[_0x2643c5(0x294)] = _0x412177[_0x2643c5(0x4cf)]["x"]),
        (_0x27e1b4[_0x2643c5(0x1dd)] = _0x412177[_0x2643c5(0x4cf)]["y"]),
        _0x27e1b4[_0x2643c5(0x1cd)](
          _0x3e3780,
          Math["PI"] - _0x412177["dir"] + _0x323212,
        ),
        _0x24bb4a(),
        _0x338c29(function () {
          _0xbdafb3(_carromBotShotTurn);
        }, 0x8fc));
    }
    function _carromFindOpenBaseline(y) {
      var radius = _0x133600 + 0x10;
      var baselineY = Number.isFinite(y) ? y : _0x429ae3;
      var pieces = _0x2a9c75.concat(_0x3e4566, _0x3231b3), intervals = [];
      for (var i = 0; i < pieces.length; i++) {
        var p = pieces[i];
        if (!p || !Number.isFinite(p.x) || !Number.isFinite(p.y)) return null;
        var dy = p.y - baselineY;
        if (Math.abs(dy) >= radius) continue;
        var dx = Math.sqrt(radius * radius - dy * dy);
        intervals.push({ start: p.x - dx, end: p.x + dx });
      }
      intervals.sort(function (a, b) { return a.start - b.start; });
      var cursor = _0x55e1a0;
      for (var j = 0; j < intervals.length; j++) {
        var interval = intervals[j];
        if (interval.end < cursor) continue;
        if (interval.start > cursor) {
          var candidate = (cursor + Math.min(interval.start, _0x187453)) / 2;
          if (candidate <= _0x187453 && !_0x23a7dc({x:candidate,y:baselineY}, radius)) return candidate;
        }
        cursor = Math.max(cursor, interval.end);
        if (cursor > _0x187453) return null;
      }
      var last = (cursor + _0x187453) / 2;
      return last <= _0x187453 && !_0x23a7dc({x:last,y:baselineY}, radius) ? last : null;
    }
    function _0x3d12d7() {
      var _0x385866 = _0x157421;
      let _0x3a50e5 = _0x5d148e === 0x2
        ? _0x2a9c75.concat(_0x3e4566, _0x3231b3)
        : _0x2a9c75.length === 1 && _0x3231b3.length
          ? _0x3231b3.slice()
          : _0x2a9c75.slice();
      !_0x3a50e5[_0x385866(0x182)] &&
        (_0x3a50e5 = _0x3a50e5[_0x385866(0x1c0)](_0x3e4566, _0x3231b3));
      if (!_0x3a50e5.length) return null;
      let _0xe88441 =
          _0x3a50e5[
            Math[_0x385866(0x1f8)](
              Math[_0x385866(0xec)]() * _0x3a50e5[_0x385866(0x182)],
            )
          ],
        _0x4b85cd = {
          x: _0x55e1a0 + Math[_0x385866(0xec)]() * (_0x187453 - _0x55e1a0),
          y: _0x429ae3,
        };
      if (_0x23a7dc(_0x4b85cd, _0x133600 + 0x10)) {
        let _0x2cdbc8 = _0x4b85cd["x"],
          _0x7c680f = _0x4b85cd["y"];
        for (
          let _0x280ad6 = 0x0;
          _0x280ad6 < _0x187453 - _0x55e1a0;
          _0x280ad6 += 0x2
        ) {
          if (
            _0x2cdbc8 + _0x280ad6 < _0x187453 &&
            !_0x23a7dc(
              { x: _0x2cdbc8 + _0x280ad6, y: _0x7c680f },
              _0x133600 + 0x10,
            )
          ) {
            _0x4b85cd["x"] = _0x2cdbc8 + _0x280ad6;
            break;
          } else {
            if (
              _0x2cdbc8 - _0x280ad6 > _0x55e1a0 &&
              !_0x23a7dc(
                { x: _0x2cdbc8 - _0x280ad6, y: _0x7c680f },
                _0x133600 + 0x10,
              )
            ) {
              _0x4b85cd["x"] = _0x2cdbc8 - _0x280ad6;
              break;
            }
          }
        }
      }
      if (_0x23a7dc(_0x4b85cd, _0x133600 + 0x10)) {
        var _carromOpenX = _carromFindOpenBaseline();
        if (_carromOpenX === null) return null;
        _0x4b85cd.x = _carromOpenX;
      }
      var _carromFallbackDir = _0x8b2762(_0x4b85cd, _0xe88441);
      var _carromFallbackDistance = Math.sqrt(Math.pow(_0xe88441.x - _0x4b85cd.x, 2) + Math.pow(_0xe88441.y - _0x4b85cd.y, 2));
      if (_carromStartPathBlocked(_0x4b85cd, _carromFallbackDir, _carromFallbackDistance, _0xe88441)) {
        // Keep fallback available if no sampled alternative is clear.
        for (var _carromTry = 0; _carromTry <= 6; _carromTry++) {
          var _carromPos = {x: _0x55e1a0 + (_0x187453 - _0x55e1a0) * _carromTry / 6, y: _0x429ae3};
          if (_0x23a7dc(_carromPos, _0x133600 + 0x10)) continue;
          var _carromDir = _0x8b2762(_carromPos, _0xe88441);
          var _carromDistance = Math.sqrt(Math.pow(_0xe88441.x - _carromPos.x, 2) + Math.pow(_0xe88441.y - _carromPos.y, 2));
          if (!_carromStartPathBlocked(_carromPos, _carromDir, _carromDistance, _0xe88441)) {
            _0x4b85cd = _carromPos; _carromFallbackDir = _carromDir; break;
          }
        }
      }
      return { pos: _0x4b85cd, dir: _carromFallbackDir };
    }
    function _0x52106f(
      _0x3796e7,
      _0x31dcf9,
      _0x9b1349,
      _0x393f58,
      _0x1c8c11,
      _0x158572,
    ) {
      var _0x2b4d0b = _0x157421;
      let _0x3ed68d = 0x5,
        _0x227745 = 0x3;
      var _0x2dec07 = [];
      for (
        let _0x3b2c0d = 0x0;
        _0x3b2c0d < _0x31dcf9[_0x2b4d0b(0x182)];
        _0x3b2c0d++
      ) {
        let _0x5bf2f1 = _0x31dcf9[_0x3b2c0d],
          _0x2708bd = _0x5ccc96;
        if (
          _0x5bf2f1["y"] >
          _0x24c0ca["y"] +
            _0x24c0ca[_0x2b4d0b(0x21c)] -
            (_0x429ae3 + _0x3ce1ab - _0x24c0ca["y"])
        )
          continue;
        if (_0x5bf2f1["y"] < _0x3796e7["y"]) continue;
        if (_0x5bf2f1["x"] < _0x3796e7["x"]) continue;
        let _0x3bd0a2 = _0x8b2762(_0x5bf2f1, _0x3796e7),
          _0x3bfc4a = _0x2bd695(_0x5bf2f1, _0x3796e7),
          _0x1602ce = _0x393f58
            ? Math[_0x2b4d0b(0x322)](
                Math[_0x2b4d0b(0x430)](_0x1c8c11) *
                  Math[_0x2b4d0b(0x430)](_0x3bd0a2) +
                  Math[_0x2b4d0b(0x1c8)](_0x1c8c11) *
                    Math[_0x2b4d0b(0x1c8)](_0x3bd0a2),
              )
            : 0x1;
        if (_0x1602ce < 0.5) continue;
        let _0x3f1eca =
          _0x9b1349 &&
          _0x3ea989(_0x5bf2f1, _0x3ce1ab * 0x2, _0x3bd0a2, _0x3bfc4a);
        if (_0x3f1eca) continue;
        let _0x445ac0 = {
          x:
            _0x5bf2f1["x"] -
            Math[_0x2b4d0b(0x430)](_0x3bd0a2) * (_0x3ce1ab + _0x133600),
          y:
            _0x5bf2f1["y"] -
            Math[_0x2b4d0b(0x1c8)](_0x3bd0a2) * (_0x3ce1ab + _0x133600),
        };
        if (_0x5bf2f1["y"] < _0x429ae3)
          for (let _0x20a52d = -0x1; _0x20a52d <= _0x3ed68d; _0x20a52d++) {
            let _0x1d6680 = 0x0;
            if (_0x20a52d < 0x0) {
              _0x1d6680 =
                _0x5bf2f1["x"] -
                (_0x5bf2f1["y"] - _0x429ae3) / Math["tan"](_0x3bd0a2);
              if (_0x1d6680 < _0x55e1a0 || _0x1d6680 > _0x187453) continue;
            } else {
              _0x1d6680 =
                _0x55e1a0 + (_0x187453 - _0x55e1a0) * (_0x20a52d / _0x3ed68d);
              if (_0x1d6680 > _0x5bf2f1["x"] - _0x3ce1ab - _0x133600) continue;
            }
            let _0x2c664d = { x: _0x1d6680, y: _0x429ae3 };
            if (_0x23a7dc(_0x2c664d, _0x133600 + _0x3ce1ab)) continue;
            let _0x1cd0f4 = _0x8b2762(_0x2c664d, _0x445ac0),
              _0x3291e7 = _0x2bd695(_0x2c664d, _0x445ac0),
              _0x4db6fc = Math.max(0,
                Math[_0x2b4d0b(0x430)](_0x3bd0a2) *
                  Math[_0x2b4d0b(0x430)](_0x1cd0f4) +
                  Math["sin"](_0x3bd0a2) * Math[_0x2b4d0b(0x1c8)](_0x1cd0f4),
              ),
              _0x523a92 = _0x16430c(_0x3bd0a2, _0x1cd0f4),
              _0x24a99c = _0x3bfc4a + _0x3291e7 + (_0x158572 || 0x0);
            _0x4db6fc *= _0x1602ce;
            let _0x448747 = 0xa + (0x1 - _0x4db6fc) * _0x301cde;
            if (_0x4db6fc > _0x5ccc96 && _0x4db6fc > _0x2708bd) {
              let _0x53086d = _0x3ea989(
                _0x2c664d,
                _0x133600 * 0x2,
                _0x1cd0f4,
                _0x3291e7,
              ) || _carromStartPathBlocked(_0x2c664d, _0x1cd0f4, _0x3291e7, _0x5bf2f1);
              if (_0x53086d) continue;
              _0x2708bd = _0x4db6fc;
              if (_0x393f58)
                _0x393f58[_0x2b4d0b(0x3b0)]({
                  pos: _0x2c664d,
                  dir: _0x1cd0f4,
                  speed: _0x448747,
                  hDot: _0x4db6fc,
                  dist: _0x24a99c,
                });
              else
                _0x2dec07[_0x2b4d0b(0x3b0)]({
                  pos: _0x2c664d,
                  dir: _0x1cd0f4,
                  speed: _0x448747,
                  hDot: _0x4db6fc,
                  dist: _0x24a99c,
                });
              if (_0x20a52d < 0x0) break;
            }
          }
        if (_0x2708bd < 0.7) {
          let _0x198e4d =
            _0x24c0ca["y"] +
            _0x24c0ca["height"] -
            0x1a -
            _0x133600 +
            (_0x24c0ca["y"] +
              _0x24c0ca[_0x2b4d0b(0x21c)] -
              0x1a -
              _0x133600 -
              _0x445ac0["y"]);
          for (let _0x3961f5 = 0x0; _0x3961f5 <= _0x227745; _0x3961f5++) {
            let _0x3723ac =
              _0x55e1a0 + (_0x187453 - _0x55e1a0) * (_0x3961f5 / _0x227745);
            if (_0x3723ac < _0x5bf2f1["x"] + _0x3ce1ab + _0x133600) continue;
            let _0x3442b5 = { x: _0x3723ac, y: _0x429ae3 };
            if (_0x23a7dc(_0x3442b5, _0x133600 + _0x3ce1ab)) continue;
            let _0x248c6b = _0x8b2762(_0x3442b5, {
                x: _0x445ac0["x"],
                y: _0x198e4d,
              }),
              _0x4199d5 =
                _0x3723ac +
                (0x1 / Math[_0x2b4d0b(0x19b)](_0x248c6b)) *
                  (_0x24c0ca["y"] +
                    _0x24c0ca[_0x2b4d0b(0x21c)] -
                    0x1a -
                    _0x133600 -
                    _0x429ae3),
              _0x5b4aca = {
                x: _0x4199d5,
                y:
                  _0x24c0ca["y"] +
                  _0x24c0ca[_0x2b4d0b(0x21c)] -
                  0x1a -
                  _0x133600,
              },
              _0xa1fc64 = _0x2bd695(_0x5b4aca, _0x3442b5),
              _0x63ef0a = _0x8b2762(_0x5b4aca, _0x445ac0),
              _0x157794 = _0x2bd695(_0x5b4aca, _0x445ac0),
              _0x3099e5 = Math.max(0,
                Math[_0x2b4d0b(0x430)](_0x3bd0a2) *
                  Math[_0x2b4d0b(0x430)](_0x63ef0a) +
                  Math[_0x2b4d0b(0x1c8)](_0x3bd0a2) *
                    Math[_0x2b4d0b(0x1c8)](_0x63ef0a),
              ),
              _0x1ce3bb =
                _0x3bfc4a + _0xa1fc64 + _0x157794 + (_0x158572 || 0x0);
            _0x3099e5 *= _0x1602ce;
            let _0x4677c1 = 0xa + (0x1 - _0x3099e5) * _0x301cde;
            if (_0x3099e5 > _0x5ccc96 && _0x3099e5 > _0x2708bd) {
              let _0x1dab44 = _0x3ea989(
                _0x3442b5,
                _0x133600 * 0x2,
                _0x248c6b,
                _0xa1fc64,
              ) || _carromStartPathBlocked(_0x3442b5, _0x248c6b, _0xa1fc64, null);
              if (_0x1dab44) continue;
              let _0x478446 = _0x3ea989(
                _0x5b4aca,
                _0x133600 * 0x2,
                _0x63ef0a,
                _0x157794,
              ) || _carromStartPathBlocked(_0x5b4aca, _0x63ef0a, _0x157794, _0x5bf2f1);
              if (_0x478446) continue;
              _0x2708bd = _0x3099e5;
              if (_0x393f58)
                _0x393f58[_0x2b4d0b(0x3b0)]({
                  pos: _0x3442b5,
                  dir: _0x248c6b,
                  speed: _0x4677c1,
                  hDot: _0x3099e5,
                  dist: _0x1ce3bb,
                });
              else
                _0x2dec07[_0x2b4d0b(0x3b0)]({
                  pos: _0x3442b5,
                  dir: _0x248c6b,
                  speed: _0x4677c1,
                  hDot: _0x3099e5,
                  dist: _0x1ce3bb,
                });
            }
          }
        }
        if (_0x2708bd <= 0.5 && !_0x393f58) {
          var _0x4191c3 = {
              x:
                _0x5bf2f1["x"] -
                Math["cos"](_0x3bd0a2) * (_0x3ce1ab + _0x3ce1ab),
              y:
                _0x5bf2f1["y"] -
                Math[_0x2b4d0b(0x1c8)](_0x3bd0a2) * (_0x3ce1ab + _0x3ce1ab),
            },
            _0x5bee96 = _0x2a9c75["concat"](_0x3e4566, _0x3231b3);
          _0x52106f(
            _0x4191c3,
            _0x5bee96,
            !![],
            _0x2dec07,
            _0x3bd0a2,
            _0x3bfc4a,
          );
          continue;
        }
      }
      return _0x2dec07;
    }
    function _0x25af2a(
      _0xc72ab3,
      _0x4a4db6,
      _0x19427c,
      _0x362db2,
      _0x5bd84c,
      _0x199793,
    ) {
      var _0x218670 = _0x157421;
      let _0x385c6d = 0x5,
        _0xbd7d34 = 0x3;
      var _0x192a08 = [];
      for (
        let _0x2a1151 = 0x0;
        _0x2a1151 < _0x4a4db6[_0x218670(0x182)];
        _0x2a1151++
      ) {
        let _0x5ccf72 = _0x4a4db6[_0x2a1151],
          _0x28180b = _0x5ccc96;
        if (
          _0x5ccf72["y"] >
          _0x24c0ca["y"] +
            _0x24c0ca[_0x218670(0x21c)] -
            (_0x429ae3 + _0x3ce1ab - _0x24c0ca["y"])
        )
          continue;
        if (_0x5ccf72["y"] < _0xc72ab3["y"]) continue;
        if (_0x5ccf72["x"] > _0xc72ab3["x"]) continue;
        let _0x4ea0a1 = _0x8b2762(_0x5ccf72, _0xc72ab3),
          _0x5a9326 = _0x2bd695(_0x5ccf72, _0xc72ab3),
          _0x4fcd0f = _0x362db2
            ? Math[_0x218670(0x322)](
                Math[_0x218670(0x430)](_0x5bd84c) * Math["cos"](_0x4ea0a1) +
                  Math[_0x218670(0x1c8)](_0x5bd84c) *
                    Math[_0x218670(0x1c8)](_0x4ea0a1),
              )
            : 0x1;
        if (_0x4fcd0f < 0.5) continue;
        let _0x1f5a98 =
          _0x19427c &&
          _0x3ea989(_0x5ccf72, _0x3ce1ab * 0x2, _0x4ea0a1, _0x5a9326);
        if (_0x1f5a98) continue;
        let _0x549a1b = {
          x: _0x5ccf72["x"] - Math["cos"](_0x4ea0a1) * (_0x3ce1ab + _0x133600),
          y:
            _0x5ccf72["y"] -
            Math[_0x218670(0x1c8)](_0x4ea0a1) * (_0x3ce1ab + _0x133600),
        };
        if (_0x5ccf72["y"] < _0x429ae3)
          for (let _0x9c63b = -0x1; _0x9c63b <= _0x385c6d; _0x9c63b++) {
            let _0x37641b = 0x0;
            if (_0x9c63b < 0x0) {
              _0x37641b =
                _0x5ccf72["x"] -
                (_0x5ccf72["y"] - _0x429ae3) /
                  Math[_0x218670(0x19b)](_0x4ea0a1);
              if (_0x37641b < _0x55e1a0 || _0x37641b > _0x187453) continue;
            } else {
              _0x37641b =
                _0x55e1a0 + (_0x187453 - _0x55e1a0) * (_0x9c63b / _0x385c6d);
              if (_0x37641b > _0x5ccf72["x"] - _0x3ce1ab - _0x133600) continue;
            }
            let _0x259ced = { x: _0x37641b, y: _0x429ae3 };
            if (_0x23a7dc(_0x259ced, _0x133600 + _0x3ce1ab)) continue;
            let _0x33ad63 = _0x8b2762(_0x259ced, _0x549a1b),
              _0x51ba9e = _0x2bd695(_0x259ced, _0x549a1b),
              _0x3c8aae = Math.max(0,
                Math[_0x218670(0x430)](_0x4ea0a1) *
                  Math[_0x218670(0x430)](_0x33ad63) +
                  Math[_0x218670(0x1c8)](_0x4ea0a1) *
                    Math[_0x218670(0x1c8)](_0x33ad63),
              ),
              _0x394a5d = _0x16430c(_0x4ea0a1, _0x33ad63),
              _0xbeb150 = _0x5a9326 + _0x51ba9e + (_0x199793 || 0x0);
            _0x3c8aae *= _0x4fcd0f;
            let _0x33c3f5 = 0xa + (0x1 - _0x3c8aae) * _0x301cde;
            if (_0x3c8aae > _0x5ccc96 && _0x3c8aae > _0x28180b) {
              let _0x281f85 = _0x3ea989(
                _0x259ced,
                _0x133600 * 0x2,
                _0x33ad63,
                _0x51ba9e,
              ) || _carromStartPathBlocked(_0x259ced, _0x33ad63, _0x51ba9e, _0x5ccf72);
              if (_0x281f85) continue;
              _0x28180b = _0x3c8aae;
              if (_0x362db2)
                _0x362db2[_0x218670(0x3b0)]({
                  pos: _0x259ced,
                  dir: _0x33ad63,
                  speed: _0x33c3f5,
                  hDot: _0x3c8aae,
                  dist: _0xbeb150,
                });
              else
                _0x192a08[_0x218670(0x3b0)]({
                  pos: _0x259ced,
                  dir: _0x33ad63,
                  speed: _0x33c3f5,
                  hDot: _0x3c8aae,
                  dist: _0xbeb150,
                });
              if (_0x9c63b < 0x0) break;
            }
          }
        if (_0x28180b < 0.7) {
          let _0x224747 =
            _0x24c0ca["y"] +
            _0x24c0ca["height"] -
            0x1a -
            _0x133600 +
            (_0x24c0ca["y"] +
              _0x24c0ca[_0x218670(0x21c)] -
              0x1a -
              _0x133600 -
              _0x549a1b["y"]);
          for (let _0x4cb531 = 0x0; _0x4cb531 <= _0xbd7d34; _0x4cb531++) {
            let _0x225639 =
              _0x55e1a0 + (_0x187453 - _0x55e1a0) * (_0x4cb531 / _0xbd7d34);
            if (_0x225639 > _0x5ccf72["x"] - _0x3ce1ab - _0x133600) continue;
            let _0x38960c = { x: _0x225639, y: _0x429ae3 };
            if (_0x23a7dc(_0x38960c, _0x133600 + _0x3ce1ab)) continue;
            let _0x37f94f = _0x8b2762(_0x38960c, {
                x: _0x549a1b["x"],
                y: _0x224747,
              }),
              _0x3db71e =
                _0x225639 +
                (0x1 / Math[_0x218670(0x19b)](_0x37f94f)) *
                  (_0x24c0ca["y"] +
                    _0x24c0ca[_0x218670(0x21c)] -
                    0x1a -
                    _0x133600 -
                    _0x429ae3),
              _0x8ead75 = {
                x: _0x3db71e,
                y:
                  _0x24c0ca["y"] +
                  _0x24c0ca[_0x218670(0x21c)] -
                  0x1a -
                  _0x133600,
              },
              _0x277390 = _0x2bd695(_0x8ead75, _0x38960c),
              _0x15aa97 = _0x8b2762(_0x8ead75, _0x549a1b),
              _0x244b79 = _0x2bd695(_0x8ead75, _0x549a1b),
              _0x10d489 = Math.max(0,
                Math["cos"](_0x4ea0a1) * Math[_0x218670(0x430)](_0x15aa97) +
                  Math[_0x218670(0x1c8)](_0x4ea0a1) * Math["sin"](_0x15aa97),
              ),
              _0x3a85e7 =
                _0x5a9326 + _0x277390 + _0x244b79 + (_0x199793 || 0x0);
            _0x10d489 *= _0x4fcd0f;
            let _0x57f7a8 = 0xa + (0x1 - _0x10d489) * _0x301cde;
            if (_0x10d489 > _0x5ccc96 && _0x10d489 > _0x28180b) {
              let _0x333e22 = _0x3ea989(
                _0x38960c,
                _0x133600 * 0x2,
                _0x37f94f,
                _0x277390,
              ) || _carromStartPathBlocked(_0x38960c, _0x37f94f, _0x277390, null);
              if (_0x333e22) continue;
              let _0xceb28 = _0x3ea989(
                _0x8ead75,
                _0x133600 * 0x2,
                _0x15aa97,
                _0x244b79,
              ) || _carromStartPathBlocked(_0x8ead75, _0x15aa97, _0x244b79, _0x5ccf72);
              if (_0xceb28) continue;
              _0x28180b = _0x10d489;
              if (_0x362db2)
                _0x362db2[_0x218670(0x3b0)]({
                  pos: _0x38960c,
                  dir: _0x37f94f,
                  speed: _0x57f7a8,
                  hDot: _0x10d489,
                  dist: _0x3a85e7,
                });
              else
                _0x192a08[_0x218670(0x3b0)]({
                  pos: _0x38960c,
                  dir: _0x37f94f,
                  speed: _0x57f7a8,
                  hDot: _0x10d489,
                  dist: _0x3a85e7,
                });
            }
          }
        }
        if (_0x28180b <= 0.5 && !_0x362db2) {
          var _0x592de6 = {
              x:
                _0x5ccf72["x"] -
                Math["cos"](_0x4ea0a1) * (_0x3ce1ab + _0x3ce1ab),
              y:
                _0x5ccf72["y"] -
                Math[_0x218670(0x1c8)](_0x4ea0a1) * (_0x3ce1ab + _0x3ce1ab),
            },
            _0x3d49b8 = _0x2a9c75[_0x218670(0x1c0)](_0x3e4566, _0x3231b3);
          _0x25af2a(
            _0x592de6,
            _0x3d49b8,
            !![],
            _0x192a08,
            _0x4ea0a1,
            _0x5a9326,
          );
          continue;
        }
      }
      return _0x192a08;
    }
    function _0x521eef(
      _0x49dbe0,
      _0x4a1699,
      _0x1df4ed,
      _0x44ed86,
      _0x4385f7,
      _0x2c42e5,
    ) {
      var _0xba44b = _0x157421;
      let _0x54d63f = 0x5,
        _0x120ffb = 0x3;
      var _0x10409d = [];
      for (
        let _0x1105a3 = 0x0;
        _0x1105a3 < _0x4a1699[_0xba44b(0x182)];
        _0x1105a3++
      ) {
        let _0x401fea = _0x4a1699[_0x1105a3],
          _0x5d6e03 = _0x5ccc96;
        if (_0x401fea["y"] < _0x429ae3 + _0x3ce1ab) continue;
        if (_0x401fea["y"] >= _0x49dbe0["y"]) continue;
        if (_0x401fea["x"] < _0x49dbe0["x"]) continue;
        let _0x398643 = _0x8b2762(_0x401fea, _0x49dbe0),
          _0x2df9cc = _0x2bd695(_0x401fea, _0x49dbe0),
          _0x873a71 = _0x44ed86
            ? Math[_0xba44b(0x322)](
                Math[_0xba44b(0x430)](_0x4385f7) *
                  Math[_0xba44b(0x430)](_0x398643) +
                  Math[_0xba44b(0x1c8)](_0x4385f7) * Math["sin"](_0x398643),
              )
            : 0x1;
        if (_0x873a71 < 0.5) continue;
        let _0x58abc0 =
          _0x1df4ed &&
          _0x3ea989(_0x401fea, _0x3ce1ab * 0x2, _0x398643, _0x2df9cc);
        if (_0x58abc0) continue;
        let _0x10f68c = {
          x:
            _0x401fea["x"] -
            Math[_0xba44b(0x430)](_0x398643) * (_0x3ce1ab + _0x133600),
          y:
            _0x401fea["y"] -
            Math[_0xba44b(0x1c8)](_0x398643) * (_0x3ce1ab + _0x133600),
        };
        for (let _0x1ee85a = -0x1; _0x1ee85a <= _0x54d63f; _0x1ee85a++) {
          let _0x2a011a = 0x0;
          if (_0x1ee85a < 0x0) {
            _0x2a011a =
              _0x401fea["x"] -
              (_0x401fea["y"] - _0x429ae3) / Math[_0xba44b(0x19b)](_0x398643);
            if (_0x2a011a < _0x55e1a0 || _0x2a011a > _0x187453) continue;
          } else
            _0x2a011a =
              _0x55e1a0 + (_0x187453 - _0x55e1a0) * (_0x1ee85a / _0x54d63f);
          let _0x41e2cf = { x: _0x2a011a, y: _0x429ae3 };
          if (_0x23a7dc(_0x41e2cf, _0x133600 + _0x3ce1ab)) continue;
          let _0x395f57 = _0x8b2762(_0x41e2cf, _0x10f68c),
            _0x3013bf = _0x2bd695(_0x41e2cf, _0x10f68c),
            _0x5f04cc = Math.max(0,
              Math["cos"](_0x398643) * Math["cos"](_0x395f57) +
                Math[_0xba44b(0x1c8)](_0x398643) *
                  Math[_0xba44b(0x1c8)](_0x395f57),
            ),
            _0x50a676 = _0x16430c(_0x398643, _0x395f57),
            _0x593986 = _0x2df9cc + _0x3013bf + (_0x2c42e5 || 0x0);
          _0x5f04cc *= _0x873a71;
          let _0x33de1f = 0xa + (0x1 - _0x5f04cc) * _0x301cde;
          if (_0x5f04cc > _0x5ccc96 && _0x5f04cc > _0x5d6e03) {
            let _0x529618 = _0x3ea989(
              _0x41e2cf,
              _0x133600 * 0x2,
              _0x395f57,
              _0x3013bf,
            ) || _carromStartPathBlocked(_0x41e2cf, _0x395f57, _0x3013bf, _0x401fea);
            if (_0x529618) continue;
            _0x5d6e03 = _0x5f04cc;
            if (_0x44ed86)
              _0x44ed86[_0xba44b(0x3b0)]({
                pos: _0x41e2cf,
                dir: _0x395f57,
                speed: _0x33de1f,
                hDot: _0x5f04cc,
                dist: _0x593986,
              });
            else
              _0x10409d[_0xba44b(0x3b0)]({
                pos: _0x41e2cf,
                dir: _0x395f57,
                speed: _0x33de1f,
                hDot: _0x5f04cc,
                dist: _0x593986,
              });
            if (_0x1ee85a < 0x0) break;
          }
        }
        if (_0x5d6e03 < 0.7) {
          let _0xadd7ef =
            _0x24c0ca["x"] +
            _0x24c0ca[_0xba44b(0xfd)] -
            0x1a -
            _0x133600 +
            (_0x24c0ca["x"] +
              _0x24c0ca[_0xba44b(0xfd)] -
              0x1a -
              _0x133600 -
              _0x10f68c["x"]);
          for (let _0x146638 = 0x0; _0x146638 <= _0x120ffb; _0x146638++) {
            let _0x17c8b4 =
                _0x55e1a0 + (_0x187453 - _0x55e1a0) * (_0x146638 / _0x120ffb),
              _0x1590c9 = { x: _0x17c8b4, y: _0x429ae3 };
            if (_0x23a7dc(_0x1590c9, _0x133600 + _0x3ce1ab)) continue;
            let _0x3e3b8f = _0x8b2762(_0x1590c9, {
                x: _0xadd7ef,
                y: _0x10f68c["y"],
              }),
              _0x5d04eb =
                _0x429ae3 -
                Math[_0xba44b(0x19b)](_0x3e3b8f) *
                  (_0x17c8b4 -
                    (_0x24c0ca["x"] + _0x24c0ca["width"] - 0x1a - _0x133600)),
              _0x2fcc90 = {
                x:
                  _0x24c0ca["x"] + _0x24c0ca[_0xba44b(0xfd)] - 0x1a - _0x133600,
                y: _0x5d04eb,
              },
              _0x3542cc = _0x2bd695(_0x2fcc90, _0x1590c9),
              _0x163ae8 = _0x8b2762(_0x2fcc90, _0x10f68c),
              _0x1a5851 = _0x2bd695(_0x2fcc90, _0x10f68c),
              _0x112b48 = Math.max(0,
                Math[_0xba44b(0x430)](_0x398643) *
                  Math[_0xba44b(0x430)](_0x163ae8) +
                  Math[_0xba44b(0x1c8)](_0x398643) *
                    Math[_0xba44b(0x1c8)](_0x163ae8),
              ),
              _0x23aa0c =
                _0x2df9cc + _0x3542cc + _0x1a5851 + (_0x2c42e5 || 0x0);
            _0x112b48 *= _0x873a71;
            let _0x24bdd3 = 0xa + (0x1 - _0x112b48) * _0x301cde;
            if (_0x112b48 > _0x5ccc96 && _0x112b48 > _0x5d6e03) {
              let _0x2ddf6e = _0x3ea989(
                _0x1590c9,
                _0x133600 * 0x2,
                _0x3e3b8f,
                _0x3542cc,
              ) || _carromStartPathBlocked(_0x1590c9, _0x3e3b8f, _0x3542cc, null);
              if (_0x2ddf6e) continue;
              let _0x559514 = _0x3ea989(
                _0x2fcc90,
                _0x133600 * 0x2,
                _0x163ae8,
                _0x1a5851,
              ) || _carromStartPathBlocked(_0x2fcc90, _0x163ae8, _0x1a5851, _0x401fea);
              if (_0x559514) continue;
              _0x5d6e03 = _0x112b48;
              if (_0x44ed86)
                _0x44ed86[_0xba44b(0x3b0)]({
                  pos: _0x1590c9,
                  dir: _0x3e3b8f,
                  speed: _0x24bdd3,
                  hDot: _0x112b48,
                  dist: _0x23aa0c,
                });
              else
                _0x10409d["push"]({
                  pos: _0x1590c9,
                  dir: _0x3e3b8f,
                  speed: _0x24bdd3,
                  hDot: _0x112b48,
                  dist: _0x23aa0c,
                });
            }
          }
        }
        if (_0x5d6e03 <= 0.5 && !_0x44ed86) {
          var _0x2b4a5f = {
              x:
                _0x401fea["x"] -
                Math[_0xba44b(0x430)](_0x398643) * (_0x3ce1ab + _0x3ce1ab),
              y:
                _0x401fea["y"] -
                Math[_0xba44b(0x1c8)](_0x398643) * (_0x3ce1ab + _0x3ce1ab),
            },
            _0x252e97 = _0x2a9c75[_0xba44b(0x1c0)](_0x3e4566, _0x3231b3);
          _0x521eef(
            _0x2b4a5f,
            _0x252e97,
            !![],
            _0x10409d,
            _0x398643,
            _0x2df9cc,
          );
          continue;
        }
      }
      return _0x10409d;
    }
    function _0x30849b(
      _0x2e9b0d,
      _0x5b36c6,
      _0x19556e,
      _0x53788d,
      _0x5e3826,
      _0x40ebad,
    ) {
      var _0x35324e = _0x157421;
      let _0x22c7cf = 0x5,
        _0x4bdfc3 = 0x3;
      var _0x1c4f05 = [];
      for (
        let _0x45f2f7 = 0x0;
        _0x45f2f7 < _0x5b36c6[_0x35324e(0x182)];
        _0x45f2f7++
      ) {
        let _0x42b5f4 = _0x5b36c6[_0x45f2f7],
          _0x42c127 = _0x5ccc96;
        if (_0x42b5f4["y"] < _0x429ae3 + _0x3ce1ab) continue;
        if (_0x42b5f4["y"] >= _0x2e9b0d["y"]) continue;
        if (_0x42b5f4["x"] > _0x2e9b0d["x"]) continue;
        let _0x89089b = _0x8b2762(_0x42b5f4, _0x2e9b0d),
          _0x354580 = _0x2bd695(_0x42b5f4, _0x2e9b0d),
          _0x5b321d = _0x53788d
            ? Math["abs"](
                Math[_0x35324e(0x430)](_0x5e3826) * Math["cos"](_0x89089b) +
                  Math[_0x35324e(0x1c8)](_0x5e3826) *
                    Math[_0x35324e(0x1c8)](_0x89089b),
              )
            : 0x1;
        if (_0x5b321d < 0.5) continue;
        let _0x4356f9 =
          _0x19556e &&
          _0x3ea989(_0x42b5f4, _0x3ce1ab * 0x2, _0x89089b, _0x354580);
        if (_0x4356f9) continue;
        let _0xb71b68 = {
          x:
            _0x42b5f4["x"] -
            Math[_0x35324e(0x430)](_0x89089b) * (_0x3ce1ab + _0x133600),
          y:
            _0x42b5f4["y"] -
            Math[_0x35324e(0x1c8)](_0x89089b) * (_0x3ce1ab + _0x133600),
        };
        for (let _0x1e6dec = -0x1; _0x1e6dec <= _0x22c7cf; _0x1e6dec++) {
          let _0x297c0a = 0x0;
          if (_0x1e6dec < 0x0) {
            _0x297c0a =
              _0x42b5f4["x"] -
              (_0x42b5f4["y"] - _0x429ae3) / Math["tan"](_0x89089b);
            if (_0x297c0a < _0x55e1a0 || _0x297c0a > _0x187453) continue;
          } else
            _0x297c0a =
              _0x55e1a0 + (_0x187453 - _0x55e1a0) * (_0x1e6dec / _0x22c7cf);
          let _0x296671 = { x: _0x297c0a, y: _0x429ae3 };
          if (_0x23a7dc(_0x296671, _0x133600 + _0x3ce1ab)) continue;
          let _0x17d54f = _0x8b2762(_0x296671, _0xb71b68),
            _0xa2dec0 = _0x2bd695(_0x296671, _0xb71b68),
            _0x3e0e94 = Math.max(0,
              Math[_0x35324e(0x430)](_0x89089b) *
                Math[_0x35324e(0x430)](_0x17d54f) +
                Math["sin"](_0x89089b) * Math[_0x35324e(0x1c8)](_0x17d54f),
            ),
            _0x183a5f = _0x16430c(_0x89089b, _0x17d54f),
            _0x2133dd = _0x354580 + _0xa2dec0 + (_0x40ebad || 0x0);
          _0x3e0e94 *= _0x5b321d;
          let _0xe463f6 = 0xa + (0x1 - _0x3e0e94) * _0x301cde;
          if (_0x3e0e94 > _0x5ccc96 && _0x3e0e94 > _0x42c127) {
            let _0x1fe197 = _0x3ea989(
              _0x296671,
              _0x133600 * 0x2,
              _0x17d54f,
              _0xa2dec0,
            ) || _carromStartPathBlocked(_0x296671, _0x17d54f, _0xa2dec0, _0x42b5f4);
            if (_0x1fe197) continue;
            _0x42c127 = _0x3e0e94;
            if (_0x53788d)
              _0x53788d[_0x35324e(0x3b0)]({
                pos: _0x296671,
                dir: _0x17d54f,
                speed: _0xe463f6,
                hDot: _0x3e0e94,
                dist: _0x2133dd,
              });
            else
              _0x1c4f05[_0x35324e(0x3b0)]({
                pos: _0x296671,
                dir: _0x17d54f,
                speed: _0xe463f6,
                hDot: _0x3e0e94,
                dist: _0x2133dd,
              });
            if (_0x1e6dec < 0x0) break;
          }
        }
        if (_0x42c127 < 0.7) {
          let _0x4ca4fd =
            _0x24c0ca["x"] +
            0x1a +
            _0x133600 -
            (_0xb71b68["x"] - (_0x24c0ca["x"] + 0x1a + _0x133600));
          for (let _0x38cf59 = 0x0; _0x38cf59 <= _0x4bdfc3; _0x38cf59++) {
            let _0x380256 =
                _0x55e1a0 + (_0x187453 - _0x55e1a0) * (_0x38cf59 / _0x4bdfc3),
              _0x226e70 = { x: _0x380256, y: _0x429ae3 };
            if (_0x23a7dc(_0x226e70, _0x133600 + _0x3ce1ab)) continue;
            let _0x2851b3 = _0x8b2762(_0x226e70, {
                x: _0x4ca4fd,
                y: _0xb71b68["y"],
              }),
              _0x57086c =
                _0x429ae3 -
                Math[_0x35324e(0x19b)](_0x2851b3) *
                  (_0x380256 - (_0x24c0ca["x"] + 0x1a + _0x133600)),
              _0x2cc74c = {
                x: _0x24c0ca["x"] + 0x1a + _0x133600,
                y: _0x57086c,
              },
              _0x14830a = _0x2bd695(_0x2cc74c, _0x226e70),
              _0x2f02a9 = _0x8b2762(_0x2cc74c, _0xb71b68),
              _0x3f8514 = _0x2bd695(_0x2cc74c, _0xb71b68),
              _0x59bbeb = Math.max(0,
                Math[_0x35324e(0x430)](_0x89089b) *
                  Math[_0x35324e(0x430)](_0x2f02a9) +
                  Math[_0x35324e(0x1c8)](_0x89089b) *
                    Math[_0x35324e(0x1c8)](_0x2f02a9),
              ),
              _0x2989a7 =
                _0x354580 + _0x14830a + _0x3f8514 + (_0x40ebad || 0x0);
            _0x59bbeb *= _0x5b321d;
            let _0x5f2cb1 = 0xa + (0x1 - _0x59bbeb) * _0x301cde;
            if (_0x59bbeb > _0x5ccc96 && _0x59bbeb > _0x42c127) {
              let _0x2796f2 = _0x3ea989(
                _0x226e70,
                _0x133600 * 0x2,
                _0x2851b3,
                _0x14830a,
              ) || _carromStartPathBlocked(_0x226e70, _0x2851b3, _0x14830a, null);
              if (_0x2796f2) continue;
              let _0x54cc49 = _0x3ea989(
                _0x2cc74c,
                _0x133600 * 0x2,
                _0x2f02a9,
                _0x3f8514,
              ) || _carromStartPathBlocked(_0x2cc74c, _0x2f02a9, _0x3f8514, _0x42b5f4);
              if (_0x54cc49) continue;
              _0x42c127 = _0x59bbeb;
              if (_0x53788d)
                _0x53788d[_0x35324e(0x3b0)]({
                  pos: _0x226e70,
                  dir: _0x2851b3,
                  speed: _0x5f2cb1,
                  hDot: _0x59bbeb,
                  dist: _0x2989a7,
                });
              else
                _0x1c4f05[_0x35324e(0x3b0)]({
                  pos: _0x226e70,
                  dir: _0x2851b3,
                  speed: _0x5f2cb1,
                  hDot: _0x59bbeb,
                  dist: _0x2989a7,
                });
            }
          }
        }
        if (_0x42c127 <= 0.5 && !_0x53788d) {
          var _0xf51964 = {
              x:
                _0x42b5f4["x"] -
                Math["cos"](_0x89089b) * (_0x3ce1ab + _0x3ce1ab),
              y:
                _0x42b5f4["y"] -
                Math[_0x35324e(0x1c8)](_0x89089b) * (_0x3ce1ab + _0x3ce1ab),
            },
            _0x4531c0 = _0x2a9c75[_0x35324e(0x1c0)](_0x3e4566, _0x3231b3);
          _0x30849b(
            _0xf51964,
            _0x4531c0,
            !![],
            _0x1c4f05,
            _0x89089b,
            _0x354580,
          );
          continue;
        }
      }
      return _0x1c4f05;
    }
    function _0x23a7dc(_0x15152b, _0x25ee0d) {
      var _0x1fef48 = _0x157421;
      let _0x555326 = _0x2a9c75[_0x1fef48(0x1c0)](_0x3e4566, _0x3231b3);
      for (let _0x14acea = 0x0; _0x14acea < _0x555326["length"]; _0x14acea++) {
        if (_0x2bd695(_0x15152b, _0x555326[_0x14acea]) < _0x25ee0d) return !![];
      }
      return ![];
    }
    function _carromStartPathBlocked(origin, angle, length, intendedTarget) {
      if (!origin || !Number.isFinite(origin.x) || !Number.isFinite(origin.y) ||
          !Number.isFinite(angle) || !Number.isFinite(length) || length < 0) return true;
      if (length === 0) return false;
      var dx = Math.cos(angle), dy = Math.sin(angle), end = Math.min(length, _0x133600 * 2),
        radius = _0x133600 + 16, discs = _0x3e4566.concat(_0x2a9c75, _0x3231b3);
      for (var disc of discs) {
        if (disc === intendedTarget) continue;
        if (!disc || !Number.isFinite(disc.x) || !Number.isFinite(disc.y)) return true;
        var x = disc.x - origin.x, y = disc.y - origin.y,
          along = Math.max(0, Math.min(end, x * dx + y * dy)),
          ex = x - along * dx, ey = y - along * dy;
        if (ex * ex + ey * ey < radius * radius) return true;
      }
      return false;
    }
    function _0x3ea989(_0x3e50b6, _0x192a9b, _0x372c57, _0x501ec4) {
      var _0x5ef868 = _0x157421;
      let _0x5b4ed9 = []
          [_0x5ef868(0x1c0)](_0x3e4566)
          ["concat"](_0x2a9c75, _0x3231b3);
      let _carromSteps = Math.floor(_0x501ec4 / _0x192a9b);
      if (_carromSteps < 1) return false;
      let _carromDx = Math.cos(_0x372c57), _carromDy = Math.sin(_0x372c57),
        _carromEnd = _carromSteps * _0x192a9b, _carromRadius = _0x192a9b * 0.9,
        _carromGapRadius = Math.min(_carromRadius, _0x192a9b / 2 + 16);
      // Preserve the original sample checks and fill the gaps using at most
      // the moving circle plus a regular coin's physical radius.
      for (let _carromDisc of _0x5b4ed9) {
        let _carromX = _carromDisc.x - _0x3e50b6.x, _carromY = _carromDisc.y - _0x3e50b6.y,
          _carromAlong = Math.max(_0x192a9b, Math.min(_carromEnd, _carromX * _carromDx + _carromY * _carromDy)),
          _carromOffsetX = _carromX - _carromAlong * _carromDx,
          _carromOffsetY = _carromY - _carromAlong * _carromDy,
          _carromSample = Math.max(1, Math.min(_carromSteps, Math.round(_carromAlong / _0x192a9b))) * _0x192a9b,
          _carromSampleX = _carromX - _carromSample * _carromDx,
          _carromSampleY = _carromY - _carromSample * _carromDy;
        if (_carromSampleX * _carromSampleX + _carromSampleY * _carromSampleY < _carromRadius * _carromRadius ||
            _carromOffsetX * _carromOffsetX + _carromOffsetY * _carromOffsetY < _carromGapRadius * _carromGapRadius) return true;
      }
      return ![];
    }
    function _0x247dad(_0x250221, _0x1a62e0, _0x1f1c9e) {
      var _0x2ddb9c = _0x157421;
      for (
        let _0x567082 = 0x0;
        _0x567082 < _0x1a62e0[_0x2ddb9c(0x182)];
        _0x567082++
      ) {
        if (_0x2bd695(_0x250221, _0x1a62e0[_0x567082]) < _0x1f1c9e) return !![];
      }
      return ![];
    }
    function _0x4c7a25() {
      var _0x4acaa8 = _0x157421,
        _0x32ec82 = new Date(),
        _0x486edb = _0x32ec82[_0x4acaa8(0x414)](),
        _0x2a0f1d = _0x486edb - _0x6d1a83;
      _0x2a0f1d > _0x66b857
        ? ((_0x530cb1 = !![]), _0x50d6f7["showBonusMark"](!![]))
        : _0x50d6f7[_0x4acaa8(0x27a)](_0x66b857 - _0x2a0f1d);
    }
    function _0x49d791(_0x2d8e89) {
      var _0xcaac96 = _0x157421;
      if (_0x3e61d0 || _carromHostPaused || _carromAdTokens.length) return;
      _0x3768e7++;
      if (_0x3768e7 > 0x2540be3ff) _0x3768e7 = 0x0;
      (_0x3eeb21[_0xcaac96(0x3c8)](_0x2d8e89),
        ParticleManager["update"](_0x2d8e89),
        Tweener[_0xcaac96(0x3c8)](_0x2d8e89));
      if (_carromHostPaused || _carromAdTokens.length) return;
      _0x50d6f7 &&
        _0x50d6f7[_0xcaac96(0x197)] &&
        _0x3768e7 % 0x3c == 0x0 &&
        !_0x530cb1 &&
        _0x4c7a25();
      if (!_0x3fddb3) return;
      if (!_0xcd5b2f) {
        _0x1f977d--;
        if (_0x1f977d <= 0x0) _0x2e33a4();
      }
      if (_0x3a1262) {
        if (_0x1a373b > 0x0 && _0x209883 && _0x3768e7 % 0xc8 == 0x0) {
          for (
            let _0x15550f = 0x0;
            _0x15550f < _0x3e4566[_0xcaac96(0x182)];
            _0x15550f++
          )
            _0x3e4566[_0x15550f][_0xcaac96(0x2c3)]();
        }
      }
      if (_0x3a1262 && (_0x408018 !== 0x0 || (_0x5d148e === 0 && !_0x183856))) {
        if (_0x1a373b > 0x0) {
          _0x1a373b--;
          _0x209883
            ? (_0x2cf38a["frame"][_0xcaac96(0x4b7)] =
                (_0x1a373b / _0x1f57de) * 0x64)
            : (_0x44d1ad[_0xcaac96(0x39a)]["value"] =
                (_0x1a373b / _0x1f57de) * 0x64);
          if (_0x1a373b <= 0x0) {
            _0x24bb4a();
            if (((_0x5d148e === 1 && _0x4268e2) || (_0x5d148e === 2 && _carromFreestyleQueenState.phase === "pending"))) {
              if (!_0x209883) _carromAiShotTurn = _carromTurnId;
              _0x5ebd99 = false;
              // Queue settlement for after pocket detection, including retry ticks.
              let _carromTimeoutTicket = {turn: _carromTurnId, round: _carromRoundId, armed: false, armWait: 4};
              _carromTimeoutReady = _carromTimeoutTicket;
              _0x338c29(function () { if (_carromTimeoutReady === _carromTimeoutTicket) _carromTimeoutTicket.armed = true; }, 0x32);
            } else if (_0x209883) _0x50a0ff();
            else _0x5e7a5f();
          }
        }
      }
      if (!_0x27e1b4[_0xcaac96(0x25e)]) {
        (_0x27e1b4[_0xcaac96(0x3c8)](0x1),
          (_0x27e1b4["zOrder"] = 0xa + _0x27e1b4["y"] / 0x64));
        if (_0x2bd695(_0x27e1b4, _0x2fc10d[0x0]) <= 0x14)
          (_0x28fba8[_0xcaac96(0x383)](_0xcaac96(0x29e)),
            (_0x530863 = !![]),
            _0x27e1b4[_0xcaac96(0x4c3)](!![]),
            Tweener[_0xcaac96(0x3a0)](
              _0x27e1b4,
              {
                x: _0x2fc10d[0x0]["x"],
                y: _0x2fc10d[0x0]["y"],
                alpha: 0.7,
                scaleX: 0.7,
                scaleY: 0.7,
              },
              {
                time: 0xf,
                transition: _0xcaac96(0xeb),
                onComplete: function (_0x478e38) {
                  _0x21acae();
                },
              },
            ));
        else {
          if (_0x2bd695(_0x27e1b4, _0x2fc10d[0x1]) <= 0x14)
            (_0x28fba8[_0xcaac96(0x383)](_0xcaac96(0x29e)),
              (_0x530863 = !![]),
              _0x27e1b4[_0xcaac96(0x4c3)](!![]),
              Tweener[_0xcaac96(0x3a0)](
                _0x27e1b4,
                {
                  x: _0x2fc10d[0x1]["x"],
                  y: _0x2fc10d[0x1]["y"],
                  alpha: 0.7,
                  scaleX: 0.7,
                  scaleY: 0.7,
                },
                {
                  time: 0xf,
                  transition: _0xcaac96(0xeb),
                  onComplete: function (_0x2efba6) {
                    _0x21acae();
                  },
                },
              ));
          else {
            if (_0x2bd695(_0x27e1b4, _0x2fc10d[0x2]) <= 0x14)
              (_0x28fba8["play"](_0xcaac96(0x29e)),
                (_0x530863 = !![]),
                _0x27e1b4["setSensor"](!![]),
                Tweener[_0xcaac96(0x3a0)](
                  _0x27e1b4,
                  {
                    x: _0x2fc10d[0x2]["x"],
                    y: _0x2fc10d[0x2]["y"],
                    alpha: 0.7,
                    scaleX: 0.7,
                    scaleY: 0.7,
                  },
                  {
                    time: 0xf,
                    transition: _0xcaac96(0xeb),
                    onComplete: function (_0x505897) {
                      _0x21acae();
                    },
                  },
                ));
            else
              _0x2bd695(_0x27e1b4, _0x2fc10d[0x3]) <= 0x14 &&
                (_0x28fba8[_0xcaac96(0x383)]("pot"),
                (_0x530863 = !![]),
                _0x27e1b4[_0xcaac96(0x4c3)](!![]),
                Tweener["addTween"](
                  _0x27e1b4,
                  {
                    x: _0x2fc10d[0x3]["x"],
                    y: _0x2fc10d[0x3]["y"],
                    alpha: 0.7,
                    scaleX: 0.7,
                    scaleY: 0.7,
                  },
                  {
                    time: 0xf,
                    transition: _0xcaac96(0xeb),
                    onComplete: function (_0x4b6aca) {
                      _0x21acae();
                    },
                  },
                ));
          }
        }
      }
      var _0x2af6b9 = _0x3231b3[_0xcaac96(0x3c6)](0x0);
      for (let _0x24b438 = 0x0; _0x24b438 < _0x2af6b9["length"]; _0x24b438++) {
        let _0x91f24c = _0x2af6b9[_0x24b438];
        let _carromQueenPocketRound = _carromRoundId;
        (_0x91f24c[_0xcaac96(0x3c8)](),
          (_0x91f24c[_0xcaac96(0x43d)] = 0xa + _0x91f24c["y"] / 0x64));
        if (_0x2bd695(_0x91f24c, _0x2fc10d[0x0]) <= 0x14)
          (_0x28fba8["play"](_0xcaac96(0x29e)),
            (_0x5ebd99 = !![]),
            (_0x4268e2 = !![]),
            _0x91f24c[_0xcaac96(0x4a0)](),
            _0x253500(_0x3231b3, _0x91f24c, !![]),
            (_carromPendingQueenPocket = _0x91f24c),
            _0x54f71d(0x0),
            _0x5d148e == 0x2 && _0x31089b[_0xcaac96(0x3b0)](_0x91f24c),
            Tweener[_0xcaac96(0x3a0)](
              _0x91f24c,
              {
                x: _0x2fc10d[0x0]["x"],
                y: _0x2fc10d[0x0]["y"],
                alpha: 0.7,
                scaleX: 0.9,
                scaleY: 0.9,
              },
              {
                time: 0xf,
                transition: "easeOutCirc",
                onComplete: function (_0x3dfbbb) {
                  if (!_0x3fddb3 || _carromQueenPocketRound !== _carromRoundId) { if (_0x3dfbbb.parent) _0x3dfbbb.parent.removeChild(_0x3dfbbb); return; }
                  if (_carromPendingQueenPocket !== _0x91f24c) return;
                  var _0x158a8b = _0xcaac96;
                  if (_0x5d148e == 0x2) {
                  } else
                    ((_0x91f24c[_0x158a8b(0x43d)] = 0x6e),
                      _0x209883
                        ? Tweener["addTween"](
                            _0x3dfbbb,
                            {
                              x: _0x539ff8["x"] + 0x50,
                              y: _0x539ff8["y"],
                              scaleX: 0.9,
                              scaleY: 0.9,
                              alpha: 0x1,
                            },
                            {
                              time: 0x14,
                              transition: "easeOutQuad",
                              onComplete: function () {
                                    if (!_0x3fddb3 || _carromQueenPocketRound !== _carromRoundId) { if (_0x3dfbbb.parent) _0x3dfbbb.parent.removeChild(_0x3dfbbb); return; }
                  if (_carromPendingQueenPocket !== _0x91f24c) return;
                                var _0x33c53a = _0x158a8b;
                                ((_carromPendingQueenPocket === _0x3dfbbb && (_carromPendingQueenPocket = null)), (_0x404020 = _0x3dfbbb),
                                  (_0x337f1a["x"] = _0x3dfbbb["x"] + 0xa),
                                  (_0x337f1a["y"] = _0x3dfbbb["y"] - 0xa),
                                  (_0x337f1a[_0x33c53a(0x197)] = !![]),
                                  (_0x337f1a["texture"] =
                                    PIXI[_0x33c53a(0x304)]["TextureCache"][
                                      (_0x5d148e === 1 && !_0x4268e2 ? "check_filled" : "check_unfilled")
                                    ]));
                              },
                            },
                          )
                        : Tweener["addTween"](
                            _0x3dfbbb,
                            {
                              x: _0x25b85f["x"] - 0x32,
                              y: _0x25b85f["y"],
                              scaleX: 0.9,
                              scaleY: 0.9,
                              alpha: 0x1,
                            },
                            {
                              time: 0x14,
                              transition: _0x158a8b(0x1f9),
                              onComplete: function () {
                                    if (!_0x3fddb3 || _carromQueenPocketRound !== _carromRoundId) { if (_0x3dfbbb.parent) _0x3dfbbb.parent.removeChild(_0x3dfbbb); return; }
                  if (_carromPendingQueenPocket !== _0x91f24c) return;
                                var _0x27e67e = _0x158a8b;
                                ((_carromPendingQueenPocket === _0x3dfbbb && (_carromPendingQueenPocket = null)), (_0x404020 = _0x3dfbbb),
                                  (_0x337f1a["x"] = _0x3dfbbb["x"] + 0xa));
                                ((_0x337f1a["y"] = _0x3dfbbb["y"] - 0xa),
                                  (_0x337f1a["visible"] = !![]),
                                  (_0x337f1a[_0x27e67e(0x335)] =
                                    PIXI[_0x27e67e(0x304)][_0x27e67e(0x299)][
                                      (_0x5d148e === 1 && !_0x4268e2 ? "check_filled" : "check_unfilled")
                                    ]));
                              },
                            },
                          ));
                },
              },
            ));
        else {
          if (_0x2bd695(_0x91f24c, _0x2fc10d[0x1]) <= 0x14)
            (_0x28fba8[_0xcaac96(0x383)]("pot"),
              (_0x5ebd99 = !![]),
              (_0x4268e2 = !![]),
              _0x91f24c[_0xcaac96(0x4a0)](),
              _0x253500(_0x3231b3, _0x91f24c, !![]),
            (_carromPendingQueenPocket = _0x91f24c),
              _0x54f71d(0x1),
              _0x5d148e == 0x2 && _0x31089b[_0xcaac96(0x3b0)](_0x91f24c),
              Tweener[_0xcaac96(0x3a0)](
                _0x91f24c,
                {
                  x: _0x2fc10d[0x1]["x"],
                  y: _0x2fc10d[0x1]["y"],
                  alpha: 0.7,
                  scaleX: 0.9,
                  scaleY: 0.9,
                },
                {
                  time: 0xf,
                  transition: _0xcaac96(0xeb),
                  onComplete: function (_0xc3117a) {
                  if (!_0x3fddb3 || _carromQueenPocketRound !== _carromRoundId) { if (_0xc3117a.parent) _0xc3117a.parent.removeChild(_0xc3117a); return; }
                  if (_carromPendingQueenPocket !== _0x91f24c) return;
                    var _0x427609 = _0xcaac96;
                    if (_0x5d148e == 0x2) {
                    } else
                      ((_0x91f24c[_0x427609(0x43d)] = 0x6e),
                        _0x209883
                          ? Tweener[_0x427609(0x3a0)](
                              _0xc3117a,
                              {
                                x: _0x539ff8["x"] + 0x50,
                                y: _0x539ff8["y"],
                                scaleX: 0.9,
                                scaleY: 0.9,
                                alpha: 0x1,
                              },
                              {
                                time: 0x14,
                                transition: "easeOutQuad",
                                onComplete: function () {
                                    if (!_0x3fddb3 || _carromQueenPocketRound !== _carromRoundId) { if (_0xc3117a.parent) _0xc3117a.parent.removeChild(_0xc3117a); return; }
                  if (_carromPendingQueenPocket !== _0x91f24c) return;
                                  var _0x3cfb3a = _0x427609;
                                  ((_carromPendingQueenPocket === _0xc3117a && (_carromPendingQueenPocket = null)), (_0x404020 = _0xc3117a),
                                    (_0x337f1a["x"] = _0xc3117a["x"] + 0xa),
                                    (_0x337f1a["y"] = _0xc3117a["y"] - 0xa),
                                    (_0x337f1a[_0x3cfb3a(0x197)] = !![]),
                                    (_0x337f1a[_0x3cfb3a(0x335)] =
                                      PIXI[_0x3cfb3a(0x304)][_0x3cfb3a(0x299)][
                                        (_0x5d148e === 1 && !_0x4268e2 ? "check_filled" : "check_unfilled")
                                      ]));
                                },
                              },
                            )
                          : Tweener[_0x427609(0x3a0)](
                              _0xc3117a,
                              {
                                x: _0x25b85f["x"] - 0x32,
                                y: _0x25b85f["y"],
                                scaleX: 0.9,
                                scaleY: 0.9,
                                alpha: 0x1,
                              },
                              {
                                time: 0x14,
                                transition: _0x427609(0x1f9),
                                onComplete: function () {
                                    if (!_0x3fddb3 || _carromQueenPocketRound !== _carromRoundId) { if (_0xc3117a.parent) _0xc3117a.parent.removeChild(_0xc3117a); return; }
                  if (_carromPendingQueenPocket !== _0x91f24c) return;
                                  var _0x4d44cb = _0x427609;
                                  ((_carromPendingQueenPocket === _0xc3117a && (_carromPendingQueenPocket = null)), (_0x404020 = _0xc3117a),
                                    (_0x337f1a["x"] = _0xc3117a["x"] + 0xa),
                                    (_0x337f1a["y"] = _0xc3117a["y"] - 0xa),
                                    (_0x337f1a[_0x4d44cb(0x197)] = !![]),
                                    (_0x337f1a[_0x4d44cb(0x335)] =
                                      PIXI["utils"][_0x4d44cb(0x299)][
                                        (_0x5d148e === 1 && !_0x4268e2 ? "check_filled" : "check_unfilled")
                                      ]));
                                },
                              },
                            ));
                  },
                },
              ));
          else {
            if (_0x2bd695(_0x91f24c, _0x2fc10d[0x2]) <= 0x14)
              (_0x28fba8[_0xcaac96(0x383)](_0xcaac96(0x29e)),
                (_0x5ebd99 = !![]),
                (_0x4268e2 = !![]),
                _0x91f24c["removeFromWorld"](),
                _0x253500(_0x3231b3, _0x91f24c, !![]),
            (_carromPendingQueenPocket = _0x91f24c),
                _0x54f71d(0x2),
                _0x5d148e == 0x2 && _0x31089b[_0xcaac96(0x3b0)](_0x91f24c),
                Tweener[_0xcaac96(0x3a0)](
                  _0x91f24c,
                  {
                    x: _0x2fc10d[0x2]["x"],
                    y: _0x2fc10d[0x2]["y"],
                    alpha: 0.7,
                    scaleX: 0.9,
                    scaleY: 0.9,
                  },
                  {
                    time: 0xf,
                    transition: "easeOutCirc",
                    onComplete: function (_0x3b5e8b) {
                  if (!_0x3fddb3 || _carromQueenPocketRound !== _carromRoundId) { if (_0x3b5e8b.parent) _0x3b5e8b.parent.removeChild(_0x3b5e8b); return; }
                  if (_carromPendingQueenPocket !== _0x91f24c) return;
                      var _0x4f0477 = _0xcaac96;
                      if (_0x5d148e == 0x2) {
                      } else
                        ((_0x91f24c[_0x4f0477(0x43d)] = 0x6e),
                          _0x209883
                            ? Tweener[_0x4f0477(0x3a0)](
                                _0x3b5e8b,
                                {
                                  x: _0x539ff8["x"] + 0x50,
                                  y: _0x539ff8["y"],
                                  scaleX: 0.9,
                                  scaleY: 0.9,
                                  alpha: 0x1,
                                },
                                {
                                  time: 0x14,
                                  transition: _0x4f0477(0x1f9),
                                  onComplete: function () {
                                    if (!_0x3fddb3 || _carromQueenPocketRound !== _carromRoundId) { if (_0x3b5e8b.parent) _0x3b5e8b.parent.removeChild(_0x3b5e8b); return; }
                  if (_carromPendingQueenPocket !== _0x91f24c) return;
                                    var _0x5a3195 = _0x4f0477;
                                    ((_carromPendingQueenPocket === _0x3b5e8b && (_carromPendingQueenPocket = null)), (_0x404020 = _0x3b5e8b),
                                      (_0x337f1a["x"] = _0x3b5e8b["x"] + 0xa),
                                      (_0x337f1a["y"] = _0x3b5e8b["y"] - 0xa),
                                      (_0x337f1a[_0x5a3195(0x197)] = !![]),
                                      (_0x337f1a[_0x5a3195(0x335)] =
                                        PIXI[_0x5a3195(0x304)][
                                          _0x5a3195(0x299)
                                        ][(_0x5d148e === 1 && !_0x4268e2 ? "check_filled" : "check_unfilled")]));
                                  },
                                },
                              )
                            : Tweener[_0x4f0477(0x3a0)](
                                _0x3b5e8b,
                                {
                                  x: _0x25b85f["x"] - 0x32,
                                  y: _0x25b85f["y"],
                                  scaleX: 0.9,
                                  scaleY: 0.9,
                                  alpha: 0x1,
                                },
                                {
                                  time: 0x14,
                                  transition: "easeOutQuad",
                                  onComplete: function () {
                                    if (!_0x3fddb3 || _carromQueenPocketRound !== _carromRoundId) { if (_0x3b5e8b.parent) _0x3b5e8b.parent.removeChild(_0x3b5e8b); return; }
                  if (_carromPendingQueenPocket !== _0x91f24c) return;
                                    var _0xd3a21 = _0x4f0477;
                                    ((_carromPendingQueenPocket === _0x3b5e8b && (_carromPendingQueenPocket = null)), (_0x404020 = _0x3b5e8b),
                                      (_0x337f1a["x"] = _0x3b5e8b["x"] + 0xa),
                                      (_0x337f1a["y"] = _0x3b5e8b["y"] - 0xa),
                                      (_0x337f1a[_0xd3a21(0x197)] = !![]),
                                      (_0x337f1a["texture"] =
                                        PIXI[_0xd3a21(0x304)][_0xd3a21(0x299)][
                                          (_0x5d148e === 1 && !_0x4268e2 ? "check_filled" : "check_unfilled")
                                        ]));
                                  },
                                },
                              ));
                    },
                  },
                ));
            else
              _0x2bd695(_0x91f24c, _0x2fc10d[0x3]) <= 0x14 &&
                (_0x28fba8[_0xcaac96(0x383)](_0xcaac96(0x29e)),
                (_0x5ebd99 = !![]),
                (_0x4268e2 = !![]),
                _0x91f24c["removeFromWorld"](),
                _0x253500(_0x3231b3, _0x91f24c, !![]),
            (_carromPendingQueenPocket = _0x91f24c),
                _0x54f71d(0x3),
                _0x5d148e == 0x2 && _0x31089b[_0xcaac96(0x3b0)](_0x91f24c),
                Tweener[_0xcaac96(0x3a0)](
                  _0x91f24c,
                  {
                    x: _0x2fc10d[0x3]["x"],
                    y: _0x2fc10d[0x3]["y"],
                    alpha: 0.7,
                    scaleX: 0.9,
                    scaleY: 0.9,
                  },
                  {
                    time: 0xf,
                    transition: _0xcaac96(0xeb),
                    onComplete: function (_0xa70983) {
                  if (!_0x3fddb3 || _carromQueenPocketRound !== _carromRoundId) { if (_0xa70983.parent) _0xa70983.parent.removeChild(_0xa70983); return; }
                  if (_carromPendingQueenPocket !== _0x91f24c) return;
                      var _0x2eabac = _0xcaac96;
                      if (_0x5d148e == 0x2) {
                      } else
                        ((_0x91f24c[_0x2eabac(0x43d)] = 0x6e),
                          _0x209883
                            ? Tweener[_0x2eabac(0x3a0)](
                                _0xa70983,
                                {
                                  x: _0x539ff8["x"] + 0x50,
                                  y: _0x539ff8["y"],
                                  scaleX: 0.9,
                                  scaleY: 0.9,
                                  alpha: 0x1,
                                },
                                {
                                  time: 0x14,
                                  transition: _0x2eabac(0x1f9),
                                  onComplete: function () {
                                    if (!_0x3fddb3 || _carromQueenPocketRound !== _carromRoundId) { if (_0xa70983.parent) _0xa70983.parent.removeChild(_0xa70983); return; }
                  if (_carromPendingQueenPocket !== _0x91f24c) return;
                                    var _0xc16497 = _0x2eabac;
                                    ((_carromPendingQueenPocket === _0xa70983 && (_carromPendingQueenPocket = null)), (_0x404020 = _0xa70983),
                                      (_0x337f1a["x"] = _0xa70983["x"] + 0xa),
                                      (_0x337f1a["y"] = _0xa70983["y"] - 0xa),
                                      (_0x337f1a[_0xc16497(0x197)] = !![]),
                                      (_0x337f1a["texture"] =
                                        PIXI[_0xc16497(0x304)][
                                          _0xc16497(0x299)
                                        ][(_0x5d148e === 1 && !_0x4268e2 ? "check_filled" : "check_unfilled")]));
                                  },
                                },
                              )
                            : Tweener[_0x2eabac(0x3a0)](
                                _0xa70983,
                                {
                                  x: _0x25b85f["x"] - 0x32,
                                  y: _0x25b85f["y"],
                                  scaleX: 0.9,
                                  scaleY: 0.9,
                                  alpha: 0x1,
                                },
                                {
                                  time: 0x14,
                                  transition: _0x2eabac(0x1f9),
                                  onComplete: function () {
                                    if (!_0x3fddb3 || _carromQueenPocketRound !== _carromRoundId) { if (_0xa70983.parent) _0xa70983.parent.removeChild(_0xa70983); return; }
                  if (_carromPendingQueenPocket !== _0x91f24c) return;
                                    var _0x58e005 = _0x2eabac;
                                    ((_carromPendingQueenPocket === _0xa70983 && (_carromPendingQueenPocket = null)), (_0x404020 = _0xa70983),
                                      (_0x337f1a["x"] = _0xa70983["x"] + 0xa),
                                      (_0x337f1a["y"] = _0xa70983["y"] - 0xa),
                                      (_0x337f1a[_0x58e005(0x197)] = !![]),
                                      (_0x337f1a[_0x58e005(0x335)] =
                                        PIXI[_0x58e005(0x304)][
                                          _0x58e005(0x299)
                                        ][(_0x5d148e === 1 && !_0x4268e2 ? "check_filled" : "check_unfilled")]));
                                  },
                                },
                              ));
                    },
                  },
                ));
          }
        }
      }
      var _0x2af6b9 = _0x3e4566["slice"](0x0);
      for (
        let _0x2cfe77 = 0x0;
        _0x2cfe77 < _0x2af6b9[_0xcaac96(0x182)];
        _0x2cfe77++
      ) {
        let _0x2c2cc8 = _0x2af6b9[_0x2cfe77];
        (_0x2c2cc8[_0xcaac96(0x3c8)](),
          (_0x2c2cc8["zOrder"] = 0xa + _0x2c2cc8["y"] / 0x64));
        if (_0x2bd695(_0x2c2cc8, _0x2fc10d[0x0]) <= 0x14) {
          _0x28fba8[_0xcaac96(0x383)](_0xcaac96(0x29e));
          _0x4268e2 &&
            ((_0x337f1a["texture"] =
              PIXI[_0xcaac96(0x304)][_0xcaac96(0x299)][_0xcaac96(0x234)]),
            Tweener[_0xcaac96(0x3a0)](
              _0x337f1a,
              { scaleX: 1.2, scaleY: 1.2 },
              { time: 0xa, transition: _0xcaac96(0x205) },
            ));
          if (_0x209883 || _0x5d148e == 0x2) _0x5ebd99 = !![];
          ((_carromQueenClearedThisShot = _carromQueenClearedThisShot || (_0x5d148e === 1 && _0x4268e2)), (_0x4268e2 = ![]),
            _0x2c2cc8[_0xcaac96(0x4a0)](),
            _0x253500(_0x3e4566, _0x2c2cc8, !![]),
            _0x54f71d(0x0),
            (_0x2c2cc8[_0xcaac96(0x43d)] = 0xa));
          _0x31089b["push"](_0x2c2cc8);
          Tweener[_0xcaac96(0x3a0)](
            _0x2c2cc8,
            {
              x: _0x2fc10d[0x0]["x"],
              y: _0x2fc10d[0x0]["y"],
              alpha: 0.7,
              scaleX: 0.9,
              scaleY: 0.9,
            },
            {
              time: 0xf,
              transition: "easeOutCirc",
              onComplete: function (_0x5507a8) {
                if (_0x5d148e == 0x1 && !_0x2a9c75["length"]) {
                } else {
                }
              },
            },
          );
        } else {
          if (_0x2bd695(_0x2c2cc8, _0x2fc10d[0x1]) <= 0x14) {
            _0x28fba8[_0xcaac96(0x383)](_0xcaac96(0x29e));
            _0x4268e2 &&
              ((_0x337f1a[_0xcaac96(0x335)] =
                PIXI[_0xcaac96(0x304)]["TextureCache"]["check_filled"]),
              Tweener[_0xcaac96(0x3a0)](
                _0x337f1a,
                { scaleX: 1.2, scaleY: 1.2 },
                { time: 0xa, transition: _0xcaac96(0x205) },
              ));
            if (_0x209883 || _0x5d148e == 0x2) _0x5ebd99 = !![];
            ((_carromQueenClearedThisShot = _carromQueenClearedThisShot || (_0x5d148e === 1 && _0x4268e2)), (_0x4268e2 = ![]),
              _0x2c2cc8[_0xcaac96(0x4a0)](),
              _0x253500(_0x3e4566, _0x2c2cc8, !![]),
              _0x54f71d(0x1),
              (_0x2c2cc8[_0xcaac96(0x43d)] = 0xa));
            _0x31089b["push"](_0x2c2cc8);
            Tweener[_0xcaac96(0x3a0)](
              _0x2c2cc8,
              {
                x: _0x2fc10d[0x1]["x"],
                y: _0x2fc10d[0x1]["y"],
                alpha: 0.7,
                scaleX: 0.9,
                scaleY: 0.9,
              },
              {
                time: 0xf,
                transition: _0xcaac96(0xeb),
                onComplete: function (_0x5b75ae) {
                  if (_0x5d148e == 0x1 && !_0x2a9c75["length"]) {
                  } else {
                  }
                },
              },
            );
          } else {
            if (_0x2bd695(_0x2c2cc8, _0x2fc10d[0x2]) <= 0x14) {
              _0x28fba8[_0xcaac96(0x383)](_0xcaac96(0x29e));
              _0x4268e2 &&
                ((_0x337f1a["texture"] =
                  PIXI[_0xcaac96(0x304)][_0xcaac96(0x299)][_0xcaac96(0x234)]),
                Tweener[_0xcaac96(0x3a0)](
                  _0x337f1a,
                  { scaleX: 1.2, scaleY: 1.2 },
                  { time: 0xa, transition: _0xcaac96(0x205) },
                ));
              if (_0x209883 || _0x5d148e == 0x2) _0x5ebd99 = !![];
              ((_carromQueenClearedThisShot = _carromQueenClearedThisShot || (_0x5d148e === 1 && _0x4268e2)), (_0x4268e2 = ![]),
                _0x2c2cc8[_0xcaac96(0x4a0)](),
                _0x253500(_0x3e4566, _0x2c2cc8, !![]),
                _0x54f71d(0x2),
                (_0x2c2cc8[_0xcaac96(0x43d)] = 0xa));
              _0x31089b[_0xcaac96(0x3b0)](_0x2c2cc8);
              Tweener["addTween"](
                _0x2c2cc8,
                {
                  x: _0x2fc10d[0x2]["x"],
                  y: _0x2fc10d[0x2]["y"],
                  alpha: 0.7,
                  scaleX: 0.9,
                  scaleY: 0.9,
                },
                {
                  time: 0xf,
                  transition: "easeOutCirc",
                  onComplete: function (_0x496ebc) {
                    var _0x67a916 = _0xcaac96;
                    if (_0x5d148e == 0x1 && !_0x2a9c75[_0x67a916(0x182)]) {
                    } else {
                    }
                  },
                },
              );
            } else {
              if (_0x2bd695(_0x2c2cc8, _0x2fc10d[0x3]) <= 0x14) {
                _0x28fba8[_0xcaac96(0x383)](_0xcaac96(0x29e));
                _0x4268e2 &&
                  ((_0x337f1a["texture"] =
                    PIXI[_0xcaac96(0x304)][_0xcaac96(0x299)]["check_filled"]),
                  Tweener["addTween"](
                    _0x337f1a,
                    { scaleX: 1.2, scaleY: 1.2 },
                    { time: 0xa, transition: "bow" },
                  ));
                if (_0x209883 || _0x5d148e == 0x2) _0x5ebd99 = !![];
                ((_carromQueenClearedThisShot = _carromQueenClearedThisShot || (_0x5d148e === 1 && _0x4268e2)), (_0x4268e2 = ![]),
                  _0x2c2cc8[_0xcaac96(0x4a0)](),
                  _0x253500(_0x3e4566, _0x2c2cc8, !![]),
                  _0x54f71d(0x3),
                  (_0x2c2cc8["zOrder"] = 0xa));
                _0x31089b[_0xcaac96(0x3b0)](_0x2c2cc8);
                Tweener[_0xcaac96(0x3a0)](
                  _0x2c2cc8,
                  {
                    x: _0x2fc10d[0x3]["x"],
                    y: _0x2fc10d[0x3]["y"],
                    alpha: 0.7,
                    scaleX: 0.9,
                    scaleY: 0.9,
                  },
                  {
                    time: 0xf,
                    transition: _0xcaac96(0xeb),
                    onComplete: function (_0x5611e7) {
                      var _0x3246e5 = _0xcaac96;
                      if (_0x5d148e == 0x1 && !_0x2a9c75[_0x3246e5(0x182)]) {
                      } else {
                      }
                    },
                  },
                );
              }
            }
          }
        }
      }
      var _0x2af6b9 = _0x2a9c75[_0xcaac96(0x3c6)](0x0);
      for (let _0x148c54 = 0x0; _0x148c54 < _0x2af6b9["length"]; _0x148c54++) {
        let _0x959ea5 = _0x2af6b9[_0x148c54];
        (_0x959ea5[_0xcaac96(0x3c8)](),
          (_0x959ea5[_0xcaac96(0x43d)] = 0xa + _0x959ea5["y"] / 0x64));
        if (_0x2bd695(_0x959ea5, _0x2fc10d[0x0]) <= 0x14) {
          _0x28fba8[_0xcaac96(0x383)](_0xcaac96(0x29e));
          _0x4268e2 &&
            ((_0x337f1a[_0xcaac96(0x335)] =
              PIXI["utils"][_0xcaac96(0x299)]["check_filled"]),
            Tweener[_0xcaac96(0x3a0)](
              _0x337f1a,
              { scaleX: 1.2, scaleY: 1.2 },
              { time: 0xa, transition: _0xcaac96(0x205) },
            ));
          if (!_0x209883 || _0x5d148e == 0x2) _0x5ebd99 = !![];
          ((_carromQueenClearedThisShot = _carromQueenClearedThisShot || (_0x5d148e === 1 && _0x4268e2)), (_0x4268e2 = ![]),
            _0x959ea5[_0xcaac96(0x4a0)](),
            _0x253500(_0x2a9c75, _0x959ea5, !![]),
            _0x54f71d(0x0),
            (_0x959ea5[_0xcaac96(0x43d)] = 0xa));
          _0x31089b[_0xcaac96(0x3b0)](_0x959ea5);
          Tweener[_0xcaac96(0x3a0)](
            _0x959ea5,
            {
              x: _0x2fc10d[0x0]["x"],
              y: _0x2fc10d[0x0]["y"],
              alpha: 0.7,
              scaleX: 0.9,
              scaleY: 0.9,
            },
            {
              time: 0xf,
              transition: _0xcaac96(0xeb),
              onComplete: function (_0x2035c1) {
                var _0x5f3662 = _0xcaac96;
                if (_0x5d148e == 0x1 && !_0x3e4566[_0x5f3662(0x182)]) {
                } else {
                }
              },
            },
          );
        } else {
          if (_0x2bd695(_0x959ea5, _0x2fc10d[0x1]) <= 0x14) {
            _0x28fba8[_0xcaac96(0x383)](_0xcaac96(0x29e));
            _0x4268e2 &&
              ((_0x337f1a[_0xcaac96(0x335)] =
                PIXI[_0xcaac96(0x304)][_0xcaac96(0x299)][_0xcaac96(0x234)]),
              Tweener[_0xcaac96(0x3a0)](
                _0x337f1a,
                { scaleX: 1.2, scaleY: 1.2 },
                { time: 0xa, transition: _0xcaac96(0x205) },
              ));
            if (!_0x209883 || _0x5d148e == 0x2) _0x5ebd99 = !![];
            ((_carromQueenClearedThisShot = _carromQueenClearedThisShot || (_0x5d148e === 1 && _0x4268e2)), (_0x4268e2 = ![]),
              _0x959ea5[_0xcaac96(0x4a0)](),
              _0x253500(_0x2a9c75, _0x959ea5, !![]),
              _0x54f71d(0x1),
              (_0x959ea5[_0xcaac96(0x43d)] = 0xa));
            _0x31089b[_0xcaac96(0x3b0)](_0x959ea5);
            Tweener[_0xcaac96(0x3a0)](
              _0x959ea5,
              {
                x: _0x2fc10d[0x1]["x"],
                y: _0x2fc10d[0x1]["y"],
                alpha: 0.7,
                scaleX: 0.9,
                scaleY: 0.9,
              },
              {
                time: 0xf,
                transition: _0xcaac96(0xeb),
                onComplete: function (_0x15d729) {
                  if (_0x5d148e == 0x1 && !_0x3e4566["length"]) {
                  } else {
                  }
                },
              },
            );
          } else {
            if (_0x2bd695(_0x959ea5, _0x2fc10d[0x2]) <= 0x14) {
              _0x28fba8[_0xcaac96(0x383)](_0xcaac96(0x29e));
              _0x4268e2 &&
                ((_0x337f1a[_0xcaac96(0x335)] =
                  PIXI[_0xcaac96(0x304)]["TextureCache"][_0xcaac96(0x234)]),
                Tweener[_0xcaac96(0x3a0)](
                  _0x337f1a,
                  { scaleX: 1.2, scaleY: 1.2 },
                  { time: 0xa, transition: _0xcaac96(0x205) },
                ));
              if (!_0x209883 || _0x5d148e == 0x2) _0x5ebd99 = !![];
              ((_carromQueenClearedThisShot = _carromQueenClearedThisShot || (_0x5d148e === 1 && _0x4268e2)), (_0x4268e2 = ![]),
                _0x959ea5[_0xcaac96(0x4a0)](),
                _0x253500(_0x2a9c75, _0x959ea5, !![]),
                _0x54f71d(0x2),
                (_0x959ea5[_0xcaac96(0x43d)] = 0xa));
              _0x31089b[_0xcaac96(0x3b0)](_0x959ea5);
              Tweener[_0xcaac96(0x3a0)](
                _0x959ea5,
                {
                  x: _0x2fc10d[0x2]["x"],
                  y: _0x2fc10d[0x2]["y"],
                  alpha: 0.7,
                  scaleX: 0.9,
                  scaleY: 0.9,
                },
                {
                  time: 0xf,
                  transition: _0xcaac96(0xeb),
                  onComplete: function (_0x39759e) {
                    var _0xb15607 = _0xcaac96;
                    if (_0x5d148e == 0x1 && !_0x3e4566[_0xb15607(0x182)]) {
                    } else {
                    }
                  },
                },
              );
            } else {
              if (_0x2bd695(_0x959ea5, _0x2fc10d[0x3]) <= 0x14) {
                _0x28fba8[_0xcaac96(0x383)]("pot");
                _0x4268e2 &&
                  ((_0x337f1a[_0xcaac96(0x335)] =
                    PIXI[_0xcaac96(0x304)][_0xcaac96(0x299)][_0xcaac96(0x234)]),
                  Tweener[_0xcaac96(0x3a0)](
                    _0x337f1a,
                    { scaleX: 1.2, scaleY: 1.2 },
                    { time: 0xa, transition: _0xcaac96(0x205) },
                  ));
                if (!_0x209883 || _0x5d148e == 0x2) _0x5ebd99 = !![];
                ((_carromQueenClearedThisShot = _carromQueenClearedThisShot || (_0x5d148e === 1 && _0x4268e2)), (_0x4268e2 = ![]),
                  _0x959ea5["removeFromWorld"](),
                  _0x253500(_0x2a9c75, _0x959ea5, !![]),
                  _0x54f71d(0x3),
                  (_0x959ea5[_0xcaac96(0x43d)] = 0xa));
                _0x31089b["push"](_0x959ea5);
                Tweener[_0xcaac96(0x3a0)](
                  _0x959ea5,
                  {
                    x: _0x2fc10d[0x3]["x"],
                    y: _0x2fc10d[0x3]["y"],
                    alpha: 0.7,
                    scaleX: 0.9,
                    scaleY: 0.9,
                  },
                  {
                    time: 0xf,
                    transition: "easeOutCirc",
                    onComplete: function (_0x4b6533) {
                      var _0x2acdfd = _0xcaac96;
                      if (_0x5d148e == 0x1 && !_0x3e4566[_0x2acdfd(0x182)]) {
                      } else {
                      }
                    },
                  },
                );
              }
            }
          }
        }
      }
      _carromFlushTimeoutAfterScan();
      (_0x1392b5[_0xcaac96(0x321)](0x1 / 0x3c, 0xa, 0xa),
        _0x1392b5["clearForces"]());
      if (!_0x3fddb3) return;
      if (!_0x39ab6a) return;
      if (_0x3b3e21) _0xcf7ce5[_0xcaac96(0x1ac)]();
      else {
      }
    }
    var _0x990fb7 = 0x0;
    function _0x4bf21a(_0x55838a) {
      if (_carromMatchBlocked()) return;
      _0x990fb7 += _0x55838a;
      while (_0x990fb7 > 0x1) {
        (_0x990fb7--, _0x49d791(0x1));
        if (_carromMatchBlocked()) break;
      }
    }
    function _0x1c49c9() {}
    function _0x18076e(_0x24af22, _0x94b31e) {
      var _0x54dc09 = _0x157421;
      ((_0x25199a["full"]["width"] =
        (_0x24af22[_0x54dc09(0x2f7)] / 0x64) * 0x1ae),
        _0x423f7f["render"]());
    }
    function _0x16b945(_0x4c4876, _0x30a3fe) {
      _0x3690db();
    }
    function _0xf558ce(_0x17fdf4) {
      if (_0x3e43c0 || !_0x3b3e21 || _0x3e61d0 || _carromHostPaused || !_0x3fddb3) return;
      if (_0xcfa3ba) _0xcfa3ba = ![];
    }
    function _0x152e94(_0x52c0ad) {
      var _0x3523aa = _0x157421;
      if (_0x3e43c0 || !_0x3b3e21 || _0x3e61d0 || _carromHostPaused || !_0x3fddb3) return;
      (_0x52c0ad[_0x3523aa(0x457)](),
        (_0x2b840a["x"] = _0x52c0ad[_0x3523aa(0x3ca)]["global"]["x"]),
        (_0x2b840a["y"] = _0x52c0ad["data"][_0x3523aa(0x192)]["y"]));
    }
    function _0x12774a(_0x47887d) {
      var _0x1b3d43 = _0x157421;
      if (_0x3e43c0 || !_0x3b3e21 || _0x3e61d0 || _carromHostPaused || !_0x3fddb3) return;
      ((_0x2b840a["x"] = _0x47887d["data"][_0x1b3d43(0x192)]["x"]),
        (_0x2b840a["y"] = _0x47887d[_0x1b3d43(0x3ca)][_0x1b3d43(0x192)]["y"]),
        _0x47887d[_0x1b3d43(0x457)]());
    }
    function _0x3154dc(_0x28ac5a) {
      var _0x3b1684 = _0x157421;
      if (_0x3e43c0 || !_0x3b3e21 || _0x3e61d0 || _carromHostPaused || !_0x3fddb3) return;
      if (!_0xb768e8 || _0xb768e8 != _0x28ac5a[_0x3b1684(0x17e)]) {
        _0xb768e8 = _0x28ac5a[_0x3b1684(0x17e)];
        switch (_0x28ac5a["keyCode"]) {
          case 0x25:
            break;
          case 0x27:
            break;
        }
      }
    }
    function _0x3d59fa(_0x2fe861) {
      var _0x1a1c46 = _0x157421;
      _0xb768e8 == _0x2fe861[_0x1a1c46(0x17e)] && (_0xb768e8 = null);
    }
    function _0x232077() {
      var _0x1a9efd = _0x157421;
      for (
        let _0x4f77f4 = 0x0;
        _0x4f77f4 < _0x57e1d2[_0x1a9efd(0x182)];
        _0x4f77f4++
      ) {
        if (
          _0x57e1d2[_0x4f77f4]["state"] == "locked" &&
          _0x57e1d2[_0x4f77f4][_0x1a9efd(0x4b7)] <= _0xa07851
        )
          return !![];
        else {
          if (
            (_0x57e1d2[_0x4f77f4]["state"] == "unlocked" ||
              _0x57e1d2[_0x4f77f4][_0x1a9efd(0x43f)] == _0x1a9efd(0x16d)) &&
            _0x57e1d2[_0x4f77f4][_0x1a9efd(0x1ea)] <
              _0x4537e2[_0x4f77f4]["upgrade"] &&
            _0x57e1d2[_0x4f77f4]["upgradeCost"] <= _0xa07851
          )
            return !![];
        }
      }
      for (
        let _0x2134e6 = 0x0;
        _0x2134e6 < _0x75fa36[_0x1a9efd(0x182)];
        _0x2134e6++
      ) {
        if (
          _0x75fa36[_0x2134e6][_0x1a9efd(0x43f)] == "locked" &&
          _0x75fa36[_0x2134e6][_0x1a9efd(0x4b7)] <= _0xa07851
        )
          return !![];
      }
      return ![];
    }
    function _0xffce48(_0x152195) {
      return _0x2916e6[_0x152195];
    }
    function _carromMatchBlocked() {
      return _carromHostPaused || _carromAdTokens.length > 0;
    }
    function _carromAdPause(token) {
      if (_carromAdTokens.indexOf(token) >= 0) return;
      _carromAdTokens.push(token);
      _0x990fb7 = 0;
      _carromPauseMatchTimers();
      _carromSyncMute();
    }
    function _carromAdResume(token) {
      var index = _carromAdTokens.indexOf(token);
      if (index < 0) return;
      _carromAdTokens.splice(index, 1);
      _carromSyncMute();
      if (!_carromMatchBlocked()) _carromResumeMatchTimers();
    }
    function _carromMatchSchedule(owner, callback, delay) {
      var task = { owner: owner, callback: callback, remaining: delay, handle: null, due: 0, version: 0 };
      _carromMatchTimers.push(task);
      if (!_carromMatchBlocked()) _carromMatchArm(task);
    }
    function _carromMatchNow() {
      return typeof performance !== 'undefined' && typeof performance.now === 'function' ? performance.now() : Date.now();
    }
    function _carromMatchArm(task) {
      var armVersion = ++task.version;
      task.due = _carromMatchNow() + task.remaining;
      task.handle = setTimeout(function () {
        if (task.version !== armVersion || _carromMatchBlocked()) return;
        task.handle = null;
        var index = _carromMatchTimers.indexOf(task);
        if (index < 0) return;
        _carromMatchTimers.splice(index, 1);
        if (task.owner === _carromActiveMatch && _0x423f7f && task.owner.parent === _0x423f7f.stage) task.callback();
      }, task.remaining);
    }
    function _carromCancelMatchTimers(owner) {
      _carromMatchTimers.slice().forEach(function (task) {
        if (task.owner !== owner) return;
        task.version++;
        if (task.handle !== null) clearTimeout(task.handle);
        var index = _carromMatchTimers.indexOf(task);
        if (index >= 0) _carromMatchTimers.splice(index, 1);
      });
    }
    function _carromPauseMatchTimers() {
      var now = _carromMatchNow();
      _carromMatchTimers.forEach(function (task) {
        if (task.handle === null) return;
        task.version++;
        clearTimeout(task.handle);
        task.handle = null;
        task.remaining = Math.max(0, task.due - now);
      });
    }
    function _carromResumeMatchTimers() {
      if (_carromMatchBlocked()) return;
      _carromMatchTimers.slice().forEach(function (task) {
        if (!task.owner || task.owner !== _carromActiveMatch || !_0x423f7f || task.owner.parent !== _0x423f7f.stage) {
          var index = _carromMatchTimers.indexOf(task);
          if (index >= 0) _carromMatchTimers.splice(index, 1);
        } else if (task.handle === null) _carromMatchArm(task);
      });
    }
    function _0x338c29(_0x49a911, _0x3fc90b) {
      var _0x10b8c3 = _0x157421;
      var _carromScheduledRound = _carromRoundId;
      Tweener[_0x10b8c3(0x3a0)](
        {},
        {},
        {
          time: (_0x3fc90b / 0x3e8) * 0x3c,
          onComplete: function () {
            if (_0x3fddb3 && _carromScheduledRound === _carromRoundId) _0x49a911();
          },
        },
      );
    }
    function _0x16430c(_0x32a605, _0x37061e) {
      var _0x50d4b3 = _0x157421,
        _0x4ffa82 =
          Math[_0x50d4b3(0x322)](_0x37061e - _0x32a605) % (Math["PI"] * 0x2),
        _0x38f782 =
          _0x4ffa82 > Math["PI"] ? Math["PI"] * 0x2 - _0x4ffa82 : _0x4ffa82;
      return _0x38f782;
    }
    function _0x14149a(_0x480040, _0x4ae9f4) {
      var _0x59e154 = _0x4ae9f4 - _0x480040;
      if (_0x59e154 < 0x0) _0x59e154 += Math["PI"] * 0x2;
      if (_0x59e154 > Math["PI"]) return -0x1;
      else return 0x1;
    }
    function _0x8b2762(_0x27903e, _0x3123a8) {
      var _0x272be5 = _0x157421;
      return Math[_0x272be5(0x196)](
        _0x3123a8["y"] - _0x27903e["y"],
        _0x3123a8["x"] - _0x27903e["x"],
      );
    }
    function _0x5c2120(_0x186937, _0x4709c3) {
      var _0x3cec61 = _0x157421;
      let _0x8d8085 = [];
      for (
        let _0x34529c = 0x0;
        _0x34529c < _0x4709c3[_0x3cec61(0x182)];
        _0x34529c++
      ) {
        _0x8d8085[_0x3cec61(0x3b0)](_0x186937[_0x4709c3[_0x34529c]]);
      }
      return _0x8d8085;
    }
    function _0x19a53c(_0xb3551d, _0x40ba14) {
      let _0xa8d80f = 0x0;
      for (let _0x550f53 in _0xb3551d) {
        _0xa8d80f += _0xb3551d[_0x550f53][_0x40ba14];
      }
      let _0x51bcb7 = Math["random"]() * _0xa8d80f,
        _0x3dba8b = 0x0;
      for (let _0x4d9442 in _0xb3551d) {
        _0x3dba8b += _0xb3551d[_0x4d9442][_0x40ba14];
        if (_0x51bcb7 <= _0x3dba8b) return _0xb3551d[_0x4d9442];
      }
    }
    function _0x46c4a6(_0x84ed48) {
      let _0x5b9f26 = 0x0;
      for (let _0x3eb229 in _0x84ed48) {
        _0x5b9f26 += _0x84ed48[_0x3eb229];
      }
      let _0x3bc54a = Math["random"]() * _0x5b9f26,
        _0x4c9288 = 0x0;
      for (let _0x406183 in _0x84ed48) {
        _0x4c9288 += _0x84ed48[_0x406183];
        if (_0x3bc54a <= _0x4c9288) return _0x406183;
      }
    }
    function _0x5b6388(_0x2343ab) {
      var _0xd7ce39 = _0x157421;
      return Array[_0xd7ce39(0x381)](Array(_0x2343ab)[_0xd7ce39(0x35c)]());
    }
    function _0x144b30(_0x233df7, _0x6d4559) {
      var _0x2859a2 = _0x157421;
      return (
        _0x233df7 +
        Math[_0x2859a2(0x1f8)](
          Math[_0x2859a2(0xec)]() * (_0x6d4559 - _0x233df7),
        )
      );
    }
    function _0x2f9b78(_0x45e9d4, _0x468e82) {
      var _0x10e082 = _0x157421;
      if (typeof _0x45e9d4 != _0x10e082(0x375)) return _0x45e9d4;
      var _0x51e245 = "",
        _0x4d6aaf = _0x468e82 || 0x4;
      if (_0x45e9d4 >= 0xf4240)
        _0x51e245 = Math[_0x10e082(0x167)](_0x45e9d4 / 0x186a0) / 0xa + "M";
      else
        _0x45e9d4 >= Math[_0x10e082(0x3fa)](0xa, _0x4d6aaf)
          ? (_0x51e245 = Math["round"](_0x45e9d4 / 0x64) / 0xa + "K")
          : (_0x51e245 = _0x45e9d4[_0x10e082(0x18c)]());
      return _0x51e245;
    }
    function _0x57abb1(_0xd74a18, _0x7925af, _0x272615) {
      var _0x3b9a1a = _0x157421;
      for (var _0x237208 = 0x0; _0x237208 < _0x7925af["length"]; _0x237208++) {
        if (
          !_0x7925af[_0x237208][_0x3b9a1a(0x47c)] &&
          _0x7925af[_0x237208][_0x3b9a1a(0x4a4)] &&
          _0x2bd695(_0xd74a18, _0x7925af[_0x237208]) <
            _0x272615 + (_0x7925af[_0x237208]["radius"] || 0x0)
        )
          return _0x7925af[_0x237208];
      }
      return ![];
    }
    function _0x4468f2(_0x38666d, _0x57ad8f) {
      var _0x43c792 = _0x157421;
      return !(
        _0x57ad8f["x"] > _0x38666d["x"] + _0x38666d[_0x43c792(0xfd)] ||
        _0x57ad8f["x"] + _0x57ad8f[_0x43c792(0xfd)] < _0x38666d["x"] ||
        _0x57ad8f["y"] > _0x38666d["y"] + _0x38666d["height"] ||
        _0x57ad8f["y"] + _0x57ad8f[_0x43c792(0x21c)] < _0x38666d["y"]
      );
    }
    function _0x3b2ed8(
      _0xc8ffa2,
      _0x5632da,
      _0xf7a61,
      _0xa7340d,
      _0x120347,
      _0x7ab410,
      _0x4316dc,
      _0x2021bf,
    ) {
      let _0x2d6883 = lineLine(
          _0xc8ffa2,
          _0x5632da,
          _0xf7a61,
          _0xa7340d,
          _0x120347,
          _0x7ab410,
          _0x120347,
          _0x7ab410 + _0x2021bf,
        ),
        _0x2cd4c2 = lineLine(
          _0xc8ffa2,
          _0x5632da,
          _0xf7a61,
          _0xa7340d,
          _0x120347 + _0x4316dc,
          _0x7ab410,
          _0x120347 + _0x4316dc,
          _0x7ab410 + _0x2021bf,
        ),
        _0x5ad0d4 = lineLine(
          _0xc8ffa2,
          _0x5632da,
          _0xf7a61,
          _0xa7340d,
          _0x120347,
          _0x7ab410,
          _0x120347 + _0x4316dc,
          _0x7ab410,
        ),
        _0x54ab52 = lineLine(
          _0xc8ffa2,
          _0x5632da,
          _0xf7a61,
          _0xa7340d,
          _0x120347,
          _0x7ab410 + _0x2021bf,
          _0x120347 + _0x4316dc,
          _0x7ab410 + _0x2021bf,
        );
      if (_0x2d6883 || _0x2cd4c2 || _0x5ad0d4 || _0x54ab52) return !![];
      return ![];
    }
    function _0x51e52b(_0x53ff35) {
      var _0x4b8b32 = _0x157421;
      Tweener[_0x4b8b32(0x469)](_0x53ff35);
      if (_0x53ff35[_0x4b8b32(0x494)])
        _0x3eeb21[_0x4b8b32(0x126)](_0x53ff35[_0x4b8b32(0x494)]);
      if (_0x53ff35[_0x4b8b32(0x35d)])
        _0x53ff35[_0x4b8b32(0x35d)][_0x4b8b32(0x28c)](_0x53ff35);
       _0x53ff35= [];
    }
    function _0x253500(_0x1a9578, _0x5e8f98, _0x3aa770) {
      var _0x14e616 = _0x157421,
        _0x44c2cf = _0x1a9578[_0x14e616(0x1f2)](_0x5e8f98);
      if (_0x44c2cf > -0x1) {
        _0x1a9578["splice"](_0x44c2cf, 0x1);
        if (_0x3aa770) return;
        if (_0x5e8f98[_0x14e616(0x35d)]) {
          var _0x58cf7e = _0x5e8f98[_0x14e616(0x35d)];
          _0x58cf7e[_0x14e616(0x28c)](_0x5e8f98);
        }
      }
      if (_0x5e8f98["kill"]) _0x5e8f98[_0x14e616(0x40b)]();
      (Tweener[_0x14e616(0x469)](_0x5e8f98), _0x5e8f98["destroy"]());
    }
    function _0x5c3d1d(_0x152b91) {
      var _0x88f015 = _0x157421;
      if (!_0x152b91) return [];
      for (var _0x4d77f0 = 0x0; _0x4d77f0 < _0x152b91["length"]; _0x4d77f0++) {
        var _0x387f81 = _0x152b91[_0x4d77f0];
        if (_0x387f81[_0x88f015(0x35d)])
          _0x387f81[_0x88f015(0x35d)][_0x88f015(0x28c)](_0x387f81);
        Tweener[_0x88f015(0x469)](_0x387f81);
        if (_0x387f81[_0x88f015(0x495)])
          _0x387f81[_0x88f015(0x495)][_0x88f015(0x40b)]();
        if (
          _0x387f81[_0x88f015(0x1f3)] &&
          _0x387f81[_0x88f015(0x1f3)]["parent"]
        )
          _0x387f81[_0x88f015(0x1f3)]["parent"][_0x88f015(0x28c)](
            _0x387f81[_0x88f015(0x1f3)],
          );
        if (
          _0x387f81[_0x88f015(0x293)] &&
          _0x387f81[_0x88f015(0x293)][_0x88f015(0x35d)]
        )
          _0x387f81[_0x88f015(0x293)][_0x88f015(0x35d)][_0x88f015(0x28c)](
            _0x387f81["hpBar"],
          );
        if (_0x387f81["destroy"]) _0x387f81["destroy"]();
      }
      return ((_0x152b91 = []), []);
    }
    function _0xcab61f(_0x3bd4f9, _0x9d8ea6) {
      var _0x590afa = _0x157421;
      let _0x211f75 = _0x9d8ea6[0x0] - _0x3bd4f9[0x0],
        _0xe59fff = _0x9d8ea6[0x1] - _0x3bd4f9[0x1];
      return {
        length: Math[_0x590afa(0x3bb)](
          Math[_0x590afa(0x3fa)](_0x211f75, 0x2) + Math["pow"](_0xe59fff, 0x2),
        ),
        angle: Math[_0x590afa(0x196)](_0xe59fff, _0x211f75),
      };
    }
    function _0x322404(_0x4195c2) {
      var _0x3f96d1 = _0x157421;
      if (_0x4195c2["length"] < 0x2) return 0x0;
      var _0x18d274 = 0x0,
        _0x56f5ce = Math[_0x3f96d1(0x196)](
          _0x4195c2[0x1]["y"] - _0x4195c2[0x0]["y"],
          _0x4195c2[0x1]["x"] - _0x4195c2[0x0]["x"],
        );
      for (var _0x1e2ed8 = 0x1; _0x1e2ed8 < _0x4195c2["length"]; _0x1e2ed8++) {
        var _0x421533 = _0x4195c2[_0x1e2ed8 - 0x1],
          _0x476fae = _0x4195c2[_0x1e2ed8],
          _0x14cdc4 = Math[_0x3f96d1(0x196)](
            _0x476fae["y"] - _0x421533["y"],
            _0x476fae["x"] - _0x421533["x"],
          ),
          _0x50d017 = _0x14cdc4 - _0x56f5ce;
        ((_0x50d017 =
          ((_0x50d017 + Math["PI"]) % (Math["PI"] * 0x2)) - Math["PI"]),
          (_0x18d274 += _0x50d017),
          (_0x56f5ce = _0x14cdc4));
      }
      return _0x18d274;
    }
    function _0x2bd695(_0x257841, _0x5a8b36) {
      var _0x12534d = _0x157421,
        _0xe5d282 = _0x257841["x"] - _0x5a8b36["x"],
        _0x448408 = _0x257841["y"] - _0x5a8b36["y"];
      return Math[_0x12534d(0x3bb)](
        _0xe5d282 * _0xe5d282 + _0x448408 * _0x448408,
      );
    }
    var _0x3f0a26 = (function () {
        var _0x5b5d08 = _0x157421;
        function _0x3874f3(_0x4f7a94) {
          var _0x5ebea4 = _0x3797;
          PIXI[_0x5ebea4(0x30a)][_0x5ebea4(0x37a)](this);
          var _0x227ccc = this,
            _0x181a39 = PIXI[_0x5ebea4(0x385)][_0x5ebea4(0x348)](
              "purple_lights_behind",
            );
          (_0x181a39[_0x5ebea4(0x4a1)][_0x5ebea4(0x27e)](0.5),
            (_0x181a39["x"] = 0x140),
            (_0x181a39["y"] = 0x208),
            this[_0x5ebea4(0x37b)](_0x181a39),
            (_0x181a39[_0x5ebea4(0xe5)] = 0x0),
            Tweener["addTween"](
              _0x181a39,
              { alpha: 0x1 },
              { time: 0xf, delay: 0xa, transition: _0x5ebea4(0x1f9) },
            ));
          var _0x5d699d = PIXI["Sprite"]["fromFrame"](_0x5ebea4(0x1fc));
          (_0x5d699d[_0x5ebea4(0x4a1)][_0x5ebea4(0x27e)](0.5),
            (_0x5d699d[_0x5ebea4(0x4a1)]["y"] = 0x1),
            (_0x5d699d["x"] = 0x140),
            (_0x5d699d["y"] = 0x217),
            this["addChild"](_0x5d699d),
            (_0x5d699d[_0x5ebea4(0xe5)] = 0x0),
            (_0x5d699d[_0x5ebea4(0x231)]["y"] = 0x1),
            Tweener["addTween"](
              _0x5d699d,
              { alpha: 0x1, scaleY: 0x1 },
              { time: 0xf, delay: 0x14, transition: _0x5ebea4(0x1f9) },
            ));
          var _0x4fc8ff = PIXI[_0x5ebea4(0x385)]["fromFrame"](_0x5ebea4(0x166));
          (_0x4fc8ff[_0x5ebea4(0x4a1)][_0x5ebea4(0x27e)](0.5),
            (_0x4fc8ff["x"] = 0x140),
            (_0x4fc8ff["y"] = 0x21c),
            this[_0x5ebea4(0x37b)](_0x4fc8ff),
            (_0x4fc8ff["alpha"] = 0x0),
            Tweener[_0x5ebea4(0x3a0)](
              _0x4fc8ff,
              { alpha: 0x1 },
              { time: 0xf, delay: 0xa, transition: _0x5ebea4(0x1f9) },
            ));
          var _0x3216eb = new PIXI[_0x5ebea4(0x402)]("0", {
            font: _0x5ebea4(0x33e),
            fill: 0xffffff,
            align: _0x5ebea4(0x221),
          });
          (_0x3216eb[_0x5ebea4(0x4a1)]["set"](0.5),
            (_0x3216eb["x"] =
              0x140 +
              _0x3216eb["width"] / 0x2 -
              (_0x3216eb[_0x5ebea4(0xfd)] / 0x2 + 0x7 + 0x48)),
            (_0x3216eb["y"] = 0x1fe),
            this[_0x5ebea4(0x37b)](_0x3216eb),
            (this["valueLabel"] = _0x3216eb));
          var _0x9ee0ce = PIXI["Sprite"][_0x5ebea4(0x348)](_0x5ebea4(0x217));
          (_0x9ee0ce[_0x5ebea4(0x4a1)][_0x5ebea4(0x27e)](0.5),
            (_0x9ee0ce["x"] =
              _0x3216eb["x"] +
              _0x3216eb["width"] / 0x2 +
              0xf +
              _0x9ee0ce["width"] / 0x2),
            (_0x9ee0ce["y"] = 0x1ef),
            this[_0x5ebea4(0x37b)](_0x9ee0ce),
            (this["valueIcon"] = _0x9ee0ce),
            _0x3216eb["scale"][_0x5ebea4(0x27e)](0x0),
            Tweener[_0x5ebea4(0x3a0)](
              _0x3216eb,
              { scaleX: 0x1, scaleY: 0x1 },
              { time: 0x14, delay: 0x14, transition: "easeOutBack" },
            ),
            _0x9ee0ce[_0x5ebea4(0x231)]["set"](0x0),
            Tweener["addTween"](
              _0x9ee0ce,
              { scaleX: 0x1, scaleY: 0x1 },
              { time: 0x14, delay: 0x14, transition: _0x5ebea4(0x426) },
            ),
            Tweener[_0x5ebea4(0x3a0)](
              { value: 0x0 },
              { value: _0x4f7a94 },
              {
                time: 0x14,
                delay: 0x14,
                transition: _0x5ebea4(0x235),
                onUpdate: function (_0xf0a1c6) {
                  var _0x294654 = _0x5ebea4;
                  ((_0x3216eb[_0x294654(0x1aa)] =
                    "" + Math[_0x294654(0x167)](_0xf0a1c6["value"])),
                    (_0x3216eb["x"] =
                      0x140 +
                      _0x3216eb[_0x294654(0xfd)] / 0x2 -
                      (_0x3216eb[_0x294654(0xfd)] / 0x2 + 0x7 + 0x48)),
                    (_0x9ee0ce["x"] =
                      _0x3216eb["x"] +
                      _0x3216eb[_0x294654(0xfd)] / 0x2 +
                      0xf +
                      _0x9ee0ce[_0x294654(0xfd)] / 0x2));
                },
              },
            ));
          var _0x6ae114 =
            PIXI[_0x5ebea4(0x385)][_0x5ebea4(0x348)]("Congratulations");
          (_0x6ae114[_0x5ebea4(0x4a1)][_0x5ebea4(0x27e)](0.5),
            (_0x6ae114["x"] = 0x140),
            (_0x6ae114["y"] = 0xfa),
            this[_0x5ebea4(0x37b)](_0x6ae114),
            (this[_0x5ebea4(0x291)] = _0x6ae114));
          var _0x1a8e1e = PIXI[_0x5ebea4(0x385)][_0x5ebea4(0x348)](
            _0x5ebea4(0x23b),
          );
          (_0x1a8e1e[_0x5ebea4(0x4a1)][_0x5ebea4(0x27e)](0.5),
            (_0x1a8e1e["x"] = 0x140),
            (_0x1a8e1e["y"] = 0x13b),
            this["addChild"](_0x1a8e1e),
            (this["wonText"] = _0x1a8e1e),
            _0x6ae114[_0x5ebea4(0x231)][_0x5ebea4(0x27e)](0x0),
            Tweener[_0x5ebea4(0x3a0)](
              _0x6ae114,
              { scaleX: 0x1, scaleY: 0x1 },
              { time: 0x14, delay: 0x19, transition: "easeOutBack" },
            ),
            _0x1a8e1e[_0x5ebea4(0x231)]["set"](0x0),
            Tweener[_0x5ebea4(0x3a0)](
              _0x1a8e1e,
              { scaleX: 0x1, scaleY: 0x1 },
              { time: 0x14, delay: 0x1e, transition: _0x5ebea4(0x426) },
            ));
          var _0x3e37bc = new _0x32d81c(
            PIXI[_0x5ebea4(0x304)][_0x5ebea4(0x299)][_0x5ebea4(0x1e6)],
          );
          (_0x3e37bc[_0x5ebea4(0x4a1)]["set"](0.5),
            (_0x3e37bc["x"] = 0x140),
            (_0x3e37bc["y"] = 0x33e),
            _0x3e37bc[_0x5ebea4(0x3d4)](
              _0x5ebea4(0x444),
              PIXI[_0x5ebea4(0x304)]["TextureCache"][_0x5ebea4(0x324)],
            ),
            this[_0x5ebea4(0x37b)](_0x3e37bc),
            (this[_0x5ebea4(0x3ce)] = _0x3e37bc),
            _0x3e37bc["on"](
              _0x5ebea4(0x2a7),
              function () {
                var _0x4b943d = _0x5ebea4;
                this[_0x4b943d(0xfe)]("claim");
              }[_0x5ebea4(0x374)](this),
            ),
            _0x3e37bc[_0x5ebea4(0x231)][_0x5ebea4(0x27e)](0x0),
            Tweener[_0x5ebea4(0x3a0)](
              _0x3e37bc,
              { scaleX: 0x1, scaleY: 0x1 },
              { time: 0x14, delay: 0x32, transition: "easeOutBack" },
            ));
          var _0x43b63d = new _0x32d81c(
            PIXI[_0x5ebea4(0x304)][_0x5ebea4(0x299)][_0x5ebea4(0x437)],
          );
          (_0x43b63d[_0x5ebea4(0x4a1)][_0x5ebea4(0x27e)](0.5),
            (_0x43b63d[_0x5ebea4(0x197)] = ![]),
            (_0x43b63d["x"] = 0x140),
            (_0x43b63d["y"] = 0x3c0),
            _0x43b63d[_0x5ebea4(0x3d4)](
              _0x5ebea4(0x444),
              PIXI["utils"]["TextureCache"][_0x5ebea4(0x238)],
            ),
            this[_0x5ebea4(0x37b)](_0x43b63d),
            (this[_0x5ebea4(0x3ba)] = _0x43b63d),
            _0x43b63d["on"](
              _0x5ebea4(0x2a7),
              function () {
                this["emit"]("ad");
              }["bind"](this),
            ));
        }
        return (
          (_0x3874f3[_0x5b5d08(0x333)] = Object[_0x5b5d08(0x454)](
            PIXI[_0x5b5d08(0x30a)][_0x5b5d08(0x333)],
          )),
          (_0x3874f3[_0x5b5d08(0x333)][_0x5b5d08(0x13d)] = function () {
            var _0x5b01cc = _0x5b5d08;
            ((this[_0x5b01cc(0x3ba)][_0x5b01cc(0x197)] = !![]),
              this["btnClaimAd"][_0x5b01cc(0x231)][_0x5b01cc(0x27e)](0x0),
              Tweener[_0x5b01cc(0x3a0)](
                this[_0x5b01cc(0x3ba)],
                { scaleX: 0x1, scaleY: 0x1 },
                { time: 0x14, delay: 0x32, transition: _0x5b01cc(0x426) },
              ));
          }),
          (_0x3874f3[_0x5b5d08(0x333)][_0x5b5d08(0x183)] = function () {}),
          (_0x3874f3[_0x5b5d08(0x333)]["update"] = function () {}),
          (_0x3874f3[_0x5b5d08(0x333)][_0x5b5d08(0x12d)] = function (
            _0x334eff,
          ) {}),
          Object["defineProperties"](_0x3874f3[_0x5b5d08(0x333)], {
            value: {
              set: function (_0x348e79) {
                var _0x334b0a = _0x5b5d08;
                this[_0x334b0a(0x3e2)] = _0x348e79;
              },
              get: function () {
                var _0x335d95 = _0x5b5d08;
                return this[_0x335d95(0x3e2)];
              },
            },
          }),
          _0x3874f3
        );
      })(),
      _0x702477 = (function () {
        var _0x35b4ca = _0x157421;
        function _0x27676b(_0x2e5dd8) {
          var _0x3de155 = _0x3797;
          PIXI["Container"][_0x3de155(0x37a)](this);
          var _0xc5ed75 = this,
            _0x10fcb0 = PIXI[_0x3de155(0x385)]["fromFrame"](_0x3de155(0x1ed));
          (_0x10fcb0[_0x3de155(0x4a1)][_0x3de155(0x27e)](0.5),
            (_0x10fcb0["x"] = 0x140),
            (_0x10fcb0["y"] = _0x27ae22 / 0x2),
            this[_0x3de155(0x37b)](_0x10fcb0));
          var _0x2daf59 = PIXI[_0x3de155(0x385)][_0x3de155(0x348)]("coins");
          (_0x2daf59[_0x3de155(0x4a1)]["set"](0.5),
            (_0x2daf59["x"] = 0xaa),
            (_0x2daf59["y"] = 0x6e),
            this[_0x3de155(0x37b)](_0x2daf59));
          var _0x2b289e = PIXI[_0x3de155(0x385)][_0x3de155(0x348)](
            _0x3de155(0x433),
          );
          (_0x2b289e[_0x3de155(0x4a1)][_0x3de155(0x27e)](0.5),
            (_0x2b289e["x"] = 0x16d),
            (_0x2b289e["y"] = 0x6e),
            this[_0x3de155(0x37b)](_0x2b289e));
          var _0x1c79db = PIXI["Sprite"][_0x3de155(0x348)](_0x3de155(0x3c9));
          (_0x1c79db["anchor"][_0x3de155(0x27e)](0.5),
            (_0x1c79db["x"] = 0x122),
            (_0x1c79db["y"] = 0x21c),
            this[_0x3de155(0x37b)](_0x1c79db));
          var _0x2f52fe = PIXI[_0x3de155(0x385)][_0x3de155(0x348)](
            _0x3de155(0x346),
          );
          (_0x2f52fe[_0x3de155(0x4a1)][_0x3de155(0x27e)](0.5),
            (_0x2f52fe["x"] = 0x140),
            (_0x2f52fe["y"] = 0x1f4),
            this[_0x3de155(0x37b)](_0x2f52fe),
            (this[_0x3de155(0x288)] = _0x2f52fe),
            Tweener["addTween"](
              _0x2f52fe,
              { rotation: Math["PI"] * 0x2 },
              { time: 0x384, loop: -0x1 },
            ));
          var _0xd7f2d = PIXI[_0x3de155(0x385)][_0x3de155(0x348)](
            _0x3de155(0x16f),
          );
          (_0xd7f2d[_0x3de155(0x4a1)][_0x3de155(0x27e)](0.5),
            (_0xd7f2d["x"] = 0x140),
            (_0xd7f2d["y"] = 0x1f4),
            this[_0x3de155(0x37b)](_0xd7f2d));
          var _0x142a43 = PIXI[_0x3de155(0x385)][_0x3de155(0x348)](
            "carrom_spinning_wheel_base_bright",
          );
          (_0x142a43[_0x3de155(0x4a1)][_0x3de155(0x27e)](0.5),
            (_0x142a43["x"] = 0x258),
            (_0x142a43["y"] = 0x1ef),
            (_0x142a43[_0x3de155(0x1ec)] = 0.1),
            this[_0x3de155(0x37b)](_0x142a43),
            (_0x142a43[_0x3de155(0xe5)] = 0x1),
            Tweener[_0x3de155(0x3a0)](
              _0x142a43,
              {
                alpha: [
                  0x1, 0.8, 0.6, 0.4, 0.2, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                  0.2, 0.4, 0.6, 0.8, 0x1,
                ],
                scaleY: [
                  0x1, 0.8, 0.6, 0.4, 0.2, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                  0.2, 0.4, 0.6, 0.8, 0x1,
                ],
              },
              { time: 0xe1, loop: -0x1 },
            ),
            (this[_0x3de155(0xd4)] = _0x142a43));
          var _0x3358d3 = PIXI[_0x3de155(0x385)][_0x3de155(0x348)](
            _0x3de155(0x195),
          );
          (_0x3358d3[_0x3de155(0x4a1)][_0x3de155(0x27e)](0.5),
            (_0x3358d3["x"] = 0x15e),
            (_0x3358d3["y"] = 0x1ef),
            (_0x3358d3[_0x3de155(0x1ec)] = 0.1),
            this[_0x3de155(0x37b)](_0x3358d3),
            (_0x3358d3["alpha"] = 0x0),
            Tweener[_0x3de155(0x3a0)](
              _0x3358d3,
              {
                alpha: [
                  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0.2,
                  0.4, 0.6, 0.8, 0x1, 0x1, 0.8, 0.6, 0.4, 0.2, 0x0, 0x0, 0x0,
                  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                  0x0, 0x0, 0x0, 0x0, 0x0,
                ],
                scaleX: [
                  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0.2,
                  0.4, 0.6, 0.8, 0x1, 0x1, 0.8, 0.6, 0.4, 0.2, 0x0, 0x0, 0x0,
                  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                  0x0, 0x0, 0x0, 0x0, 0x0,
                ],
                scaleY: [
                  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0.2,
                  0.4, 0.6, 0.8, 0x1, 0x1, 0.8, 0.6, 0.4, 0.2, 0x0, 0x0, 0x0,
                  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                  0x0, 0x0, 0x0, 0x0, 0x0,
                ],
              },
              { time: 0xe1, loop: -0x1 },
            ));
          var _0xc42f9b = new _0x32d81c(
            PIXI[_0x3de155(0x304)][_0x3de155(0x299)]["carrom_spin_button"],
          );
          (_0xc42f9b[_0x3de155(0x4a1)][_0x3de155(0x27e)](0.5),
            (_0xc42f9b["x"] = 0x140),
            (_0xc42f9b["y"] = 0x3c0),
            _0xc42f9b[_0x3de155(0x3d4)](
              _0x3de155(0x444),
              PIXI["utils"][_0x3de155(0x299)]["carrom_spin_button_hover"],
            ),
            _0xc42f9b[_0x3de155(0x3d4)](
              _0x3de155(0x2db),
              PIXI[_0x3de155(0x304)][_0x3de155(0x299)][_0x3de155(0x1b3)],
            ),
            this[_0x3de155(0x37b)](_0xc42f9b),
            (this[_0x3de155(0x21e)] = _0xc42f9b),
            _0xc42f9b["on"](
              _0x3de155(0x2a7),
              function () {
                this["emit"]("spin");
              }[_0x3de155(0x374)](this),
            ));
          var _0x152da1 = new _0x32d81c(
            PIXI["utils"][_0x3de155(0x299)][_0x3de155(0x170)],
          );
          (_0x152da1[_0x3de155(0x4a1)][_0x3de155(0x27e)](0.5),
            (_0x152da1["x"] = 0x37),
            (_0x152da1["y"] = 0x2d),
            _0x152da1[_0x3de155(0x3d4)](
              _0x3de155(0x444),
              PIXI[_0x3de155(0x304)][_0x3de155(0x299)][_0x3de155(0x44f)],
            ),
            this[_0x3de155(0x37b)](_0x152da1),
            _0x152da1["on"](
              _0x3de155(0x2a7),
              function () {
                var _0x53c94c = _0x3de155;
                this[_0x53c94c(0xfe)]("back");
              }[_0x3de155(0x374)](this),
            ),
            (this[_0x3de155(0x46e)] = _0x152da1),
            (this["_speed"] = 0x0));
        }
        return (
          (_0x27676b["prototype"] = Object[_0x35b4ca(0x454)](
            PIXI["Container"][_0x35b4ca(0x333)],
          )),
          (_0x27676b[_0x35b4ca(0x333)][_0x35b4ca(0x10b)] = function () {
            var _0x154929 = _0x35b4ca;
            ((this[_0x154929(0xd4)][_0x154929(0x197)] = ![]),
              Tweener["extract"](this[_0x154929(0x288)]));
          }),
          (_0x27676b[_0x35b4ca(0x333)][_0x35b4ca(0x2cf)] = function () {
            var _0x313672 = _0x35b4ca;
            this[_0x313672(0x288)][_0x313672(0x1ec)] += this[_0x313672(0x2d4)];
          }),
          (_0x27676b["prototype"][_0x35b4ca(0x183)] = function () {}),
          (_0x27676b["prototype"]["update"] = function () {}),
          (_0x27676b["prototype"][_0x35b4ca(0x12d)] = function (_0x353699) {
            var _0x15f8a9 = _0x35b4ca;
            (this[_0x15f8a9(0x46e)][_0x15f8a9(0x12d)](_0x353699),
              this[_0x15f8a9(0x21e)][_0x15f8a9(0x12d)](_0x353699),
              this[_0x15f8a9(0x21e)][_0x15f8a9(0x231)][_0x15f8a9(0x27e)](0x1),
              _0x353699
                ? Tweener[_0x15f8a9(0x3a0)](
                    this["_btnSpin"],
                    { scaleX: 1.03, scaleY: 1.03 },
                    { time: 0x28, transition: "bow", loop: -0x1 },
                  )
                : Tweener[_0x15f8a9(0x469)](this[_0x15f8a9(0x21e)]));
          }),
          Object[_0x35b4ca(0x211)](_0x27676b[_0x35b4ca(0x333)], {
            speed: {
              set: function (_0x38e0d2) {
                this["_speed"] = _0x38e0d2;
              },
              get: function () {
                var _0x24b725 = _0x35b4ca;
                return this[_0x24b725(0x2d4)];
              },
            },
          }),
          _0x27676b
        );
      })(),
      _0x48223d = (function () {
        var _0x3db648 = _0x157421;
        function _0x23b3fa(_0x2f6693) {
          var _0x2e20a3 = _0x3797;
          (PIXI[_0x2e20a3(0x30a)][_0x2e20a3(0x37a)](this),
            (this[_0x2e20a3(0x1e2)] = _0x2f6693[_0x2e20a3(0x125)]),
            (this[_0x2e20a3(0x225)] = _0x2f6693[_0x2e20a3(0x3c2)]));
          var _0x14449a = PIXI[_0x2e20a3(0x385)][_0x2e20a3(0x348)](
            _0x2e20a3(0x37f),
          );
          (_0x14449a["anchor"][_0x2e20a3(0x27e)](0.5),
            (_0x14449a["x"] = 0x0),
            (_0x14449a["y"] = 0x0),
            this[_0x2e20a3(0x37b)](_0x14449a));
          var _0x137d0b = PIXI["Sprite"]["fromFrame"](_0x2e20a3(0xdb));
          (_0x137d0b[_0x2e20a3(0x4a1)]["set"](0.5),
            (_0x137d0b["x"] = 0x0),
            (_0x137d0b["y"] = -0x14a),
            this[_0x2e20a3(0x37b)](_0x137d0b));
          var _0x325017 = new _0x32d81c(
            PIXI[_0x2e20a3(0x304)]["TextureCache"][_0x2e20a3(0x105)],
          );
          (_0x325017[_0x2e20a3(0x4a1)][_0x2e20a3(0x27e)](0.5),
            (_0x325017["x"] = 0x0),
            (_0x325017["y"] = 0x5),
            _0x325017[_0x2e20a3(0x3d4)](
              _0x2e20a3(0x444),
              PIXI[_0x2e20a3(0x304)][_0x2e20a3(0x299)]["home_button_sfx"],
            ),
            this[_0x2e20a3(0x37b)](_0x325017),
            (this[_0x2e20a3(0x103)] = _0x325017),
            _0x325017["on"](
              "pointertap",
              function () {
                var _0x555ccf = _0x2e20a3;
                (this[_0x555ccf(0xfe)](_0x555ccf(0x10a)),
                  this[_0x555ccf(0x40b)]());
              }["bind"](this),
            ));
          var _0x286d44 = new _0x32d81c(
            PIXI[_0x2e20a3(0x304)]["TextureCache"][_0x2e20a3(0x20d)],
          );
          (_0x286d44[_0x2e20a3(0x4a1)][_0x2e20a3(0x27e)](0.5),
            (_0x286d44["x"] = 0x0),
            (_0x286d44["y"] = 0x96),
            _0x286d44[_0x2e20a3(0x3d4)](
              _0x2e20a3(0x444),
              PIXI[_0x2e20a3(0x304)][_0x2e20a3(0x299)][_0x2e20a3(0xe1)],
            ),
            this[_0x2e20a3(0x37b)](_0x286d44),
            (this[_0x2e20a3(0x2b8)] = _0x286d44),
            _0x286d44["on"](
              _0x2e20a3(0x2a7),
              function () {
                var _0x282718 = _0x2e20a3;
                ((_0x4df363[_0x282718(0x197)] = !![]),
                  (_0x32757b[_0x282718(0x197)] = !![]),
                  this[_0x282718(0x12d)](![]));
              }[_0x2e20a3(0x374)](this),
            ));
          var _0x25c039 = new _0x32d81c(
            PIXI[_0x2e20a3(0x304)]["TextureCache"][_0x2e20a3(0x350)],
          );
          (_0x25c039[_0x2e20a3(0x4a1)][_0x2e20a3(0x27e)](0.5),
            (_0x25c039["x"] = 0x7a),
            (_0x25c039["y"] = -0x91),
            this[_0x2e20a3(0x37b)](_0x25c039),
            (this["_btnMusic"] = _0x25c039));
          this[_0x2e20a3(0x1e2)]
            ? (this[_0x2e20a3(0x408)][_0x2e20a3(0x3d4)](
                "up",
                PIXI["utils"][_0x2e20a3(0x299)][_0x2e20a3(0x4ac)],
              ),
              this[_0x2e20a3(0x408)][_0x2e20a3(0x3d4)](
                _0x2e20a3(0x444),
                PIXI["utils"][_0x2e20a3(0x299)][_0x2e20a3(0x3bf)],
              ))
            : (this[_0x2e20a3(0x408)][_0x2e20a3(0x3d4)](
                "up",
                PIXI[_0x2e20a3(0x304)][_0x2e20a3(0x299)]["music_button"],
              ),
              this[_0x2e20a3(0x408)][_0x2e20a3(0x3d4)](
                _0x2e20a3(0x444),
                PIXI[_0x2e20a3(0x304)][_0x2e20a3(0x299)][_0x2e20a3(0x3bf)],
              ));
          (this[_0x2e20a3(0x408)][_0x2e20a3(0x484)](),
            _0x25c039["on"](
              _0x2e20a3(0x2a7),
              function (_0x5f27eb) {
                var _0x3b5eab = _0x2e20a3;
                ((this[_0x3b5eab(0x1e2)] = !this["_music"]),
                  this["_music"]
                    ? (this[_0x3b5eab(0x408)][_0x3b5eab(0x3d4)](
                        "up",
                        PIXI[_0x3b5eab(0x304)]["TextureCache"][
                          "music_button_off"
                        ],
                      ),
                      this[_0x3b5eab(0x408)][_0x3b5eab(0x3d4)](
                        _0x3b5eab(0x444),
                        PIXI[_0x3b5eab(0x304)][_0x3b5eab(0x299)][
                          _0x3b5eab(0x3bf)
                        ],
                      ))
                    : (this["_btnMusic"][_0x3b5eab(0x3d4)](
                        "up",
                        PIXI["utils"]["TextureCache"][_0x3b5eab(0x350)],
                      ),
                      this[_0x3b5eab(0x408)][_0x3b5eab(0x3d4)](
                        _0x3b5eab(0x444),
                        PIXI[_0x3b5eab(0x304)]["TextureCache"][
                          "music_button_sfx"
                        ],
                      )),
                  this[_0x3b5eab(0x408)][_0x3b5eab(0x484)](),
                  this[_0x3b5eab(0xfe)](
                    _0x3b5eab(0x40f),
                    this[_0x3b5eab(0x1e2)],
                  ));
              }["bind"](this),
            ));
          var _0x1534d8 = new _0x32d81c(
            PIXI[_0x2e20a3(0x304)]["TextureCache"][_0x2e20a3(0x144)],
          );
          (_0x1534d8["anchor"][_0x2e20a3(0x27e)](0.5),
            (_0x1534d8["x"] = -0x76),
            (_0x1534d8["y"] = -0x91),
            this[_0x2e20a3(0x37b)](_0x1534d8),
            (this["_btnSound"] = _0x1534d8));
          this["_sound"]
            ? (this[_0x2e20a3(0x3da)][_0x2e20a3(0x3d4)](
                "up",
                PIXI[_0x2e20a3(0x304)][_0x2e20a3(0x299)][_0x2e20a3(0x1d0)],
              ),
              this[_0x2e20a3(0x3da)]["registerState"](
                _0x2e20a3(0x444),
                PIXI[_0x2e20a3(0x304)][_0x2e20a3(0x299)][_0x2e20a3(0x176)],
              ))
            : (this["_btnSound"][_0x2e20a3(0x3d4)](
                "up",
                PIXI["utils"][_0x2e20a3(0x299)]["sfx_button"],
              ),
              this[_0x2e20a3(0x3da)][_0x2e20a3(0x3d4)](
                _0x2e20a3(0x444),
                PIXI["utils"]["TextureCache"][_0x2e20a3(0x176)],
              ));
          (this[_0x2e20a3(0x3da)][_0x2e20a3(0x484)](),
            _0x1534d8["on"](
              "pointertap",
              function (_0x3c1eb2) {
                var _0x191d72 = _0x2e20a3;
                ((this[_0x191d72(0x225)] = !this[_0x191d72(0x225)]),
                  this[_0x191d72(0x225)]
                    ? (this[_0x191d72(0x3da)][_0x191d72(0x3d4)](
                        "up",
                        PIXI[_0x191d72(0x304)][_0x191d72(0x299)][
                          _0x191d72(0x1d0)
                        ],
                      ),
                      this[_0x191d72(0x3da)][_0x191d72(0x3d4)](
                        _0x191d72(0x444),
                        PIXI["utils"][_0x191d72(0x299)][_0x191d72(0x176)],
                      ))
                    : (this["_btnSound"][_0x191d72(0x3d4)](
                        "up",
                        PIXI[_0x191d72(0x304)][_0x191d72(0x299)][
                          _0x191d72(0x144)
                        ],
                      ),
                      this[_0x191d72(0x3da)][_0x191d72(0x3d4)](
                        _0x191d72(0x444),
                        PIXI[_0x191d72(0x304)][_0x191d72(0x299)][
                          "sfx_button_hover"
                        ],
                      )),
                  this["_btnSound"][_0x191d72(0x484)](),
                  this[_0x191d72(0xfe)](
                    "change_mute_sound",
                    this[_0x191d72(0x225)],
                  ));
              }[_0x2e20a3(0x374)](this),
            ));
          var _0x19811d = new _0x32d81c(
            PIXI[_0x2e20a3(0x304)]["TextureCache"][_0x2e20a3(0x1e7)],
          );
          (_0x19811d[_0x2e20a3(0x4a1)]["set"](0.5),
            (_0x19811d["x"] = 0xfa),
            (_0x19811d["y"] = -0x1f4),
            _0x19811d[_0x2e20a3(0x3d4)](
              _0x2e20a3(0x444),
              PIXI[_0x2e20a3(0x304)][_0x2e20a3(0x299)][_0x2e20a3(0xd3)],
            ),
            this[_0x2e20a3(0x37b)](_0x19811d),
            _0x19811d["on"](
              _0x2e20a3(0x2a7),
              function () {
                var _0x3dab11 = _0x2e20a3;
                (this["emit"](_0x3dab11(0x4c4)), this[_0x3dab11(0x40b)]());
              }[_0x2e20a3(0x374)](this),
            ),
            (this[_0x2e20a3(0x46e)] = _0x19811d));
          var _0x4df363 = new PIXI["Graphics"]();
          ((_0x4df363[_0x2e20a3(0x197)] = ![]),
            _0x4df363[_0x2e20a3(0x339)](0x0, 0.9),
            _0x4df363[_0x2e20a3(0x26a)](
              0x0,
              0x0,
              _0x5568a2 + _0x24b13c,
              _0x27ae22 + _0x376ce3,
            ),
            (_0x4df363["x"] = -(_0x5568a2 + _0x24b13c) / 0x2),
            (_0x4df363["y"] = -(_0x27ae22 + _0x376ce3) / 0x2 - 0x14),
            this[_0x2e20a3(0x37b)](_0x4df363),
            (this[_0x2e20a3(0x428)] = _0x4df363));
          var _0x32757b = new _0x15504e();
          ((_0x32757b["y"] = -0x1e),
            (_0x32757b[_0x2e20a3(0x197)] = ![]),
            this[_0x2e20a3(0x37b)](_0x32757b),
            _0x32757b["on"](
              _0x2e20a3(0x4c4),
              function () {
                var _0x141a9f = _0x2e20a3;
                ((_0x4df363[_0x141a9f(0x197)] = ![]),
                  (_0x32757b[_0x141a9f(0x197)] = ![]),
                  this[_0x141a9f(0x12d)](!![]));
              }[_0x2e20a3(0x374)](this),
            ));
        }
        return (
          (_0x23b3fa["prototype"] = Object[_0x3db648(0x454)](
            PIXI[_0x3db648(0x30a)][_0x3db648(0x333)],
          )),
          (_0x23b3fa[_0x3db648(0x333)]["setEnable"] = function (_0x57fb30) {
            var _0x30d994 = _0x3db648;
            (this[_0x30d994(0x103)][_0x30d994(0x12d)](_0x57fb30),
              this[_0x30d994(0x2b8)]["setEnable"](_0x57fb30),
              this[_0x30d994(0x46e)][_0x30d994(0x12d)](_0x57fb30),
              this["_btnSound"]["setEnable"](_0x57fb30),
              this[_0x30d994(0x408)][_0x30d994(0x12d)](_0x57fb30));
          }),
          (_0x23b3fa["prototype"][_0x3db648(0x198)] = function (_0x31c438) {
            var _0x50ca4c = _0x3db648;
            _0x31c438
              ? ((this[_0x50ca4c(0x3da)][_0x50ca4c(0x1bf)] = ![]),
                (this[_0x50ca4c(0x3da)][_0x50ca4c(0x335)] =
                  PIXI[_0x50ca4c(0x304)][_0x50ca4c(0x299)]["sfx_button_hover"]),
                (this[_0x50ca4c(0x408)][_0x50ca4c(0x1bf)] = ![]),
                (this[_0x50ca4c(0x408)][_0x50ca4c(0x335)] =
                  PIXI[_0x50ca4c(0x304)][_0x50ca4c(0x299)][_0x50ca4c(0x3bf)]))
              : ((this["_btnSound"]["interactive"] = !![]),
                this[_0x50ca4c(0x3da)][_0x50ca4c(0x484)](),
                (this[_0x50ca4c(0x408)][_0x50ca4c(0x1bf)] = !![]),
                this["_btnMusic"]["updateState"]());
          }),
          (_0x23b3fa["prototype"]["kill"] = function () {
            var _0x26fd4f = _0x3db648;
            for (
              var _0x57a19c = 0x0;
              _0x57a19c < this[_0x26fd4f(0x3f9)][_0x26fd4f(0x182)];
              _0x57a19c++
            ) {
              ((this[_0x26fd4f(0x3f9)][_0x57a19c][_0x26fd4f(0x1bf)] = ![]),
                this[_0x26fd4f(0x3f9)][_0x57a19c][_0x26fd4f(0x31f)](),
                Tweener[_0x26fd4f(0x469)](this[_0x26fd4f(0x3f9)][_0x57a19c]));
            }
            ((this[_0x26fd4f(0x1bf)] = ![]),
              this[_0x26fd4f(0x31f)](),
              Tweener[_0x26fd4f(0x469)](this));
            if (this[_0x26fd4f(0x35d)])
              this[_0x26fd4f(0x35d)][_0x26fd4f(0x28c)](this);
            this["destroy"]();
          }),
          _0x23b3fa
        );
      })(),
      _0x42b398 = (function () {
        var _0x5ec3fb = _0x157421;
        function _0x94418(_0x475c6c, _0x4cc959) {
          var _0x3d330d = _0x3797;
          (PIXI[_0x3d330d(0x30a)][_0x3d330d(0x37a)](this),
            (this[_0x3d330d(0x1e2)] = _0x475c6c[_0x3d330d(0x125)]),
            (this[_0x3d330d(0x225)] = _0x475c6c["sound"]));
          var _0x15ec96 = PIXI["Sprite"][_0x3d330d(0x348)](_0x3d330d(0x264));
          (_0x15ec96[_0x3d330d(0x4a1)][_0x3d330d(0x27e)](0.5),
            (_0x15ec96["x"] = 0x0),
            (_0x15ec96["y"] = 0x0),
            this[_0x3d330d(0x37b)](_0x15ec96));
          var _0xaa3a73 = PIXI[_0x3d330d(0x385)]["fromFrame"](_0x3d330d(0x116));
          (_0xaa3a73[_0x3d330d(0x4a1)][_0x3d330d(0x27e)](0.5),
            (_0xaa3a73["x"] = 0x0),
            (_0xaa3a73["y"] = -0x14a - 0x41),
            this["addChild"](_0xaa3a73));
          var _0x552107 = new _0x32d81c(
            PIXI[_0x3d330d(0x304)][_0x3d330d(0x299)][_0x3d330d(0x105)],
          );
          (_0x552107[_0x3d330d(0x4a1)][_0x3d330d(0x27e)](0.5),
            (_0x552107["x"] = 0x0),
            (_0x552107["y"] = -0x87),
            _0x552107[_0x3d330d(0x3d4)](
              _0x3d330d(0x444),
              PIXI["utils"][_0x3d330d(0x299)][_0x3d330d(0x482)],
            ),
            this[_0x3d330d(0x37b)](_0x552107),
            _0x552107["on"](
              _0x3d330d(0x2a7),
              function () {
                var _0x1969f4 = _0x3d330d;
                ((_0x51153d[_0x1969f4(0x197)] = !![]),
                  (_0x46ed10[_0x1969f4(0x197)] = !![]),
                  this[_0x1969f4(0x12d)](![]));
              }["bind"](this),
            ),
            (this[_0x3d330d(0x103)] = _0x552107));
          var _0x6dedea = new _0x32d81c(
            PIXI[_0x3d330d(0x304)][_0x3d330d(0x299)][_0x3d330d(0x20d)],
          );
          (_0x6dedea[_0x3d330d(0x4a1)][_0x3d330d(0x27e)](0.5),
            (_0x6dedea["x"] = 0x0),
            (_0x6dedea["y"] = 0xa),
            _0x6dedea["registerState"](
              _0x3d330d(0x444),
              PIXI[_0x3d330d(0x304)][_0x3d330d(0x299)]["tutorial_button_hover"],
            ),
            this[_0x3d330d(0x37b)](_0x6dedea),
            (this[_0x3d330d(0x2b8)] = _0x6dedea),
            _0x6dedea["on"](
              _0x3d330d(0x2a7),
              function () {
                var _0x3710fe = _0x3d330d;
                ((_0x51153d[_0x3710fe(0x197)] = !![]),
                  (_0x1bace[_0x3710fe(0x197)] = !![]),
                  this[_0x3710fe(0x12d)](![]));
              }[_0x3d330d(0x374)](this),
            ));
          var _0x4224a9 = new _0x32d81c(
            PIXI[_0x3d330d(0x304)][_0x3d330d(0x299)][_0x3d330d(0x350)],
          );
          (_0x4224a9[_0x3d330d(0x4a1)][_0x3d330d(0x27e)](0.5),
            (_0x4224a9["x"] = 0x7a),
            (_0x4224a9["y"] = -0x91 - 0x41),
            (this[_0x3d330d(0x408)] = _0x4224a9));
          this[_0x3d330d(0x1e2)]
            ? (this[_0x3d330d(0x408)][_0x3d330d(0x3d4)](
                "up",
                PIXI["utils"][_0x3d330d(0x299)]["music_button_off"],
              ),
              this[_0x3d330d(0x408)]["registerState"](
                _0x3d330d(0x444),
                PIXI[_0x3d330d(0x304)][_0x3d330d(0x299)][_0x3d330d(0x3bf)],
              ))
            : (this[_0x3d330d(0x408)][_0x3d330d(0x3d4)](
                "up",
                PIXI[_0x3d330d(0x304)]["TextureCache"][_0x3d330d(0x350)],
              ),
              this[_0x3d330d(0x408)]["registerState"](
                "down",
                PIXI[_0x3d330d(0x304)][_0x3d330d(0x299)][_0x3d330d(0x3bf)],
              ));
          (this["_btnMusic"][_0x3d330d(0x484)](),
            _0x4224a9["on"](
              _0x3d330d(0x2a7),
              function (_0x405d00) {
                var _0x5c1037 = _0x3d330d;
                ((this[_0x5c1037(0x1e2)] = !this[_0x5c1037(0x1e2)]),
                  this[_0x5c1037(0x1e2)]
                    ? (this[_0x5c1037(0x408)][_0x5c1037(0x3d4)](
                        "up",
                        PIXI[_0x5c1037(0x304)][_0x5c1037(0x299)][
                          _0x5c1037(0x4ac)
                        ],
                      ),
                      this["_btnMusic"][_0x5c1037(0x3d4)](
                        _0x5c1037(0x444),
                        PIXI[_0x5c1037(0x304)][_0x5c1037(0x299)][
                          _0x5c1037(0x3bf)
                        ],
                      ))
                    : (this["_btnMusic"]["registerState"](
                        "up",
                        PIXI[_0x5c1037(0x304)]["TextureCache"][
                          _0x5c1037(0x350)
                        ],
                      ),
                      this[_0x5c1037(0x408)]["registerState"](
                        "down",
                        PIXI[_0x5c1037(0x304)]["TextureCache"][
                          "music_button_sfx"
                        ],
                      )),
                  this["_btnMusic"][_0x5c1037(0x484)](),
                  this[_0x5c1037(0xfe)](
                    _0x5c1037(0x40f),
                    this[_0x5c1037(0x1e2)],
                  ));
              }[_0x3d330d(0x374)](this),
            ));
          var _0x5c42af = new _0x32d81c(
            PIXI[_0x3d330d(0x304)][_0x3d330d(0x299)][_0x3d330d(0x144)],
          );
          (_0x5c42af["anchor"][_0x3d330d(0x27e)](0.5),
            (_0x5c42af["x"] = -0x76),
            (_0x5c42af["y"] = -0x91 - 0x41),
            (this[_0x3d330d(0x3da)] = _0x5c42af));
          this[_0x3d330d(0x225)]
            ? (this[_0x3d330d(0x3da)]["registerState"](
                "up",
                PIXI[_0x3d330d(0x304)]["TextureCache"][_0x3d330d(0x1d0)],
              ),
              this[_0x3d330d(0x3da)]["registerState"](
                _0x3d330d(0x444),
                PIXI[_0x3d330d(0x304)][_0x3d330d(0x299)][_0x3d330d(0x176)],
              ))
            : (this[_0x3d330d(0x3da)][_0x3d330d(0x3d4)](
                "up",
                PIXI["utils"][_0x3d330d(0x299)][_0x3d330d(0x144)],
              ),
              this[_0x3d330d(0x3da)][_0x3d330d(0x3d4)](
                "down",
                PIXI["utils"][_0x3d330d(0x299)][_0x3d330d(0x176)],
              ));
          (this["_btnSound"][_0x3d330d(0x484)](),
            _0x5c42af["on"](
              _0x3d330d(0x2a7),
              function (_0x447b76) {
                var _0x222515 = _0x3d330d;
                ((this["_sound"] = !this[_0x222515(0x225)]),
                  this[_0x222515(0x225)]
                    ? (this[_0x222515(0x3da)][_0x222515(0x3d4)](
                        "up",
                        PIXI[_0x222515(0x304)]["TextureCache"][
                          _0x222515(0x1d0)
                        ],
                      ),
                      this[_0x222515(0x3da)][_0x222515(0x3d4)](
                        _0x222515(0x444),
                        PIXI[_0x222515(0x304)][_0x222515(0x299)][
                          _0x222515(0x176)
                        ],
                      ))
                    : (this[_0x222515(0x3da)]["registerState"](
                        "up",
                        PIXI[_0x222515(0x304)][_0x222515(0x299)][
                          _0x222515(0x144)
                        ],
                      ),
                      this[_0x222515(0x3da)][_0x222515(0x3d4)](
                        "down",
                        PIXI[_0x222515(0x304)][_0x222515(0x299)][
                          _0x222515(0x176)
                        ],
                      )),
                  this[_0x222515(0x3da)][_0x222515(0x484)](),
                  this[_0x222515(0xfe)](
                    "change_mute_sound",
                    this[_0x222515(0x225)],
                  ));
              }[_0x3d330d(0x374)](this),
            ));
          var _0x5da5d4 = new _0x32d81c(
            PIXI["utils"][_0x3d330d(0x299)][_0x3d330d(0x15d)],
          );
          (_0x5da5d4["anchor"][_0x3d330d(0x27e)](0.5),
            _0x5da5d4["scale"]["set"](0x1),
            (_0x5da5d4["x"] = 0x0),
            (_0x5da5d4["y"] = 0x96),
            _0x5da5d4[_0x3d330d(0x3d4)](
              "down",
              PIXI[_0x3d330d(0x304)][_0x3d330d(0x299)][_0x3d330d(0x468)],
            ),
            this[_0x3d330d(0x37b)](_0x5da5d4),
            _0x5da5d4["on"](
              _0x3d330d(0x2a7),
              function () {
                var _0x32855b = _0x3d330d;
                (this["emit"](_0x32855b(0x4c4)), this["kill"]());
              }[_0x3d330d(0x374)](this),
            ),
            (this[_0x3d330d(0x46e)] = _0x5da5d4));
          var _0x51153d = new PIXI[_0x3d330d(0x148)]();
          ((_0x51153d[_0x3d330d(0x197)] = ![]),
            _0x51153d[_0x3d330d(0x339)](0x0, 0.9),
            _0x51153d[_0x3d330d(0x26a)](
              0x0,
              0x0,
              _0x5568a2 + _0x24b13c,
              _0x27ae22 + _0x376ce3,
            ),
            (_0x51153d["x"] = -(_0x5568a2 + _0x24b13c) / 0x2),
            (_0x51153d["y"] = -(_0x27ae22 + _0x376ce3) / 0x2 - 0x14),
            this[_0x3d330d(0x37b)](_0x51153d),
            (this[_0x3d330d(0x428)] = _0x51153d));
          var _0x46ed10 = new _0x1e4d27();
          ((_0x46ed10["visible"] = ![]),
            (_0x46ed10["y"] = -0x6e),
            this[_0x3d330d(0x37b)](_0x46ed10),
            _0x46ed10["on"](
              "close",
              function () {
                var _0x1b6fd0 = _0x3d330d;
                ((_0x51153d[_0x1b6fd0(0x197)] = ![]),
                  (_0x46ed10[_0x1b6fd0(0x197)] = ![]),
                  this[_0x1b6fd0(0x12d)](!![]));
              }[_0x3d330d(0x374)](this),
            ),
            _0x46ed10["on"](
              _0x3d330d(0x277),
              function () {
                var _0x3e8ba4 = _0x3d330d;
                (this[_0x3e8ba4(0xfe)]("home"), this[_0x3e8ba4(0x40b)]());
              }[_0x3d330d(0x374)](this),
            ));
          var _0x1bace = new _0x15504e(_0x4cc959);
          ((_0x1bace["y"] = -0x1e),
            (_0x1bace[_0x3d330d(0x197)] = ![]),
            this["addChild"](_0x1bace),
            _0x1bace["on"](
              _0x3d330d(0x4c4),
              function () {
                var _0xf0fd6c = _0x3d330d;
                ((_0x51153d[_0xf0fd6c(0x197)] = ![]),
                  (_0x1bace["visible"] = ![]),
                  this[_0xf0fd6c(0x12d)](!![]));
              }[_0x3d330d(0x374)](this),
            ));
        }
        return (
          (_0x94418[_0x5ec3fb(0x333)] = Object[_0x5ec3fb(0x454)](
            PIXI["Container"][_0x5ec3fb(0x333)],
          )),
          (_0x94418[_0x5ec3fb(0x333)][_0x5ec3fb(0x12d)] = function (_0x44498e) {
            var _0x448ccb = _0x5ec3fb;
            (this[_0x448ccb(0x103)]["setEnable"](_0x44498e),
              this[_0x448ccb(0x2b8)][_0x448ccb(0x12d)](_0x44498e),
              this[_0x448ccb(0x46e)][_0x448ccb(0x12d)](_0x44498e),
              this["_btnSound"][_0x448ccb(0x12d)](_0x44498e),
              this["_btnMusic"]["setEnable"](_0x44498e));
          }),
          (_0x94418[_0x5ec3fb(0x333)]["updateAudio"] = function (_0x537cc2) {
            var _0x1c98d2 = _0x5ec3fb;
            _0x537cc2
              ? ((this[_0x1c98d2(0x3da)][_0x1c98d2(0x1bf)] = ![]),
                (this[_0x1c98d2(0x3da)][_0x1c98d2(0x335)] =
                  PIXI["utils"][_0x1c98d2(0x299)][_0x1c98d2(0x176)]),
                (this[_0x1c98d2(0x408)][_0x1c98d2(0x1bf)] = ![]),
                (this[_0x1c98d2(0x408)][_0x1c98d2(0x335)] =
                  PIXI["utils"]["TextureCache"][_0x1c98d2(0x3bf)]))
              : ((this[_0x1c98d2(0x3da)][_0x1c98d2(0x1bf)] = !![]),
                this[_0x1c98d2(0x3da)][_0x1c98d2(0x484)](),
                (this["_btnMusic"]["interactive"] = !![]),
                this[_0x1c98d2(0x408)][_0x1c98d2(0x484)]());
          }),
          (_0x94418[_0x5ec3fb(0x333)][_0x5ec3fb(0x40b)] = function () {
            var _0x311ad1 = _0x5ec3fb;
            for (
              var _0x256cb7 = 0x0;
              _0x256cb7 < this[_0x311ad1(0x3f9)][_0x311ad1(0x182)];
              _0x256cb7++
            ) {
              ((this[_0x311ad1(0x3f9)][_0x256cb7][_0x311ad1(0x1bf)] = ![]),
                this[_0x311ad1(0x3f9)][_0x256cb7][_0x311ad1(0x31f)](),
                Tweener["extract"](this[_0x311ad1(0x3f9)][_0x256cb7]));
            }
            ((this[_0x311ad1(0x1bf)] = ![]),
              this[_0x311ad1(0x31f)](),
              Tweener["extract"](this));
            if (this[_0x311ad1(0x35d)]) this["parent"][_0x311ad1(0x28c)](this);
            this["destroy"]();
          }),
          _0x94418
        );
      })(),
      _0x1e4d27 = (function () {
        var _0x38ba6c = _0x157421;
        function _0x58afd7(_0x394256) {
          var _0x5b88e7 = _0x3797;
          PIXI[_0x5b88e7(0x30a)][_0x5b88e7(0x37a)](this);
          var _0xa8fdab = PIXI["Sprite"][_0x5b88e7(0x348)]("exit_question");
          (_0xa8fdab["anchor"]["set"](0.5),
            _0xa8fdab["scale"][_0x5b88e7(0x27e)](1.1),
            (_0xa8fdab["x"] = 0x0),
            (_0xa8fdab["y"] = -0x28),
            this[_0x5b88e7(0x37b)](_0xa8fdab),
            (this["frame"] = _0xa8fdab));
          var _0x28754f = new _0x32d81c(
            PIXI[_0x5b88e7(0x304)][_0x5b88e7(0x299)]["button_no"],
          );
          (_0x28754f["anchor"]["set"](0.5),
            _0x28754f["scale"][_0x5b88e7(0x27e)](0x1),
            (_0x28754f["x"] = 0x69),
            (_0x28754f["y"] = 0x82),
            _0x28754f[_0x5b88e7(0x3d4)](
              _0x5b88e7(0x444),
              PIXI[_0x5b88e7(0x304)][_0x5b88e7(0x299)][_0x5b88e7(0x47a)],
            ),
            this["addChild"](_0x28754f),
            _0x28754f["on"](
              _0x5b88e7(0x2a7),
              function () {
                this["emit"]("close");
              }[_0x5b88e7(0x374)](this),
            ));
          var _0x3d5fc8 = new _0x32d81c(
            PIXI["utils"][_0x5b88e7(0x299)][_0x5b88e7(0x34d)],
          );
          (_0x3d5fc8[_0x5b88e7(0x4a1)]["set"](0.5),
            _0x3d5fc8["scale"][_0x5b88e7(0x27e)](0x1),
            (_0x3d5fc8["x"] = -0x85),
            (_0x3d5fc8["y"] = 0x82),
            _0x3d5fc8[_0x5b88e7(0x3d4)](
              _0x5b88e7(0x444),
              PIXI[_0x5b88e7(0x304)]["TextureCache"]["button_yes_hover"],
            ),
            this[_0x5b88e7(0x37b)](_0x3d5fc8),
            _0x3d5fc8["on"](
              _0x5b88e7(0x2a7),
              function () {
                var _0x292da1 = _0x5b88e7;
                this[_0x292da1(0xfe)](_0x292da1(0x277));
              }[_0x5b88e7(0x374)](this),
            ),
            (this["_page"] = 0x0));
        }
        return (
          (_0x58afd7[_0x38ba6c(0x333)] = Object[_0x38ba6c(0x454)](
            PIXI["Container"][_0x38ba6c(0x333)],
          )),
          (_0x58afd7[_0x38ba6c(0x333)][_0x38ba6c(0x40b)] = function () {
            var _0xadcbe4 = _0x38ba6c;
            for (
              var _0x459662 = 0x0;
              _0x459662 < this[_0xadcbe4(0x3f9)][_0xadcbe4(0x182)];
              _0x459662++
            ) {
              ((this["children"][_0x459662]["interactive"] = ![]),
                this[_0xadcbe4(0x3f9)][_0x459662][_0xadcbe4(0x31f)](),
                Tweener[_0xadcbe4(0x469)](this[_0xadcbe4(0x3f9)][_0x459662]));
            }
            ((this[_0xadcbe4(0x1bf)] = ![]),
              this[_0xadcbe4(0x31f)](),
              Tweener["extract"](this));
            if (this["parent"]) this[_0xadcbe4(0x35d)][_0xadcbe4(0x28c)](this);
            this[_0xadcbe4(0x3bc)]();
          }),
          _0x58afd7
        );
      })(),
      _0x15504e = (function () {
        var _0xdf4c8f = _0x157421;
        function _0x46735f(_0x3244c4) {
          var _0x5e7a40 = _0x3797;
          (PIXI[_0x5e7a40(0x30a)][_0x5e7a40(0x37a)](this),
            (this[_0x5e7a40(0x168)] = [
              _0x5e7a40(0x3d8),
              _0x5e7a40(0x251),
              _0x5e7a40(0x44c),
              _0x5e7a40(0x389),
              _0x5e7a40(0x438),
              "tut_6_6",
            ]),
            (this[_0x5e7a40(0x38c)] = [
              _0x5e7a40(0x1c9),
              _0x5e7a40(0x163),
              _0x5e7a40(0x1d6),
              _0x5e7a40(0x39b),
              _0x5e7a40(0x256),
              "tut_06_screen_design",
            ]),
            (this[_0x5e7a40(0x32f)] = [
              _0x5e7a40(0x11a),
              _0x5e7a40(0x31a),
              _0x5e7a40(0x117),
              _0x5e7a40(0x41d),
              _0x5e7a40(0x41d),
              _0x5e7a40(0x41d),
            ]));
          var _0x3b05c3 =
            PIXI[_0x5e7a40(0x385)][_0x5e7a40(0x348)]("tut_WOODEN_BASE");
          (_0x3b05c3[_0x5e7a40(0x4a1)]["set"](0.5),
            (_0x3b05c3["x"] = 0x0),
            (_0x3b05c3["y"] = 0x0),
            this[_0x5e7a40(0x37b)](_0x3b05c3));
          var _0x595230 = PIXI["Sprite"]["fromFrame"](_0x5e7a40(0x1c9));
          (_0x595230["anchor"][_0x5e7a40(0x27e)](0.5),
            (_0x595230["x"] = 0x0),
            (_0x595230["y"] = 0x0),
            this[_0x5e7a40(0x37b)](_0x595230),
            (this[_0x5e7a40(0x39a)] = _0x595230));
          var _0x572278 = PIXI["Sprite"][_0x5e7a40(0x348)](_0x5e7a40(0x11a));
          (_0x572278[_0x5e7a40(0x4a1)][_0x5e7a40(0x27e)](0.5),
            (_0x572278["x"] = 0x0),
            (_0x572278["y"] = -0x190),
            this[_0x5e7a40(0x37b)](_0x572278),
            (this[_0x5e7a40(0x2a4)] = _0x572278));
          var _0xc81e1e = PIXI["Sprite"][_0x5e7a40(0x348)]("tut_ARROW_RIGHT");
          (_0xc81e1e["anchor"][_0x5e7a40(0x27e)](0.5),
            (_0xc81e1e["x"] = 0x55),
            (_0xc81e1e["y"] = 0x1a4),
            this[_0x5e7a40(0x37b)](_0xc81e1e),
            (this[_0x5e7a40(0x218)] = _0xc81e1e),
            (_0xc81e1e["interactive"] = !![]),
            _0xc81e1e["on"]("pointerdown", this["goRight"]["bind"](this)));
          var _0xbf139d = PIXI["Sprite"]["fromFrame"](_0x5e7a40(0x2d3));
          ((_0xbf139d[_0x5e7a40(0x197)] = ![]),
            _0xbf139d["anchor"][_0x5e7a40(0x27e)](0.5),
            (_0xbf139d["x"] = -0x55),
            (_0xbf139d["y"] = 0x1a4),
            this[_0x5e7a40(0x37b)](_0xbf139d),
            (this[_0x5e7a40(0x35b)] = _0xbf139d),
            (_0xbf139d[_0x5e7a40(0x1bf)] = !![]),
            _0xbf139d["on"](
              "pointerdown",
              this[_0x5e7a40(0x28e)][_0x5e7a40(0x374)](this),
            ));
          var _0x4e7e57 = PIXI[_0x5e7a40(0x385)][_0x5e7a40(0x348)](
            _0x5e7a40(0x3d8),
          );
          (_0x4e7e57[_0x5e7a40(0x4a1)][_0x5e7a40(0x27e)](0.5),
            (_0x4e7e57["x"] = 0x0),
            (_0x4e7e57["y"] = 0x1a4),
            this[_0x5e7a40(0x37b)](_0x4e7e57),
            (this[_0x5e7a40(0x2f2)] = _0x4e7e57));
          if (typeof _0x3244c4 !== _0x5e7a40(0x1b1)) {
            if (_0x3244c4 == 0x0)
              ((this[_0x5e7a40(0x168)] = [
                "tut_1_4",
                _0x5e7a40(0x49f),
                _0x5e7a40(0x132),
                _0x5e7a40(0x48c),
              ]),
                (this["PAGES"] = [
                  "tut_01_screen_design",
                  _0x5e7a40(0x163),
                  _0x5e7a40(0x1d6),
                  _0x5e7a40(0x300),
                ]),
                (this[_0x5e7a40(0x32f)] = [
                  _0x5e7a40(0x11a),
                  _0x5e7a40(0x31a),
                  _0x5e7a40(0x117),
                  _0x5e7a40(0x41d),
                ]));
            else {
              if (_0x3244c4 == 0x1)
                ((this[_0x5e7a40(0x168)] = [
                  _0x5e7a40(0x418),
                  _0x5e7a40(0x49f),
                  "tut_3_4",
                  "tut_4_4",
                ]),
                  (this[_0x5e7a40(0x38c)] = [
                    _0x5e7a40(0x1c9),
                    _0x5e7a40(0x163),
                    "tut_03_screen_design",
                    "tut_04_screen_design",
                  ]),
                  (this[_0x5e7a40(0x32f)] = [
                    "tut_01_title",
                    _0x5e7a40(0x31a),
                    _0x5e7a40(0x117),
                    _0x5e7a40(0x41d),
                  ]));
              else
                _0x3244c4 == 0x2 &&
                  ((this[_0x5e7a40(0x168)] = [
                    _0x5e7a40(0x418),
                    _0x5e7a40(0x49f),
                    _0x5e7a40(0x132),
                    _0x5e7a40(0x48c),
                  ]),
                  (this["PAGES"] = [
                    _0x5e7a40(0x1c9),
                    "tut_02_screen_design",
                    _0x5e7a40(0x1d6),
                    _0x5e7a40(0x256),
                  ]),
                  (this[_0x5e7a40(0x32f)] = [
                    _0x5e7a40(0x11a),
                    _0x5e7a40(0x31a),
                    _0x5e7a40(0x117),
                    _0x5e7a40(0x41d),
                  ]));
            }
            _0x4e7e57[_0x5e7a40(0x335)] =
              PIXI[_0x5e7a40(0x304)][_0x5e7a40(0x299)]["tut_1_4"];
          }
          var _0x3e221d = new _0x32d81c(
            PIXI["utils"][_0x5e7a40(0x299)]["close_button"],
          );
          (_0x3e221d[_0x5e7a40(0x4a1)][_0x5e7a40(0x27e)](0.5),
            _0x3e221d[_0x5e7a40(0x231)][_0x5e7a40(0x27e)](0.9),
            (_0x3e221d["x"] = 0xfa),
            (_0x3e221d["y"] = -0x1d6),
            _0x3e221d[_0x5e7a40(0x3d4)](
              "down",
              PIXI[_0x5e7a40(0x304)]["TextureCache"]["close_button_hover"],
            ),
            this["addChild"](_0x3e221d),
            _0x3e221d["on"](
              "pointertap",
              function () {
                var _0x5778fd = _0x5e7a40;
                this["emit"](_0x5778fd(0x4c4));
              }[_0x5e7a40(0x374)](this),
            ),
            (this[_0x5e7a40(0x2bd)] = 0x0),
            (this[_0x5e7a40(0x306)] = _0x3244c4));
        }
        return (
          (_0x46735f[_0xdf4c8f(0x333)] = Object[_0xdf4c8f(0x454)](
            PIXI[_0xdf4c8f(0x30a)]["prototype"],
          )),
          (_0x46735f[_0xdf4c8f(0x333)][_0xdf4c8f(0x28e)] = function () {
            var _0x22cf3e = _0xdf4c8f;
            _0x28fba8[_0x22cf3e(0x383)](_0x22cf3e(0x111));
            if (this["_page"] <= 0x0) return;
            (this[_0x22cf3e(0x2bd)]--,
              this[_0x22cf3e(0x2bd)] == 0x0 &&
                (this[_0x22cf3e(0x35b)][_0x22cf3e(0x197)] = ![]),
              (this[_0x22cf3e(0x218)][_0x22cf3e(0x197)] = !![]),
              (this[_0x22cf3e(0x39a)][_0x22cf3e(0x335)] =
                PIXI[_0x22cf3e(0x304)]["TextureCache"][
                  this[_0x22cf3e(0x38c)][this["_page"]]
                ]),
              (this[_0x22cf3e(0x2a4)]["texture"] =
                PIXI[_0x22cf3e(0x304)][_0x22cf3e(0x299)][
                  this[_0x22cf3e(0x32f)][this["_page"]]
                ]),
              (this["pageCount"]["texture"] =
                PIXI["utils"][_0x22cf3e(0x299)][
                  this["PAGE_COUNTER"][this[_0x22cf3e(0x2bd)]]
                ]));
          }),
          (_0x46735f[_0xdf4c8f(0x333)]["goRight"] = function () {
            var _0x171e4d = _0xdf4c8f;
            _0x28fba8["play"](_0x171e4d(0x111));
            if (typeof this[_0x171e4d(0x306)] !== _0x171e4d(0x1b1)) {
              if (this[_0x171e4d(0x2bd)] >= 0x3) return;
            }
            if (this[_0x171e4d(0x2bd)] >= 0x5) return;
            (this[_0x171e4d(0x2bd)]++,
              this[_0x171e4d(0x2bd)] == 0x5 &&
                (this["right"][_0x171e4d(0x197)] = ![]),
              (this[_0x171e4d(0x35b)][_0x171e4d(0x197)] = !![]),
              (this["frame"][_0x171e4d(0x335)] =
                PIXI[_0x171e4d(0x304)][_0x171e4d(0x299)][
                  this[_0x171e4d(0x38c)][this[_0x171e4d(0x2bd)]]
                ]),
              (this[_0x171e4d(0x2a4)][_0x171e4d(0x335)] =
                PIXI[_0x171e4d(0x304)][_0x171e4d(0x299)][
                  this[_0x171e4d(0x32f)][this[_0x171e4d(0x2bd)]]
                ]),
              (this[_0x171e4d(0x2f2)][_0x171e4d(0x335)] =
                PIXI[_0x171e4d(0x304)][_0x171e4d(0x299)][
                  this[_0x171e4d(0x168)][this[_0x171e4d(0x2bd)]]
                ]));
          }),
          (_0x46735f[_0xdf4c8f(0x333)][_0xdf4c8f(0x40b)] = function () {
            var _0x221fba = _0xdf4c8f;
            for (
              var _0x14ea72 = 0x0;
              _0x14ea72 < this[_0x221fba(0x3f9)]["length"];
              _0x14ea72++
            ) {
              ((this["children"][_0x14ea72][_0x221fba(0x1bf)] = ![]),
                this[_0x221fba(0x3f9)][_0x14ea72][_0x221fba(0x31f)](),
                Tweener[_0x221fba(0x469)](this["children"][_0x14ea72]));
            }
            ((this[_0x221fba(0x1bf)] = ![]),
              this[_0x221fba(0x31f)](),
              Tweener[_0x221fba(0x469)](this));
            if (this[_0x221fba(0x35d)])
              this[_0x221fba(0x35d)][_0x221fba(0x28c)](this);
            this[_0x221fba(0x3bc)]();
          }),
          _0x46735f
        );
      })(),
      _0x3020e6 = (function () {
        var _0x5097f1 = _0x157421;
        function _0x5f1a21(_0x48c159) {
          var _0xef337d = _0x3797;
          PIXI[_0xef337d(0x30a)][_0xef337d(0x37a)](this);
          var _0x22f444 = PIXI[_0xef337d(0x385)][_0xef337d(0x348)](
            _0x48c159 ? _0xef337d(0x2d5) : _0xef337d(0x466),
          );
          (_0x22f444[_0xef337d(0x4a1)][_0xef337d(0x27e)](0.5),
            this[_0xef337d(0x37b)](_0x22f444));
          var _0x1aeedb = PIXI[_0xef337d(0x385)][_0xef337d(0x348)](
            "avatar_silhouette_cha01",
          );
          (_0x1aeedb[_0xef337d(0x4a1)][_0xef337d(0x27e)](0.5),
            this[_0xef337d(0x37b)](_0x1aeedb),
            (this[_0xef337d(0x362)] = _0x1aeedb));
        }
        return (
          (_0x5f1a21[_0x5097f1(0x333)] = Object[_0x5097f1(0x454)](
            PIXI[_0x5097f1(0x30a)][_0x5097f1(0x333)],
          )),
          _0x5f1a21
        );
      })(),
      _0x483e8b = (function () {
        var _0x5303e8 = _0x157421;
        const _0x2a96b3 = 0x7b,
          _0x54aa42 = 0x7b,
          _0x36c778 = 0xf;
        function _0x5acaba() {
          var _0x40bf65 = _0x3797;
          PIXI[_0x40bf65(0x30a)][_0x40bf65(0x37a)](this);
          var _0x16bc94 = PIXI[_0x40bf65(0x385)]["fromFrame"](_0x40bf65(0xee));
          (_0x16bc94["anchor"]["set"](0.5),
            _0x16bc94[_0x40bf65(0x231)]["set"](0.85),
            this["addChild"](_0x16bc94));
          var _0x4dee54 = PIXI["Sprite"][_0x40bf65(0x348)](_0x40bf65(0x15b));
          (_0x4dee54[_0x40bf65(0x4a1)][_0x40bf65(0x27e)](0.5),
            _0x4dee54[_0x40bf65(0x231)][_0x40bf65(0x27e)](0.85),
            this[_0x40bf65(0x37b)](_0x4dee54),
            (this[_0x40bf65(0x2bc)] = _0x4dee54));
          var _0x5f5ca6 = new PIXI[_0x40bf65(0x148)]();
          (_0x5f5ca6["beginFill"](0xff00),
            this["addChild"](_0x5f5ca6),
            (_0x4dee54["mask"] = _0x5f5ca6),
            Tweener[_0x40bf65(0x3a0)](
              { period: 0x0 },
              { period: 0x64 },
              {
                time: 0x64,
                loop: -0x1,
                onUpdate: function (_0x17c967) {
                  var _0x597232 = _0x40bf65;
                  if (this[_0x597232(0x3e2)] < 0xa) {
                    this["fill"][_0x597232(0x335)] =
                      PIXI[_0x597232(0x304)][_0x597232(0x299)][
                        _0x597232(0x3ea)
                      ];
                    if (
                      Math["round"](_0x17c967[_0x597232(0x2c2)] / 0x5) % 0x2 ==
                      0x0
                    )
                      this[_0x597232(0x2bc)][_0x597232(0x197)] = ![];
                    else this[_0x597232(0x2bc)]["visible"] = !![];
                  } else {
                    if (this[_0x597232(0x3e2)] < 0x1e) {
                      this[_0x597232(0x2bc)][_0x597232(0x335)] =
                        PIXI[_0x597232(0x304)][_0x597232(0x299)][
                          _0x597232(0x1f5)
                        ];
                      if (
                        Math[_0x597232(0x167)](
                          _0x17c967[_0x597232(0x2c2)] / 0xa,
                        ) %
                          0x2 ==
                        0x0
                      )
                        this[_0x597232(0x2bc)][_0x597232(0x197)] = ![];
                      else this[_0x597232(0x2bc)][_0x597232(0x197)] = !![];
                    } else
                      ((this[_0x597232(0x2bc)][_0x597232(0x335)] =
                        PIXI[_0x597232(0x304)][_0x597232(0x299)][
                          _0x597232(0x15b)
                        ]),
                        (this["fill"]["visible"] = !![]));
                  }
                }[_0x40bf65(0x374)](this),
              },
            ),
            (this[_0x40bf65(0x3e2)] = 0x0));
        }
        return (
          (_0x5acaba[_0x5303e8(0x333)] = Object[_0x5303e8(0x454)](
            PIXI[_0x5303e8(0x30a)][_0x5303e8(0x333)],
          )),
          (_0x5acaba[_0x5303e8(0x333)][_0x5303e8(0xed)] = function () {
            var _0x4b0166 = _0x5303e8;
            (this[_0x4b0166(0x2bc)][_0x4b0166(0x20a)]["clear"](),
              this[_0x4b0166(0x2bc)][_0x4b0166(0x20a)][_0x4b0166(0x339)](
                0xff00,
              ));
            if (this[_0x4b0166(0x3e2)] > 0x64 - 12.5) {
              let _0x576ef7 = (this[_0x4b0166(0x3e2)] - (0x64 - 12.5)) / 12.5;
              (this["fill"][_0x4b0166(0x20a)]["drawRect"](
                _0x2a96b3 / 0x2 - (_0x576ef7 * _0x2a96b3) / 0x2,
                -_0x54aa42 / 0x2,
                (_0x576ef7 * _0x2a96b3) / 0x2,
                _0x36c778,
              ),
                this[_0x4b0166(0x2bc)][_0x4b0166(0x20a)]["drawRect"](
                  _0x2a96b3 / 0x2 - _0x36c778,
                  -_0x54aa42 / 0x2 + _0x36c778,
                  _0x36c778,
                  _0x54aa42 - _0x36c778 * 0x2,
                ),
                this[_0x4b0166(0x2bc)][_0x4b0166(0x20a)][_0x4b0166(0x26a)](
                  -_0x2a96b3 / 0x2,
                  _0x54aa42 / 0x2 - _0x36c778,
                  _0x2a96b3,
                  _0x36c778,
                ),
                this[_0x4b0166(0x2bc)]["mask"][_0x4b0166(0x26a)](
                  -_0x2a96b3 / 0x2,
                  -_0x54aa42 / 0x2 + _0x36c778,
                  _0x36c778,
                  _0x54aa42 - _0x36c778 * 0x2,
                ),
                this[_0x4b0166(0x2bc)][_0x4b0166(0x20a)][_0x4b0166(0x26a)](
                  -_0x2a96b3 / 0x2,
                  -_0x54aa42 / 0x2,
                  _0x2a96b3 / 0x2,
                  _0x36c778,
                ));
            } else {
              if (this[_0x4b0166(0x3e2)] > 0x64 - 12.5 - 0x19) {
                let _0x510ade =
                  (this[_0x4b0166(0x3e2)] - (0x64 - 12.5 - 0x19)) / 0x19;
                (this[_0x4b0166(0x2bc)][_0x4b0166(0x20a)][_0x4b0166(0x26a)](
                  _0x2a96b3 / 0x2 - _0x36c778,
                  -_0x54aa42 / 0x2 +
                    _0x36c778 +
                    (_0x54aa42 - _0x36c778 * 0x2) -
                    _0x510ade * (_0x54aa42 - _0x36c778 * 0x2),
                  _0x36c778,
                  _0x510ade * (_0x54aa42 - _0x36c778 * 0x2),
                ),
                  this[_0x4b0166(0x2bc)][_0x4b0166(0x20a)][_0x4b0166(0x26a)](
                    -_0x2a96b3 / 0x2,
                    _0x54aa42 / 0x2 - _0x36c778,
                    _0x2a96b3,
                    _0x36c778,
                  ),
                  this[_0x4b0166(0x2bc)][_0x4b0166(0x20a)][_0x4b0166(0x26a)](
                    -_0x2a96b3 / 0x2,
                    -_0x54aa42 / 0x2 + _0x36c778,
                    _0x36c778,
                    _0x54aa42 - _0x36c778 * 0x2,
                  ),
                  this[_0x4b0166(0x2bc)][_0x4b0166(0x20a)]["drawRect"](
                    -_0x2a96b3 / 0x2,
                    -_0x54aa42 / 0x2,
                    _0x2a96b3 / 0x2,
                    _0x36c778,
                  ));
              } else {
                if (this["_value"] > 0x64 - 12.5 - 0x32) {
                  let _0x5f2025 =
                    (this[_0x4b0166(0x3e2)] - (0x64 - 12.5 - 0x32)) / 0x19;
                  (this["fill"][_0x4b0166(0x20a)][_0x4b0166(0x26a)](
                    -_0x2a96b3 / 0x2,
                    _0x54aa42 / 0x2 - _0x36c778,
                    _0x2a96b3 * _0x5f2025,
                    _0x36c778,
                  ),
                    this[_0x4b0166(0x2bc)][_0x4b0166(0x20a)][_0x4b0166(0x26a)](
                      -_0x2a96b3 / 0x2,
                      -_0x54aa42 / 0x2 + _0x36c778,
                      _0x36c778,
                      _0x54aa42 - _0x36c778 * 0x2,
                    ),
                    this[_0x4b0166(0x2bc)][_0x4b0166(0x20a)]["drawRect"](
                      -_0x2a96b3 / 0x2,
                      -_0x54aa42 / 0x2,
                      _0x2a96b3 / 0x2,
                      _0x36c778,
                    ));
                } else {
                  if (this[_0x4b0166(0x3e2)] > 0x64 - 12.5 - 0x4b) {
                    let _0x190ddf =
                      (this[_0x4b0166(0x3e2)] - (0x64 - 12.5 - 0x4b)) / 0x19;
                    (this[_0x4b0166(0x2bc)][_0x4b0166(0x20a)][_0x4b0166(0x26a)](
                      -_0x2a96b3 / 0x2,
                      -_0x54aa42 / 0x2 + _0x36c778,
                      _0x36c778,
                      _0x190ddf * (_0x54aa42 - _0x36c778 * 0x2),
                    ),
                      this[_0x4b0166(0x2bc)]["mask"][_0x4b0166(0x26a)](
                        -_0x2a96b3 / 0x2,
                        -_0x54aa42 / 0x2,
                        _0x2a96b3 / 0x2,
                        _0x36c778,
                      ));
                  } else {
                    let _0x476deb = this[_0x4b0166(0x3e2)] / 12.5;
                    this[_0x4b0166(0x2bc)]["mask"][_0x4b0166(0x26a)](
                      -_0x2a96b3 / 0x2 +
                        _0x2a96b3 / 0x2 -
                        (_0x2a96b3 / 0x2) * _0x476deb,
                      -_0x54aa42 / 0x2,
                      (_0x2a96b3 / 0x2) * _0x476deb,
                      _0x36c778,
                    );
                  }
                }
              }
            }
          }),
          Object[_0x5303e8(0x211)](_0x5acaba[_0x5303e8(0x333)], {
            value: {
              set: function (_0x3e71f8) {
                var _0x5047ac = _0x5303e8;
                ((this[_0x5047ac(0x3e2)] = _0x3e71f8), this[_0x5047ac(0xed)]());
              },
              get: function () {
                var _0x19e1e8 = _0x5303e8;
                return this[_0x19e1e8(0x3e2)];
              },
            },
          }),
          _0x5acaba
        );
      })(),
      _0x51b412 = (function () {
        var _0x305b26 = _0x157421;
        function _0x10b7ef(
          _0x20fbca,
          _0x29a1ef,
          _0x1f76b7,
          _0x37059e,
          _0xf10fb7,
        ) {
          var _0x4f4fa6 = _0x3797;
          PIXI["Container"][_0x4f4fa6(0x37a)](this);
          var _0x44895 = PIXI["Sprite"][_0x4f4fa6(0x348)](_0x4f4fa6(0xe8));
          (_0x44895[_0x4f4fa6(0x4a1)][_0x4f4fa6(0x27e)](0.5),
            (_0x44895[_0x4f4fa6(0xe5)] = 0.9),
            this[_0x4f4fa6(0x37b)](_0x44895));
          var _0x41a240 = PIXI[_0x4f4fa6(0x385)][_0x4f4fa6(0x348)](
            _0x4f4fa6(0x41f),
          );
          (_0x41a240[_0x4f4fa6(0x4a1)][_0x4f4fa6(0x27e)](0.5),
            (_0x41a240["y"] = -0x140),
            _0x44895[_0x4f4fa6(0x37b)](_0x41a240));
          var _0x47f1bf =
            PIXI[_0x4f4fa6(0x385)][_0x4f4fa6(0x348)]("results_title");
          (_0x47f1bf[_0x4f4fa6(0x4a1)][_0x4f4fa6(0x27e)](0.5),
            (_0x47f1bf["y"] = -0x12c),
            this[_0x4f4fa6(0x37b)](_0x47f1bf));
          var _0x3ea2e3 = PIXI[_0x4f4fa6(0x385)][_0x4f4fa6(0x348)](
            _0x4f4fa6(0xff),
          );
          (_0x3ea2e3[_0x4f4fa6(0x4a1)]["set"](0.5),
            (_0x3ea2e3["y"] = -0x1ea),
            this[_0x4f4fa6(0x37b)](_0x3ea2e3),
            (_0x3ea2e3["alpha"] = 0x0),
            (_0x3ea2e3["x"] = -0x64),
            Tweener[_0x4f4fa6(0x3a0)](
              _0x3ea2e3,
              { x: 0x0, alpha: 0x1 },
              { time: 0x14, delay: 0x5, transition: "easeOutQuad" },
            ));
          var _0x47e8d2 = PIXI["Sprite"][_0x4f4fa6(0x348)](_0x4f4fa6(0x3cd));
          (_0x47e8d2[_0x4f4fa6(0x4a1)][_0x4f4fa6(0x27e)](0.5),
            (_0x47e8d2["x"] = -0x82),
            (_0x47e8d2["y"] = -0x1e),
            this[_0x4f4fa6(0x37b)](_0x47e8d2),
            _0x47e8d2[_0x4f4fa6(0x231)]["set"](0x0),
            Tweener[_0x4f4fa6(0x3a0)](
              _0x47e8d2,
              { scaleX: 0x1, scaleY: 0x1 },
              { time: 0xf, delay: 0xa, transition: _0x4f4fa6(0x426) },
            ));
          var _0x2057f6 = PIXI["Sprite"][_0x4f4fa6(0x348)](_0x4f4fa6(0x2ac));
          (_0x2057f6["anchor"][_0x4f4fa6(0x27e)](0.5),
            (_0x2057f6["x"] = 0x0),
            (_0x2057f6["y"] = 0x64),
            _0x47e8d2["addChild"](_0x2057f6));
          var _0x1e5455 = PIXI["Sprite"][_0x4f4fa6(0x348)](_0x4f4fa6(0x28b));
          (_0x1e5455[_0x4f4fa6(0x4a1)][_0x4f4fa6(0x27e)](0.5),
            _0x1e5455[_0x4f4fa6(0x231)]["set"](1.4),
            (_0x1e5455["x"] = -0x3c),
            (_0x1e5455["y"] = -0x3c),
            _0x47e8d2["addChild"](_0x1e5455),
            (this[_0x4f4fa6(0x21b)] = _0x1e5455));
          if (_0x1f76b7 >= 0x0) {
            var _0x45e46e = PIXI[_0x4f4fa6(0x385)][_0x4f4fa6(0x348)](
              _0x4cd129[_0x1f76b7][_0x4f4fa6(0xf3)],
            );
            (_0x45e46e[_0x4f4fa6(0x4a1)][_0x4f4fa6(0x27e)](0.5),
              _0x45e46e[_0x4f4fa6(0x231)]["set"](0.32),
              _0x1e5455[_0x4f4fa6(0x37b)](_0x45e46e));
          }
          var _0x1b5078 = new PIXI["BitmapText"]("" + _0x37059e, {
            font: _0x4f4fa6(0x316),
            fill: 0xffffff,
            align: "center",
          });
          (_0x1b5078[_0x4f4fa6(0x4a1)][_0x4f4fa6(0x27e)](0.5),
            (_0x1b5078["anchor"]["x"] = 0x0),
            (_0x1b5078["x"] = -0x19),
            (_0x1b5078["y"] = -0x3c),
            _0x47e8d2[_0x4f4fa6(0x37b)](_0x1b5078));
          var _0x30c326 = PIXI["Sprite"][_0x4f4fa6(0x348)](_0x4f4fa6(0x2cc));
          (_0x30c326[_0x4f4fa6(0x4a1)][_0x4f4fa6(0x27e)](0.5),
            (_0x30c326["x"] = 0x82),
            (_0x30c326["y"] = -0x1e),
            this[_0x4f4fa6(0x37b)](_0x30c326),
            _0x30c326[_0x4f4fa6(0x231)][_0x4f4fa6(0x27e)](0x0),
            Tweener[_0x4f4fa6(0x3a0)](
              _0x30c326,
              { scaleX: 0x1, scaleY: 0x1 },
              { time: 0xf, delay: 0xa, transition: "easeOutBack" },
            ));
          var _0x139366 = PIXI[_0x4f4fa6(0x385)][_0x4f4fa6(0x348)](
            _0x4f4fa6(0x3ed),
          );
          (_0x139366[_0x4f4fa6(0x4a1)]["set"](0.5),
            (_0x139366["x"] = 0x0),
            (_0x139366["y"] = 0x64),
            _0x30c326["addChild"](_0x139366));
          var _0x13dc85 = PIXI["Sprite"][_0x4f4fa6(0x348)](
            "Carrom_player_black",
          );
          (_0x13dc85[_0x4f4fa6(0x4a1)][_0x4f4fa6(0x27e)](0.5),
            _0x13dc85[_0x4f4fa6(0x231)]["set"](1.4),
            (_0x13dc85["x"] = -0x3c),
            (_0x13dc85["y"] = -0x3c),
            _0x30c326[_0x4f4fa6(0x37b)](_0x13dc85));
          var _0x2238df = new PIXI[_0x4f4fa6(0x402)]("" + _0xf10fb7, {
            font: _0x4f4fa6(0x316),
            fill: 0xffffff,
            align: _0x4f4fa6(0x221),
          });
          (_0x2238df[_0x4f4fa6(0x4a1)][_0x4f4fa6(0x27e)](0.5),
            (_0x2238df[_0x4f4fa6(0x4a1)]["x"] = 0x0),
            (_0x2238df["x"] = -0x19),
            (_0x2238df["y"] = -0x3c),
            _0x30c326[_0x4f4fa6(0x37b)](_0x2238df));
          var _0x19837a = new PIXI[_0x4f4fa6(0x402)]("0", {
            font: _0x4f4fa6(0x3a8),
            fill: 0xffffff,
            align: "center",
          });
          (_0x19837a[_0x4f4fa6(0x4a1)]["set"](0.5),
            (_0x19837a["x"] = 0x0),
            (_0x19837a["y"] = 0xa0),
            this[_0x4f4fa6(0x37b)](_0x19837a));
          var _0x524876 = PIXI[_0x4f4fa6(0x385)]["fromFrame"](_0x4f4fa6(0x171));
          (_0x524876[_0x4f4fa6(0x4a1)][_0x4f4fa6(0x27e)](0.5),
            (_0x524876["x"] = 0x0),
            (_0x524876["y"] = 0xa0),
            this[_0x4f4fa6(0x37b)](_0x524876),
            (_0x19837a["x"] = -(_0x524876[_0x4f4fa6(0xfd)] + 0xa) / 0x2),
            (_0x524876["x"] =
              _0x19837a["x"] +
              _0x19837a[_0x4f4fa6(0xfd)] / 0x2 +
              _0x524876["width"] / 0x2 +
              0xa),
            Tweener["addTween"](
              { value: 0x0 },
              { value: _0x29a1ef },
              {
                time: 0x28,
                transition: _0x4f4fa6(0x1f9),
                onUpdate: function (_0x119456) {
                  var _0x58ca99 = _0x4f4fa6;
                  ((_0x19837a[_0x58ca99(0x1aa)] =
                    "" + Math[_0x58ca99(0x167)](_0x119456[_0x58ca99(0x4b7)])),
                    (_0x19837a["x"] =
                      -(_0x524876[_0x58ca99(0xfd)] + 0xa) / 0x2),
                    (_0x524876["x"] =
                      _0x19837a["x"] +
                      _0x19837a[_0x58ca99(0xfd)] / 0x2 +
                      _0x524876[_0x58ca99(0xfd)] / 0x2 +
                      0xa));
                },
              },
            ));
          var _0x2fe586 = new _0x32d81c(
            PIXI["utils"][_0x4f4fa6(0x299)][_0x4f4fa6(0x1e6)],
          );
          (_0x2fe586[_0x4f4fa6(0x4a1)][_0x4f4fa6(0x27e)](0.5),
            (_0x2fe586["x"] = 0x0),
            (_0x2fe586["y"] = 0x154),
            _0x2fe586[_0x4f4fa6(0x3d4)](
              "down",
              PIXI["utils"][_0x4f4fa6(0x299)][_0x4f4fa6(0x324)],
            ),
            this[_0x4f4fa6(0x37b)](_0x2fe586),
            _0x2fe586["on"](
              "pointerdown",
              function () {
                var _0x37d7c3 = _0x4f4fa6;
                this[_0x37d7c3(0xfe)](_0x37d7c3(0x4c4));
              }[_0x4f4fa6(0x374)](this),
            ));
          !_0x20fbca &&
            ((_0x2fe586[_0x4f4fa6(0x335)] =
              PIXI[_0x4f4fa6(0x304)]["TextureCache"][_0x4f4fa6(0x16a)]),
            _0x2fe586[_0x4f4fa6(0x3d4)](
              "up",
              PIXI[_0x4f4fa6(0x304)]["TextureCache"][_0x4f4fa6(0x16a)],
            ),
            _0x2fe586[_0x4f4fa6(0x3d4)](
              _0x4f4fa6(0x444),
              PIXI[_0x4f4fa6(0x304)][_0x4f4fa6(0x299)][_0x4f4fa6(0x342)],
            ),
            (_0x47f1bf[_0x4f4fa6(0x335)] =
              PIXI["utils"]["TextureCache"][_0x4f4fa6(0x2a8)]),
            (_0x3ea2e3[_0x4f4fa6(0x335)] =
              PIXI[_0x4f4fa6(0x304)][_0x4f4fa6(0x299)][_0x4f4fa6(0x26d)]),
            (_0x47e8d2[_0x4f4fa6(0x335)] =
              PIXI[_0x4f4fa6(0x304)]["TextureCache"][_0x4f4fa6(0x42c)]),
            (_0x30c326[_0x4f4fa6(0x335)] =
              PIXI[_0x4f4fa6(0x304)][_0x4f4fa6(0x299)][_0x4f4fa6(0x110)]),
            (_0x44895["visible"] = ![]));
          var _0x4a6ca2 = new _0x32d81c(
            PIXI[_0x4f4fa6(0x304)][_0x4f4fa6(0x299)]["results_claimx2_button"],
          );
          (_0x4a6ca2[_0x4f4fa6(0x4a1)][_0x4f4fa6(0x27e)](0.5),
            (_0x4a6ca2[_0x4f4fa6(0x197)] = ![]),
            (_0x4a6ca2["x"] = 0x0),
            (_0x4a6ca2["y"] = 0x1d6),
            _0x4a6ca2["registerState"](
              _0x4f4fa6(0x444),
              PIXI[_0x4f4fa6(0x304)][_0x4f4fa6(0x299)][
                "results_claimx2_button_hover"
              ],
            ),
            this[_0x4f4fa6(0x37b)](_0x4a6ca2),
            (this["btnClaimAd"] = _0x4a6ca2),
            _0x4a6ca2["on"](
              _0x4f4fa6(0x2a7),
              function () {
                var _0x1ae9f2 = _0x4f4fa6;
                this[_0x1ae9f2(0xfe)]("ad");
              }[_0x4f4fa6(0x374)](this),
            ));
        }
        return (
          (_0x10b7ef["prototype"] = Object[_0x305b26(0x454)](
            PIXI["Container"][_0x305b26(0x333)],
          )),
          (_0x10b7ef[_0x305b26(0x333)][_0x305b26(0x13d)] = function () {
            var _0x427c3e = _0x305b26;
            ((this[_0x427c3e(0x3ba)]["visible"] = !![]),
              this[_0x427c3e(0x3ba)][_0x427c3e(0x231)][_0x427c3e(0x27e)](0x0),
              Tweener[_0x427c3e(0x3a0)](
                this["btnClaimAd"],
                { scaleX: 0x1, scaleY: 0x1 },
                { time: 0x14, delay: 0x32, transition: _0x427c3e(0x426) },
              ));
          }),
          (_0x10b7ef["prototype"][_0x305b26(0x3d0)] = function () {
            var _0x1a6146 = _0x305b26;
            this[_0x1a6146(0x3ba)][_0x1a6146(0x197)] = ![];
          }),
          _0x10b7ef
        );
      })(),
      _0x350929 = (function () {
        var _0x1e8f29 = _0x157421;
        function _0x54469e(_0x224ece) {
          var _0x59bea5 = _0x3797;
          PIXI[_0x59bea5(0x30a)][_0x59bea5(0x37a)](this);
          var _0x25b726 = PIXI[_0x59bea5(0x385)][_0x59bea5(0x348)](
            _0x59bea5(0x382),
          );
          (_0x25b726[_0x59bea5(0x4a1)][_0x59bea5(0x27e)](0.5),
            this["addChild"](_0x25b726),
            (this[_0x59bea5(0x1f7)] = _0x25b726));
          var _0xb7b923 = PIXI[_0x59bea5(0x385)]["fromFrame"](
            "strike_green_stroke",
          );
          (_0xb7b923[_0x59bea5(0x4a1)][_0x59bea5(0x27e)](0.5),
            (_0xb7b923["visible"] = ![]),
            (_0xb7b923["x"] = 0x8),
            (_0xb7b923["y"] = -0x7),
            this[_0x59bea5(0x37b)](_0xb7b923),
            (this["_frame"] = _0xb7b923));
          var _0x47ca8f = PIXI[_0x59bea5(0x385)][_0x59bea5(0x348)](
            _0x224ece["icon"],
          );
          (_0x47ca8f[_0x59bea5(0x4a1)][_0x59bea5(0x27e)](0.5),
            (_0x47ca8f["x"] = 0xa),
            (_0x47ca8f["y"] = -0x84),
            this[_0x59bea5(0x37b)](_0x47ca8f),
            (this[_0x59bea5(0x280)] = _0x47ca8f));
          var _0x480c77 = PIXI[_0x59bea5(0x385)][_0x59bea5(0x348)]("shop_tick");
          (_0x480c77[_0x59bea5(0x4a1)][_0x59bea5(0x27e)](0.5),
            (_0x480c77["x"] = 0x2d),
            (_0x480c77["y"] = -0xaa),
            (_0x480c77[_0x59bea5(0x197)] = ![]),
            this[_0x59bea5(0x37b)](_0x480c77),
            (this[_0x59bea5(0x27f)] = _0x480c77),
            (_0x25b726["interactive"] = !![]),
            (_0x25b726[_0x59bea5(0x2e6)] = !![]),
            _0x25b726["on"](
              _0x59bea5(0x43e),
              function (_0x58952a) {
                var _0xdf979d = _0x59bea5;
                if (
                  _0x58952a[_0xdf979d(0x3ca)]["global"]["y"] <
                  0xe6 + _0x376ce3 / 0x2
                )
                  return;
                this[_0xdf979d(0xfe)](_0xdf979d(0x20f), this["id"]);
              }["bind"](this),
            ));
          var _0x42b4ea = PIXI[_0x59bea5(0x385)][_0x59bea5(0x348)](
            "shop_strikers_module_dimmed",
          );
          (_0x42b4ea["anchor"]["set"](0.5),
            (_0x42b4ea["x"] = 0x9),
            (_0x42b4ea["y"] = -0x12),
            this[_0x59bea5(0x37b)](_0x42b4ea),
            (this[_0x59bea5(0x3f1)] = _0x42b4ea));
          var _0x3c9672 = new _0x32d81c(
            PIXI[_0x59bea5(0x304)][_0x59bea5(0x299)]["shop_button_buy"],
          );
          (_0x3c9672[_0x59bea5(0x4a1)][_0x59bea5(0x27e)](0.5),
            (_0x3c9672["x"] = 0x7),
            (_0x3c9672["y"] = 0x6b),
            _0x3c9672["registerState"](
              "down",
              PIXI[_0x59bea5(0x304)][_0x59bea5(0x299)][_0x59bea5(0x31b)],
            ),
            this[_0x59bea5(0x37b)](_0x3c9672),
            _0x3c9672["on"](
              _0x59bea5(0x2a7),
              function () {
                var _0x5d0754 = _0x59bea5;
                this[_0x5d0754(0xfe)]("buy", this["id"]);
              }["bind"](this),
            ),
            (this["_button"] = _0x3c9672));
          var _0x5113b5 = PIXI[_0x59bea5(0x385)]["fromFrame"](_0x59bea5(0x255));
          (_0x5113b5[_0x59bea5(0x4a1)]["set"](0.5),
            (_0x5113b5["x"] = 0x38),
            (_0x5113b5["y"] = 0x0),
            _0x3c9672[_0x59bea5(0x37b)](_0x5113b5));
          var _0x4c636e = new PIXI[_0x59bea5(0x402)]("0", {
            font: _0x59bea5(0x2f3),
            fill: 0xffffff,
            align: "right",
          });
          ((_0x4c636e[_0x59bea5(0x4a1)]["x"] = 0x1),
            (_0x4c636e["anchor"]["y"] = 0.5),
            (_0x4c636e[_0x59bea5(0xe5)] = 0x1),
            (_0x4c636e["x"] = 0x2a),
            (_0x4c636e["y"] = 0x2),
            _0x3c9672[_0x59bea5(0x37b)](_0x4c636e),
            (_0x3c9672[_0x59bea5(0x4b4)] = _0x4c636e),
            (this[_0x59bea5(0x47e)] = _0x4c636e),
            (this["_fieldIcon"] = _0x5113b5),
            (this[_0x59bea5(0x1bc)] = []),
            (this[_0x59bea5(0x3a9)] = []),
            (this[_0x59bea5(0x44a)] = []));
          for (let _0x5f2617 = 0x0; _0x5f2617 < 0x5; _0x5f2617++) {
            var _0x1b7fc3 = PIXI["Sprite"][_0x59bea5(0x348)](_0x59bea5(0xdc));
            (_0x1b7fc3["anchor"][_0x59bea5(0x27e)](0.5),
              (_0x1b7fc3["x"] = 0xf + 0xe * _0x5f2617),
              (_0x1b7fc3["y"] = -0x1c),
              this[_0x59bea5(0x37b)](_0x1b7fc3),
              this[_0x59bea5(0x1bc)]["push"](_0x1b7fc3));
          }
          for (let _0x3bd206 = 0x0; _0x3bd206 < 0x5; _0x3bd206++) {
            var _0x1b7fc3 =
              PIXI[_0x59bea5(0x385)][_0x59bea5(0x348)]("strike_blue_bit");
            (_0x1b7fc3[_0x59bea5(0x4a1)]["set"](0.5),
              (_0x1b7fc3["x"] = 0xf + 0xe * _0x3bd206),
              (_0x1b7fc3["y"] = 0x9),
              this[_0x59bea5(0x37b)](_0x1b7fc3),
              this[_0x59bea5(0x3a9)][_0x59bea5(0x3b0)](_0x1b7fc3));
          }
          for (let _0x572ea8 = 0x0; _0x572ea8 < 0x5; _0x572ea8++) {
            var _0x1b7fc3 = PIXI[_0x59bea5(0x385)][_0x59bea5(0x348)](
              _0x59bea5(0xdc),
            );
            (_0x1b7fc3["anchor"][_0x59bea5(0x27e)](0.5),
              (_0x1b7fc3["x"] = 0xf + 0xe * _0x572ea8),
              (_0x1b7fc3["y"] = 0x2e),
              this[_0x59bea5(0x37b)](_0x1b7fc3),
              this[_0x59bea5(0x44a)][_0x59bea5(0x3b0)](_0x1b7fc3));
          }
          (this[_0x59bea5(0x135)](_0x224ece, 0x0), (this["id"] = 0x0));
        }
        return (
          (_0x54469e[_0x1e8f29(0x333)] = Object[_0x1e8f29(0x454)](
            PIXI[_0x1e8f29(0x30a)][_0x1e8f29(0x333)],
          )),
          (_0x54469e[_0x1e8f29(0x333)]["updateStats"] = function (
            _0x2ab436,
            _0x15ae1c,
            _0x4f70c6,
          ) {
            var _0x354c69 = _0x1e8f29;
            for (
              let _0x267aad = 0x0;
              _0x267aad < this[_0x354c69(0x1bc)][_0x354c69(0x182)];
              _0x267aad++
            ) {
              let _0x160881 = this[_0x354c69(0x1bc)][_0x267aad],
                _0x3c05c7 = _0x2ab436[_0x354c69(0x3a1)],
                _0x574d71 =
                  !_0x4f70c6 &&
                  _0x15ae1c < _0x2ab436[_0x354c69(0x1ea)] &&
                  _0x2ab436["upgrades"][_0x15ae1c] == 0x1
                    ? 0x1
                    : 0x0;
              for (let _0x4fd926 = 0x0; _0x4fd926 < _0x15ae1c; _0x4fd926++)
                if (_0x2ab436[_0x354c69(0x315)][_0x4fd926] == 0x1) _0x3c05c7++;
              if (_0x267aad < _0x3c05c7)
                ((_0x160881[_0x354c69(0x197)] = !![]),
                  (_0x160881[_0x354c69(0x335)] =
                    PIXI["utils"]["TextureCache"][_0x354c69(0x30d)]));
              else
                _0x267aad < _0x3c05c7 + _0x574d71
                  ? ((_0x160881[_0x354c69(0x197)] = !![]),
                    (_0x160881[_0x354c69(0x335)] =
                      PIXI["utils"][_0x354c69(0x299)][_0x354c69(0xdc)]))
                  : (_0x160881[_0x354c69(0x197)] = ![]);
            }
            for (
              let _0x21333a = 0x0;
              _0x21333a < this[_0x354c69(0x3a9)][_0x354c69(0x182)];
              _0x21333a++
            ) {
              let _0x43735f = this[_0x354c69(0x3a9)][_0x21333a],
                _0x291990 = _0x2ab436[_0x354c69(0x227)],
                _0x1a74ee =
                  !_0x4f70c6 &&
                  _0x15ae1c < _0x2ab436[_0x354c69(0x1ea)] &&
                  _0x2ab436[_0x354c69(0x315)][_0x15ae1c] == 0x0
                    ? 0x1
                    : 0x0;
              for (let _0x13dda2 = 0x0; _0x13dda2 < _0x15ae1c; _0x13dda2++)
                if (_0x2ab436[_0x354c69(0x315)][_0x13dda2] == 0x0) _0x291990++;
              if (_0x21333a < _0x291990)
                ((_0x43735f["visible"] = !![]),
                  (_0x43735f[_0x354c69(0x335)] =
                    PIXI[_0x354c69(0x304)][_0x354c69(0x299)][
                      _0x354c69(0x30d)
                    ]));
              else
                _0x21333a < _0x291990 + _0x1a74ee
                  ? ((_0x43735f[_0x354c69(0x197)] = !![]),
                    (_0x43735f[_0x354c69(0x335)] =
                      PIXI[_0x354c69(0x304)][_0x354c69(0x299)][
                        _0x354c69(0xdc)
                      ]))
                  : (_0x43735f[_0x354c69(0x197)] = ![]);
            }
            for (
              let _0x2aba37 = 0x0;
              _0x2aba37 < this[_0x354c69(0x44a)][_0x354c69(0x182)];
              _0x2aba37++
            ) {
              let _0x23fdd5 = this[_0x354c69(0x44a)][_0x2aba37],
                _0x22f407 = _0x2ab436[_0x354c69(0x149)],
                _0x4e721d =
                  !_0x4f70c6 &&
                  _0x15ae1c < _0x2ab436[_0x354c69(0x1ea)] &&
                  _0x2ab436[_0x354c69(0x315)][_0x15ae1c] == 0x2
                    ? 0x1
                    : 0x0;
              for (let _0x5d021a = 0x0; _0x5d021a < _0x15ae1c; _0x5d021a++)
                if (_0x2ab436[_0x354c69(0x315)][_0x5d021a] == 0x2) _0x22f407++;
              if (_0x2aba37 < _0x22f407)
                ((_0x23fdd5["visible"] = !![]),
                  (_0x23fdd5[_0x354c69(0x335)] =
                    PIXI[_0x354c69(0x304)][_0x354c69(0x299)][
                      _0x354c69(0x30d)
                    ]));
              else
                _0x2aba37 < _0x22f407 + _0x4e721d
                  ? ((_0x23fdd5[_0x354c69(0x197)] = !![]),
                    (_0x23fdd5[_0x354c69(0x335)] =
                      PIXI[_0x354c69(0x304)]["TextureCache"][_0x354c69(0xdc)]))
                  : (_0x23fdd5["visible"] = ![]);
            }
          }),
          (_0x54469e[_0x1e8f29(0x333)]["setState"] = function (
            _0x3de80b,
            _0x378e5d,
            _0x53ecef,
          ) {
            var _0x364236 = _0x1e8f29;
            this[_0x364236(0xd6)] = _0x3de80b;
            switch (_0x3de80b) {
              case _0x364236(0x2c8):
                ((this[_0x364236(0xe5)] = 0.9),
                  (this[_0x364236(0x34e)][_0x364236(0x197)] = !![]),
                  this[_0x364236(0x34e)][_0x364236(0x12d)](![]),
                  (this[_0x364236(0x34e)]["texture"] =
                    PIXI[_0x364236(0x304)][_0x364236(0x299)][_0x364236(0x31b)]),
                  this[_0x364236(0x34e)]["registerState"](
                    "up",
                    PIXI[_0x364236(0x304)][_0x364236(0x299)][_0x364236(0x31b)],
                  ),
                  this[_0x364236(0x34e)][_0x364236(0x3d4)](
                    "down",
                    PIXI["utils"][_0x364236(0x299)]["shop_button_buy_hover"],
                  ),
                  (this[_0x364236(0x47e)][_0x364236(0xe5)] = 0.5),
                  (this["_field"][_0x364236(0x1aa)] =
                    "" + _0x2f9b78(_0x378e5d)),
                  (this[_0x364236(0x47e)]["x"] = 0x2d),
                  (this[_0x364236(0xd0)]["x"] = 0x38),
                  (this[_0x364236(0xfa)][_0x364236(0x197)] = ![]),
                  (this[_0x364236(0x27f)][_0x364236(0x197)] = ![]),
                  (this[_0x364236(0x3f1)][_0x364236(0x197)] = !![]));
                break;
              case "available":
                ((this[_0x364236(0xe5)] = 0x1),
                  (this[_0x364236(0x34e)][_0x364236(0x197)] = !![]),
                  this[_0x364236(0x34e)][_0x364236(0x12d)](!![]),
                  (this[_0x364236(0x34e)]["texture"] =
                    PIXI[_0x364236(0x304)][_0x364236(0x299)][_0x364236(0x3c1)]),
                  this[_0x364236(0x34e)][_0x364236(0x3d4)](
                    "up",
                    PIXI["utils"][_0x364236(0x299)][_0x364236(0x3c1)],
                  ),
                  this["_button"][_0x364236(0x3d4)](
                    _0x364236(0x444),
                    PIXI[_0x364236(0x304)]["TextureCache"][_0x364236(0x31b)],
                  ),
                  (this[_0x364236(0x47e)][_0x364236(0xe5)] = 0x1),
                  (this[_0x364236(0x47e)]["text"] = "" + _0x2f9b78(_0x378e5d)),
                  (this[_0x364236(0x47e)]["x"] = 0x2d),
                  (this[_0x364236(0xd0)]["x"] = 0x38),
                  (this[_0x364236(0xfa)]["visible"] = ![]),
                  (this[_0x364236(0x27f)]["visible"] = ![]),
                  (this[_0x364236(0x3f1)][_0x364236(0x197)] = !![]));
                break;
              case _0x364236(0x434):
                ((this[_0x364236(0xe5)] = 0x1),
                  (this["_button"][_0x364236(0x197)] = !![]));
                _0x53ecef
                  ? ((this[_0x364236(0x34e)]["texture"] =
                      PIXI["utils"]["TextureCache"][_0x364236(0x328)]),
                    this[_0x364236(0x34e)]["registerState"](
                      "up",
                      PIXI[_0x364236(0x304)][_0x364236(0x299)][
                        "shop_button_upgrade_arrow"
                      ],
                    ),
                    this[_0x364236(0x34e)][_0x364236(0x3d4)](
                      _0x364236(0x444),
                      PIXI["utils"][_0x364236(0x299)][_0x364236(0x2a5)],
                    ),
                    this[_0x364236(0x34e)][_0x364236(0x12d)](!![]),
                    (this[_0x364236(0x47e)][_0x364236(0xe5)] = 0x1),
                    (this[_0x364236(0x47e)][_0x364236(0x1aa)] =
                      "" + _0x2f9b78(_0x378e5d)))
                  : ((this[_0x364236(0x34e)]["texture"] =
                      PIXI[_0x364236(0x304)][_0x364236(0x299)][
                        "shop_button_upgrade_arrow_hover"
                      ]),
                    this[_0x364236(0x34e)]["registerState"](
                      "up",
                      PIXI["utils"][_0x364236(0x299)][_0x364236(0x2a5)],
                    ),
                    this["_button"][_0x364236(0x3d4)](
                      "down",
                      PIXI[_0x364236(0x304)][_0x364236(0x299)][
                        _0x364236(0x2a5)
                      ],
                    ),
                    this[_0x364236(0x34e)]["setEnable"](![]),
                    (this[_0x364236(0x47e)][_0x364236(0xe5)] = 0.6),
                    (this[_0x364236(0x47e)][_0x364236(0x1aa)] =
                      "" + _0x2f9b78(_0x378e5d)));
                typeof _0x378e5d === "number"
                  ? (this["_fieldIcon"]["visible"] = !![])
                  : ((this[_0x364236(0xd0)][_0x364236(0x197)] = ![]),
                    (this[_0x364236(0x34e)][_0x364236(0x335)] =
                      PIXI[_0x364236(0x304)]["TextureCache"][_0x364236(0x10d)]),
                    this["_button"][_0x364236(0x3d4)](
                      "up",
                      PIXI[_0x364236(0x304)][_0x364236(0x299)][
                        _0x364236(0x10d)
                      ],
                    ),
                    this[_0x364236(0x34e)][_0x364236(0x3d4)](
                      _0x364236(0x444),
                      PIXI[_0x364236(0x304)][_0x364236(0x299)][
                        _0x364236(0x10d)
                      ],
                    ));
                ((this[_0x364236(0x47e)]["x"] =
                  this[_0x364236(0x47e)][_0x364236(0xfd)] / 0x2 + 0x7),
                  (this[_0x364236(0xd0)]["x"] =
                    this[_0x364236(0x47e)]["x"] + 0xc),
                  (this[_0x364236(0xfa)][_0x364236(0x197)] = ![]),
                  (this[_0x364236(0x27f)]["visible"] = ![]),
                  (this["overlay"][_0x364236(0x197)] = ![]));
                break;
              case "equiped":
                ((this[_0x364236(0xe5)] = 0x1),
                  (this["_button"][_0x364236(0x197)] = !![]));
                _0x53ecef
                  ? ((this[_0x364236(0x34e)][_0x364236(0x335)] =
                      PIXI[_0x364236(0x304)][_0x364236(0x299)][
                        "shop_button_upgrade_arrow"
                      ]),
                    this[_0x364236(0x34e)]["registerState"](
                      "up",
                      PIXI[_0x364236(0x304)]["TextureCache"][
                        "shop_button_upgrade_arrow"
                      ],
                    ),
                    this[_0x364236(0x34e)][_0x364236(0x3d4)](
                      _0x364236(0x444),
                      PIXI[_0x364236(0x304)]["TextureCache"][_0x364236(0x2a5)],
                    ),
                    this["_button"]["setEnable"](!![]),
                    (this["_field"][_0x364236(0xe5)] = 0x1),
                    (this["_field"][_0x364236(0x1aa)] =
                      "" + _0x2f9b78(_0x378e5d)))
                  : ((this[_0x364236(0x34e)]["texture"] =
                      PIXI[_0x364236(0x304)]["TextureCache"][_0x364236(0x2a5)]),
                    this["_button"][_0x364236(0x3d4)](
                      "up",
                      PIXI[_0x364236(0x304)]["TextureCache"][
                        "shop_button_upgrade_arrow_hover"
                      ],
                    ),
                    this[_0x364236(0x34e)][_0x364236(0x3d4)](
                      "down",
                      PIXI[_0x364236(0x304)][_0x364236(0x299)][
                        _0x364236(0x2a5)
                      ],
                    ),
                    this[_0x364236(0x34e)][_0x364236(0x12d)](![]),
                    (this[_0x364236(0x47e)][_0x364236(0xe5)] = 0.6),
                    (this[_0x364236(0x47e)][_0x364236(0x1aa)] =
                      "" + _0x2f9b78(_0x378e5d)));
                typeof _0x378e5d === _0x364236(0x375)
                  ? (this["_fieldIcon"]["visible"] = !![])
                  : ((this[_0x364236(0xd0)]["visible"] = ![]),
                    (this[_0x364236(0x34e)][_0x364236(0x335)] =
                      PIXI[_0x364236(0x304)][_0x364236(0x299)][
                        "shop_button_upgrade_hover"
                      ]),
                    this[_0x364236(0x34e)]["registerState"](
                      "up",
                      PIXI["utils"][_0x364236(0x299)][
                        "shop_button_upgrade_hover"
                      ],
                    ),
                    this["_button"]["registerState"](
                      _0x364236(0x444),
                      PIXI[_0x364236(0x304)][_0x364236(0x299)][
                        "shop_button_upgrade_hover"
                      ],
                    ));
                ((this[_0x364236(0x47e)]["x"] =
                  this["_field"][_0x364236(0xfd)] / 0x2 + 0x7),
                  (this[_0x364236(0xd0)]["x"] =
                    this[_0x364236(0x47e)]["x"] + 0xc),
                  (this[_0x364236(0xfa)][_0x364236(0x197)] = !![]),
                  (this[_0x364236(0x27f)][_0x364236(0x197)] = !![]),
                  (this[_0x364236(0x3f1)]["visible"] = ![]));
                break;
            }
          }),
          (_0x54469e["prototype"]["setEnable"] = function (_0x2cb21d) {
            var _0x5f04ed = _0x1e8f29;
            switch (this[_0x5f04ed(0xd6)]) {
              case _0x5f04ed(0x2c8):
                this[_0x5f04ed(0x34e)][_0x5f04ed(0x12d)](![]);
                break;
              case _0x5f04ed(0x3ef):
                this["_button"]["setEnable"](_0x2cb21d);
                break;
              case _0x5f04ed(0x400):
                this[_0x5f04ed(0x34e)][_0x5f04ed(0x12d)](_0x2cb21d);
                break;
              case _0x5f04ed(0x434):
                this["_button"][_0x5f04ed(0x12d)](_0x2cb21d);
                break;
              case _0x5f04ed(0x16d):
                this[_0x5f04ed(0x34e)][_0x5f04ed(0x12d)](_0x2cb21d);
                break;
            }
          }),
          _0x54469e
        );
      })(),
      _0x3a6671 = (function () {
        var _0x2fc29c = _0x157421;
        function _0x5d3695(_0x3e1768) {
          var _0x183313 = _0x3797;
          PIXI[_0x183313(0x30a)][_0x183313(0x37a)](this);
          var _0x42a3c2 =
            PIXI[_0x183313(0x385)]["fromFrame"]("stone_module_base");
          (_0x42a3c2[_0x183313(0x4a1)][_0x183313(0x27e)](0.5),
            this[_0x183313(0x37b)](_0x42a3c2));
          var _0x49cf91 = PIXI[_0x183313(0x385)][_0x183313(0x348)](
            _0x183313(0x4a6),
          );
          (_0x49cf91[_0x183313(0x4a1)][_0x183313(0x27e)](0.5),
            (_0x49cf91[_0x183313(0x197)] = ![]),
            this[_0x183313(0x37b)](_0x49cf91),
            (this["_frame"] = _0x49cf91));
          var _0x566637 = PIXI[_0x183313(0x385)][_0x183313(0x348)](
            _0x3e1768["icon"],
          );
          (_0x566637[_0x183313(0x4a1)][_0x183313(0x27e)](0.5),
            (_0x566637["x"] = 0x0),
            (_0x566637["y"] = -0x3f),
            this[_0x183313(0x37b)](_0x566637),
            (this["_icon"] = _0x566637));
          var _0x3ddd76 = PIXI[_0x183313(0x385)][_0x183313(0x348)]("shop_tick");
          (_0x3ddd76[_0x183313(0x4a1)][_0x183313(0x27e)](0.5),
            (_0x3ddd76["x"] = 0x2d),
            (_0x3ddd76["y"] = -0x64),
            (_0x3ddd76["visible"] = ![]),
            this[_0x183313(0x37b)](_0x3ddd76),
            (this["_tick"] = _0x3ddd76),
            (_0x42a3c2[_0x183313(0x1bf)] = !![]),
            (_0x42a3c2[_0x183313(0x2e6)] = !![]),
            _0x42a3c2["on"](
              _0x183313(0x43e),
              function (_0x892101) {
                var _0x29010b = _0x183313;
                this[_0x29010b(0xfe)](_0x29010b(0x20f), this["id"]);
              }["bind"](this),
            ));
          var _0x40b07a = PIXI[_0x183313(0x385)][_0x183313(0x348)](
            "shop_stones_module_dimmed",
          );
          (_0x40b07a[_0x183313(0x4a1)]["set"](0.5),
            (_0x40b07a["x"] = 0x0),
            (_0x40b07a["y"] = -0xe),
            this[_0x183313(0x37b)](_0x40b07a),
            (this[_0x183313(0x3f1)] = _0x40b07a));
          var _0x52615d = new _0x32d81c(
            PIXI[_0x183313(0x304)]["TextureCache"][_0x183313(0x3c1)],
          );
          (_0x52615d["anchor"][_0x183313(0x27e)](0.5),
            (_0x52615d["x"] = 0x0),
            (_0x52615d["y"] = 0x2f),
            _0x52615d[_0x183313(0x3d4)](
              "down",
              PIXI["utils"]["TextureCache"][_0x183313(0x31b)],
            ),
            this[_0x183313(0x37b)](_0x52615d),
            _0x52615d["on"](
              "pointertap",
              function () {
                var _0x128db6 = _0x183313;
                this["emit"](_0x128db6(0x2ba), this["id"]);
              }[_0x183313(0x374)](this),
            ),
            (this[_0x183313(0x34e)] = _0x52615d));
          var _0x3798b0 =
            PIXI[_0x183313(0x385)][_0x183313(0x348)]("shop_single_coin");
          (_0x3798b0[_0x183313(0x4a1)][_0x183313(0x27e)](0.5),
            (_0x3798b0["x"] = 0x38),
            (_0x3798b0["y"] = 0x0),
            _0x52615d[_0x183313(0x37b)](_0x3798b0));
          var _0x4b6be4 = new PIXI[_0x183313(0x402)]("0", {
            font: "24px\x20Simonetta_white2",
            fill: 0xffffff,
            align: _0x183313(0x218),
          });
          ((_0x4b6be4[_0x183313(0x4a1)]["x"] = 0x1),
            (_0x4b6be4["anchor"]["y"] = 0.5),
            (_0x4b6be4["alpha"] = 0x1),
            (_0x4b6be4["x"] = 0x2a),
            (_0x4b6be4["y"] = 0x2),
            _0x52615d[_0x183313(0x37b)](_0x4b6be4),
            (_0x52615d["content"] = _0x4b6be4),
            (this[_0x183313(0x47e)] = _0x4b6be4),
            (this[_0x183313(0xd0)] = _0x3798b0),
            (this["id"] = 0x0));
        }
        return (
          (_0x5d3695["prototype"] = Object[_0x2fc29c(0x454)](
            PIXI[_0x2fc29c(0x30a)][_0x2fc29c(0x333)],
          )),
          (_0x5d3695[_0x2fc29c(0x333)][_0x2fc29c(0x1b7)] = function (
            _0x5c42bc,
            _0x315948,
            _0x4c9764,
          ) {
            var _0x19b03b = _0x2fc29c;
            this["_state"] = _0x5c42bc;
            switch (_0x5c42bc) {
              case _0x19b03b(0x2c8):
                ((this[_0x19b03b(0xe5)] = 0.9),
                  (this["_button"][_0x19b03b(0x197)] = !![]),
                  this[_0x19b03b(0x34e)][_0x19b03b(0x12d)](![]),
                  (this[_0x19b03b(0x34e)][_0x19b03b(0x335)] =
                    PIXI["utils"][_0x19b03b(0x299)][_0x19b03b(0x31b)]),
                  this[_0x19b03b(0x34e)][_0x19b03b(0x3d4)](
                    "up",
                    PIXI[_0x19b03b(0x304)][_0x19b03b(0x299)][_0x19b03b(0x31b)],
                  ),
                  this[_0x19b03b(0x34e)]["registerState"](
                    _0x19b03b(0x444),
                    PIXI[_0x19b03b(0x304)]["TextureCache"][_0x19b03b(0x31b)],
                  ),
                  (this["_field"][_0x19b03b(0xe5)] = 0.5),
                  (this[_0x19b03b(0x47e)][_0x19b03b(0x1aa)] =
                    "" + _0x2f9b78(_0x315948)),
                  (this["_field"]["x"] = 0x2d),
                  (this[_0x19b03b(0xd0)]["x"] = 0x38),
                  (this["_frame"][_0x19b03b(0x197)] = ![]),
                  (this[_0x19b03b(0x27f)]["visible"] = ![]),
                  (this[_0x19b03b(0x3f1)][_0x19b03b(0x197)] = !![]));
                break;
              case _0x19b03b(0x3ef):
                ((this[_0x19b03b(0xe5)] = 0x1),
                  (this[_0x19b03b(0x34e)][_0x19b03b(0x197)] = !![]),
                  this[_0x19b03b(0x34e)][_0x19b03b(0x12d)](!![]),
                  (this[_0x19b03b(0x34e)][_0x19b03b(0x335)] =
                    PIXI[_0x19b03b(0x304)][_0x19b03b(0x299)][_0x19b03b(0x3c1)]),
                  this["_button"][_0x19b03b(0x3d4)](
                    "up",
                    PIXI[_0x19b03b(0x304)]["TextureCache"][_0x19b03b(0x3c1)],
                  ),
                  this[_0x19b03b(0x34e)][_0x19b03b(0x3d4)](
                    _0x19b03b(0x444),
                    PIXI[_0x19b03b(0x304)][_0x19b03b(0x299)][_0x19b03b(0x31b)],
                  ),
                  (this[_0x19b03b(0x47e)][_0x19b03b(0xe5)] = 0x1),
                  (this[_0x19b03b(0x47e)][_0x19b03b(0x1aa)] =
                    "" + _0x2f9b78(_0x315948)),
                  (this[_0x19b03b(0x47e)]["x"] = 0x2d),
                  (this[_0x19b03b(0xd0)]["x"] = 0x38),
                  (this[_0x19b03b(0xfa)][_0x19b03b(0x197)] = ![]),
                  (this["_tick"][_0x19b03b(0x197)] = ![]),
                  (this["overlay"][_0x19b03b(0x197)] = !![]));
                break;
              case _0x19b03b(0x434):
                ((this[_0x19b03b(0xe5)] = 0x1),
                  (this[_0x19b03b(0x34e)]["visible"] = !![]),
                  (this[_0x19b03b(0x34e)][_0x19b03b(0x335)] =
                    PIXI[_0x19b03b(0x304)][_0x19b03b(0x299)][_0x19b03b(0x44d)]),
                  this[_0x19b03b(0x34e)]["registerState"](
                    "up",
                    PIXI[_0x19b03b(0x304)][_0x19b03b(0x299)][_0x19b03b(0x44d)],
                  ),
                  this[_0x19b03b(0x34e)][_0x19b03b(0x3d4)](
                    "down",
                    PIXI["utils"][_0x19b03b(0x299)][
                      "shop_button_upgrade_hover"
                    ],
                  ),
                  (this[_0x19b03b(0x47e)][_0x19b03b(0xe5)] = 0x1),
                  (this["_field"]["text"] = "" + _0x315948),
                  (this[_0x19b03b(0x47e)]["x"] = 0x2d),
                  (this[_0x19b03b(0xd0)]["x"] = 0x38));
                typeof _0x315948 === _0x19b03b(0x375)
                  ? (this["_fieldIcon"][_0x19b03b(0x197)] = !![])
                  : (this[_0x19b03b(0xd0)][_0x19b03b(0x197)] = ![]);
                ((this[_0x19b03b(0x47e)][_0x19b03b(0x1aa)] = _0x19b03b(0x32e)),
                  (this["_fieldIcon"][_0x19b03b(0x197)] = ![]),
                  (this[_0x19b03b(0x47e)]["x"] =
                    this["_field"][_0x19b03b(0xfd)] / 0x2),
                  (this["_fieldIcon"]["x"] = this["_field"]["x"] + 0xc),
                  (this["_frame"][_0x19b03b(0x197)] = ![]),
                  (this[_0x19b03b(0x27f)][_0x19b03b(0x197)] = ![]),
                  (this[_0x19b03b(0x3f1)]["visible"] = ![]));
                break;
              case _0x19b03b(0x16d):
                ((this[_0x19b03b(0xe5)] = 0x1),
                  (this[_0x19b03b(0x34e)][_0x19b03b(0x197)] = !![]),
                  (this[_0x19b03b(0x34e)][_0x19b03b(0x335)] =
                    PIXI[_0x19b03b(0x304)][_0x19b03b(0x299)][
                      "shop_button_upgrade_hover"
                    ]),
                  this[_0x19b03b(0x34e)][_0x19b03b(0x3d4)](
                    "up",
                    PIXI[_0x19b03b(0x304)][_0x19b03b(0x299)][
                      "shop_button_upgrade_hover"
                    ],
                  ),
                  this[_0x19b03b(0x34e)][_0x19b03b(0x3d4)](
                    _0x19b03b(0x444),
                    PIXI["utils"][_0x19b03b(0x299)][_0x19b03b(0x10d)],
                  ),
                  (this[_0x19b03b(0x47e)][_0x19b03b(0xe5)] = 0.5),
                  (this[_0x19b03b(0x47e)]["x"] = 0x2d),
                  (this["_fieldIcon"]["x"] = 0x38));
                typeof _0x315948 === _0x19b03b(0x375)
                  ? (this["_fieldIcon"][_0x19b03b(0x197)] = !![])
                  : (this["_fieldIcon"][_0x19b03b(0x197)] = ![]);
                ((this["_field"]["text"] = _0x19b03b(0x137)),
                  (this[_0x19b03b(0xd0)][_0x19b03b(0x197)] = ![]),
                  (this[_0x19b03b(0x47e)]["x"] =
                    this[_0x19b03b(0x47e)][_0x19b03b(0xfd)] / 0x2),
                  (this[_0x19b03b(0xd0)]["x"] =
                    this[_0x19b03b(0x47e)]["x"] + 0xc),
                  (this[_0x19b03b(0xfa)][_0x19b03b(0x197)] = !![]),
                  (this[_0x19b03b(0x27f)][_0x19b03b(0x197)] = !![]),
                  (this[_0x19b03b(0x3f1)]["visible"] = ![]));
                break;
            }
          }),
          (_0x5d3695[_0x2fc29c(0x333)][_0x2fc29c(0x12d)] = function (
            _0x35fceb,
          ) {
            var _0x328afe = _0x2fc29c;
            switch (this[_0x328afe(0xd6)]) {
              case _0x328afe(0x2c8):
                this[_0x328afe(0x34e)][_0x328afe(0x12d)](![]);
                break;
              case _0x328afe(0x3ef):
                this[_0x328afe(0x34e)][_0x328afe(0x12d)](_0x35fceb);
                break;
              case _0x328afe(0x400):
                this["_button"][_0x328afe(0x12d)](_0x35fceb);
                break;
              case _0x328afe(0x434):
                this[_0x328afe(0x34e)][_0x328afe(0x12d)](_0x35fceb);
                break;
              case _0x328afe(0x16d):
                this[_0x328afe(0x34e)]["setEnable"](_0x35fceb);
                break;
            }
          }),
          _0x5d3695
        );
      })(),
      _0x886cb6 = (function () {
        var _0x214425 = _0x157421;
        function _0x5a73c6() {
          var _0x144535 = _0x3797;
          PIXI[_0x144535(0x30a)]["call"](this);
          var _0x67013e = PIXI[_0x144535(0x385)][_0x144535(0x348)](
            _0x144535(0x474),
          );
          ((_0x67013e[_0x144535(0x4a1)]["x"] = 0.5),
            (_0x67013e["anchor"]["y"] = 0.5),
            (_0x67013e["x"] = 0x140),
            (_0x67013e["y"] = 0x471 / 0x2),
            this["addChild"](_0x67013e));
          var _0x1e671a = new PIXI[_0x144535(0x30a)]();
          ((_0x1e671a["x"] = 0x6b),
            (_0x1e671a["y"] = 0x1b8),
            this[_0x144535(0x3df)](_0x1e671a, 0x1),
            (this[_0x144535(0x4b4)] = _0x1e671a),
            (this[_0x144535(0x283)] = []));
          for (let _0x2bef2b = 0x0; _0x2bef2b < 0x9; _0x2bef2b++) {
            let _0x2e3310 = Math[_0x144535(0x1f8)](_0x2bef2b / 0x3),
              _0x3b10b7 = _0x2bef2b - _0x2e3310 * 0x3;
            var _0x2f7f02 = new _0x350929(_0x4537e2[_0x2bef2b]);
            ((_0x2f7f02["x"] = _0x3b10b7 * 0xcd),
              (_0x2f7f02["y"] = _0x2e3310 * 0x190),
              (_0x2f7f02["id"] = _0x2bef2b),
              _0x1e671a["addChild"](_0x2f7f02),
              _0x2f7f02["on"](
                _0x144535(0x20f),
                function (_0x21126f) {
                  var _0x18c874 = _0x144535;
                  this[_0x18c874(0xfe)]("select", _0x21126f);
                }[_0x144535(0x374)](this),
              ),
              _0x2f7f02["on"](
                "buy",
                function (_0x344bea) {
                  var _0x338578 = _0x144535;
                  this[_0x338578(0xfe)](_0x338578(0x2ba), _0x344bea);
                }[_0x144535(0x374)](this),
              ),
              this[_0x144535(0x283)]["push"](_0x2f7f02));
          }
          var _0x10e7e8 = new PIXI[_0x144535(0x30a)]();
          (_0x10e7e8,
            (visible = !![]),
            (_0x10e7e8["x"] = 0x6b + 0x276 + 0xa),
            (_0x10e7e8["y"] = 0x17c),
            (_0x10e7e8[_0x144535(0xe5)] = 0x0),
            this[_0x144535(0x3df)](_0x10e7e8, 0x1),
            (this["stonesContent"] = _0x10e7e8),
            (this[_0x144535(0x1a5)] = []));
          for (
            let _0x358e9e = 0x0;
            _0x358e9e < _0x4cd129["length"];
            _0x358e9e++
          ) {
            let _0x58e7bf = Math["floor"](_0x358e9e / 0x3),
              _0x476640 = _0x358e9e - _0x58e7bf * 0x3;
            var _0x2f7f02 = new _0x3a6671(_0x4cd129[_0x358e9e]);
            ((_0x2f7f02[_0x144535(0x197)] = !![]),
              (_0x2f7f02["x"] = 0x8 + _0x476640 * 0xcd),
              (_0x2f7f02["y"] = _0x58e7bf * 0xff),
              (_0x2f7f02["id"] = _0x358e9e),
              _0x10e7e8["addChild"](_0x2f7f02),
              _0x2f7f02["on"](
                _0x144535(0x20f),
                function (_0x5569ec) {
                  var _0x377178 = _0x144535;
                  this[_0x377178(0xfe)]("select_stone", _0x5569ec);
                }["bind"](this),
              ),
              _0x2f7f02["on"](
                "buy",
                function (_0x1b9394) {
                  var _0x2858c5 = _0x144535;
                  this[_0x2858c5(0xfe)](_0x2858c5(0x184), _0x1b9394);
                }[_0x144535(0x374)](this),
              ),
              this[_0x144535(0x1a5)]["push"](_0x2f7f02));
          }
          var _0x14707c =
            PIXI[_0x144535(0x385)]["fromFrame"]("shop_header_base");
          ((_0x14707c[_0x144535(0x4a1)]["x"] = 0.5),
            (_0x14707c["x"] = 0x140),
            (_0x14707c["y"] = -0xfd / 0x2 + 0x0),
            this[_0x144535(0x37b)](_0x14707c));
          var _0x53b76f = PIXI[_0x144535(0x385)]["fromFrame"](_0x144535(0xe4));
          (_0x53b76f[_0x144535(0x4a1)][_0x144535(0x27e)](0.5),
            (_0x53b76f["x"] = 0x69),
            (_0x53b76f["y"] = 0xaf),
            this[_0x144535(0x37b)](_0x53b76f),
            (this[_0x144535(0x254)] = _0x53b76f),
            (_0x53b76f[_0x144535(0x1bf)] = !![]),
            (_0x53b76f["buttonMode"] = !![]),
            _0x53b76f["on"](
              "pointertap",
              this[_0x144535(0x36f)][_0x144535(0x374)](this),
            ));
          var _0x4cda8d = PIXI["Sprite"][_0x144535(0x348)](_0x144535(0x2fa));
          (_0x4cda8d[_0x144535(0x4a1)]["set"](0.5),
            (_0x4cda8d["x"] = 0x217),
            (_0x4cda8d["y"] = 0xaf),
            this[_0x144535(0x37b)](_0x4cda8d),
            (this[_0x144535(0x4b9)] = _0x4cda8d),
            (_0x4cda8d[_0x144535(0x1bf)] = !![]),
            (_0x4cda8d[_0x144535(0x2e6)] = !![]),
            _0x4cda8d["on"](
              _0x144535(0x2a7),
              this[_0x144535(0x2eb)][_0x144535(0x374)](this),
            ));
          var _0x437cd3 = PIXI["Sprite"][_0x144535(0x348)](_0x144535(0x370));
          (_0x437cd3[_0x144535(0x4a1)][_0x144535(0x27e)](0.5),
            (_0x437cd3["x"] = 0x203),
            (_0x437cd3["y"] = 0x46),
            this[_0x144535(0x37b)](_0x437cd3));
          var _0x31400e = PIXI[_0x144535(0x385)][_0x144535(0x348)](
            _0x144535(0x485),
          );
          (_0x31400e[_0x144535(0x4a1)]["set"](0.5),
            (_0x31400e["x"] = 0x3c),
            (_0x31400e["y"] = 0x0),
            _0x437cd3[_0x144535(0x37b)](_0x31400e));
          var _0x29b62a = new PIXI[_0x144535(0x402)]("0", {
            font: _0x144535(0x2a2),
            fill: 0xffffff,
            align: _0x144535(0x218),
          });
          (_0x29b62a[_0x144535(0x4a1)][_0x144535(0x27e)](0.5),
            (_0x29b62a["x"] = -0x23),
            (_0x29b62a["y"] = 0x3),
            _0x437cd3[_0x144535(0x37b)](_0x29b62a),
            (this[_0x144535(0x387)] = _0x29b62a));
          var _0x250feb = new _0x32d81c(
            PIXI[_0x144535(0x304)]["TextureCache"][_0x144535(0x170)],
          );
          (_0x250feb[_0x144535(0x4a1)][_0x144535(0x27e)](0.5),
            (_0x250feb["x"] = 0x4b),
            (_0x250feb["y"] = 0x46),
            _0x250feb[_0x144535(0x3d4)](
              _0x144535(0x444),
              PIXI[_0x144535(0x304)][_0x144535(0x299)][_0x144535(0x44f)],
            ),
            this["addChild"](_0x250feb),
            _0x250feb["on"](
              _0x144535(0x2a7),
              function () {
                var _0x228ea2 = _0x144535;
                this["emit"](_0x228ea2(0x3d2));
              }[_0x144535(0x374)](this),
            ),
            (this["_btnBack"] = _0x250feb),
            (this["interactive"] = !![]),
            this["on"](
              "pointerdown",
              this[_0x144535(0x1ba)][_0x144535(0x374)](this),
            ),
            this["on"](
              _0x144535(0x39c),
              this[_0x144535(0x3b2)][_0x144535(0x374)](this),
            ),
            this["on"](
              _0x144535(0x109),
              this["pointerMoveHandler"][_0x144535(0x374)](this),
            ),
            (this[_0x144535(0xcf)] = ![]),
            (this["_pointer"] = 0x0),
            (this[_0x144535(0x3f3)] = 0x0),
            (this[_0x144535(0x417)] = 0x0));
        }
        return (
          (_0x5a73c6[_0x214425(0x333)] = Object[_0x214425(0x454)](
            PIXI[_0x214425(0x30a)][_0x214425(0x333)],
          )),
          (_0x5a73c6[_0x214425(0x333)][_0x214425(0x185)] = function (
            _0xdd35fd,
          ) {
            var _0x18a0c0 = _0x214425;
            ((this[_0x18a0c0(0x476)] = _0xdd35fd),
              (this[_0x18a0c0(0x387)][_0x18a0c0(0x1aa)] =
                "" + _0x2f9b78(_0xdd35fd)));
          }),
          (_0x5a73c6[_0x214425(0x333)][_0x214425(0xf6)] = function (_0x25ea52) {
            var _0x47ec74 = _0x214425;
            for (
              let _0x1f726b = 0x0;
              _0x1f726b < this[_0x47ec74(0x283)][_0x47ec74(0x182)];
              _0x1f726b++
            ) {
              let _0x30751d = _0x25ea52[_0x1f726b][_0x47ec74(0x43f)];
              this[_0x47ec74(0x283)][_0x1f726b][_0x47ec74(0x135)](
                _0x4537e2[_0x1f726b],
                _0x25ea52[_0x1f726b]["upgrade"],
                _0x30751d == _0x47ec74(0x2c8),
              );
              if (
                _0x30751d == _0x47ec74(0x2c8) &&
                _0x25ea52[_0x1f726b][_0x47ec74(0x4b7)] <= this[_0x47ec74(0x476)]
              )
                ((_0x30751d = _0x47ec74(0x3ef)),
                  this[_0x47ec74(0x283)][_0x1f726b][_0x47ec74(0x1b7)](
                    _0x30751d,
                    _0x25ea52[_0x1f726b][_0x47ec74(0x4b7)],
                    !![],
                  ));
              else
                _0x30751d == _0x47ec74(0x434) || _0x30751d == "equiped"
                  ? _0x25ea52[_0x1f726b][_0x47ec74(0x1ea)] <
                    _0x4537e2[_0x1f726b][_0x47ec74(0x1ea)]
                    ? this["_items"][_0x1f726b][_0x47ec74(0x1b7)](
                        _0x30751d,
                        _0x25ea52[_0x1f726b][_0x47ec74(0x2c1)],
                        _0x25ea52[_0x1f726b][_0x47ec74(0x2c1)] <=
                          this[_0x47ec74(0x476)],
                      )
                    : this["_items"][_0x1f726b]["setState"](
                        _0x30751d,
                        _0x47ec74(0x404),
                        ![],
                      )
                  : this[_0x47ec74(0x283)][_0x1f726b][_0x47ec74(0x1b7)](
                      _0x30751d,
                      _0x25ea52[_0x1f726b][_0x47ec74(0x4b7)],
                      !![],
                    );
            }
          }),
          (_0x5a73c6["prototype"][_0x214425(0x3f6)] = function (_0x19bf26) {
            var _0x1cfbcc = _0x214425;
            for (
              let _0x5526e6 = 0x0;
              _0x5526e6 < this["_stonesItems"]["length"];
              _0x5526e6++
            ) {
              let _0x4c79e3 = _0x19bf26[_0x5526e6][_0x1cfbcc(0x43f)];
              (_0x4c79e3 == "locked" &&
                _0x19bf26[_0x5526e6][_0x1cfbcc(0x4b7)] <= this["_coins"] &&
                (_0x4c79e3 = "available"),
                this[_0x1cfbcc(0x1a5)][_0x5526e6][_0x1cfbcc(0x1b7)](
                  _0x4c79e3,
                  _0x19bf26[_0x5526e6][_0x1cfbcc(0x4b7)],
                  !![],
                ));
            }
          }),
          (_0x5a73c6[_0x214425(0x333)][_0x214425(0x1ba)] = function (
            _0x58465d,
          ) {
            var _0xb76bc5 = _0x214425;
            if (this[_0xb76bc5(0xcf)]) return;
            ((this[_0xb76bc5(0xcf)] = !![]),
              (this[_0xb76bc5(0x1c7)] =
                _0x58465d["data"][_0xb76bc5(0x192)]["y"]));
          }),
          (_0x5a73c6[_0x214425(0x333)][_0x214425(0x3b2)] = function (
            _0x5dcda8,
          ) {
            var _0x181d6e = _0x214425;
            if (!this[_0x181d6e(0xcf)]) return;
            ((this[_0x181d6e(0xcf)] = ![]),
              this[_0x181d6e(0x3f3)] > 0x0 &&
                Tweener["addTween"](
                  this,
                  { _scrollSpeed: 0x0 },
                  {
                    time: 0x23,
                    transition: _0x181d6e(0x1f9),
                    onUpdate: function (_0x1ff3b8) {
                      var _0x2cbbdc = _0x181d6e;
                      _0x1ff3b8[_0x2cbbdc(0x313)]();
                    },
                  },
                ));
          }),
          (_0x5a73c6[_0x214425(0x333)][_0x214425(0x204)] = function (
            _0x2f8ee1,
          ) {
            var _0x169a5a = _0x214425;
            if (!this["_drag"]) return;
            let _0x43a2dd =
              _0x2f8ee1[_0x169a5a(0x3ca)][_0x169a5a(0x192)]["y"] -
              this[_0x169a5a(0x1c7)];
            ((this[_0x169a5a(0x3f3)] = _0x43a2dd),
              (this[_0x169a5a(0x1c7)] =
                _0x2f8ee1[_0x169a5a(0x3ca)]["global"]["y"]),
              this["scrollUpdate"]());
          }),
          (_0x5a73c6["prototype"][_0x214425(0x313)] = function () {
            var _0x3e64bb = _0x214425;
            if (!this[_0x3e64bb(0x417)]) {
              this[_0x3e64bb(0x4b4)]["y"] += this["_scrollSpeed"];
              if (this["content"]["y"] < 0x96)
                this[_0x3e64bb(0x4b4)]["y"] = 0x96;
              if (this[_0x3e64bb(0x4b4)]["y"] > 0x1b8)
                this[_0x3e64bb(0x4b4)]["y"] = 0x1b8;
            } else {
              this[_0x3e64bb(0x1a7)]["y"] += this["_scrollSpeed"];
              if (this[_0x3e64bb(0x1a7)]["y"] < 0x17c)
                this[_0x3e64bb(0x1a7)]["y"] = 0x17c;
              if (this["stonesContent"]["y"] > 0x17c)
                this["stonesContent"]["y"] = 0x17c;
            }
          }),
          (_0x5a73c6["prototype"][_0x214425(0x3b7)] = function (_0x1bfe74) {
            var _0x51f85b = _0x214425;
            if (this[_0x51f85b(0x19d)]) return;
            ((this[_0x51f85b(0x175)] = !![]),
              (this[_0x51f85b(0x18f)] =
                _0x1bfe74["data"][_0x51f85b(0x192)]["x"]));
          }),
          (_0x5a73c6["prototype"][_0x214425(0x1c4)] = function (_0x2d8923) {
            var _0x573361 = _0x214425;
            if (!this["_inSwipe"]) return;
            this[_0x573361(0x175)] = ![];
            var _0x4d22d3 =
              this[_0x573361(0x18f)] -
              _0x2d8923[_0x573361(0x3ca)][_0x573361(0x192)]["x"];
            if (_0x4d22d3 > 0x140 / 0x2)
              (this[_0x573361(0x2eb)](),
                (this[_0x573361(0x18f)] =
                  _0x2d8923[_0x573361(0x3ca)][_0x573361(0x192)]["x"]));
            else
              _0x4d22d3 < -0x140 / 0x2 &&
                (this[_0x573361(0x36f)](),
                (this[_0x573361(0x18f)] =
                  _0x2d8923[_0x573361(0x3ca)]["global"]["x"]));
          }),
          (_0x5a73c6[_0x214425(0x333)][_0x214425(0x36f)] = function () {
            var _0x3f9c89 = _0x214425;
            (_0x28fba8[_0x3f9c89(0x383)](_0x3f9c89(0x16e)),
              Tweener["extract"](this),
              (this[_0x3f9c89(0x3f3)] = 0x0),
              (this[_0x3f9c89(0x417)] = 0x0),
              (this[_0x3f9c89(0x254)]["texture"] =
                PIXI["utils"]["TextureCache"][_0x3f9c89(0xe4)]),
              (this[_0x3f9c89(0x4b9)][_0x3f9c89(0x335)] =
                PIXI[_0x3f9c89(0x304)][_0x3f9c89(0x299)][
                  "shop_tab_stones_hover"
                ]),
              Tweener["addTween"](
                this[_0x3f9c89(0x4b4)],
                { alpha: 0x1, x: 0x6b },
                { time: 0xf, transition: _0x3f9c89(0x1f9) },
              ),
              Tweener["addTween"](
                this[_0x3f9c89(0x1a7)],
                { alpha: 0x0, x: 0x6b + 0x276 },
                { time: 0xf, transition: _0x3f9c89(0x1f9) },
              ));
          }),
          (_0x5a73c6[_0x214425(0x333)]["swipeRight"] = function () {
            var _0x18770d = _0x214425;
            (_0x28fba8[_0x18770d(0x383)]("tap_wood5"),
              Tweener[_0x18770d(0x469)](this),
              (this[_0x18770d(0x3f3)] = 0x0),
              (this[_0x18770d(0x417)] = 0x1),
              (this["strikersHeader"]["texture"] =
                PIXI["utils"][_0x18770d(0x299)][_0x18770d(0x458)]),
              (this["stonesHeader"][_0x18770d(0x335)] =
                PIXI[_0x18770d(0x304)][_0x18770d(0x299)]["shop_tab_stones"]),
              Tweener[_0x18770d(0x3a0)](
                this[_0x18770d(0x4b4)],
                { alpha: 0x0, x: 0x6b - 0x276 },
                { time: 0xf, transition: "easeOutQuad" },
              ),
              Tweener[_0x18770d(0x3a0)](
                this[_0x18770d(0x1a7)],
                { alpha: 0x1, x: 0x6b },
                { time: 0xf, transition: _0x18770d(0x1f9) },
              ));
          }),
          (_0x5a73c6[_0x214425(0x333)][_0x214425(0x12d)] = function (_0xe157b) {
            var _0x8e25e3 = _0x214425;
            ((this[_0x8e25e3(0x2d0)][_0x8e25e3(0x1bf)] = _0xe157b),
              (this[_0x8e25e3(0x3d6)][_0x8e25e3(0x1bf)] = _0xe157b),
              (this[_0x8e25e3(0x45d)]["interactive"] = _0xe157b));
            for (
              let _0x3dd341 = 0x0;
              _0x3dd341 < this[_0x8e25e3(0x283)][_0x8e25e3(0x182)];
              _0x3dd341++
            ) {
              let _0x1908b9 = this[_0x8e25e3(0x283)][_0x3dd341];
              _0x1908b9[_0x8e25e3(0x12d)](_0xe157b);
            }
            for (
              let _0x2f6e8c = 0x0;
              _0x2f6e8c < this[_0x8e25e3(0x297)]["length"];
              _0x2f6e8c++
            ) {
              let _0x5986d8 = this[_0x8e25e3(0x297)][_0x2f6e8c];
              _0x5986d8[_0x8e25e3(0x12d)](_0xe157b);
            }
          }),
          _0x5a73c6
        );
      })(),
      _0x4c2b9c = (function () {
        var _0x22d9c6 = _0x157421;
        function _0x4c19df() {
          var _0xb3cba2 = _0x3797;
          PIXI[_0xb3cba2(0x30a)][_0xb3cba2(0x37a)](this);
          var _0x176c53 = PIXI[_0xb3cba2(0x385)][_0xb3cba2(0x348)](
            _0xb3cba2(0x474),
          );
          (_0x176c53[_0xb3cba2(0x4a1)][_0xb3cba2(0x27e)](0.5),
            (_0x176c53["x"] = 0x140),
            (_0x176c53["y"] = _0x27ae22 / 0x2),
            this[_0xb3cba2(0x37b)](_0x176c53));
          var _0x2a8e38 =
            PIXI[_0xb3cba2(0x385)][_0xb3cba2(0x348)]("shop_header_base");
          ((_0x2a8e38[_0xb3cba2(0x4a1)]["x"] = 0.5),
            (_0x2a8e38["x"] = 0x140),
            (_0x2a8e38["y"] = -0xfd / 0x2 + 0x0),
            this[_0xb3cba2(0x37b)](_0x2a8e38));
        }
        return (
          (_0x4c19df[_0x22d9c6(0x333)] = Object["create"](
            PIXI[_0x22d9c6(0x30a)][_0x22d9c6(0x333)],
          )),
          (_0x4c19df["prototype"][_0x22d9c6(0x185)] = function (_0x12365b) {
            var _0x9dfc49 = _0x22d9c6;
            ((this["_coins"] = _0x12365b),
              (this[_0x9dfc49(0x387)][_0x9dfc49(0x1aa)] =
                "" + _0x2f9b78(_0x12365b)));
          }),
          (_0x4c19df[_0x22d9c6(0x333)][_0x22d9c6(0xf6)] = function (_0x2687e9) {
            var _0x48a387 = _0x22d9c6;
            for (
              let _0xd3caa9 = 0x0;
              _0xd3caa9 < this["_items"][_0x48a387(0x182)];
              _0xd3caa9++
            ) {
              let _0x4ce1cd = _0x2687e9[_0xd3caa9][_0x48a387(0x43f)];
              if (
                _0x4ce1cd == _0x48a387(0x2c8) &&
                _0x2687e9[_0xd3caa9][_0x48a387(0x4b7)] <= this["_coins"]
              )
                _0x4ce1cd = _0x48a387(0x3ef);
              this[_0x48a387(0x283)][_0xd3caa9][_0x48a387(0x1b7)](
                _0x4ce1cd,
                _0x2687e9[_0xd3caa9][_0x48a387(0x4b7)],
              );
            }
          }),
          (_0x4c19df[_0x22d9c6(0x333)][_0x22d9c6(0x1ba)] = function (
            _0x574ba8,
          ) {
            var _0x1994a8 = _0x22d9c6;
            if (this[_0x1994a8(0xcf)]) return;
            ((this[_0x1994a8(0xcf)] = !![]),
              (this["_pointer"] =
                _0x574ba8[_0x1994a8(0x3ca)][_0x1994a8(0x192)]["y"]));
          }),
          (_0x4c19df[_0x22d9c6(0x333)][_0x22d9c6(0x3b2)] = function (
            _0x467d46,
          ) {
            var _0xd10c73 = _0x22d9c6;
            if (!this[_0xd10c73(0xcf)]) return;
            ((this["_drag"] = ![]),
              this[_0xd10c73(0x3f3)] > 0x0 &&
                Tweener[_0xd10c73(0x3a0)](
                  this,
                  { _scrollSpeed: 0x0 },
                  {
                    time: 0x23,
                    transition: "easeOutQuad",
                    onUpdate: function (_0x5d96cf) {
                      var _0xda051 = _0xd10c73;
                      _0x5d96cf[_0xda051(0x313)]();
                    },
                  },
                ));
          }),
          (_0x4c19df[_0x22d9c6(0x333)]["pointerMoveHandler"] = function (
            _0x17e8e3,
          ) {
            var _0x204f36 = _0x22d9c6;
            if (!this["_drag"]) return;
            let _0x15e84d =
              _0x17e8e3[_0x204f36(0x3ca)][_0x204f36(0x192)]["y"] -
              this[_0x204f36(0x1c7)];
            ((this["_scrollSpeed"] = _0x15e84d),
              (this[_0x204f36(0x1c7)] = _0x17e8e3["data"]["global"]["y"]),
              this[_0x204f36(0x313)]());
          }),
          (_0x4c19df[_0x22d9c6(0x333)][_0x22d9c6(0x313)] = function () {
            var _0x27cd5e = _0x22d9c6;
            this[_0x27cd5e(0x4b4)]["y"] += this[_0x27cd5e(0x3f3)];
            if (this[_0x27cd5e(0x4b4)]["y"] < 0x96 - 0x113)
              this[_0x27cd5e(0x4b4)]["y"] = 0x96 - 0x113;
            if (this[_0x27cd5e(0x4b4)]["y"] > 0x1b8)
              this["content"]["y"] = 0x1b8;
          }),
          (_0x4c19df[_0x22d9c6(0x333)][_0x22d9c6(0x12d)] = function (
            _0x33b893,
          ) {
            var _0x423e16 = _0x22d9c6;
            this[_0x423e16(0x46e)][_0x423e16(0x12d)](_0x33b893);
          }),
          Object["defineProperties"](_0x4c19df[_0x22d9c6(0x333)], {
            chainSum: {
              set: function (_0x5f484e) {
                var _0x116a07 = _0x22d9c6;
                ((this[_0x116a07(0x1af)] = _0x5f484e),
                  (this["valueField"][_0x116a07(0x1aa)] =
                    this["_value"] + "/" + this["_chainSum"]));
              },
              get: function () {
                var _0x378c93 = _0x22d9c6;
                return this[_0x378c93(0x1af)];
              },
            },
            value: {
              set: function (_0x5cc6cb) {
                var _0x1f97aa = _0x22d9c6;
                ((this[_0x1f97aa(0x3e2)] = _0x5cc6cb),
                  (this["valueField"][_0x1f97aa(0x1aa)] = this["_value"]));
                if (this[_0x1f97aa(0x3e2)] > 0x0)
                  this[_0x1f97aa(0x387)][_0x1f97aa(0x197)] = !![];
                else this["valueField"][_0x1f97aa(0x197)] = ![];
              },
              get: function () {
                var _0x3f08d2 = _0x22d9c6;
                return this[_0x3f08d2(0x3e2)];
              },
            },
          }),
          _0x4c19df
        );
      })(),
      _0x5e1e47 = (function () {
        var _0x1c5a4a = _0x157421;
        function _0x26cb35(_0xd9e257) {
          var _0x2a7784 = _0x3797;
          (PIXI["Container"][_0x2a7784(0x37a)](this), (this["_items"] = []));
          for (let _0x28f427 = 0x0; _0x28f427 < 0x3; _0x28f427++) {
            let _0x1b9c98 = PIXI["Sprite"][_0x2a7784(0x348)](_0x2a7784(0x2cc));
            (_0x1b9c98[_0x2a7784(0x4a1)][_0x2a7784(0x27e)](0.5),
              (_0x1b9c98["x"] = 0x0),
              (_0x1b9c98["y"] = _0x28f427 * 0xa0),
              this["addChild"](_0x1b9c98),
              this[_0x2a7784(0x283)][_0x2a7784(0x3b0)](_0x1b9c98));
          }
          ((this["_speed"] = 0x14),
            (this[_0x2a7784(0x3a5)] = 0x0),
            (this[_0x2a7784(0x2e9)] = null));
        }
        return (
          (_0x26cb35["prototype"] = Object[_0x1c5a4a(0x454)](
            PIXI["Container"][_0x1c5a4a(0x333)],
          )),
          (_0x26cb35["prototype"][_0x1c5a4a(0x3c8)] = function () {
            var _0x25290c = _0x1c5a4a;
            let _0x173c0b = this[_0x25290c(0x3a5)] / 0xa0;
            for (
              let _0x2078ec = 0x0;
              _0x2078ec < this["_items"][_0x25290c(0x182)];
              _0x2078ec++
            ) {
              let _0x41adab = this[_0x25290c(0x283)][_0x2078ec];
              _0x41adab["y"] = _0x2078ec * 0xa0 - 0xa0 * _0x173c0b;
            }
          }),
          (_0x26cb35[_0x1c5a4a(0x333)]["roll"] = function () {
            var _0x3a8628 = _0x1c5a4a;
            (this["showAll"](),
              Tweener[_0x3a8628(0x3a0)](
                this,
                { _dist: 0xa0 },
                {
                  time: 0x8,
                  transition: _0x3a8628(0x1a6),
                  loop: -0x1,
                  onUpdate: function (_0x26a3d8) {
                    this["update"]();
                  }[_0x3a8628(0x374)](this),
                },
              ));
          }),
          (_0x26cb35[_0x1c5a4a(0x333)]["stop"] = function () {
            var _0xc56ac9 = _0x1c5a4a;
            Tweener[_0xc56ac9(0x3a0)](
              this,
              { _dist: 0xa0 },
              {
                time: 0x28,
                transition: _0xc56ac9(0x426),
                onUpdate: function (_0x5c90ac) {
                  this["update"]();
                }[_0xc56ac9(0x374)](this),
                onComplete: function () {
                  var _0x34119a = _0xc56ac9;
                  (this["emit"](_0x34119a(0x421)), this["hideRest"]());
                }["bind"](this),
              },
            );
          }),
          (_0x26cb35[_0x1c5a4a(0x333)]["showAll"] = function () {
            var _0x5b5820 = _0x1c5a4a;
            for (
              let _0x2ba576 = 0x0;
              _0x2ba576 < this["_items"][_0x5b5820(0x182)];
              _0x2ba576++
            ) {
              let _0x3d19d7 = this[_0x5b5820(0x283)][_0x2ba576];
              ((_0x3d19d7[_0x5b5820(0x197)] = !![]),
                (_0x3d19d7[_0x5b5820(0xe5)] = 0x1));
            }
          }),
          (_0x26cb35[_0x1c5a4a(0x333)][_0x1c5a4a(0x124)] = function () {
            var _0x130335 = _0x1c5a4a;
            for (
              let _0x116149 = 0x0;
              _0x116149 < this[_0x130335(0x283)][_0x130335(0x182)];
              _0x116149++
            ) {
              let _0x1b4f00 = this[_0x130335(0x283)][_0x116149];
              if (_0x116149 == 0x1) continue;
              Tweener["addTween"](
                _0x1b4f00,
                { alpha: 0x0 },
                { time: 0x14, transition: _0x130335(0x1f9) },
              );
            }
          }),
          Object[_0x1c5a4a(0x211)](_0x26cb35[_0x1c5a4a(0x333)], {
            value: {
              set: function (_0x49fb97) {
                var _0x297b1c = _0x1c5a4a;
                this[_0x297b1c(0x3e2)] = _0x49fb97;
              },
              get: function () {
                var _0xdb1f2f = _0x1c5a4a;
                return this[_0xdb1f2f(0x3e2)];
              },
            },
          }),
          _0x26cb35
        );
      })(),
      _0x104b9b = (function () {
        var _0xc00196 = _0x157421;
        function _0x3875cf(_0x4190b8, _0x1318a1, _0x2d7717, _0x27d57f) {
          var _0x552ab7 = _0x3797;
          PIXI["Container"][_0x552ab7(0x37a)](this);
          var _0x42d19f = this,
            _0x50891a = PIXI["Sprite"][_0x552ab7(0x348)](_0x552ab7(0x409));
          (_0x50891a[_0x552ab7(0x4a1)][_0x552ab7(0x27e)](0.5),
            (_0x50891a["x"] = 0x140),
            (_0x50891a["y"] = _0x27ae22 / 0x2),
            this[_0x552ab7(0x37b)](_0x50891a),
            (this["bg"] = _0x50891a));
          var _0x19644d = PIXI[_0x552ab7(0x385)][_0x552ab7(0x348)](
            _0x552ab7(0x3cd),
          );
          (_0x19644d["anchor"][_0x552ab7(0x27e)](0.5),
            (_0x19644d["x"] = 0xc3),
            (_0x19644d["y"] = 0x2d0 - 0x50),
            this[_0x552ab7(0x37b)](_0x19644d),
            (this[_0x552ab7(0x379)] = _0x19644d));
          var _0x35ef92 = PIXI[_0x552ab7(0x385)]["fromFrame"](_0x552ab7(0x2ac));
          (_0x35ef92[_0x552ab7(0x4a1)][_0x552ab7(0x27e)](0.5),
            (_0x35ef92["x"] = 0xc3),
            (_0x35ef92["y"] = 0x35c - 0x50),
            this["addChild"](_0x35ef92),
            (this[_0x552ab7(0x146)] = _0x35ef92));
          var _0x1abcf8 = PIXI[_0x552ab7(0x385)][_0x552ab7(0x348)](
            _0x552ab7(0x28b),
          );
          (_0x1abcf8[_0x552ab7(0x4a1)][_0x552ab7(0x27e)](0.5),
            _0x1abcf8[_0x552ab7(0x231)]["set"](1.4),
            (_0x1abcf8["x"] = 0x7d),
            (_0x1abcf8["y"] = 0x307 - 0x50),
            this[_0x552ab7(0x37b)](_0x1abcf8),
            (this[_0x552ab7(0x21b)] = _0x1abcf8));
          if (_0x1318a1 >= 0x0) {
            var _0x2463b0 = PIXI["Sprite"][_0x552ab7(0x348)](
              _0x4cd129[_0x1318a1][_0x552ab7(0xf3)],
            );
            (_0x2463b0[_0x552ab7(0x4a1)][_0x552ab7(0x27e)](0.5),
              _0x2463b0[_0x552ab7(0x231)]["set"](0.32),
              _0x1abcf8[_0x552ab7(0x37b)](_0x2463b0));
          }
          var _0x1a3dd3 = new _0x5e1e47();
          ((_0x1a3dd3["x"] = 0x18e + 0x32),
            (_0x1a3dd3["y"] = 0x2d0 - 0x50),
            this["addChild"](_0x1a3dd3),
            _0x1a3dd3["on"]("stop", function () {
              var _0x4010cb = _0x552ab7;
              (_0x28fba8[_0x4010cb(0x383)](_0x4010cb(0x172), 0.5),
                Tweener[_0x4010cb(0x3a0)](
                  _0x1abcf8,
                  { x: 0x6e, y: 0x307 - 0x50 },
                  { time: 0xf, transition: _0x4010cb(0x1f9) },
                ),
                Tweener[_0x4010cb(0x3a0)](
                  _0x19644d,
                  { scaleX: 1.3, scaleY: 1.3, x: 0xbe, y: 0x2b2 - 0x50 },
                  { time: 0xf, transition: _0x4010cb(0x1f9) },
                ),
                Tweener[_0x4010cb(0x3a0)](
                  _0x1a3dd3,
                  { scaleX: 1.3, scaleY: 1.3, x: 0x1ae, y: 0x2b2 - 0x50 },
                  { time: 0xf, transition: _0x4010cb(0x1f9) },
                ));
              let _0x2ad8a2 = _0x27d57f ? 0x3c : 0x0;
              if (_0x27d57f) _0x42d19f[_0x4010cb(0x481)]();
              (Tweener[_0x4010cb(0x3a0)](
                _0x42d19f["rewardPotIcon"],
                { scaleX: 1.2, scaleY: 1.2 },
                { time: 0xa, transition: _0x4010cb(0x1f9) },
              ),
                Tweener[_0x4010cb(0x3a0)](
                  _0x42d19f[_0x4010cb(0x398)],
                  { scaleX: 0x1, scaleY: 0x1 },
                  { time: 0xa, transition: _0x4010cb(0x1f9) },
                ),
                Tweener[_0x4010cb(0x3a0)](
                  { value: _0x2d7717 - _0x27d57f * 0x2 },
                  { value: _0x2d7717 },
                  {
                    time: 0x32,
                    delay: _0x2ad8a2 + 0x5,
                    transition: _0x4010cb(0x1f9),
                    onUpdate: function (_0x30cd72) {
                      var _0x5e7dc0 = _0x4010cb;
                      _0xcc826c[_0x5e7dc0(0x1aa)] =
                        Math[_0x5e7dc0(0x167)](_0x30cd72[_0x5e7dc0(0x4b7)]) +
                        "";
                    },
                  },
                ),
                _0x27d57f
                  ? ((_0x3fe5cf["x"] = _0x42d19f[_0x4010cb(0x3e6)]["x"] + 0x5a),
                    (_0x3fe5cf["y"] = _0x42d19f[_0x4010cb(0x3e6)]["y"] - 0x1e),
                    (_0x3fe5cf[_0x4010cb(0xe5)] = 0x0),
                    Tweener[_0x4010cb(0x3a0)](
                      _0x3fe5cf,
                      {
                        alpha: [
                          0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                          0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                          0x0, 0.2, 0.4, 0.6, 0.8, 0x1, 0x1, 0.8, 0.6, 0.4, 0.2,
                          0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                          0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                        ],
                        scaleX: [
                          0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                          0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                          0x0, 0.2, 0.4, 0.6, 0.8, 0x1, 0x1, 0.8, 0.6, 0.4, 0.2,
                          0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                          0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                        ],
                        scaleY: [
                          0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                          0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                          0x0, 0.2, 0.4, 0.6, 0.8, 0x1, 0x1, 0.8, 0.6, 0.4, 0.2,
                          0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                          0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
                        ],
                      },
                      { time: 0xe1, delay: _0x2ad8a2 / 0x2 },
                    ),
                    _carromMatchSchedule(_0x42d19f, function () {
                      var _0x3d2dbf = _0x4010cb;
                      _0x42d19f[_0x3d2dbf(0xfe)]("ready");
                    }, 0xbea))
                  : _carromMatchSchedule(_0x42d19f, function () {
                      var _0x478804 = _0x4010cb;
                      _0x42d19f[_0x478804(0xfe)]("ready");
                    }, 0x3e8));
            }),
            (this[_0x552ab7(0x130)] = _0x1a3dd3));
          var _0xc344c0 = PIXI[_0x552ab7(0x385)][_0x552ab7(0x348)](
            _0x552ab7(0x155),
          );
          (_0xc344c0[_0x552ab7(0x4a1)][_0x552ab7(0x27e)](0.5),
            _0xc344c0[_0x552ab7(0x231)][_0x552ab7(0x27e)](1.4),
            (_0xc344c0["x"] = 0x152 + 0x32),
            (_0xc344c0["y"] = 0x307 - 0x50));
          (this["addChild"](_0xc344c0), (this["oponnentPuck"] = _0xc344c0));
          var _0x38421b = PIXI[_0x552ab7(0x385)][_0x552ab7(0x348)](
            _0x552ab7(0x32a),
          );
          (_0x38421b[_0x552ab7(0x4a1)][_0x552ab7(0x27e)](0.5),
            (_0x38421b["x"] = 0x140),
            (_0x38421b["y"] = _0x27ae22 / 0x2),
            this[_0x552ab7(0x37b)](_0x38421b),
            (this[_0x552ab7(0x118)] = _0x38421b));
          var _0x4d5400 = PIXI[_0x552ab7(0x385)][_0x552ab7(0x348)](
            _0x552ab7(0x3ed),
          );
          (_0x4d5400[_0x552ab7(0x4a1)][_0x552ab7(0x27e)](0.5),
            (_0x4d5400["x"] = 0x18e + 0x32),
            (_0x4d5400["y"] = 0x35c - 0x50));
          (this[_0x552ab7(0x37b)](_0x4d5400),
            (this[_0x552ab7(0x23e)] = _0x4d5400));
          var _0x53bf46 = PIXI[_0x552ab7(0x385)][_0x552ab7(0x348)](
            _0x552ab7(0x46f),
          );
          (_0x53bf46[_0x552ab7(0x4a1)]["set"](0.5),
            _0x53bf46["scale"][_0x552ab7(0x27e)](0.7),
            (_0x53bf46["x"] = 0x140),
            (_0x53bf46["y"] = 0x127),
            this[_0x552ab7(0x37b)](_0x53bf46),
            (this[_0x552ab7(0x1ee)] = _0x53bf46),
            this[_0x552ab7(0x3ad)](_0x4190b8),
            this[_0x552ab7(0x1fe)]());
          var _0x41f64e = PIXI[_0x552ab7(0x385)]["fromFrame"](_0x552ab7(0x17f));
          (_0x41f64e[_0x552ab7(0x4a1)][_0x552ab7(0x27e)](0.5),
            (_0x41f64e["anchor"]["x"] = 0x0),
            _0x41f64e[_0x552ab7(0x231)][_0x552ab7(0x27e)](1.2),
            (_0x41f64e["x"] = 0x140),
            (_0x41f64e["y"] = 0x3ac),
            this[_0x552ab7(0x37b)](_0x41f64e),
            (this[_0x552ab7(0x3e6)] = _0x41f64e));
          var _0xcc826c = new PIXI[_0x552ab7(0x402)]("", {
            font: _0x552ab7(0x236),
            fill: 0xffffff,
            align: _0x552ab7(0x221),
          });
          (_0xcc826c["anchor"][_0x552ab7(0x27e)](0.5),
            (_0xcc826c[_0x552ab7(0x4a1)]["x"] = 0x0),
            (_0xcc826c["x"] = 0x140),
            (_0xcc826c["y"] = 0x3ac),
            this["addChild"](_0xcc826c),
            (this[_0x552ab7(0x398)] = _0xcc826c),
            (_0xcc826c[_0x552ab7(0x1aa)] = _0x2d7717 + ""),
            (_0x41f64e["x"] =
              0x140 -
              (_0x41f64e["width"] + _0xcc826c[_0x552ab7(0xfd)] + 0xa) / 0x2),
            (_0xcc826c["x"] =
              _0x41f64e["x"] + _0x41f64e[_0x552ab7(0xfd)] + 0xa),
            (_0xcc826c[_0x552ab7(0x1aa)] = _0x2d7717 - _0x27d57f * 0x2 + ""),
            _0x41f64e[_0x552ab7(0x231)][_0x552ab7(0x27e)](0x0),
            _0xcc826c[_0x552ab7(0x231)][_0x552ab7(0x27e)](0x0));
          var _0x3fe5cf = PIXI[_0x552ab7(0x385)]["fromFrame"](_0x552ab7(0x195));
          (_0x3fe5cf[_0x552ab7(0x4a1)]["set"](0.5),
            (_0x3fe5cf[_0x552ab7(0x1ec)] = 0.1),
            this["addChild"](_0x3fe5cf));
        }
        return (
          (_0x3875cf[_0xc00196(0x333)] = Object[_0xc00196(0x454)](
            PIXI["Container"]["prototype"],
          )),
          (_0x3875cf[_0xc00196(0x333)][_0xc00196(0x497)] = function (
            _0x4d9520,
          ) {
            var _0x520f68 = _0xc00196,
              _0xaebe94 = this;
            (Tweener[_0x520f68(0x3a0)](
              this[_0x520f68(0x398)],
              { scaleX: 0x0, scaleY: 0x0 },
              { time: 0xa, transition: _0x520f68(0x30c) },
            ),
              Tweener[_0x520f68(0x3a0)](
                this[_0x520f68(0x3e6)],
                { scaleX: 0x0, scaleY: 0x0 },
                { time: 0xa, transition: _0x520f68(0x30c) },
              ));
            var _0x18749d = PIXI[_0x520f68(0x385)][_0x520f68(0x348)](
              _0x520f68(0x39f),
            );
            (_0x18749d[_0x520f68(0x4a1)][_0x520f68(0x27e)](0.5),
              (_0x18749d["x"] = 0x140),
              (_0x18749d["y"] = 0x3a2),
              this[_0x520f68(0x37b)](_0x18749d),
              _0x18749d[_0x520f68(0x231)][_0x520f68(0x27e)](0x0),
              Tweener[_0x520f68(0x3a0)](
                _0x18749d,
                { scaleX: 0x1, scaleY: 0x1 },
                {
                  time: 0xf,
                  delay: 0x5,
                  onComplete: function () {
                    var _0x103a4 = _0x520f68,
                      _0x4b9493 =
                        PIXI[_0x103a4(0x385)][_0x103a4(0x348)](
                          "starting_arrow",
                        );
                    (_0x4b9493[_0x103a4(0x4a1)][_0x103a4(0x27e)](0.5),
                      (_0x4b9493["x"] = 0x1a4),
                      (_0x4b9493["y"] = 0x361),
                      _0xaebe94[_0x103a4(0x3df)](_0x4b9493, 0xa),
                      Tweener[_0x103a4(0x3a0)](
                        _0x4b9493,
                        {
                          x: [
                            0x1a4,
                            0x140 + 0x5a,
                            0x140 + 0x4b,
                            0x140 + 0x32,
                            0x140,
                            0x140 - 0x32,
                            0x140 - 0x4b,
                            0x140 - 0x5a,
                            0xdc,
                            0x140 - 0x5a,
                            0x140 - 0x4b,
                            0x140 - 0x32,
                            0x140,
                            0x172,
                            0x18b,
                            0x19a,
                          ],
                        },
                        {
                          time: 0x28,
                          transition: _0x103a4(0x1a6),
                          loop: 0x3,
                          onComplete: function (_0x50de42, _0x3bb925) {
                            var _0x48170e = _0x103a4;
                            if (_0x3bb925 > 0x0) return;
                            _0x4d9520
                              ? Tweener[_0x48170e(0x3a0)](
                                  _0x4b9493,
                                  { x: 0x1ae },
                                  {
                                    time: 0x1e,
                                    transition: _0x48170e(0x1f9),
                                    onComplete: function () {
                                      var _0x22dbd8 = _0x48170e;
                                      _0xaebe94[_0x22dbd8(0xfe)](
                                        _0x22dbd8(0x431),
                                      );
                                    },
                                  },
                                )
                              : Tweener["addTween"](
                                  _0x4b9493,
                                  { x: 0xd2 },
                                  {
                                    time: 0x1e,
                                    transition: _0x48170e(0x1f9),
                                    onComplete: function () {
                                      var _0x37cb92 = _0x48170e;
                                      _0xaebe94[_0x37cb92(0xfe)](
                                        _0x37cb92(0x431),
                                      );
                                    },
                                  },
                                );
                          },
                        },
                      ));
                  },
                },
              ));
          }),
          (_0x3875cf[_0xc00196(0x333)][_0xc00196(0x481)] = function () {
            var _0x5c86fd = _0xc00196,
              _0x1af678 = this;
            for (let _0x2a7985 = 0x5; _0x2a7985 < 0xf; _0x2a7985++) {
              var _0x4c745a = new ParticleManager[_0x5c86fd(0x16c)](
                PIXI["utils"][_0x5c86fd(0x299)]["single_coin"],
              );
              ((_0x4c745a["x"] = this[_0x5c86fd(0x379)]["x"] - 0x14),
                (_0x4c745a["y"] = this[_0x5c86fd(0x379)]["y"]),
                (_0x4c745a[_0x5c86fd(0x197)] = ![]));
              let _0x4d1f94 = 0xa + Math[_0x5c86fd(0xec)]() * 0x5,
                _0x4960de = -Math["PI"] / 0x2 + 0.3,
                _0x414604 = Math["PI"];
              (_0x2a7985 % 0x2 == 0x0 &&
                ((_0x4c745a["x"] = this["oponnentAvatar"]["x"] + 0x14),
                (_0x4c745a["y"] = this[_0x5c86fd(0x130)]["y"]),
                (_0x4960de = -Math["PI"] / 0x2 - 0.3),
                (_0x4d1f94 += 0x5),
                (_0x414604 = -Math["PI"]),
                (_0x4c745a[_0x5c86fd(0x3c2)] = !![])),
                (_0x4c745a[_0x5c86fd(0xde)] = {
                  x: Math[_0x5c86fd(0x430)](_0x4960de) * _0x4d1f94,
                  y: Math[_0x5c86fd(0x1c8)](_0x4960de) * _0x4d1f94,
                }),
                (_0x4c745a[_0x5c86fd(0x4b0)] = 0x64),
                (_0x4c745a[_0x5c86fd(0x1a8)] = _0x2a7985 * 0x5),
                this[_0x5c86fd(0x3df)](_0x4c745a, 0x9),
                ParticleManager[_0x5c86fd(0xfe)](_0x4c745a),
                Tweener[_0x5c86fd(0x3a0)](
                  _0x4c745a[_0x5c86fd(0x12f)],
                  { x: 0x0, y: 0x32 },
                  {
                    time: 0x28,
                    delay: _0x2a7985 * 0x5,
                    transition: _0x5c86fd(0x25d),
                    onStart: function (_0x4f2a5c) {
                      var _0x39a9ca = _0x5c86fd;
                      if (!_0x4f2a5c["sound"])
                        _0x28fba8[_0x39a9ca(0x383)](_0x39a9ca(0x49c));
                    },
                  },
                ),
                Tweener[_0x5c86fd(0x3a0)](
                  _0x4c745a,
                  { rotation: _0x414604 },
                  {
                    time: 0x28,
                    delay: _0x2a7985 * 0x5,
                    onComplete: function (_0x571c6e) {
                      var _0x46e364 = _0x5c86fd;
                      ((_0x571c6e["visible"] = ![]),
                        _0x1af678[_0x46e364(0x3e6)]["scale"]["set"](1.2),
                        Tweener[_0x46e364(0x3a0)](
                          _0x1af678["rewardPotIcon"],
                          { scaleX: 1.3, scaleY: 1.3 },
                          { time: 0xa, transition: _0x46e364(0x205) },
                        ));
                      if (_0x571c6e[_0x46e364(0x3c2)])
                        _0x28fba8[_0x46e364(0x383)](_0x46e364(0x450));
                    },
                  },
                ));
            }
          }),
          (_0x3875cf[_0xc00196(0x333)][_0xc00196(0x3c8)] = function () {}),
          (_0x3875cf["prototype"]["loadTable"] = function (_0x52077e) {
            var _0x148a75 = _0xc00196;
            ((this["bg"][_0x148a75(0x335)] =
              PIXI[_0x148a75(0x304)]["TextureCache"][_0x52077e["bg"]]),
              (this[_0x148a75(0x1ee)][_0x148a75(0x335)] =
                PIXI["utils"][_0x148a75(0x299)][_0x52077e[_0x148a75(0x1ee)]]),
              (this[_0x148a75(0x118)][_0x148a75(0x335)] =
                PIXI["utils"]["TextureCache"][_0x52077e[_0x148a75(0x118)]]));
          }),
          (_0x3875cf[_0xc00196(0x333)]["startRoll"] = function () {
            var _0x1eb22a = _0xc00196;
            _carromCancelMatchTimers(this);
            (this[_0x1eb22a(0x379)][_0x1eb22a(0x231)][_0x1eb22a(0x27e)](0x1),
              (this[_0x1eb22a(0x379)]["x"] = 0xc3),
              (this[_0x1eb22a(0x379)]["y"] = 0x2d0 - 0x50),
              (this[_0x1eb22a(0x146)]["x"] = 0xc3),
              (this[_0x1eb22a(0x146)]["y"] = 0x35c - 0x50),
              (this[_0x1eb22a(0x21b)]["x"] = 0x7d),
              (this[_0x1eb22a(0x21b)]["y"] = 0x307 - 0x50),
              this[_0x1eb22a(0x130)][_0x1eb22a(0x231)][_0x1eb22a(0x27e)](0x1),
              (this["oponnentAvatar"]["x"] = 0x18e + 0x1e),
              (this["oponnentAvatar"]["y"] = 0x2d0 - 0x50),
              (this["oponnentNameLabel"]["x"] = 0x18e + 0x1e),
              (this[_0x1eb22a(0x23e)]["y"] = 0x35c - 0x50),
              (this[_0x1eb22a(0x26c)]["x"] = 0x152 + 0x1e),
              (this[_0x1eb22a(0x26c)]["y"] = 0x307 - 0x50),
              this[_0x1eb22a(0x130)][_0x1eb22a(0x1cf)](),
              _carromMatchSchedule(this,
                function () {
                  var _0x50ac82 = _0x1eb22a;
                  this[_0x50ac82(0x130)][_0x50ac82(0x421)]();
                }[_0x1eb22a(0x374)](this),
                0xbb8,
              ));
          }),
          (_0x3875cf[_0xc00196(0x333)][_0xc00196(0x12d)] = function (
            _0x316211,
          ) {}),
          Object[_0xc00196(0x211)](_0x3875cf[_0xc00196(0x333)], {
            value: {
              set: function (_0x2c4809) {
                var _0x568495 = _0xc00196;
                this[_0x568495(0x3e2)] = _0x2c4809;
              },
              get: function () {
                var _0x475c28 = _0xc00196;
                return this[_0x475c28(0x3e2)];
              },
            },
          }),
          _0x3875cf
        );
      })(),
      _0x40d778 = (function () {
        var _0x4eee9b = _0x157421;
        function _0x560a6b(_0x3055d4) {
          var _0x1dc83a = _0x3797;
          PIXI[_0x1dc83a(0x30a)][_0x1dc83a(0x37a)](this);
          var _0x114e89 = PIXI["Sprite"]["fromFrame"](
            "" + _0x3055d4[_0x1dc83a(0x1f7)],
          );
          (_0x114e89[_0x1dc83a(0x4a1)][_0x1dc83a(0x27e)](0.5),
            this[_0x1dc83a(0x37b)](_0x114e89));
          var _0x451d24 = PIXI["Sprite"][_0x1dc83a(0x348)](
            "" + _0x3055d4[_0x1dc83a(0x1ee)],
          );
          (_0x451d24["anchor"]["set"](0.5),
            (_0x451d24["x"] = 0xc),
            (_0x451d24["y"] = -0x144),
            this[_0x1dc83a(0x37b)](_0x451d24));
          var _0x2bacfd = PIXI[_0x1dc83a(0x385)]["fromFrame"](_0x1dc83a(0x245));
          (_0x2bacfd[_0x1dc83a(0x4a1)][_0x1dc83a(0x27e)](0.5),
            (_0x2bacfd["x"] = 0xf),
            (_0x2bacfd["y"] = 0xa),
            this["addChild"](_0x2bacfd));
          var _0x1ee8c3 =
            PIXI[_0x1dc83a(0x385)][_0x1dc83a(0x348)]("tableselect_coins");
          (_0x1ee8c3[_0x1dc83a(0x4a1)][_0x1dc83a(0x27e)](0.5),
            (_0x1ee8c3["x"] = 0x91),
            (_0x1ee8c3["y"] = 0x0),
            _0x2bacfd[_0x1dc83a(0x37b)](_0x1ee8c3));
          var _0x57372e = new PIXI["BitmapText"](
            "" + _0x3055d4[_0x1dc83a(0x272)],
            { font: _0x1dc83a(0x336), fill: 0xffffff, align: _0x1dc83a(0x221) },
          );
          (_0x57372e["anchor"]["set"](0.5),
            (_0x57372e["anchor"]["x"] = 0x1),
            (_0x57372e["x"] = 0x5f),
            (_0x57372e["y"] = 0x5),
            _0x2bacfd[_0x1dc83a(0x37b)](_0x57372e));
          var _0x123331 = PIXI[_0x1dc83a(0x385)]["fromFrame"](_0x1dc83a(0x164));
          (_0x123331[_0x1dc83a(0x4a1)][_0x1dc83a(0x27e)](0.5),
            (_0x123331["x"] = 0xf),
            (_0x123331["y"] = 0x6e),
            this[_0x1dc83a(0x37b)](_0x123331));
          var _0x380545 = PIXI[_0x1dc83a(0x385)][_0x1dc83a(0x348)](
            _0x1dc83a(0x485),
          );
          (_0x380545[_0x1dc83a(0x4a1)]["set"](0.5),
            (_0x380545["x"] = 0x91),
            (_0x380545["y"] = 0x0),
            _0x123331[_0x1dc83a(0x37b)](_0x380545));
          var _0x4926d1 = new PIXI["BitmapText"]("" + _0x3055d4["fee"], {
            font: _0x1dc83a(0x127),
            fill: 0xffffff,
            align: _0x1dc83a(0x221),
          });
          (_0x4926d1[_0x1dc83a(0x4a1)][_0x1dc83a(0x27e)](0.5),
            (_0x4926d1[_0x1dc83a(0x4a1)]["x"] = 0x1),
            (_0x4926d1["x"] = 0x5f),
            (_0x4926d1["y"] = 0x3),
            _0x123331[_0x1dc83a(0x37b)](_0x4926d1));
          var _0x3f8df2 = new _0x32d81c(
            PIXI[_0x1dc83a(0x304)]["TextureCache"][_0x1dc83a(0x267)],
          );
          (_0x3f8df2[_0x1dc83a(0x4a1)][_0x1dc83a(0x27e)](0.5),
            _0x3f8df2["scale"][_0x1dc83a(0x27e)](0x1),
            (_0x3f8df2["x"] = 0xf),
            (_0x3f8df2["y"] = 0xf0),
            _0x3f8df2[_0x1dc83a(0x3d4)](
              _0x1dc83a(0x444),
              PIXI["utils"]["TextureCache"]["tableselect_select_button_hover"],
            ),
            _0x3f8df2[_0x1dc83a(0x3d4)](
              _0x1dc83a(0x2db),
              PIXI[_0x1dc83a(0x304)]["TextureCache"][_0x1dc83a(0xea)],
            ),
            this[_0x1dc83a(0x37b)](_0x3f8df2),
            _0x3f8df2["on"](
              _0x1dc83a(0x2a7),
              function () {
                var _0x49497d = _0x1dc83a;
                this[_0x49497d(0xfe)](_0x49497d(0x3b0), this["id"]);
              }[_0x1dc83a(0x374)](this),
            ),
            (this[_0x1dc83a(0x4ad)] = _0x3f8df2));
        }
        return (
          (_0x560a6b[_0x4eee9b(0x333)] = Object["create"](
            PIXI[_0x4eee9b(0x30a)][_0x4eee9b(0x333)],
          )),
          (_0x560a6b[_0x4eee9b(0x333)][_0x4eee9b(0x1b7)] = function (
            _0x5cedee,
            _0x4b174c,
          ) {}),
          (_0x560a6b["prototype"]["setEnable"] = function (_0x5cc39e) {
            var _0x31844a = _0x4eee9b;
            this[_0x31844a(0x4ad)][_0x31844a(0x12d)](_0x5cc39e);
          }),
          _0x560a6b
        );
      })(),
      _0x22a07c = (function () {
        var _0x3bee86 = _0x157421;
        function _0x14d186() {
          var _0x4ada4a = _0x3797;
          PIXI[_0x4ada4a(0x30a)][_0x4ada4a(0x37a)](this);
          var _0x41f815 = PIXI[_0x4ada4a(0x385)][_0x4ada4a(0x348)](
            _0x4ada4a(0x189),
          );
          (_0x41f815[_0x4ada4a(0x4a1)]["set"](0.5),
            (_0x41f815["x"] = 0x140),
            (_0x41f815["y"] = _0x27ae22 / 0x2),
            this[_0x4ada4a(0x37b)](_0x41f815));
          var _0x2ef2ea = PIXI[_0x4ada4a(0x385)]["fromFrame"](_0x4ada4a(0x370));
          (_0x2ef2ea[_0x4ada4a(0x4a1)][_0x4ada4a(0x27e)](0.5),
            (_0x2ef2ea["x"] = 0x203),
            (_0x2ef2ea["y"] = 0x46),
            this["addChild"](_0x2ef2ea));
          var _0x3780cc = PIXI[_0x4ada4a(0x385)]["fromFrame"](_0x4ada4a(0x485));
          (_0x3780cc[_0x4ada4a(0x4a1)][_0x4ada4a(0x27e)](0.5),
            (_0x3780cc["x"] = 0x3c),
            (_0x3780cc["y"] = 0x0),
            _0x2ef2ea[_0x4ada4a(0x37b)](_0x3780cc),
            (this[_0x4ada4a(0x19e)] = _0x3780cc));
          var _0x545cce = new PIXI[_0x4ada4a(0x402)]("0", {
            font: _0x4ada4a(0x2a2),
            fill: 0xffffff,
            align: _0x4ada4a(0x221),
          });
          (_0x545cce[_0x4ada4a(0x4a1)][_0x4ada4a(0x27e)](0.5),
            (_0x545cce["x"] = -0x23),
            (_0x545cce["y"] = 0x3),
            _0x2ef2ea[_0x4ada4a(0x37b)](_0x545cce),
            (this[_0x4ada4a(0x387)] = _0x545cce));
          var _0x40329e = new _0x32d81c(
            PIXI[_0x4ada4a(0x304)][_0x4ada4a(0x299)][_0x4ada4a(0x170)],
          );
          (_0x40329e["anchor"]["set"](0.5),
            (_0x40329e["x"] = 0x4b),
            (_0x40329e["y"] = 0x46),
            _0x40329e[_0x4ada4a(0x3d4)](
              _0x4ada4a(0x444),
              PIXI[_0x4ada4a(0x304)]["TextureCache"][_0x4ada4a(0x44f)],
            ),
            this[_0x4ada4a(0x37b)](_0x40329e),
            _0x40329e["on"](
              "pointertap",
              function () {
                var _0x3ae0a6 = _0x4ada4a;
                this[_0x3ae0a6(0xfe)]("back");
              }["bind"](this),
            ),
            (this[_0x4ada4a(0x46e)] = _0x40329e));
          var _0x539dba = new PIXI[_0x4ada4a(0x30a)]();
          ((_0x539dba["x"] = 0x136),
            (_0x539dba["y"] = 0x25d),
            this[_0x4ada4a(0x3df)](_0x539dba, 0x1),
            (this["content"] = _0x539dba),
            (this["_items"] = []));
          for (let _0x313a05 = 0x0; _0x313a05 < 0x6; _0x313a05++) {
            if (_0x313a05 == 0x0) {
              var _0x5bdd36 =
                PIXI["Sprite"][_0x4ada4a(0x348)]("tut_WOODEN_BASE");
              (_0x5bdd36["anchor"][_0x4ada4a(0x27e)](0.5),
                (_0x5bdd36["x"] = 0x0 + _0x313a05 * 0x230),
                (_0x5bdd36["y"] = 0x0),
                (_0x5bdd36["id"] = _0x313a05 - 0x1),
                _0x539dba["addChild"](_0x5bdd36),
                this["_items"][_0x4ada4a(0x3b0)](_0x5bdd36));
              var _0x2cf795 =
                PIXI[_0x4ada4a(0x385)][_0x4ada4a(0x348)]("tut_04_title");
              (_0x2cf795[_0x4ada4a(0x4a1)][_0x4ada4a(0x27e)](0.5),
                (_0x2cf795["y"] = -0x190),
                _0x5bdd36[_0x4ada4a(0x37b)](_0x2cf795));
              var _0x2aa6e2 = PIXI[_0x4ada4a(0x385)][_0x4ada4a(0x348)](
                _0x4ada4a(0x39b),
              );
              (_0x2aa6e2[_0x4ada4a(0x4a1)][_0x4ada4a(0x27e)](0.5),
                _0x5bdd36[_0x4ada4a(0x37b)](_0x2aa6e2),
                (_0x5bdd36[_0x4ada4a(0x35e)] = _0x2aa6e2));
            } else {
              var _0x46317f = new _0x40d778(_0x1ac80c[_0x313a05 - 0x1]);
              ((_0x46317f["x"] = 0x0 + _0x313a05 * 0x230),
                (_0x46317f["y"] = 0x0),
                (_0x46317f["id"] = _0x313a05 - 0x1),
                _0x539dba["addChild"](_0x46317f),
                _0x46317f["on"](
                  _0x4ada4a(0x3b0),
                  function (_0x5803bf) {
                    var _0xdec217 = _0x4ada4a;
                    this[_0xdec217(0xfe)](_0xdec217(0x20f), _0x5803bf);
                  }[_0x4ada4a(0x374)](this),
                ),
                this[_0x4ada4a(0x283)][_0x4ada4a(0x3b0)](_0x46317f));
            }
          }
          var _0x337864 = PIXI[_0x4ada4a(0x385)][_0x4ada4a(0x348)](
            _0x4ada4a(0x29a),
          );
          (_0x337864[_0x4ada4a(0x4a1)][_0x4ada4a(0x27e)](0.5),
            (_0x337864["x"] = 0x253),
            (_0x337864["y"] = 0x248),
            this[_0x4ada4a(0x37b)](_0x337864),
            (this[_0x4ada4a(0x13b)] = _0x337864),
            (_0x337864[_0x4ada4a(0x1bf)] = !![]),
            (_0x337864[_0x4ada4a(0x2e6)] = !![]),
            _0x337864["on"](
              _0x4ada4a(0x2a7),
              this[_0x4ada4a(0x477)][_0x4ada4a(0x374)](this),
            ));
          var _0x558ffd = PIXI[_0x4ada4a(0x385)][_0x4ada4a(0x348)](
            "tableselect_arrow_left",
          );
          (_0x558ffd["anchor"][_0x4ada4a(0x27e)](0.5),
            (_0x558ffd[_0x4ada4a(0x197)] = ![]),
            (_0x558ffd["x"] = 0x28),
            (_0x558ffd["y"] = 0x248),
            this[_0x4ada4a(0x37b)](_0x558ffd),
            (this["arrLeft"] = _0x558ffd),
            (_0x558ffd[_0x4ada4a(0x1bf)] = !![]),
            (_0x558ffd["buttonMode"] = !![]),
            _0x558ffd["on"](
              _0x4ada4a(0x2a7),
              this[_0x4ada4a(0x28e)][_0x4ada4a(0x374)](this),
            ));
          var _0x4703bb = new _0x32d81c(
            PIXI[_0x4ada4a(0x304)][_0x4ada4a(0x299)][_0x4ada4a(0x28a)],
          );
          (_0x4703bb[_0x4ada4a(0x4a1)][_0x4ada4a(0x27e)](0.5),
            (_0x4703bb["x"] = 0x22b),
            (_0x4703bb["y"] = 0x42e),
            _0x4703bb[_0x4ada4a(0x3d4)](
              _0x4ada4a(0x444),
              PIXI["utils"][_0x4ada4a(0x299)][_0x4ada4a(0x208)],
            ),
            this[_0x4ada4a(0x37b)](_0x4703bb),
            _0x4703bb["on"](
              "pointertap",
              function () {
                var _0x29833b = _0x4ada4a;
                this[_0x29833b(0xfe)](_0x29833b(0x309));
              }[_0x4ada4a(0x374)](this),
            ),
            (this[_0x4ada4a(0x443)] = _0x4703bb));
          var _0xf1e695 = PIXI[_0x4ada4a(0x385)][_0x4ada4a(0x348)](
            _0x4ada4a(0x3b5),
          );
          (_0xf1e695[_0x4ada4a(0x4a1)][_0x4ada4a(0x27e)](0.5),
            (_0xf1e695["x"] = -0x2d),
            (_0xf1e695["y"] = -0x23),
            _0x4703bb[_0x4ada4a(0x37b)](_0xf1e695),
            (_0x4703bb[_0x4ada4a(0x2ce)] = _0xf1e695));
          var _0x4b6337 = new _0x32d81c(
            PIXI[_0x4ada4a(0x304)][_0x4ada4a(0x299)]["lobby_button_tutorial"],
          );
          (_0x4b6337[_0x4ada4a(0x4a1)]["set"](0.5),
            (_0x4b6337["x"] = 0x46),
            (_0x4b6337["y"] = 0x42e),
            _0x4b6337[_0x4ada4a(0x3d4)](
              _0x4ada4a(0x444),
              PIXI[_0x4ada4a(0x304)][_0x4ada4a(0x299)][
                "lobby_button_tutorial_pressed"
              ],
            ),
            this[_0x4ada4a(0x37b)](_0x4b6337),
            _0x4b6337["on"](
              "pointertap",
              function () {
                var _0x18605c = _0x4ada4a;
                this[_0x18605c(0xfe)](_0x18605c(0x252));
              }["bind"](this),
            ),
            (this[_0x4ada4a(0x3fe)] = _0x4b6337),
            (this[_0x4ada4a(0xcf)] = ![]),
            (this[_0x4ada4a(0x1c7)] = 0x0),
            (this["_scrollSpeed"] = 0x0),
            (this[_0x4ada4a(0x151)] = 0x0),
            (this["_coins"] = 0x0));
        }
        return (
          (_0x14d186[_0x3bee86(0x333)] = Object[_0x3bee86(0x454)](
            PIXI[_0x3bee86(0x30a)][_0x3bee86(0x333)],
          )),
          (_0x14d186["prototype"][_0x3bee86(0x162)] = function (_0x3f37fa) {
            var _0xcbbb48 = _0x3bee86;
            this[_0xcbbb48(0x443)][_0xcbbb48(0x2ce)][_0xcbbb48(0x197)] =
              _0x3f37fa;
          }),
          (_0x14d186[_0x3bee86(0x333)][_0x3bee86(0x491)] = function (
            _0x21f9d2,
          ) {
            var _0x1b55a0 = _0x3bee86;
            switch (_0x21f9d2) {
              case 0x0:
                this[_0x1b55a0(0x283)][0x0]["rules"][_0x1b55a0(0x335)] =
                  PIXI[_0x1b55a0(0x304)][_0x1b55a0(0x299)][_0x1b55a0(0x300)];
                break;
              case 0x1:
                this[_0x1b55a0(0x283)][0x0][_0x1b55a0(0x35e)][
                  _0x1b55a0(0x335)
                ] = PIXI[_0x1b55a0(0x304)][_0x1b55a0(0x299)][_0x1b55a0(0x39b)];
                break;
              case 0x2:
                this[_0x1b55a0(0x283)][0x0]["rules"][_0x1b55a0(0x335)] =
                  PIXI[_0x1b55a0(0x304)][_0x1b55a0(0x299)][_0x1b55a0(0x256)];
                break;
            }
          }),
          (_0x14d186["prototype"]["reset"] = function () {
            var _0x4990c1 = _0x3bee86;
            ((this[_0x4990c1(0x151)] = 0x0),
              (this[_0x4990c1(0x4b4)]["x"] = 0x136),
              (this[_0x4990c1(0x156)]["visible"] = ![]),
              (this[_0x4990c1(0x13b)][_0x4990c1(0x197)] = !![]));
          }),
          (_0x14d186["prototype"][_0x3bee86(0xf6)] = function (_0x3c6ec2) {}),
          (_0x14d186[_0x3bee86(0x333)]["setCoins"] = function (_0x4dc86c) {
            var _0x40d898 = _0x3bee86;
            _0x4dc86c > this[_0x40d898(0x476)] &&
              (this[_0x40d898(0x19e)]["scale"]["set"](0x1),
              Tweener[_0x40d898(0x3a0)](
                this[_0x40d898(0x19e)],
                { scaleX: 1.1, scaleY: 1.1 },
                { time: 0xf, transition: _0x40d898(0x205) },
              ));
            ((this[_0x40d898(0x476)] = _0x4dc86c),
              (this[_0x40d898(0x387)][_0x40d898(0x1aa)] =
                "" + _0x2f9b78(_0x4dc86c)));
            for (
              let _0x55eb2d = 0x0;
              _0x55eb2d < this[_0x40d898(0x283)][_0x40d898(0x182)];
              _0x55eb2d++
            ) {
              if (_0x55eb2d == 0x0) continue;
              this[_0x40d898(0x283)][_0x55eb2d]["setEnable"](
                this[_0x40d898(0x476)] >=
                  _0x1ac80c[_0x55eb2d - 0x1][_0x40d898(0x177)],
              );
            }
          }),
          (_0x14d186[_0x3bee86(0x333)][_0x3bee86(0x477)] = function () {
            var _0x545a1b = _0x3bee86;
            _0x28fba8[_0x545a1b(0x383)]("tap_wood5");
            if (
              this["_selected"] >=
              this[_0x545a1b(0x283)][_0x545a1b(0x182)] - 0x1
            )
              return;
            this[_0x545a1b(0x151)]++;
            if (
              this[_0x545a1b(0x151)] ==
              this[_0x545a1b(0x283)][_0x545a1b(0x182)] - 0x1
            )
              this[_0x545a1b(0x13b)][_0x545a1b(0x197)] = ![];
            ((this[_0x545a1b(0x156)][_0x545a1b(0x197)] = !![]),
              Tweener[_0x545a1b(0x3a0)](
                this[_0x545a1b(0x4b4)],
                { x: 0x136 - 0x230 * this[_0x545a1b(0x151)] },
                { time: 0xf, transition: "easeOutQuad" },
              ));
          }),
          (_0x14d186[_0x3bee86(0x333)][_0x3bee86(0x28e)] = function () {
            var _0x38520a = _0x3bee86;
            _0x28fba8[_0x38520a(0x383)](_0x38520a(0x16e));
            if (this[_0x38520a(0x151)] <= 0x0) return;
            this[_0x38520a(0x151)]--;
            if (this[_0x38520a(0x151)] == 0x0)
              this[_0x38520a(0x156)]["visible"] = ![];
            ((this[_0x38520a(0x13b)][_0x38520a(0x197)] = !![]),
              Tweener[_0x38520a(0x3a0)](
                this[_0x38520a(0x4b4)],
                { x: 0x136 - 0x230 * this["_selected"] },
                { time: 0xf, transition: _0x38520a(0x1f9) },
              ));
          }),
          (_0x14d186["prototype"]["pointerDownHandler"] = function (
            _0x4235e7,
          ) {}),
          (_0x14d186[_0x3bee86(0x333)][_0x3bee86(0x3b2)] = function (
            _0x3ebaa0,
          ) {}),
          (_0x14d186["prototype"][_0x3bee86(0x204)] = function (_0x303014) {}),
          (_0x14d186[_0x3bee86(0x333)][_0x3bee86(0x313)] = function () {}),
          (_0x14d186[_0x3bee86(0x333)][_0x3bee86(0x12d)] = function (
            _0x3147f2,
          ) {
            var _0x106d2d = _0x3bee86;
            (this["_btnBack"][_0x106d2d(0x12d)](_0x3147f2),
              this[_0x106d2d(0x443)][_0x106d2d(0x12d)](_0x3147f2),
              this[_0x106d2d(0x3fe)][_0x106d2d(0x12d)](_0x3147f2),
              (this[_0x106d2d(0x156)][_0x106d2d(0x1bf)] = _0x3147f2),
              (this["arrRight"][_0x106d2d(0x1bf)] = _0x3147f2));
          }),
          Object[_0x3bee86(0x211)](_0x14d186[_0x3bee86(0x333)], {}),
          _0x14d186
        );
      })(),
      _0x28bd7a = (function () {
        var _0xe29347 = _0x157421;
        function _0x369d47() {
          var _0x50b4ad = _0x3797;
          PIXI["Container"][_0x50b4ad(0x37a)](this);
          var _0x521eed = PIXI[_0x50b4ad(0x385)]["fromFrame"](_0x50b4ad(0x189));
          (_0x521eed["anchor"][_0x50b4ad(0x27e)](0.5),
            (_0x521eed["x"] = 0x140),
            (_0x521eed["y"] = _0x27ae22 / 0x2),
            this["addChild"](_0x521eed));
          var _0x8b5322 = PIXI[_0x50b4ad(0x385)][_0x50b4ad(0x348)](
            _0x50b4ad(0x357),
          );
          (_0x8b5322[_0x50b4ad(0x4a1)]["set"](0.5),
            (_0x8b5322["x"] = 0x140),
            (_0x8b5322["y"] = 0xdc),
            this[_0x50b4ad(0x37b)](_0x8b5322));
          var _0xa9b8d3 = new Animable(_0xbf118[_0x50b4ad(0x25a)][0x0]);
          (_0xa9b8d3[_0x50b4ad(0x231)][_0x50b4ad(0x27e)](1.56),
            _0xa9b8d3[_0x50b4ad(0x4a1)]["set"](0.5),
            (_0xa9b8d3[_0x50b4ad(0x3eb)] = 0x1),
            (_0xa9b8d3["y"] = 0x28),
            _0x8b5322[_0x50b4ad(0x37b)](_0xa9b8d3),
            _0xa9b8d3["addAnimation"](
              "idle",
              _0xbf118[_0x50b4ad(0x25a)],
              [
                0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xa, 0xb, 0xc,
                0xd, 0xe, 0xf, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
                0x18,
              ],
            ),
            _0x3eeb21[_0x50b4ad(0x3d7)](null, _0xa9b8d3),
            Tweener[_0x50b4ad(0x3a0)](
              _0x8b5322,
              { scaleX: 1.03, scaleY: 1.03 },
              {
                time: 0x28,
                delay: 0xc8,
                loop: -0x1,
                transition: _0x50b4ad(0x205),
                onStart: function () {
                  var _0x38c829 = _0x50b4ad;
                  _0xa9b8d3[_0x38c829(0x32b)](_0x38c829(0x435), 0x0, 0x14);
                },
              },
            ));
          var _0x34dca0 = PIXI["Sprite"][_0x50b4ad(0x348)](_0x50b4ad(0x370));
          (_0x34dca0[_0x50b4ad(0x4a1)][_0x50b4ad(0x27e)](0.5),
            (_0x34dca0["x"] = 0x203),
            (_0x34dca0["y"] = 0x46),
            this[_0x50b4ad(0x37b)](_0x34dca0),
            (_0x34dca0["interactive"] = !![]),
            _0x34dca0["on"](
              _0x50b4ad(0x43e),
              function () {
                var _0x3f04ca = _0x50b4ad;
                this[_0x3f04ca(0xfe)](_0x3f04ca(0x463));
              }[_0x50b4ad(0x374)](this),
            ));
          var _0x48958d = PIXI[_0x50b4ad(0x385)][_0x50b4ad(0x348)](
            _0x50b4ad(0x485),
          );
          (_0x48958d[_0x50b4ad(0x4a1)][_0x50b4ad(0x27e)](0.5),
            (_0x48958d["x"] = 0x3c),
            (_0x48958d["y"] = 0x0),
            _0x34dca0[_0x50b4ad(0x37b)](_0x48958d),
            (this["coinsIcon"] = _0x48958d));
          var _0x1adeef = new PIXI["BitmapText"]("0", {
            font: _0x50b4ad(0x2a2),
            fill: 0xffffff,
            align: _0x50b4ad(0x221),
          });
          (_0x1adeef[_0x50b4ad(0x4a1)]["set"](0.5),
            (_0x1adeef["x"] = -0x23),
            (_0x1adeef["y"] = 0x3),
            _0x34dca0[_0x50b4ad(0x37b)](_0x1adeef),
            (this["valueField"] = _0x1adeef));
          var _0x4367b8 = new _0x32d81c(
            PIXI[_0x50b4ad(0x304)][_0x50b4ad(0x299)]["lobby_button_discpool"],
          );
          (_0x4367b8[_0x50b4ad(0x4a1)][_0x50b4ad(0x27e)](0.5),
            (_0x4367b8["x"] = 0x131),
            (_0x4367b8["y"] = 0x230),
            _0x4367b8[_0x50b4ad(0x3d4)](
              _0x50b4ad(0x444),
              PIXI[_0x50b4ad(0x304)][_0x50b4ad(0x299)][_0x50b4ad(0x2ef)],
            ),
            this[_0x50b4ad(0x37b)](_0x4367b8),
            _0x4367b8["on"](
              _0x50b4ad(0x2a7),
              function () {
                this["emit"]("play", 0x0);
              }[_0x50b4ad(0x374)](this),
            ),
            (this[_0x50b4ad(0x42b)] = _0x4367b8));
          var _0x536212 = new _0x32d81c(
            PIXI["utils"]["TextureCache"]["lobby_button_carrom"],
          );
          (_0x536212["anchor"][_0x50b4ad(0x27e)](0.5),
            (_0x536212["x"] = 0x131),
            (_0x536212["y"] = 0x2d7),
            _0x536212["registerState"](
              _0x50b4ad(0x444),
              PIXI[_0x50b4ad(0x304)][_0x50b4ad(0x299)][
                "lobby_button_carrom_hover"
              ],
            ),
            this["addChild"](_0x536212),
            _0x536212["on"](
              _0x50b4ad(0x2a7),
              function () {
                var _0x45cd02 = _0x50b4ad;
                this[_0x45cd02(0xfe)](_0x45cd02(0x383), 0x1);
              }[_0x50b4ad(0x374)](this),
            ),
            (this["_btnPlayCarrom"] = _0x536212));
          var _0x183e0f = new _0x32d81c(
            PIXI[_0x50b4ad(0x304)]["TextureCache"][_0x50b4ad(0x415)],
          );
          (_0x183e0f[_0x50b4ad(0x4a1)][_0x50b4ad(0x27e)](0.5),
            (_0x183e0f["x"] = 0x131),
            (_0x183e0f["y"] = 0x37f),
            _0x183e0f[_0x50b4ad(0x3d4)](
              _0x50b4ad(0x444),
              PIXI[_0x50b4ad(0x304)]["TextureCache"][
                "lobby_button_freestyle_hover"
              ],
            ),
            this[_0x50b4ad(0x37b)](_0x183e0f),
            _0x183e0f["on"](
              "pointertap",
              function () {
                var _0x20e4f8 = _0x50b4ad;
                this["emit"](_0x20e4f8(0x383), 0x2);
              }["bind"](this),
            ),
            (this[_0x50b4ad(0x3b8)] = _0x183e0f));
          var _0x250d34 = new _0x32d81c(
            PIXI[_0x50b4ad(0x304)][_0x50b4ad(0x299)][_0x50b4ad(0x28a)],
          );
          (_0x250d34[_0x50b4ad(0x4a1)][_0x50b4ad(0x27e)](0.5),
            (_0x250d34["x"] = 0x22b),
            (_0x250d34["y"] = 0x42e),
            _0x250d34[_0x50b4ad(0x3d4)](
              _0x50b4ad(0x444),
              PIXI[_0x50b4ad(0x304)][_0x50b4ad(0x299)][_0x50b4ad(0x208)],
            ),
            this[_0x50b4ad(0x37b)](_0x250d34),
            _0x250d34["on"](
              _0x50b4ad(0x2a7),
              function () {
                var _0xec733d = _0x50b4ad;
                this[_0xec733d(0xfe)]("shop");
              }[_0x50b4ad(0x374)](this),
            ),
            (this[_0x50b4ad(0x443)] = _0x250d34));
          var _0x5ba40b = PIXI["Sprite"][_0x50b4ad(0x348)](_0x50b4ad(0x3b5));
          (_0x5ba40b["anchor"]["set"](0.5),
            (_0x5ba40b["x"] = -0x2d),
            (_0x5ba40b["y"] = -0x23),
            _0x250d34[_0x50b4ad(0x37b)](_0x5ba40b),
            (_0x250d34[_0x50b4ad(0x2ce)] = _0x5ba40b));
          var _0x31470c = new _0x32d81c(
            PIXI[_0x50b4ad(0x304)][_0x50b4ad(0x299)][_0x50b4ad(0x473)],
          );
          (_0x31470c[_0x50b4ad(0x4a1)]["set"](0.5),
            (_0x31470c["x"] = 0x46),
            (_0x31470c["y"] = 0x42e),
            _0x31470c[_0x50b4ad(0x3d4)](
              _0x50b4ad(0x444),
              PIXI[_0x50b4ad(0x304)][_0x50b4ad(0x299)][_0x50b4ad(0x3f8)],
            ),
            this[_0x50b4ad(0x37b)](_0x31470c),
            _0x31470c["on"](
              _0x50b4ad(0x2a7),
              function () {
                var _0x5c96cd = _0x50b4ad;
                this[_0x5c96cd(0xfe)](_0x5c96cd(0x252));
              }[_0x50b4ad(0x374)](this),
            ),
            (this[_0x50b4ad(0x3fe)] = _0x31470c));
          var _0x59cae4 = new _0x32d81c(
            PIXI["utils"][_0x50b4ad(0x299)][_0x50b4ad(0x420)],
          );
          (_0x59cae4[_0x50b4ad(0x4a1)]["set"](0.5),
            _0x59cae4[_0x50b4ad(0x231)]["set"](0.9),
            (_0x59cae4["x"] = 0x5a),
            (_0x59cae4["y"] = 0x62),
            _0x59cae4[_0x50b4ad(0x3d4)](
              "down",
              PIXI["utils"]["TextureCache"][_0x50b4ad(0x397)],
            ),
            _0x59cae4[_0x50b4ad(0x3d4)](
              _0x50b4ad(0x2db),
              PIXI["utils"][_0x50b4ad(0x299)]["lobby_button_dailybonus_hover"],
            ),
            this[_0x50b4ad(0x37b)](_0x59cae4),
            _0x59cae4["on"](
              _0x50b4ad(0x2a7),
              function () {
                var _0x3e764d = _0x50b4ad;
                this[_0x3e764d(0xfe)]("bonus");
              }["bind"](this),
            ),
            (this[_0x50b4ad(0x38e)] = _0x59cae4));
          var _0x10070f = new PIXI["BitmapText"]("00:00:00", {
            font: _0x50b4ad(0x2d2),
            fill: 0xffffff,
            align: _0x50b4ad(0x221),
          });
          (_0x10070f[_0x50b4ad(0x4a1)][_0x50b4ad(0x27e)](0.5),
            (_0x10070f["x"] = 0x0),
            (_0x10070f["y"] = 0x14),
            _0x59cae4[_0x50b4ad(0x37b)](_0x10070f));
          var _0x1839c0 = PIXI[_0x50b4ad(0x385)][_0x50b4ad(0x348)](
            _0x50b4ad(0x3b5),
          );
          (_0x1839c0[_0x50b4ad(0x4a1)][_0x50b4ad(0x27e)](0.5),
            (_0x1839c0["x"] = 0x2b),
            (_0x1839c0["y"] = -0x32),
            _0x59cae4["addChild"](_0x1839c0),
            (_0x59cae4[_0x50b4ad(0x21f)] = _0x10070f),
            (_0x59cae4[_0x50b4ad(0x2ce)] = _0x1839c0));
          var _0x33bf5b = PIXI["Sprite"][_0x50b4ad(0x348)](_0x50b4ad(0x279));
          (_0x33bf5b[_0x50b4ad(0x4a1)][_0x50b4ad(0x27e)](0.5),
            (_0x33bf5b["x"] = 0x0),
            (_0x33bf5b["y"] = -0xa),
            _0x59cae4[_0x50b4ad(0x37b)](_0x33bf5b));
          const _0x387a3a = new _0x32d81c(
            PIXI[_0x50b4ad(0x304)][_0x50b4ad(0x299)][_0x50b4ad(0x38b)],
          );
          (_0x387a3a[_0x50b4ad(0x4a1)][_0x50b4ad(0x27e)](0.5),
            (_0x387a3a["y"] = 0x3c),
            _0x387a3a["registerState"](
              "down",
              PIXI[_0x50b4ad(0x304)]["TextureCache"][_0x50b4ad(0x46b)],
            ),
            _0x387a3a[_0x50b4ad(0x3d4)](
              _0x50b4ad(0x2db),
              PIXI["utils"][_0x50b4ad(0x299)][_0x50b4ad(0x46b)],
            ),
            _0x59cae4["addChild"](_0x387a3a),
            (_0x59cae4[_0x50b4ad(0x2a4)] = _0x33bf5b),
            (_0x59cae4[_0x50b4ad(0x441)] = _0x387a3a),
            _0x387a3a["on"](
              _0x50b4ad(0x2a7),
              function () {
                this["emit"]("ad");
              }["bind"](this),
            ),
            (this[_0x50b4ad(0x476)] = 0x0),
            (this[_0x50b4ad(0xf4)] = !![]));
        }
        return (
          (_0x369d47[_0xe29347(0x333)] = Object["create"](
            PIXI[_0xe29347(0x30a)][_0xe29347(0x333)],
          )),
          (_0x369d47["prototype"][_0xe29347(0x162)] = function (_0x5d9ad2) {
            var _0x5d19b8 = _0xe29347;
            this[_0x5d19b8(0x443)][_0x5d19b8(0x2ce)]["visible"] = _0x5d9ad2;
          }),
          (_0x369d47[_0xe29347(0x333)][_0xe29347(0x27a)] = function (
            _0x433ee0,
          ) {
            var _0x48ca96 = _0xe29347;
            let _0x5785c3 = _0x433ee0,
              _0x27d077 = Math["floor"](_0x5785c3 / 0x3e8 / 0x3c / 0x3c / 0x18);
            _0x5785c3 -= _0x27d077 * 0x3e8 * 0x3c * 0x3c * 0x18;
            let _0xaf2ad3 = Math[_0x48ca96(0x1f8)](
              _0x5785c3 / 0x3e8 / 0x3c / 0x3c,
            );
            _0x5785c3 -= _0xaf2ad3 * 0x3e8 * 0x3c * 0x3c;
            let _0x5f2f34 = Math[_0x48ca96(0x1f8)](_0x5785c3 / 0x3e8 / 0x3c);
            _0x5785c3 -= _0x5f2f34 * 0x3e8 * 0x3c;
            let _0x461fae = Math[_0x48ca96(0x1f8)](_0x5785c3 / 0x3e8),
              _0x586c59 = _0xaf2ad3 > 0x9 ? "" + _0xaf2ad3 : "0" + _0xaf2ad3,
              _0x20045c = _0x5f2f34 > 0x9 ? "" + _0x5f2f34 : "0" + _0x5f2f34,
              _0x5143a9 = _0x461fae > 0x9 ? "" + _0x461fae : "0" + _0x461fae;
            this[_0x48ca96(0x38e)][_0x48ca96(0x21f)][_0x48ca96(0x1aa)] =
              "(" + _0x586c59 + ":" + _0x20045c + ":" + _0x5143a9 + ")";
          }),
          (_0x369d47[_0xe29347(0x333)][_0xe29347(0x15a)] = function (
            _0x42b986,
          ) {
            var _0xb93ba2 = _0xe29347;
            ((this[_0xb93ba2(0x38e)][_0xb93ba2(0x2ce)][_0xb93ba2(0x197)] =
              _0x42b986),
              (this[_0xb93ba2(0x38e)][_0xb93ba2(0x21f)][_0xb93ba2(0x197)] =
                !_0x42b986));
            if (_0x42b986) this[_0xb93ba2(0x38e)][_0xb93ba2(0x2a4)]["y"] = 0x0;
            else this[_0xb93ba2(0x38e)][_0xb93ba2(0x2a4)]["y"] = -0xa;
            this[_0xb93ba2(0x38e)][_0xb93ba2(0x12d)](
              this["_enabled"] && _0x530cb1,
            );
          }),
          (_0x369d47["prototype"][_0xe29347(0x185)] = function (_0x46097c) {
            var _0x528041 = _0xe29347;
            (_0x46097c > this[_0x528041(0x476)] &&
              (this[_0x528041(0x19e)][_0x528041(0x231)][_0x528041(0x27e)](0x1),
              Tweener[_0x528041(0x3a0)](
                this[_0x528041(0x19e)],
                { scaleX: 1.1, scaleY: 1.1 },
                { time: 0xf, transition: _0x528041(0x205) },
              )),
              (this["_coins"] = _0x46097c),
              (this[_0x528041(0x387)][_0x528041(0x1aa)] =
                "" + _0x2f9b78(_0x46097c)));
          }),
          (_0x369d47["prototype"][_0xe29347(0x12d)] = function (_0x1e88ee) {
            var _0x462001 = _0xe29347;
            ((this["_enabled"] = _0x1e88ee),
              this["_btnPlayDisk"][_0x462001(0x12d)](_0x1e88ee),
              this[_0x462001(0x253)][_0x462001(0x12d)](_0x1e88ee),
              this[_0x462001(0x3b8)][_0x462001(0x12d)](_0x1e88ee),
              this[_0x462001(0x3fe)]["setEnable"](_0x1e88ee),
              this["_btnShop"]["setEnable"](_0x1e88ee),
              this[_0x462001(0x38e)][_0x462001(0x12d)](_0x1e88ee && _0x530cb1));
          }),
          Object[_0xe29347(0x211)](_0x369d47[_0xe29347(0x333)], {
            value: {
              set: function (_0x17024d) {
                this["_value"] = _0x17024d;
              },
              get: function () {
                var _0xeacd2 = _0xe29347;
                return this[_0xeacd2(0x3e2)];
              },
            },
          }),
          _0x369d47
        );
      })(),
      _0x1eceb4 = (function () {
        var _0x1b59d5 = _0x157421;
        function _0x31b1ae(_0x13d56f) {
          var _0x4d8048 = _0x3797;
          PIXI[_0x4d8048(0x30a)][_0x4d8048(0x37a)](this);
          var _0x3c6868 = new PIXI[_0x4d8048(0x402)]("0", {
            font: "30px\x20Simonetta_white2",
            fill: 0xffffff,
            align: _0x4d8048(0x221),
          });
          (_0x3c6868["anchor"][_0x4d8048(0x27e)](0.5),
            (_0x3c6868[_0x4d8048(0x4a1)]["x"] = 0x1),
            (_0x3c6868["x"] = 0x0),
            (_0x3c6868["y"] = 0x0),
            this[_0x4d8048(0x37b)](_0x3c6868),
            (this[_0x4d8048(0x160)] = _0x3c6868));
          var _0x464e3f = new PIXI["BitmapText"]("0", {
            font: _0x4d8048(0x2a2),
            fill: 0xffffff,
            align: "center",
          });
          (_0x464e3f[_0x4d8048(0x4a1)][_0x4d8048(0x27e)](0.5),
            (_0x464e3f[_0x4d8048(0x4a1)]["x"] = 0x0),
            (_0x464e3f["x"] = 0x5),
            (_0x464e3f["y"] = 0x0),
            this["addChild"](_0x464e3f),
            (this[_0x4d8048(0x498)] = _0x464e3f),
            (this[_0x4d8048(0x3e2)] = 0x0),
            (this[_0x4d8048(0x372)] = _0x13d56f));
        }
        return (
          (_0x31b1ae[_0x1b59d5(0x333)] = Object[_0x1b59d5(0x454)](
            PIXI["Container"][_0x1b59d5(0x333)],
          )),
          (_0x31b1ae[_0x1b59d5(0x333)][_0x1b59d5(0xed)] = function (_0xe74679) {
            var _0x2dcb2d = _0x1b59d5;
            _0xe74679
              ? Tweener[_0x2dcb2d(0x3a0)](
                  this[_0x2dcb2d(0x160)],
                  { scaleX: 1.1, scaleY: 1.1 },
                  {
                    time: 0x5,
                    transition: "easeInQuad",
                    onComplete: function (_0x5bb1d3) {
                      var _0x493be5 = _0x2dcb2d;
                      ((this["valueLabel"][_0x493be5(0x1aa)] =
                        "" + this[_0x493be5(0x3e2)]),
                        Tweener["addTween"](
                          this[_0x493be5(0x160)],
                          { scaleX: 0x1, scaleY: 0x1 },
                          { time: 0x5, transition: _0x493be5(0x1f9) },
                        ));
                    }[_0x2dcb2d(0x374)](this),
                  },
                )
              : (this[_0x2dcb2d(0x160)][_0x2dcb2d(0x1aa)] =
                  "" + this[_0x2dcb2d(0x3e2)]);
          }),
          Object[_0x1b59d5(0x211)](_0x31b1ae["prototype"], {
            value: {
              get: function () {
                var _0x34cdf6 = _0x1b59d5;
                return this[_0x34cdf6(0x3e2)];
              },
              set: function (_0x33dfbb) {
                var _0x1b6df5 = _0x1b59d5;
                let _0x386a35 = _0x33dfbb > this[_0x1b6df5(0x3e2)];
                ((this[_0x1b6df5(0x3e2)] = _0x33dfbb),
                  this["redraw"](_0x386a35));
              },
            },
            goal: {
              get: function () {
                return this["_goal"];
              },
              set: function (_0x3c945e) {
                var _0x59420c = _0x1b59d5;
                ((this["_goal"] = _0x3c945e),
                  (this[_0x59420c(0x498)][_0x59420c(0x1aa)] =
                    "/" + this["_goal"]));
              },
            },
          }),
          _0x31b1ae
        );
      })(),
      _0x133fee = (function () {
        var _0x5cefba = _0x157421;
        function _0x2b6730(_0x24b187) {
          var _0x45417b = _0x3797;
          PIXI["Container"][_0x45417b(0x37a)](this);
          var _0x8fadb2 = PIXI[_0x45417b(0x385)][_0x45417b(0x348)](
            "Carrom_player_white",
          );
          (_0x8fadb2[_0x45417b(0x4a1)][_0x45417b(0x27e)](0.5),
            this["addChild"](_0x8fadb2));
          var _0x525d00 = PIXI[_0x45417b(0x385)][_0x45417b(0x348)](
            _0x45417b(0x28b),
          );
          ((_0x525d00[_0x45417b(0x197)] = ![]),
            _0x525d00[_0x45417b(0x4a1)][_0x45417b(0x27e)](0.5),
            _0x525d00[_0x45417b(0x231)]["set"](0.32),
            _0x8fadb2[_0x45417b(0x37b)](_0x525d00),
            (this["cover"] = _0x525d00));
          _0x24b187 == "white"
            ? (_0x8fadb2[_0x45417b(0x335)] =
                PIXI[_0x45417b(0x304)][_0x45417b(0x299)][_0x45417b(0x28b)])
            : (_0x8fadb2[_0x45417b(0x335)] =
                PIXI[_0x45417b(0x304)][_0x45417b(0x299)][
                  "Carrom_player_black"
                ]);
          var _0x2e67d4 = new PIXI["BitmapText"]("0", {
            font: _0x45417b(0x1de),
            fill: 0xffffff,
            align: "center",
          });
          (_0x2e67d4[_0x45417b(0x4a1)]["set"](0.5),
            (_0x2e67d4[_0x45417b(0x4a1)]["x"] = 0x0),
            (_0x2e67d4["x"] =
              _0x8fadb2["x"] + _0x8fadb2[_0x45417b(0xfd)] / 0x2 + 0x5),
            (_0x2e67d4["y"] = 0x4),
            this[_0x45417b(0x37b)](_0x2e67d4),
            (this[_0x45417b(0x160)] = _0x2e67d4),
            (this[_0x45417b(0x3e2)] = 0x0));
        }
        return (
          (_0x2b6730[_0x5cefba(0x333)] = Object[_0x5cefba(0x454)](
            PIXI[_0x5cefba(0x30a)]["prototype"],
          )),
          (_0x2b6730[_0x5cefba(0x333)][_0x5cefba(0x3e0)] = function (
            _0x10fd00,
          ) {
            var _0x58b552 = _0x5cefba;
            _0x10fd00 >= 0x0
              ? ((this[_0x58b552(0x118)][_0x58b552(0x197)] = !![]),
                (this[_0x58b552(0x118)]["texture"] =
                  PIXI[_0x58b552(0x304)][_0x58b552(0x299)][
                    _0x4cd129[_0x10fd00][_0x58b552(0xf3)]
                  ]))
              : (this[_0x58b552(0x118)][_0x58b552(0x197)] = ![]);
          }),
          (_0x2b6730[_0x5cefba(0x333)][_0x5cefba(0xed)] = function (_0x39b4a3) {
            var _0x3b0b5a = _0x5cefba;
            _0x39b4a3
              ? Tweener[_0x3b0b5a(0x3a0)](
                  this["valueLabel"],
                  { scaleX: 1.1, scaleY: 1.1 },
                  {
                    time: 0x5,
                    transition: "easeInQuad",
                    onComplete: function (_0x505359) {
                      var _0x37050c = _0x3b0b5a;
                      ((this[_0x37050c(0x160)][_0x37050c(0x1aa)] =
                        "" + this[_0x37050c(0x3e2)]),
                        Tweener[_0x37050c(0x3a0)](
                          this[_0x37050c(0x160)],
                          { scaleX: 0x1, scaleY: 0x1 },
                          { time: 0x5, transition: _0x37050c(0x1f9) },
                        ));
                    }[_0x3b0b5a(0x374)](this),
                  },
                )
              : (this[_0x3b0b5a(0x160)][_0x3b0b5a(0x1aa)] =
                  "" + this[_0x3b0b5a(0x3e2)]);
          }),
          Object[_0x5cefba(0x211)](_0x2b6730[_0x5cefba(0x333)], {
            value: {
              get: function () {
                var _0x4010ce = _0x5cefba;
                return this[_0x4010ce(0x3e2)];
              },
              set: function (_0x5d1646) {
                var _0x22d9fd = _0x5cefba;
                let _0x368d60 = _0x5d1646 > this["_value"];
                ((this[_0x22d9fd(0x3e2)] = _0x5d1646),
                  this["redraw"](_0x368d60));
              },
            },
          }),
          _0x2b6730
        );
      })(),
      _0x378a7c = (function () {
        var _0x5943dc = _0x157421;
        function _0x5bc786() {
          var _0x4a58bf = _0x3797;
          PIXI[_0x4a58bf(0x30a)][_0x4a58bf(0x37a)](this);
          var _0x12f860 = PIXI[_0x4a58bf(0x385)]["fromFrame"](_0x4a58bf(0x123));
          (_0x12f860[_0x4a58bf(0x4a1)]["set"](0.5),
            _0x12f860[_0x4a58bf(0x231)][_0x4a58bf(0x27e)](0x1),
            (_0x12f860["y"] = 0x19),
            (_0x12f860["alpha"] = 0.8),
            this[_0x4a58bf(0x37b)](_0x12f860),
            (this["bg"] = _0x12f860));
          var _0xd73e9b = PIXI[_0x4a58bf(0x385)]["fromFrame"](_0x4a58bf(0x17f));
          (_0xd73e9b[_0x4a58bf(0x231)][_0x4a58bf(0x27e)](0.7),
            this["addChild"](_0xd73e9b),
            (this[_0x4a58bf(0xf3)] = _0xd73e9b));
          var _0x22187b = new PIXI["BitmapText"]("0", {
            font: "42px\x20Simonetta_white2",
            fill: 0xffffff,
            align: _0x4a58bf(0x221),
          });
          ((_0x22187b["y"] = 0x5),
            this[_0x4a58bf(0x37b)](_0x22187b),
            (this[_0x4a58bf(0x160)] = _0x22187b),
            (this[_0x4a58bf(0x3e2)] = 0x0));
        }
        return (
          (_0x5bc786["prototype"] = Object["create"](
            PIXI[_0x5943dc(0x30a)]["prototype"],
          )),
          (_0x5bc786[_0x5943dc(0x333)][_0x5943dc(0xed)] = function () {
            var _0x49bb7f = _0x5943dc;
            ((this[_0x49bb7f(0x160)][_0x49bb7f(0x1aa)] =
              Math[_0x49bb7f(0x167)](this[_0x49bb7f(0x3e2)]) + ""),
              (this[_0x49bb7f(0xf3)]["x"] =
                0x0 -
                (this["icon"][_0x49bb7f(0xfd)] +
                  this["valueLabel"][_0x49bb7f(0xfd)] +
                  0xa) /
                  0x2),
              (this[_0x49bb7f(0x160)]["x"] =
                this[_0x49bb7f(0xf3)]["x"] +
                this[_0x49bb7f(0xf3)][_0x49bb7f(0xfd)] +
                0xa),
              (this["bg"]["x"] =
                this["icon"]["x"] + this[_0x49bb7f(0xf3)]["width"] / 0x2));
          }),
          Object[_0x5943dc(0x211)](_0x5bc786[_0x5943dc(0x333)], {
            value: {
              get: function () {
                var _0x3b6df3 = _0x5943dc;
                return this[_0x3b6df3(0x3e2)];
              },
              set: function (_0x4d0f6b) {
                var _0x4aa1ad = _0x5943dc;
                ((this[_0x4aa1ad(0x3e2)] = _0x4d0f6b), this[_0x4aa1ad(0xed)]());
              },
            },
          }),
          _0x5bc786
        );
      })(),
      _0x902691 = (function () {
        var _0xce473b = _0x157421;
        function _0x2ab510() {
          var _0x3d9c0e = _0x3797;
          PIXI[_0x3d9c0e(0x30a)]["call"](this);
          var _0x208dd4 = PIXI[_0x3d9c0e(0x385)][_0x3d9c0e(0x348)](
            _0x3d9c0e(0x13a),
          );
          (_0x208dd4["anchor"][_0x3d9c0e(0x27e)](0.5),
            this[_0x3d9c0e(0x37b)](_0x208dd4),
            (this[_0x3d9c0e(0x475)] = _0x208dd4));
          var _0x506db7 = PIXI[_0x3d9c0e(0x385)][_0x3d9c0e(0x348)](
            _0x3d9c0e(0x40e),
          );
          (_0x506db7["anchor"][_0x3d9c0e(0x27e)](0.5),
            (_0x506db7[_0x3d9c0e(0x4a1)]["y"] = 0x1),
            this[_0x3d9c0e(0x37b)](_0x506db7),
            (this["line"] = _0x506db7));
          var _0x16c014 = new PIXI[_0x3d9c0e(0x30a)]();
          this["addChild"](_0x16c014);
          var _0xf2e785 = new PIXI[_0x3d9c0e(0x392)](
            PIXI[_0x3d9c0e(0x304)][_0x3d9c0e(0x299)]["arrow_motion"],
            0x1e,
            0x5a,
          );
          ((_0xf2e785[_0x3d9c0e(0x4a1)]["x"] = 0.5),
            (_0xf2e785["anchor"]["y"] = 0x1),
            _0x16c014[_0x3d9c0e(0x37b)](_0xf2e785),
            Tweener[_0x3d9c0e(0x3a0)](
              _0xf2e785["tilePosition"],
              { y: -0x10d },
              { time: 0x64, loop: -0x1 },
            ));
          var _0x2e5c3b = new PIXI[_0x3d9c0e(0x148)]();
          (_0x2e5c3b["beginFill"](0xff00),
            _0x2e5c3b[_0x3d9c0e(0x2fc)](0x10 - 0xf, 0x2 - 0x5a),
            _0x2e5c3b["lineTo"](0x1d - 0xf, 0x16 - 0x5a),
            _0x2e5c3b[_0x3d9c0e(0x2d9)](0x16 - 0xf, 0x16 - 0x5a),
            _0x2e5c3b[_0x3d9c0e(0x2d9)](0x14 - 0xf, 0x59 - 0x5a),
            _0x2e5c3b[_0x3d9c0e(0x2d9)](0xb - 0xf, 0x59 - 0x5a),
            _0x2e5c3b[_0x3d9c0e(0x2d9)](0x9 - 0xf, 0x16 - 0x5a),
            _0x2e5c3b[_0x3d9c0e(0x2d9)](0x1 - 0xf, 0x16 - 0x5a),
            (_0x2e5c3b[_0x3d9c0e(0x445)] = !![]),
            _0x16c014[_0x3d9c0e(0x37b)](_0x2e5c3b),
            (_0xf2e785[_0x3d9c0e(0x20a)] = _0x2e5c3b));
          var _0x2a6728 = PIXI[_0x3d9c0e(0x385)]["fromFrame"](_0x3d9c0e(0x4a2));
          ((_0x2a6728["anchor"]["x"] = 0.5),
            (_0x2a6728["anchor"]["y"] = 0x1),
            _0x16c014[_0x3d9c0e(0x37b)](_0x2a6728),
            (this["arrow"] = _0x16c014),
            (this["_strength"] = 0x0),
            (this[_0x3d9c0e(0x390)] = 0x0),
            (this[_0x3d9c0e(0x229)] = 0.5));
        }
        return (
          (_0x2ab510[_0xce473b(0x333)] = Object[_0xce473b(0x454)](
            PIXI[_0xce473b(0x30a)][_0xce473b(0x333)],
          )),
          (_0x2ab510[_0xce473b(0x333)]["redraw"] = function () {
            var _0x58f15e = _0xce473b;
            (this[_0x58f15e(0x475)][_0x58f15e(0x231)][_0x58f15e(0x27e)](
              this["_strength"],
            ),
              this["arrow"][_0x58f15e(0x231)]["set"](this[_0x58f15e(0x4a7)]),
              (this["line"][_0x58f15e(0x231)]["y"] =
                this[_0x58f15e(0x4a7)] * this[_0x58f15e(0x229)]),
              (this[_0x58f15e(0x1d5)]["x"] =
                0x0 + Math[_0x58f15e(0x430)](this[_0x58f15e(0x390)]) * -0x14),
              (this[_0x58f15e(0x1d5)]["y"] =
                0x0 + Math[_0x58f15e(0x1c8)](this["_angle"]) * -0x14),
              (this[_0x58f15e(0x1d5)][_0x58f15e(0x1ec)] =
                this[_0x58f15e(0x390)] - Math["PI"] / 0x2),
              (this[_0x58f15e(0x3b3)]["x"] =
                Math[_0x58f15e(0x430)](
                  this[_0x58f15e(0x390)] - Math["PI"] / 0x2,
                ) * 0x0),
              (this[_0x58f15e(0x3b3)]["y"] =
                Math[_0x58f15e(0x1c8)](
                  this[_0x58f15e(0x390)] - Math["PI"] / 0x2,
                ) * 0x0),
              (this["line"][_0x58f15e(0x1ec)] =
                this[_0x58f15e(0x390)] - Math["PI"] / 0x2));
          }),
          Object["defineProperties"](_0x2ab510["prototype"], {
            strength: {
              get: function () {
                var _0x548031 = _0xce473b;
                return this[_0x548031(0x4a7)];
              },
              set: function (_0x4b803c) {
                var _0x56f210 = _0xce473b;
                ((this[_0x56f210(0x4a7)] = _0x4b803c), this[_0x56f210(0xed)]());
              },
            },
            angle: {
              get: function () {
                var _0xd465f5 = _0xce473b;
                return this[_0xd465f5(0x390)];
              },
              set: function (_0x5d9313) {
                var _0x1bf530 = _0xce473b;
                ((this[_0x1bf530(0x390)] = _0x5d9313), this[_0x1bf530(0xed)]());
              },
            },
          }),
          _0x2ab510
        );
      })(),
      _0x54e9a5 = (function () {
        var _0x55e550 = _0x157421;
        const _0x8b0237 = [
            _0x55e550(0x129),
            _0x55e550(0x47b),
            _0x55e550(0x365),
          ],
          _0x19677d = 0x10,
          _0x10fcef = 0.2,
          _0xb4107c = 1.8,
          _0x4764c1 = 0.45,
          _0x2d828a = 0x0,
          _0x4266ba = 0x1;
        function _0x5ca3cc(_0xd596f6, _0x243463) {
          var _0x4c2e17 = _0x55e550;
          (PIXI[_0x4c2e17(0x30a)]["call"](this), (this["_type"] = _0xd596f6));
          var _0x1bd59b = PIXI[_0x4c2e17(0x385)]["fromFrame"](
            _0x8b0237[this["_type"]],
          );
          ((_0x1bd59b[_0x4c2e17(0x4a1)]["x"] = 0.5),
            (_0x1bd59b[_0x4c2e17(0x4a1)]["y"] = 0.45),
            _0x1bd59b[_0x4c2e17(0x231)][_0x4c2e17(0x27e)](0.98),
            this[_0x4c2e17(0x37b)](_0x1bd59b));
          if (_0xd596f6 == 0x1) {
            if (_0x243463 >= 0x0) {
              var _0x252652 = PIXI[_0x4c2e17(0x385)][_0x4c2e17(0x348)](
                _0x4cd129[_0x243463]["icon"],
              );
              ((_0x252652["anchor"]["x"] = 0.5),
                (_0x252652[_0x4c2e17(0x4a1)]["y"] = 0.5),
                _0x252652[_0x4c2e17(0x231)][_0x4c2e17(0x27e)](0.26),
                _0x1bd59b["addChild"](_0x252652));
            }
          }
          var _0x3dd43b = new Animable(_0xbf118[_0x4c2e17(0x1a0)][0x0]);
          ((_0x3dd43b["visible"] = ![]),
            _0x3dd43b[_0x4c2e17(0x231)][_0x4c2e17(0x27e)](0.26),
            _0x3dd43b["anchor"]["set"](0.5),
            this[_0x4c2e17(0x37b)](_0x3dd43b),
            _0x3dd43b[_0x4c2e17(0x320)](
              _0x4c2e17(0x325),
              _0xbf118[_0x4c2e17(0x1a0)],
            ),
            _0x3eeb21["add"](null, _0x3dd43b, ![]),
            (this[_0x4c2e17(0x325)] = _0x3dd43b),
            (this[_0x4c2e17(0x4ae)] = _0x1392b5[_0x4c2e17(0x203)]({
              type: _0x4c2e17(0x19f),
              allowSleep: !![],
              awake: ![],
              bullet: !![],
              angularDamping: _0x10fcef,
              linearDamping: _0xb4107c,
            })));
          var _0x1dd07f = {};
          ((_0x1dd07f[_0x4c2e17(0x48e)] = _0x4764c1),
            (_0x1dd07f[_0x4c2e17(0x37d)] = _0x2d828a),
            (_0x1dd07f[_0x4c2e17(0x36b)] = _0x4266ba),
            (_0x1dd07f[_0x4c2e17(0x42f)] = box2d["Circle"](
              _0x19677d / _0x541423,
              box2d[_0x4c2e17(0x462)](0x0, 0x0),
            )),
            this[_0x4c2e17(0x4ae)][_0x4c2e17(0x471)](_0x1dd07f),
            (this[_0x4c2e17(0x4ae)][_0x4c2e17(0x343)] = "puck"));
        }
        return (
          (_0x5ca3cc[_0x55e550(0x333)] = Object["create"](
            PIXI[_0x55e550(0x30a)]["prototype"],
          )),
          (_0x5ca3cc[_0x55e550(0x333)][_0x55e550(0x36a)] = function () {
            var _0x2f2f9f = _0x55e550;
            if (
              !this[_0x2f2f9f(0x4ae)] ||
              !this[_0x2f2f9f(0x4ae)][_0x2f2f9f(0x262)]()
            )
              return;
            let _0x570100 = this["body"][_0x2f2f9f(0x128)](),
              _0x5f0660 =
                Math[_0x2f2f9f(0x322)](_0x570100["x"]) +
                Math[_0x2f2f9f(0x322)](_0x570100["y"]);
            if (_0x5f0660 < 0.2) this[_0x2f2f9f(0x142)](![]);
          }),
          (_0x5ca3cc[_0x55e550(0x333)][_0x55e550(0x262)] = function (
            _0x1e0042,
          ) {
            var _0x27e20d = _0x55e550;
            if (!this[_0x27e20d(0x4ae)]) return;
            return this[_0x27e20d(0x4ae)][_0x27e20d(0x262)]();
          }),
          (_0x5ca3cc["prototype"]["setAwake"] = function (_0xd89e0d) {
            var _0x4775ee = _0x55e550;
            if (!this[_0x4775ee(0x4ae)]) return;
            this[_0x4775ee(0x4ae)]["setAwake"](_0xd89e0d);
          }),
          (_0x5ca3cc[_0x55e550(0x333)][_0x55e550(0x2c3)] = function () {
            var _0xabfa83 = _0x55e550;
            if (!this[_0xabfa83(0x325)]) return;
            ((this[_0xabfa83(0x325)][_0xabfa83(0x197)] = !![]),
              this[_0xabfa83(0x325)][_0xabfa83(0x32b)]("light", 0x0, 0x14));
          }),
          (_0x5ca3cc[_0x55e550(0x333)]["removeFromWorld"] = function () {
            var _0x122392 = _0x55e550;
            (_0x1392b5["destroyBody"](this[_0x122392(0x4ae)]),
              (this["body"] = null),
              (this[_0x122392(0x325)]["tmp"] = !![]),
              this[_0x122392(0x28c)](this[_0x122392(0x325)]),
              (this[_0x122392(0x325)] = null));
          }),
          (_0x5ca3cc[_0x55e550(0x333)][_0x55e550(0x3c8)] = function () {
            var _0x5e4ceb = _0x55e550;
            if (this[_0x5e4ceb(0x4ae)]) {
              let _0x452d23 = this[_0x5e4ceb(0x4ae)]["getPosition"]();
              ((this["x"] = _0x452d23["x"] * _0x541423),
                (this["y"] = _0x452d23["y"] * _0x541423));
            }
          }),
          Object[_0x55e550(0x211)](_0x5ca3cc["prototype"], {
            worldX: {
              get: function () {
                var _0x1d0471 = _0x55e550;
                return (
                  this[_0x1d0471(0x4ae)][_0x1d0471(0x46a)]()["x"] * _0x541423
                );
              },
              set: function (_0x504ddd) {
                var _0x44fc2c = _0x55e550;
                let _0x4ea135 = this[_0x44fc2c(0x4ae)][_0x44fc2c(0x46a)]();
                ((_0x4ea135["x"] = _0x504ddd / _0x541423),
                  this[_0x44fc2c(0x4ae)][_0x44fc2c(0x2b2)](_0x4ea135),
                  this[_0x44fc2c(0x3c8)]());
              },
            },
            worldY: {
              get: function () {
                var _0x312c6b = _0x55e550;
                return (
                  this[_0x312c6b(0x4ae)][_0x312c6b(0x46a)]()["y"] * _0x541423
                );
              },
              set: function (_0x771f00) {
                var _0x26c3f8 = _0x55e550;
                let _0x52db28 = this[_0x26c3f8(0x4ae)][_0x26c3f8(0x46a)]();
                ((_0x52db28["y"] = _0x771f00 / _0x541423),
                  this[_0x26c3f8(0x4ae)][_0x26c3f8(0x2b2)](_0x52db28),
                  this[_0x26c3f8(0x3c8)]());
              },
            },
          }),
          _0x5ca3cc
        );
      })(),
      _0x13fb80 = (function () {
        var _0x1c0283 = _0x157421;
        const _0x1c6272 = 0x22 * 0.8,
          _0x387cff = 0x5,
          _0x20246e = 2.8,
          _0x11320b = 0.5,
          _0x67a961 = 0x0,
          _0x317e72 = 0x1;
        function _0x4e67e7() {
          var _0x541016 = _0x3797;
          PIXI[_0x541016(0x30a)][_0x541016(0x37a)](this);
          var _0x55c73f = PIXI["Sprite"][_0x541016(0x348)](_0x541016(0x43b));
          (_0x55c73f["anchor"]["set"](0.5),
            _0x55c73f[_0x541016(0x231)]["set"](0.7),
            this[_0x541016(0x37b)](_0x55c73f),
            Tweener[_0x541016(0x3a0)](
              _0x55c73f["scale"],
              { x: 0.6, y: 0.6 },
              { time: 0x46, transition: "bow", loop: -0x1 },
            ),
            Tweener[_0x541016(0x3a0)](
              _0x55c73f,
              { rotation: Math["PI"] * 0x2 },
              { time: 0x64, transition: _0x541016(0x1a6), loop: -0x1 },
            ),
            (this[_0x541016(0x325)] = _0x55c73f));
          var _0x18515c = PIXI[_0x541016(0x385)][_0x541016(0x348)](
            _0x541016(0x179),
          );
          (_0x18515c["anchor"][_0x541016(0x27e)](0.5),
            _0x18515c[_0x541016(0x231)][_0x541016(0x27e)](0.78 * 0.55 * 0.8),
            this[_0x541016(0x37b)](_0x18515c),
            (this["sprite"] = _0x18515c));
          var _0x27bb37 = PIXI[_0x541016(0x385)]["fromFrame"](_0x541016(0x17a));
          (_0x27bb37[_0x541016(0x4a1)]["set"](0.5),
            _0x27bb37[_0x541016(0x231)]["set"](0.8 * 0.8),
            (_0x27bb37["alpha"] = 0.5),
            this["addChild"](_0x27bb37),
            (this[_0x541016(0x3f1)] = _0x27bb37),
            (this[_0x541016(0x4ae)] = _0x1392b5[_0x541016(0x203)]({
              type: "dynamic",
              allowSleep: !![],
              angularDamping: _0x387cff,
              linearDamping: _0x20246e,
              angle: 0x0,
              bullet: !![],
              awake: ![],
            })));
          var _0x3096f3 = {};
          ((_0x3096f3[_0x541016(0x48e)] = _0x11320b),
            (_0x3096f3[_0x541016(0x37d)] = _0x67a961),
            (_0x3096f3[_0x541016(0x36b)] = _0x317e72),
            (_0x3096f3[_0x541016(0x25e)] = !![]),
            (_0x3096f3[_0x541016(0x42f)] = box2d[_0x541016(0x12a)](
              (_0x1c6272 * 0.8) / _0x541423,
              box2d[_0x541016(0x462)](0x0, 0x0),
            )),
            (this[_0x541016(0x461)] =
              this[_0x541016(0x4ae)][_0x541016(0x471)](_0x3096f3)),
            this["body"][_0x541016(0xe0)](),
            (this[_0x541016(0x4ae)]["objectType"] = "striker"),
            (this["_isSensor"] = !![]));
        }
        return (
          (_0x4e67e7[_0x1c0283(0x333)] = Object[_0x1c0283(0x454)](
            PIXI[_0x1c0283(0x30a)][_0x1c0283(0x333)],
          )),
          (_0x4e67e7[_0x1c0283(0x333)][_0x1c0283(0x152)] = function (
            _0x5aee44,
            _0x4b7b13,
          ) {
            var _0x2de23b = _0x1c0283;
            this[_0x2de23b(0x4ae)][_0x2de23b(0x274)](box2d["Vec2"](0x0, 0x0));
          }),
          (_0x4e67e7[_0x1c0283(0x333)][_0x1c0283(0x36a)] = function () {
            var _0x448968 = _0x1c0283;
            if (!this[_0x448968(0x4ae)] || !this[_0x448968(0x4ae)]["isAwake"]())
              return;
            let _0x520066 = this[_0x448968(0x4ae)][_0x448968(0x128)](),
              _0x3d0899 =
                Math[_0x448968(0x322)](_0x520066["x"]) +
                Math[_0x448968(0x322)](_0x520066["y"]);
            if (_0x3d0899 < 0.2) this[_0x448968(0x142)](![]);
          }),
          (_0x4e67e7[_0x1c0283(0x333)]["isAwake"] = function (_0x40370f) {
            var _0x5b71a0 = _0x1c0283;
            if (!this[_0x5b71a0(0x4ae)]) return;
            return this["body"][_0x5b71a0(0x262)]();
          }),
          (_0x4e67e7[_0x1c0283(0x333)][_0x1c0283(0x142)] = function (
            _0x4c198e,
          ) {
            var _0x50cc23 = _0x1c0283;
            this[_0x50cc23(0x4ae)][_0x50cc23(0x142)](_0x4c198e);
          }),
          (_0x4e67e7[_0x1c0283(0x333)][_0x1c0283(0x4c3)] = function (
            _0x242a9b,
          ) {
            var _0x1b1930 = _0x1c0283;
            ((this["_isSensor"] = _0x242a9b),
              this["fixture"][_0x1b1930(0x4c3)](_0x242a9b),
              (this["light"][_0x1b1930(0x197)] = ![]));
          }),
          (_0x4e67e7[_0x1c0283(0x333)][_0x1c0283(0x1cd)] = function (
            _0x521bc6,
            _0x2f31ce,
          ) {
            var _0x5ee06a = _0x1c0283;
            ((this["light"][_0x5ee06a(0x197)] = ![]),
              (this["_isSensor"] = ![]),
              this["fixture"][_0x5ee06a(0x4c3)](![]));
            let _0x4ca61d = new box2d[_0x5ee06a(0x462)](
              _0x521bc6 * Math[_0x5ee06a(0x430)](-_0x2f31ce + Math["PI"]),
              _0x521bc6 * Math[_0x5ee06a(0x1c8)](-_0x2f31ce + Math["PI"]),
            );
            (this[_0x5ee06a(0x4ae)]["setAwake"](!![]),
              this[_0x5ee06a(0x4ae)][_0x5ee06a(0x311)](_0x4ca61d));
          }),
          (_0x4e67e7["prototype"][_0x1c0283(0x3c8)] = function () {
            var _0x4de675 = _0x1c0283;
            let _0x2700a6 = this[_0x4de675(0x4ae)][_0x4de675(0x46a)]();
            ((this["x"] = _0x2700a6["x"] * 0x64),
              (this["y"] = _0x2700a6["y"] * 0x64),
              (this[_0x4de675(0x1ec)] = this["body"][_0x4de675(0x489)]()));
          }),
          Object["defineProperties"](_0x4e67e7["prototype"], {
            isSensor: {
              get: function () {
                var _0x5444dc = _0x1c0283;
                return this[_0x5444dc(0x453)];
              },
              set: function (_0x308817) {
                var _0x1b69c1 = _0x1c0283;
                this[_0x1b69c1(0x453)] = _0x308817;
              },
            },
            value: {
              get: function () {
                var _0xe80902 = _0x1c0283;
                return (
                  (this[_0xe80902(0x38a)]["x"] - MIN_POS) / (MAX_POS - MIN_POS)
                );
              },
              set: function (_0x254300) {
                var _0x190f57 = _0x1c0283;
                this[_0x190f57(0x38a)]["x"] =
                  MIN_POS + _0x254300 * (MAX_POS - MIN_POS);
              },
            },
            worldX: {
              get: function () {
                var _0x187ef6 = _0x1c0283;
                return this[_0x187ef6(0x4ae)]["getPosition"]()["x"] * _0x541423;
              },
              set: function (_0x5720f2) {
                var _0x49d380 = _0x1c0283;
                let _0x4065f4 = this[_0x49d380(0x4ae)][_0x49d380(0x46a)]();
                ((_0x4065f4["x"] = _0x5720f2 / _0x541423),
                  this[_0x49d380(0x4ae)][_0x49d380(0x274)](
                    box2d[_0x49d380(0x462)](0x0, 0x0),
                  ),
                  this[_0x49d380(0x4ae)][_0x49d380(0x2b2)](_0x4065f4),
                  this[_0x49d380(0x3c8)]());
              },
            },
            worldY: {
              get: function () {
                var _0x29e21c = _0x1c0283;
                return this[_0x29e21c(0x4ae)]["getPosition"]()["y"] * _0x541423;
              },
              set: function (_0x43a272) {
                var _0x4ccfdb = _0x1c0283;
                let _0x13391b = this[_0x4ccfdb(0x4ae)][_0x4ccfdb(0x46a)]();
                ((_0x13391b["y"] = _0x43a272 / _0x541423),
                  this[_0x4ccfdb(0x4ae)][_0x4ccfdb(0x274)](
                    box2d[_0x4ccfdb(0x462)](0x0, 0x0),
                  ),
                  this[_0x4ccfdb(0x4ae)]["setPosition"](_0x13391b),
                  this[_0x4ccfdb(0x3c8)]());
              },
            },
          }),
          _0x4e67e7
        );
      })(),
      _0x1c9a24 = (function () {
        var _0x22b026 = _0x157421;
        function _0x31d470() {
          var _0x23a813 = _0x3797;
          PIXI[_0x23a813(0x30a)][_0x23a813(0x37a)](this);
          var _0x2bbeeb =
            PIXI[_0x23a813(0x385)][_0x23a813(0x348)]("Carrom_red");
          (_0x2bbeeb[_0x23a813(0x4a1)][_0x23a813(0x27e)](0.5),
            _0x2bbeeb["scale"][_0x23a813(0x27e)](0.7),
            (_0x2bbeeb["x"] = 0x0),
            (_0x2bbeeb["y"] = 0x0),
            this[_0x23a813(0x37b)](_0x2bbeeb));
          var _0x1a64e5 = new PIXI["BitmapText"]("" + _0x1c2aac[0x0], {
            font: "25px\x20Simonetta_white2",
            fill: 0xffffff,
            align: _0x23a813(0x221),
          });
          (_0x1a64e5[_0x23a813(0x4a1)][_0x23a813(0x27e)](0.5),
            (_0x1a64e5[_0x23a813(0x4a1)]["x"] = 0x0),
            (_0x1a64e5["x"] = _0x2bbeeb["x"] + 0xf),
            (_0x1a64e5["y"] = 0x0),
            this[_0x23a813(0x37b)](_0x1a64e5));
          var _0x3852b2 = PIXI[_0x23a813(0x385)][_0x23a813(0x348)](
            _0x23a813(0x47b),
          );
          (_0x3852b2["anchor"]["set"](0.5),
            _0x3852b2[_0x23a813(0x231)]["set"](0.7),
            (_0x3852b2["x"] = 0x46),
            (_0x3852b2["y"] = 0x0),
            this[_0x23a813(0x37b)](_0x3852b2));
          var _0x4a5d16 = PIXI[_0x23a813(0x385)][_0x23a813(0x348)](
            _0x23a813(0x47b),
          );
          ((_0x4a5d16[_0x23a813(0x197)] = ![]),
            _0x4a5d16["anchor"][_0x23a813(0x27e)](0.5),
            _0x4a5d16[_0x23a813(0x231)]["set"](0.32),
            (_0x4a5d16["x"] = 0x0),
            (_0x4a5d16["y"] = 0x0),
            _0x3852b2[_0x23a813(0x37b)](_0x4a5d16),
            (this[_0x23a813(0x118)] = _0x4a5d16));
          var _0x14e815 = new PIXI[_0x23a813(0x402)]("" + _0x1c2aac[0x1], {
            font: "25px\x20Simonetta_white2",
            fill: 0xffffff,
            align: _0x23a813(0x221),
          });
          (_0x14e815[_0x23a813(0x4a1)][_0x23a813(0x27e)](0.5),
            (_0x14e815["anchor"]["x"] = 0x0),
            (_0x14e815["x"] = _0x3852b2["x"] + 0xf),
            (_0x14e815["y"] = 0x0),
            this[_0x23a813(0x37b)](_0x14e815));
          var _0xbc810 = PIXI[_0x23a813(0x385)][_0x23a813(0x348)](
            _0x23a813(0x365),
          );
          (_0xbc810[_0x23a813(0x4a1)][_0x23a813(0x27e)](0.5),
            _0xbc810["scale"]["set"](0.7),
            (_0xbc810["x"] = 0x8c),
            (_0xbc810["y"] = 0x0),
            this[_0x23a813(0x37b)](_0xbc810));
          var _0x568348 = new PIXI[_0x23a813(0x402)]("" + _0x1c2aac[0x2], {
            font: _0x23a813(0x4a8),
            fill: 0xffffff,
            align: _0x23a813(0x221),
          });
          (_0x568348[_0x23a813(0x4a1)][_0x23a813(0x27e)](0.5),
            (_0x568348["anchor"]["x"] = 0x0),
            (_0x568348["x"] = _0xbc810["x"] + 0xf),
            (_0x568348["y"] = 0x0),
            this[_0x23a813(0x37b)](_0x568348));
        }
        return (
          (_0x31d470[_0x22b026(0x333)] = Object[_0x22b026(0x454)](
            PIXI[_0x22b026(0x30a)][_0x22b026(0x333)],
          )),
          (_0x31d470[_0x22b026(0x333)][_0x22b026(0x3e0)] = function (
            _0xe98004,
          ) {
            var _0x35bd74 = _0x22b026;
            _0xe98004 >= 0x0
              ? ((this[_0x35bd74(0x118)][_0x35bd74(0x197)] = !![]),
                (this[_0x35bd74(0x118)][_0x35bd74(0x335)] =
                  PIXI["utils"][_0x35bd74(0x299)][
                    _0x4cd129[_0xe98004]["icon"]
                  ]))
              : (this["cover"][_0x35bd74(0x197)] = ![]);
          }),
          Object[_0x22b026(0x211)](_0x31d470[_0x22b026(0x333)], {
            value: {
              get: function () {
                var _0x40a869 = _0x22b026;
                return (
                  (this[_0x40a869(0x38a)]["x"] - MIN_POS) / (MAX_POS - MIN_POS)
                );
              },
              set: function (_0x4d75ba) {
                this["striker"]["x"] =
                  MIN_POS + _0x4d75ba * (MAX_POS - MIN_POS);
              },
            },
          }),
          _0x31d470
        );
      })(),
      _0x570109 = (function () {
        var _0xc1b082 = _0x157421,
          _0x5b04f9 = 0x1e,
          _0x58d866 = 0x1ae;
        function _0x1bb809() {
          var _0x214a77 = _0x3797;
          PIXI[_0x214a77(0x30a)][_0x214a77(0x37a)](this);
          var _0x5045e7 = PIXI[_0x214a77(0x385)]["fromFrame"](_0x214a77(0x2af));
          (this["addChild"](_0x5045e7), (this["bg"] = _0x5045e7));
          var _0x8d272 = PIXI["Sprite"]["fromFrame"](_0x214a77(0x22e));
          ((_0x8d272["x"] = -0x14),
            (_0x8d272["y"] = -0x14),
            this[_0x214a77(0x37b)](_0x8d272),
            (this[_0x214a77(0x39a)] = _0x8d272));
          var _0x3084ad =
            PIXI[_0x214a77(0x385)][_0x214a77(0x348)]("Carrom_strike");
          (_0x3084ad[_0x214a77(0x4a1)][_0x214a77(0x27e)](0.5),
            (_0x3084ad["x"] = _0x5b04f9 + (_0x58d866 - _0x5b04f9) / 0x2),
            (_0x3084ad["y"] = 0x1e),
            this["addChild"](_0x3084ad),
            (this[_0x214a77(0x38a)] = _0x3084ad),
            (this[_0x214a77(0x1bf)] = !![]),
            (this[_0x214a77(0x2e6)] = !![]),
            this["on"](
              _0x214a77(0x43e),
              this[_0x214a77(0x219)][_0x214a77(0x374)](this),
            ),
            this["on"](
              _0x214a77(0x39c),
              this[_0x214a77(0xf9)][_0x214a77(0x374)](this),
            ),
            this["on"](
              _0x214a77(0x2ea),
              this[_0x214a77(0xf9)][_0x214a77(0x374)](this),
            ),
            this["on"](
              _0x214a77(0x109),
              this[_0x214a77(0x3db)][_0x214a77(0x374)](this),
            ),
            (this[_0x214a77(0x47d)] = ![]),
            (this[_0x214a77(0x30f)] = 0x0),
            (this[_0x214a77(0x1da)] = 0x0),
            (this[_0x214a77(0x3f5)] = ![]));
        }
        return (
          (_0x1bb809[_0xc1b082(0x333)] = Object[_0xc1b082(0x454)](
            PIXI[_0xc1b082(0x30a)][_0xc1b082(0x333)],
          )),
          (_0x1bb809[_0xc1b082(0x333)][_0xc1b082(0x12d)] = function (
            _0x270e8a,
          ) {
            var _0x38eece = _0xc1b082;
            ((this[_0x38eece(0x3f5)] = _0x270e8a),
              this["_enable"]
                ? ((this[_0x38eece(0xe5)] = 0x1),
                  (this[_0x38eece(0x38a)][_0x38eece(0xe5)] = 0x1))
                : ((this[_0x38eece(0xe5)] = 0.5),
                  (this[_0x38eece(0x38a)]["alpha"] = 0.7)));
          }),
          (_0x1bb809["prototype"][_0xc1b082(0x219)] = function (_0x760f4c) {
            var _0x166638 = _0xc1b082;
            if (!this[_0x166638(0x3f5)]) return;
            if (this[_0x166638(0x47d)]) return;
            ((this[_0x166638(0x47d)] = !![]),
              (this["_dragPosition"] =
                _0x760f4c[_0x166638(0x3ca)]["global"]["x"] - _0x24b13c / 0x2),
              (this[_0x166638(0x1da)] = this[_0x166638(0x38a)]["x"]));
          }),
          (_0x1bb809[_0xc1b082(0x333)]["stopSlide"] = function (_0x61cbdd) {
            var _0x874eb7 = _0xc1b082;
            if (!this[_0x874eb7(0x3f5)]) return;
            if (!this[_0x874eb7(0x47d)]) return;
            ((this[_0x874eb7(0x47d)] = ![]),
              this[_0x874eb7(0xfe)](_0x874eb7(0x421)));
          }),
          (_0x1bb809[_0xc1b082(0x333)][_0xc1b082(0x3db)] = function (
            _0x535374,
          ) {
            var _0x1cadab = _0xc1b082;
            if (!this[_0x1cadab(0x3f5)]) return;
            if (!this[_0x1cadab(0x47d)]) return;
            this[_0x1cadab(0x38a)]["x"] =
              this["_tempPosition"] +
              (_0x535374[_0x1cadab(0x3ca)][_0x1cadab(0x192)]["x"] -
                _0x24b13c / 0x2 -
                this["_dragPosition"]);
            if (this[_0x1cadab(0x38a)]["x"] < _0x5b04f9)
              this["striker"]["x"] = _0x5b04f9;
            else {
              if (this[_0x1cadab(0x38a)]["x"] > _0x58d866)
                this[_0x1cadab(0x38a)]["x"] = _0x58d866;
            }
            this[_0x1cadab(0xfe)](_0x1cadab(0x3c8));
          }),
          Object[_0xc1b082(0x211)](_0x1bb809[_0xc1b082(0x333)], {
            value: {
              get: function () {
                var _0x2960d8 = _0xc1b082;
                return (
                  (this[_0x2960d8(0x38a)]["x"] - _0x5b04f9) /
                  (_0x58d866 - _0x5b04f9)
                );
              },
              set: function (_0x36f5db) {
                var _0x496014 = _0xc1b082;
                this[_0x496014(0x38a)]["x"] =
                  _0x5b04f9 + _0x36f5db * (_0x58d866 - _0x5b04f9);
              },
            },
          }),
          _0x1bb809
        );
      })(),
      _0x3eeb21 = (function () {
        "use strict";
        var _0x275455 = {},
          _0x3c8800 = [],
          _0x5abac4 = {
            add: function (_0x28aaa2, _0x274510, _0x433dea) {
              var _0x1bd12a = _0x3797;
              ((_0x274510[_0x1bd12a(0x49e)] = _0x433dea),
                _0x3c8800[_0x1bd12a(0x3b0)](_0x274510));
            },
            remove: function (_0x40c92e) {
              var _0x50704e = _0x3797,
                _0x1f3f88 = _0x3c8800[_0x50704e(0x1f2)](_0x40c92e);
              _0x1f3f88 > -0x1 && _0x3c8800[_0x50704e(0x242)](_0x1f3f88, 0x1);
            },
            update: function (_0x38aa24) {
              var _0x27fef1 = _0x3797;
              for (
                var _0x555857 = 0x0;
                _0x555857 < _0x3c8800["length"];
                _0x555857++
              ) {
                if (
                  _0x3c8800[_0x555857] &&
                  _0x3c8800[_0x555857][_0x27fef1(0x38d)]
                )
                  _0x3c8800[_0x555857]["update"](_0x38aa24);
                else {
                  if (_0x3c8800[_0x555857][_0x27fef1(0x49e)]) {
                    if (_0x3c8800[_0x555857][_0x27fef1(0x35d)])
                      _0x3c8800[_0x555857][_0x27fef1(0x35d)][_0x27fef1(0x28c)](
                        _0x3c8800[_0x555857],
                      );
                    this["remove"](_0x3c8800[_0x555857]);
                  }
                }
              }
            },
          };
        return _0x5abac4;
      })(),
      _0x28fba8 = (function () {
        var _0x26f0b8 = {},
          _0x4ec372 = {},
          _0x947d2e = {
            play: function (_0x481598, _0x2b31eb) {
              var _0x4c7976 = _0x3797;
              if (!_0x26f0b8[_0x481598]) return;
              (_0x2b31eb && _0x26f0b8[_0x481598]["volume"](_0x2b31eb),
                _0x26f0b8[_0x481598][_0x4c7976(0x383)]());
            },
            stop: function (_0x137819) {
              var _0x44f35b = _0x3797;
              if (!_0x26f0b8[_0x137819]) return;
              _0x26f0b8[_0x137819][_0x44f35b(0x421)]();
            },
            restartLoop: function (_0x246f11) {
              var _0x4a1d00 = _0x3797;
              if (
                !_0x26f0b8[_0x246f11] ||
                !_0x26f0b8[_0x246f11][_0x4a1d00(0x29b)]
              )
                return;
              _0x26f0b8[_0x246f11][_0x4a1d00(0x307)](0x0);
            },
            playLoop: function (_0x75f487) {
              var _0x18c658 = _0x3797;
              if (
                !_0x26f0b8[_0x75f487] ||
                _0x26f0b8[_0x75f487][_0x18c658(0x29b)]
              )
                return;
              ((_0x26f0b8[_0x75f487]["isPlaying"] = !![]),
                _0x26f0b8[_0x75f487][_0x18c658(0x383)]());
            },
            pauseLoop: function (_0x19d85d) {
              var _0x3f0547 = _0x3797;
              if (
                !_0x26f0b8[_0x19d85d] ||
                !_0x26f0b8[_0x19d85d][_0x3f0547(0x29b)]
              )
                return;
              ((_0x26f0b8[_0x19d85d][_0x3f0547(0x29b)] = ![]),
                _0x26f0b8[_0x19d85d]["pause"]());
            },
            stopLoop: function (_0x27099e) {
              var _0x10990c = _0x3797;
              if (
                !_0x26f0b8[_0x27099e] ||
                !_0x26f0b8[_0x27099e][_0x10990c(0x29b)]
              )
                return;
              ((_0x26f0b8[_0x27099e]["isPlaying"] = ![]),
                _0x26f0b8[_0x27099e][_0x10990c(0x421)]());
            },
            register: function (_0x4ad38a, _0x570d00, _0x505ce2) {
              var _0x42084e = _0x3797;
              _0x26f0b8[_0x4ad38a] = _0x570d00;
              if (_0x505ce2) {
                if (!_0x4ec372[_0x505ce2]) _0x4ec372[_0x505ce2] = [];
                _0x4ec372[_0x505ce2][_0x42084e(0x3b0)](_0x4ad38a);
              }
            },
            mute: function (_0x38b7ce) {
              var _0x5d89b8 = _0x3797;
              if (!_0x26f0b8[_0x38b7ce]) return;
              _0x26f0b8[_0x38b7ce][_0x5d89b8(0x187)](!![]);
            },
            unmute: function (_0x2bdce7) {
              var _0x2733bb = _0x3797;
              if (!_0x26f0b8[_0x2bdce7]) return;
              _0x26f0b8[_0x2bdce7][_0x2733bb(0x187)](![]);
            },
            muteGroup: function (_0x5c0175) {
              var _0x2454ae = _0x3797;
              if (!_0x4ec372[_0x5c0175]) return;
              for (
                let _0x1acf08 = 0x0;
                _0x1acf08 < _0x4ec372[_0x5c0175][_0x2454ae(0x182)];
                _0x1acf08++
              )
                _0x26f0b8[_0x4ec372[_0x5c0175][_0x1acf08]][_0x2454ae(0x187)](
                  !![],
                );
            },
            unmuteGroup: function (_0x5b3cce) {
              var _0x5af585 = _0x3797;
              if (!_0x4ec372[_0x5b3cce]) return;
              for (
                let _0x11022a = 0x0;
                _0x11022a < _0x4ec372[_0x5b3cce][_0x5af585(0x182)];
                _0x11022a++
              )
                _0x26f0b8[_0x4ec372[_0x5b3cce][_0x11022a]][_0x5af585(0x187)](
                  ![],
                );
            },
            get: function (_0x185ac6) {
              if (!_0x26f0b8[_0x185ac6]) return;
              return _0x26f0b8[_0x185ac6];
            },
          };
        return _0x947d2e;
      })(),
      _0x566080 = (function () {
        var _0x4ada97 = _0x157421;
        function _0x47543e(_0x3743f) {
          var _0x2cb9d6 = _0x3797;
          PIXI[_0x2cb9d6(0x30a)]["call"](this);
          if (_0x3743f) {
            var _0x6bbc2 = PIXI[_0x2cb9d6(0x385)][_0x2cb9d6(0x348)](_0x3743f);
            (_0x6bbc2[_0x2cb9d6(0x4a1)]["set"](0.5),
              this[_0x2cb9d6(0x37b)](_0x6bbc2));
          }
          ((this[_0x2cb9d6(0x4a4)] = !![]),
            (this[_0x2cb9d6(0x1a1)] = !![]),
            (this["hp"] = 0x64));
        }
        return (
          (_0x47543e[_0x4ada97(0x333)] = Object["create"](
            PIXI["Container"][_0x4ada97(0x333)],
          )),
          _0x47543e
        );
      })(),
      _0x32d81c = (function () {
        "use strict";
        var _0x4b93ad = _0x157421;
        function _0x129b41(_0x5d600d) {
          var _0x5e64ef = _0x3797;
          (PIXI[_0x5e64ef(0x385)][_0x5e64ef(0x37a)](this, _0x5d600d),
            (this["contentOffset"] = 0x0),
            (this[_0x5e64ef(0x1bf)] = !![]),
            (this["buttonMode"] = !![]),
            (this[_0x5e64ef(0x4c5)] = ![]),
            (this[_0x5e64ef(0x4bb)] = ![]),
            (this[_0x5e64ef(0x410)] = ![]),
            (this["pushed"] = ![]),
            (this[_0x5e64ef(0x2fb)] = _0x5d600d),
            this["on"](_0x5e64ef(0x43e), this["onDown"])
              ["on"]("pointerup", this[_0x5e64ef(0x4a3)])
              ["on"]("pointerupoutside", this["onUp"]));
        }
        return (
          (_0x129b41[_0x4b93ad(0x333)] = Object[_0x4b93ad(0x454)](
            PIXI["Sprite"]["prototype"],
          )),
          (_0x129b41[_0x4b93ad(0x333)][_0x4b93ad(0x4a3)] = function () {
            var _0x13738b = _0x4b93ad;
            (!this["pushed"] &&
              ((this[_0x13738b(0x3c0)] = ![]),
              this[_0x13738b(0x12d)](this[_0x13738b(0x1bf)]),
              this[_0x13738b(0x4b4)] &&
                this[_0x13738b(0x4b4)]["scale"][_0x13738b(0x27e)](0x1)),
              this["emit"]("up"));
          }),
          (_0x129b41[_0x4b93ad(0x333)][_0x4b93ad(0x337)] = function () {
            var _0x5a828f = _0x4b93ad;
            this["isdown"] = !![];
            if (this[_0x5a828f(0x2c5)])
              this[_0x5a828f(0x335)] = this[_0x5a828f(0x2c5)];
            (this["content"] &&
              this[_0x5a828f(0x4b4)][_0x5a828f(0x231)][_0x5a828f(0x27e)](0.9),
              _0x28fba8[_0x5a828f(0x383)](_0x5a828f(0x1a9)));
          }),
          (_0x129b41[_0x4b93ad(0x333)][_0x4b93ad(0x3b0)] = function () {
            var _0x281377 = _0x4b93ad;
            ((this[_0x281377(0x4c1)] = !![]), (this["isdown"] = !![]));
            if (this[_0x281377(0x2c5)])
              this[_0x281377(0x335)] = this["textureDown"];
          }),
          (_0x129b41[_0x4b93ad(0x333)][_0x4b93ad(0x232)] = function () {
            var _0x1f6304 = _0x4b93ad;
            ((this[_0x1f6304(0x4c1)] = ![]), this["onUp"]());
          }),
          (_0x129b41[_0x4b93ad(0x333)]["registerState"] = function (
            _0x4a83d4,
            _0x50b3ba,
          ) {
            var _0x244b91 = _0x4b93ad;
            switch (_0x4a83d4) {
              case "up":
                this[_0x244b91(0x2fb)] = _0x50b3ba;
                break;
              case _0x244b91(0x444):
                this["textureDown"] = _0x50b3ba;
                break;
              case _0x244b91(0x451):
                this[_0x244b91(0x22c)] = _0x50b3ba;
                break;
              case "disabled":
                this[_0x244b91(0x2b1)] = _0x50b3ba;
                break;
            }
          }),
          (_0x129b41[_0x4b93ad(0x333)][_0x4b93ad(0x484)] = function () {
            var _0x21be07 = _0x4b93ad;
            if (!this[_0x21be07(0x1bf)] && this[_0x21be07(0x2b1)])
              this["texture"] = this[_0x21be07(0x2b1)];
            else {
              if (this[_0x21be07(0x3c0)] && this[_0x21be07(0x2c5)])
                this["texture"] = this[_0x21be07(0x2c5)];
              else {
                if (this["textureOver"])
                  this[_0x21be07(0x335)] = this[_0x21be07(0x22c)];
                else this[_0x21be07(0x335)] = this[_0x21be07(0x2fb)];
              }
            }
          }),
          (_0x129b41["prototype"][_0x4b93ad(0x12d)] = function (_0x5a0817) {
            var _0x659873 = _0x4b93ad;
            if (_0x5a0817) {
              if (!this["pushed"]) this["texture"] = this[_0x659873(0x2fb)];
              this[_0x659873(0x1bf)] = !![];
            } else {
              if (!this["pushed"])
                this["texture"] =
                  this[_0x659873(0x2b1)] || this[_0x659873(0x2fb)];
              this[_0x659873(0x1bf)] = ![];
            }
          }),
          _0x129b41
        );
      })(),
      _0x568fe1 = (function () {
        var _0x17ee4f = _0x157421;
        const _0x42a342 = 0x1249ad2594c37d0000000000000000000000000000000000000000000000000000000000000000000000;
        let _0x55ce0f = [],
          _0x2f0ef2 = [],
          _0xf0418 = 0x0;
        function _0x19686c(_0x5c9ef2, _0x5b8ac5) {
          var _0x3c1b20 = _0x3797;
          if (_0x5c9ef2["zOrder"] > _0x5b8ac5[_0x3c1b20(0x43d)]) return 0x1;
          if (_0x5c9ef2[_0x3c1b20(0x43d)] < _0x5b8ac5[_0x3c1b20(0x43d)])
            return -0x1;
          if (_0x5c9ef2[_0x3c1b20(0x2e1)] > _0x5b8ac5[_0x3c1b20(0x2e1)])
            return 0x1;
          if (_0x5c9ef2["arrivalOrder"] < _0x5b8ac5[_0x3c1b20(0x2e1)])
            return -0x1;
          return 0x0;
        }
        function _0x4ffc23() {
          var _0x57aeb3 = _0x3797;
          (PIXI[_0x57aeb3(0x30a)][_0x57aeb3(0x37a)](this),
            (this[_0x57aeb3(0x237)] = function (_0x2bbdfb, _0xf0091b) {
              var _0x4b7a11 = _0x57aeb3;
              ((_0x2bbdfb[_0x4b7a11(0x43d)] = _0xf0091b || 0x0),
                (_0x2bbdfb[_0x4b7a11(0x224)] = _0x42a342),
                (_0x2bbdfb[_0x4b7a11(0x2e1)] = ++_0xf0418),
                this[_0x4b7a11(0x37b)](_0x2bbdfb));
            }),
            (this[_0x57aeb3(0x1ac)] = function () {
              var _0x4d3683 = _0x57aeb3;
              const _0x7f8ebe = this[_0x4d3683(0x3f9)];
              let _0x1f6834 = _0x7f8ebe[_0x4d3683(0x182)];
              for (let _0x3f96d9 = 0x0; _0x3f96d9 < _0x1f6834; _0x3f96d9++) {
                const _0x5aa4bd = _0x7f8ebe[_0x3f96d9];
                (_0x5aa4bd["zOrder"] !== _0x5aa4bd[_0x4d3683(0x224)]
                  ? _0x55ce0f["push"](_0x5aa4bd)
                  : _0x2f0ef2["push"](_0x5aa4bd),
                  (_0x5aa4bd[_0x4d3683(0x224)] = _0x5aa4bd[_0x4d3683(0x43d)]));
              }
              if (_0x55ce0f["length"] === 0x0) {
                _0x2f0ef2[_0x4d3683(0x182)] = 0x0;
                return;
              }
              _0x55ce0f[_0x4d3683(0x182)] > 0x1 &&
                _0x55ce0f[_0x4d3683(0x22d)](_0x19686c);
              let _0x1c0b00 = 0x0,
                _0x46d04d = 0x0,
                _0x13311a = 0x0;
              while (
                _0x46d04d < _0x55ce0f[_0x4d3683(0x182)] &&
                _0x13311a < _0x2f0ef2[_0x4d3683(0x182)]
              ) {
                _0x19686c(_0x55ce0f[_0x46d04d], _0x2f0ef2[_0x13311a]) < 0x0
                  ? (_0x7f8ebe[_0x1c0b00++] = _0x55ce0f[_0x46d04d++])
                  : (_0x7f8ebe[_0x1c0b00++] = _0x2f0ef2[_0x13311a++]);
              }
              while (_0x46d04d < _0x55ce0f["length"]) {
                _0x7f8ebe[_0x1c0b00++] = _0x55ce0f[_0x46d04d++];
              }
              while (_0x13311a < _0x2f0ef2[_0x4d3683(0x182)]) {
                _0x7f8ebe[_0x1c0b00++] = _0x2f0ef2[_0x13311a++];
              }
              ((_0x55ce0f[_0x4d3683(0x182)] = 0x0),
                (_0x2f0ef2[_0x4d3683(0x182)] = 0x0));
            }));
        }
        return (
          (_0x4ffc23["prototype"] = Object["create"](
            PIXI[_0x17ee4f(0x30a)][_0x17ee4f(0x333)],
          )),
          _0x4ffc23
        );
      })();
    const _0x434610 = (function () {
      var _0x322ed6 = _0x157421;
      function _0x563167(_0x542785) {}
      return (
        (_0x563167["game"] = {
          ready: function () {},
          levelComplete: function () {},
          gameOver: function () {},
        }),
        (_0x563167["audio"] = {
          isEnabled: function () {
            return !![];
          },
          subscribe: function () {},
        }),
        (_0x563167["ad"] = {
          break: function (_0x3c6d55) {
            var _0x4bc40e = _0x3797;
            if (_0x3c6d55[_0x4bc40e(0x12e)] == "next") {
              if (_0x3c6d55[_0x4bc40e(0x286)]) _0x3c6d55[_0x4bc40e(0x286)]();
            } else
              _0x3c6d55["beforeReward"] &&
                _0x3c6d55[_0x4bc40e(0x427)](() => {
                  _0x3c6d55["adViewed"]();
                });
          },
        }),
        (_0x563167["score"] = { update: function () {} }),
        (_0x563167[_0x322ed6(0x3e5)] = {
          getItem: function () {},
          setItem: function () {},
          removeItem: function () {},
          clear: function () {},
        }),
        _0x563167
      );
    })();
    return _0x125d76;
  })();
game[_0x4a128a(0x487)]();
var Tweener = (function () {
  var _0x397e69 = _0x4a128a,
    _0x3b9b16 = {
      tweens: [],
      loop: !![],
      params: { time: 0x1, transition: "linear", delay: 0x0, variant: 0x0 },
      fallbacks: { onStart: null, onUpdate: null, onComplete: null },
    };
  return (
    (_0x3b9b16["update"] = function (_0x3bf18d) {
      var _0x101dbb = _0x3797;
      for (
        var _0x9de64e = 0x0;
        _0x9de64e < _0x3b9b16["tweens"][_0x101dbb(0x182)];
        _0x9de64e++
      ) {
        let _0x47da4b = _0x3b9b16["tweens"][_0x9de64e];
        _0x47da4b[_0x101dbb(0x28d)] && _0x47da4b[_0x101dbb(0x3c8)](_0x3bf18d);
      }
    }),
    (_0x3b9b16[_0x397e69(0x29f)] = function () {
      var _0x56fb47 = _0x397e69;
      let _0x3f0930 = _0x3b9b16["tweens"][_0x56fb47(0x3c6)](0x0);
      for (
        var _0xefb139 = 0x0;
        _0xefb139 < _0x3f0930[_0x56fb47(0x182)];
        _0xefb139++
      ) {
        !_0x3f0930[_0xefb139]["def"]["loop"] && _0x3f0930[_0xefb139]["stop"]();
      }
    }),
    (_0x3b9b16[_0x397e69(0x40a)] = function (_0x239cf8) {
      var _0x5d2bc3 = _0x397e69;
      for (
        var _0x18d21b = 0x0;
        _0x18d21b < _0x3b9b16[_0x5d2bc3(0x42a)][_0x5d2bc3(0x182)];
        _0x18d21b++
      ) {
        if (_0x3b9b16["tweens"][_0x18d21b][_0x5d2bc3(0x2e9)] == _0x239cf8) {
          _0x3b9b16[_0x5d2bc3(0x42a)][_0x18d21b]["finish"]();
          break;
        }
      }
    }),
    (_0x3b9b16[_0x397e69(0x282)] = function (_0x2ee562) {
      var _0x2dd1db = _0x397e69;
      for (
        var _0x58ecf9 = 0x0;
        _0x58ecf9 < _0x3b9b16[_0x2dd1db(0x42a)][_0x2dd1db(0x182)];
        _0x58ecf9++
      ) {
        if (_0x3b9b16[_0x2dd1db(0x42a)][_0x58ecf9]["_target"] == _0x2ee562) {
          _0x3b9b16[_0x2dd1db(0x42a)][_0x58ecf9][_0x2dd1db(0x282)]();
          break;
        }
      }
    }),
    (_0x3b9b16["restart"] = function (_0x1c1fce) {
      var _0x12af7c = _0x397e69;
      for (
        var _0x1f9a06 = 0x0;
        _0x1f9a06 < _0x3b9b16[_0x12af7c(0x42a)]["length"];
        _0x1f9a06++
      ) {
        if (_0x3b9b16["tweens"][_0x1f9a06][_0x12af7c(0x2e9)] == _0x1c1fce) {
          _0x3b9b16[_0x12af7c(0x42a)][_0x1f9a06][_0x12af7c(0x1a2)]();
          break;
        }
      }
    }),
    (_0x3b9b16[_0x397e69(0x469)] = function (_0x304cea) {
      var _0x127341 = _0x397e69;
      for (
        var _0x5c0160 = 0x0;
        _0x5c0160 < _0x3b9b16[_0x127341(0x42a)]["length"];
        _0x5c0160++
      ) {
        if (_0x3b9b16[_0x127341(0x42a)][_0x5c0160]["_target"] === _0x304cea) {
          _0x3b9b16[_0x127341(0x42a)][_0x5c0160][_0x127341(0x421)]();
          break;
        }
      }
    }),
    (_0x3b9b16["addTween"] = function (_0xf99ff, _0x1e35e1, _0x5a3070) {
      var _0x2bc873 = _0x397e69,
        _0x3d4049 = _0x3b9b16;
      _0x3b9b16[_0x2bc873(0x469)](_0xf99ff);
      var _0x69fae6 = new _0x3d4049[_0x2bc873(0x107)](
        _0xf99ff,
        _0x1e35e1,
        _0x5a3070,
      );
      (_0x3d4049[_0x2bc873(0x42a)][_0x2bc873(0x3b0)](_0x69fae6),
        _0x69fae6[_0x2bc873(0x431)]());
    }),
    (_0x3b9b16[_0x397e69(0x27b)] = function (
      _0x3da72b,
      _0x11ddcf,
      _0x173a72,
    ) {}),
    (_0x3b9b16["Tween"] = function (_0x45063, _0x289f47, _0x3914b8) {
      var _0x411673 = _0x397e69;
      ((this[_0x411673(0x2e9)] = _0x45063),
        (this[_0x411673(0x354)] = []),
        (this[_0x411673(0xdd)] = {}),
        (this[_0x411673(0x193)] = {}),
        (this[_0x411673(0x2e8)] = {}),
        (this[_0x411673(0x28d)] = ![]),
        (this[_0x411673(0x257)] = 0x0),
        (this[_0x411673(0xe6)] = {
          time: 0x19,
          delay: 0x0,
          transition: _0x411673(0x1a6),
          variant: 0x0,
          onStart: null,
          onUpdate: null,
          onComplete: null,
          loop: ![],
        }));
      if (_0x3914b8) {
        for (var _0x2ce369 in this[_0x411673(0xe6)])
          this[_0x411673(0xe6)][_0x2ce369] = _0x3914b8[_0x2ce369]
            ? _0x3914b8[_0x2ce369]
            : this[_0x411673(0xe6)][_0x2ce369];
      }
      for (var _0x22dd0b in _0x289f47) {
        (this[_0x411673(0x354)][_0x411673(0x3b0)](_0x22dd0b),
          (this[_0x411673(0x193)][_0x22dd0b] = _0x45063[_0x22dd0b]),
          (this[_0x411673(0xdd)][_0x22dd0b] =
            _0x289f47[_0x22dd0b] - _0x45063[_0x22dd0b]),
          (this[_0x411673(0x2e8)][_0x22dd0b] = _0x289f47[_0x22dd0b]));
      }
      this["_delay"] = this[_0x411673(0xe6)][_0x411673(0x1a8)];
    }),
    (_0x3b9b16[_0x397e69(0x107)][_0x397e69(0x333)]["start"] = function () {
      this["_running"] = !![];
    }),
    (_0x3b9b16[_0x397e69(0x107)][_0x397e69(0x333)][_0x397e69(0x421)] =
      function () {
        var _0x496ad4 = _0x397e69;
        this[_0x496ad4(0x28d)] = ![];
        var _0x2e52cf = _0x3b9b16[_0x496ad4(0x42a)];
        _0x2e52cf[_0x496ad4(0x242)](_0x2e52cf[_0x496ad4(0x1f2)](this), 0x1);
      }),
    (_0x3b9b16["Tween"][_0x397e69(0x333)][_0x397e69(0x282)] = function () {
      var _0x4b24d0 = _0x397e69;
      if (!this["_running"]) return;
      this[_0x4b24d0(0x28d)] = ![];
    }),
    (_0x3b9b16[_0x397e69(0x107)]["prototype"][_0x397e69(0x1a2)] = function () {
      var _0x3b5639 = _0x397e69;
      (!this["_running"] && (this[_0x3b5639(0x28d)] = !![]),
        (this[_0x3b5639(0x1be)] = 0x0));
    }),
    (_0x3b9b16[_0x397e69(0x107)][_0x397e69(0x333)][_0x397e69(0x40a)] =
      function () {
        var _0x10f54a = _0x397e69;
        for (
          var _0x42bf36 = 0x0;
          _0x42bf36 < this[_0x10f54a(0x354)][_0x10f54a(0x182)];
          _0x42bf36++
        ) {
          var _0x1f0e27 = this[_0x10f54a(0x354)][_0x42bf36];
          this[_0x10f54a(0x2e9)][_0x1f0e27] =
            this[_0x10f54a(0x193)][_0x1f0e27] +
            this[_0x10f54a(0xdd)][_0x1f0e27];
        }
        if (this[_0x10f54a(0xe6)][_0x10f54a(0x4cb)])
          this["def"][_0x10f54a(0x4cb)](this[_0x10f54a(0x2e9)]);
        this[_0x10f54a(0x421)]();
      }),
    (_0x3b9b16[_0x397e69(0x107)][_0x397e69(0x333)][_0x397e69(0x3c8)] =
      function (_0x3e44fd) {
        var _0x51b509 = _0x397e69,
          _0x3df152 = _0x3b9b16,
          _0x1ac711 = _0x3e44fd,
          _0x4df105 = this;
        if (this[_0x51b509(0x2fd)] > 0x0) {
          this[_0x51b509(0x2fd)] -= _0x1ac711;
          if (this[_0x51b509(0x2fd)] <= 0x0 && this[_0x51b509(0xe6)]["onStart"])
            this[_0x51b509(0xe6)][_0x51b509(0x360)](this[_0x51b509(0x2e9)]);
        } else {
          var _0x2bd61d = ![],
            _0x3b6059 = this["def"]["time"];
          this["_elapsed"] += _0x1ac711;
          if (this[_0x51b509(0x257)] < 0x0) this[_0x51b509(0x257)] = 0x0;
          else {
            if (
              this[_0x51b509(0x257)] + _0x1ac711 / 0x2 >
              this[_0x51b509(0xe6)]["time"]
            )
              this[_0x51b509(0x257)] = this[_0x51b509(0xe6)]["time"];
          }
          var _0x587e19 =
              this[_0x51b509(0x257)] / this[_0x51b509(0xe6)][_0x51b509(0x149)],
            _0x573b43 = _0x3b9b16[_0x51b509(0x2f6)][
              this[_0x51b509(0xe6)][_0x51b509(0x1ce)]
            ](_0x587e19, this["def"]["variant"]);
          for (
            var _0x5a8431 = 0x0;
            _0x5a8431 < this[_0x51b509(0x354)][_0x51b509(0x182)];
            _0x5a8431++
          ) {
            var _0x247f32 = this["_prms"][_0x5a8431];
            if (this[_0x51b509(0x2e8)][_0x247f32][_0x51b509(0x194)] === Array) {
              var _0x594c4b =
                  (this["_propsEnd"][_0x247f32][_0x51b509(0x182)] - 0x1) *
                  _0x573b43,
                _0x186e4a = Math[_0x51b509(0x14a)](_0x594c4b),
                _0x20077f = 0x1 - (_0x186e4a - _0x594c4b),
                _0x32c289 =
                  _0x186e4a > 0x0
                    ? this[_0x51b509(0x2e8)][_0x247f32][_0x186e4a - 0x1]
                    : this[_0x51b509(0x193)][_0x247f32],
                _0x3aafb6 = this["_propsEnd"][_0x247f32][_0x186e4a];
              this["_target"][_0x247f32] != _0x3aafb6 &&
                ((dirty = !![]),
                (this[_0x51b509(0x2e9)][_0x247f32] =
                  _0x32c289 + (_0x3aafb6 - _0x32c289) * _0x20077f));
            } else
              this["_target"][_0x247f32] =
                this["_propsStart"][_0x247f32] +
                (this["_propsEnd"][_0x247f32] -
                  this[_0x51b509(0x193)][_0x247f32]) *
                  _0x573b43;
          }
          if (this[_0x51b509(0xe6)][_0x51b509(0x10f)])
            this[_0x51b509(0xe6)]["onUpdate"](this["_target"], _0x587e19);
          if (this[_0x51b509(0x257)] >= _0x3b6059) {
            if (this[_0x51b509(0xe6)][_0x51b509(0x12c)]) {
              if (this[_0x51b509(0xe6)]["loop"] > 0x0)
                this["def"][_0x51b509(0x12c)]--;
              ((this[_0x51b509(0x257)] = 0x0),
                (this[_0x51b509(0x2fd)] =
                  this[_0x51b509(0xe6)][_0x51b509(0x1a8)]));
              if (this["def"]["onComplete"])
                this["def"][_0x51b509(0x4cb)](
                  this[_0x51b509(0x2e9)],
                  this[_0x51b509(0xe6)][_0x51b509(0x12c)],
                  this,
                );
            } else {
              this[_0x51b509(0x421)]();
              if (this[_0x51b509(0xe6)][_0x51b509(0x4cb)])
                this["def"]["onComplete"](this[_0x51b509(0x2e9)], this);
            }
          }
        }
      }),
    (_0x3b9b16[_0x397e69(0x2f6)] = {
      linear: function (_0x1bb45f) {
        return _0x1bb45f;
      },
      easeInElastic: function (_0x58e841, _0x56ffae, _0x13c26f, _0x2f8ad5) {
        var _0x11d705 = _0x397e69,
          _0x21ff55 = 1.70158,
          _0x5b1868 = 0x0,
          _0x1fd9b3 = _0x13c26f;
        if (_0x58e841 == 0x0) return _0x56ffae;
        if ((_0x58e841 /= _0x2f8ad5) == 0x1) return _0x56ffae + _0x13c26f;
        if (!_0x5b1868) _0x5b1868 = _0x2f8ad5 * 0.3;
        if (_0x1fd9b3 < Math[_0x11d705(0x322)](_0x13c26f)) {
          _0x1fd9b3 = _0x13c26f;
          var _0x21ff55 = _0x5b1868 / 0x4;
        } else
          var _0x21ff55 =
            (_0x5b1868 / (0x2 * Math["PI"])) *
            Math[_0x11d705(0x388)](_0x13c26f / _0x1fd9b3);
        return (
          -(
            _0x1fd9b3 *
            Math["pow"](0x2, 0xa * (_0x58e841 -= 0x1)) *
            Math[_0x11d705(0x1c8)](
              ((_0x58e841 * _0x2f8ad5 - _0x21ff55) * (0x2 * Math["PI"])) /
                _0x5b1868,
            )
          ) + _0x56ffae
        );
      },
      bow: function (_0x2bca1e) {
        return Math["sin"](_0x2bca1e * Math["PI"]);
      },
      bounc: function (_0x23bea0) {
        return Math["sin"](0x3 * _0x23bea0 * Math["PI"]);
      },
      experimental: function (_0x1cd641) {
        return Math["sin"](_0x1cd641 * Math["PI"]);
      },
      easeOutSine: function (_0x46025e) {
        var _0x520b7f = _0x397e69;
        return (
          0x1 * Math[_0x520b7f(0x1c8)]((_0x46025e / 0x1) * (Math["PI"] / 0x2))
        );
      },
      easeOutCubic: function (_0x37edc0) {
        return (
          0x1 *
          ((_0x37edc0 = _0x37edc0 / 0x1 - 0x1) * _0x37edc0 * _0x37edc0 + 0x1)
        );
      },
      easeOutBounce: function (_0xe24434) {
        if (_0xe24434 < 0x1 / 2.75)
          return 0x1 * (7.5625 * _0xe24434 * _0xe24434);
        else {
          if (_0xe24434 < 0x2 / 2.75)
            return (
              (_0xe24434 -= 1.5 / 2.75),
              0x1 * (7.5625 * _0xe24434 * _0xe24434 + 0.75)
            );
          else {
            if (_0xe24434 < 2.5 / 2.75)
              return (
                (_0xe24434 -= 2.25 / 2.75),
                0x1 * (7.5625 * _0xe24434 * _0xe24434 + 0.9375)
              );
            else {
              _0xe24434 -= 1.5 / 2.75;
              if (7.5625 * _0xe24434 * _0xe24434 + 0.8575 > 0x1) return 0x1;
              else return 7.5625 * _0xe24434 * _0xe24434 + 0.8575;
            }
          }
        }
      },
      easeInOutBack: function (_0x1bc6e5) {
        var _0x1d1e4b = 1.70158;
        if ((_0x1bc6e5 /= 0x1 / 0x2) < 0x1)
          return (
            (0x1 / 0x2) *
            (_0x1bc6e5 *
              _0x1bc6e5 *
              (((_0x1d1e4b *= 1.525) + 0x1) * _0x1bc6e5 - _0x1d1e4b))
          );
        return (
          (0x1 / 0x2) *
          ((_0x1bc6e5 -= 0x2) *
            _0x1bc6e5 *
            (((_0x1d1e4b *= 1.525) + 0x1) * _0x1bc6e5 + _0x1d1e4b) +
            0x2)
        );
      },
      easeInQuad: function (_0x5c9706) {
        return _0x5c9706 * _0x5c9706;
      },
      easeOutQuad: function (_0x30f61e) {
        return -0x1 * _0x30f61e * (_0x30f61e - 0x2);
      },
      easeInOutQuad: function (_0x13d7e2) {
        if ((_0x13d7e2 /= 0x1 / 0x2) < 0x1)
          return (0x1 / 0x2) * _0x13d7e2 * _0x13d7e2;
        return (-0x1 / 0x2) * (--_0x13d7e2 * (_0x13d7e2 - 0x2) - 0x1);
      },
      easeInCubic: function (_0x16ab24) {
        return _0x16ab24 * _0x16ab24 * _0x16ab24;
      },
      easeOutCubic: function (_0x3f11cf) {
        return (
          0x1 *
          ((_0x3f11cf = _0x3f11cf / 0x1 - 0x1) * _0x3f11cf * _0x3f11cf + 0x1)
        );
      },
      easeInOutCubic: function (_0x5c6206) {
        if ((_0x5c6206 /= 0x1 / 0x2) < 0x1)
          return (0x1 / 0x2) * _0x5c6206 * _0x5c6206 * _0x5c6206;
        return (0x1 / 0x2) * ((_0x5c6206 -= 0x2) * _0x5c6206 * _0x5c6206 + 0x2);
      },
      easeInQuart: function (_0x20bc99) {
        return _0x20bc99 * _0x20bc99 * _0x20bc99 * _0x20bc99;
      },
      easeOutQuart: function (_0x4cb16d) {
        return (
          -0x1 *
          ((_0x4cb16d = _0x4cb16d / 0x1 - 0x1) *
            _0x4cb16d *
            _0x4cb16d *
            _0x4cb16d -
            0x1)
        );
      },
      easeInOutQuart: function (_0x5b6458) {
        if ((_0x5b6458 /= 0x1 / 0x2) < 0x1)
          return (0x1 / 0x2) * _0x5b6458 * _0x5b6458 * _0x5b6458 * _0x5b6458;
        return (
          (-0x1 / 0x2) *
          ((_0x5b6458 -= 0x2) * _0x5b6458 * _0x5b6458 * _0x5b6458 - 0x2)
        );
      },
      easeInQuint: function (_0x4497d6) {
        return (
          0x1 *
          (_0x4497d6 /= 0x1) *
          _0x4497d6 *
          _0x4497d6 *
          _0x4497d6 *
          _0x4497d6
        );
      },
      easeOutQuint: function (_0x31019a) {
        return (
          0x1 *
          ((_0x31019a = _0x31019a / 0x1 - 0x1) *
            _0x31019a *
            _0x31019a *
            _0x31019a *
            _0x31019a +
            0x1)
        );
      },
      easeInOutQuint: function (_0x1ecb92) {
        if ((_0x1ecb92 /= 0x1 / 0x2) < 0x1)
          return (
            (0x1 / 0x2) *
            _0x1ecb92 *
            _0x1ecb92 *
            _0x1ecb92 *
            _0x1ecb92 *
            _0x1ecb92
          );
        return (
          (0x1 / 0x2) *
          ((_0x1ecb92 -= 0x2) * _0x1ecb92 * _0x1ecb92 * _0x1ecb92 * _0x1ecb92 +
            0x2)
        );
      },
      easeInSine: function (_0x4b43bc) {
        var _0x4da0e0 = _0x397e69;
        return (
          -0x1 *
            Math[_0x4da0e0(0x430)]((_0x4b43bc / 0x1) * (Math["PI"] / 0x2)) +
          0x1
        );
      },
      easeOutSine: function (_0x515fb0) {
        return 0x1 * Math["sin"]((_0x515fb0 / 0x1) * (Math["PI"] / 0x2));
      },
      easeInOutSine: function (_0x1cdaed) {
        var _0x2e4927 = _0x397e69;
        return (
          (-0x1 / 0x2) *
          (Math[_0x2e4927(0x430)]((Math["PI"] * _0x1cdaed) / 0x1) - 0x1)
        );
      },
      easeInExpo: function (_0x2238fe) {
        return _0x2238fe === 0x0
          ? 0x1
          : 0x1 * Math["pow"](0x2, 0xa * (_0x2238fe / 0x1 - 0x1));
      },
      easeOutExpo: function (_0x4d426b) {
        return _0x4d426b === 0x1
          ? 0x1
          : 0x1 * (-Math["pow"](0x2, (-0xa * _0x4d426b) / 0x1) + 0x1);
      },
      easeInOutExpo: function (_0x39c6d0) {
        var _0x3c0fad = _0x397e69;
        if (_0x39c6d0 === 0x0) return 0x0;
        if (_0x39c6d0 === 0x1) return 0x1;
        if ((_0x39c6d0 /= 0x1 / 0x2) < 0x1)
          return (
            (0x1 / 0x2) * Math[_0x3c0fad(0x3fa)](0x2, 0xa * (_0x39c6d0 - 0x1))
          );
        return (
          (0x1 / 0x2) * (-Math[_0x3c0fad(0x3fa)](0x2, -0xa * --_0x39c6d0) + 0x2)
        );
      },
      easeInCirc: function (_0x193487) {
        var _0x3d6571 = _0x397e69;
        if (_0x193487 >= 0x1) return _0x193487;
        return (
          -0x1 *
          (Math[_0x3d6571(0x3bb)](0x1 - (_0x193487 /= 0x1) * _0x193487) - 0x1)
        );
      },
      easeOutCirc: function (_0x274518) {
        var _0x524580 = _0x397e69;
        return (
          0x1 *
          Math[_0x524580(0x3bb)](
            0x1 - (_0x274518 = _0x274518 / 0x1 - 0x1) * _0x274518,
          )
        );
      },
      easeInOutCirc: function (_0x5f2f7b) {
        var _0x5c5902 = _0x397e69;
        if ((_0x5f2f7b /= 0x1 / 0x2) < 0x1)
          return (
            (-0x1 / 0x2) *
            (Math[_0x5c5902(0x3bb)](0x1 - _0x5f2f7b * _0x5f2f7b) - 0x1)
          );
        return (
          (0x1 / 0x2) *
          (Math[_0x5c5902(0x3bb)](0x1 - (_0x5f2f7b -= 0x2) * _0x5f2f7b) + 0x1)
        );
      },
      easeInElastic: function (_0x2bf195) {
        var _0x10e7a9 = _0x397e69,
          _0x47e9ca = 1.70158,
          _0x3ffcb0 = 0x0,
          _0x4fecd1 = 0x1;
        if (_0x2bf195 === 0x0) return 0x0;
        if ((_0x2bf195 /= 0x1) == 0x1) return 0x1;
        return (
          !_0x3ffcb0 && (_0x3ffcb0 = 0x1 * 0.3),
          _0x4fecd1 < Math[_0x10e7a9(0x322)](0x1)
            ? ((_0x4fecd1 = 0x1), (_0x47e9ca = _0x3ffcb0 / 0x4))
            : (_0x47e9ca =
                (_0x3ffcb0 / (0x2 * Math["PI"])) *
                Math["asin"](0x1 / _0x4fecd1)),
          -(
            _0x4fecd1 *
            Math["pow"](0x2, 0xa * (_0x2bf195 -= 0x1)) *
            Math[_0x10e7a9(0x1c8)](
              ((_0x2bf195 * 0x1 - _0x47e9ca) * (0x2 * Math["PI"])) / _0x3ffcb0,
            )
          )
        );
      },
      easeOutElastic: function (_0x1225b6) {
        var _0x1a4109 = _0x397e69,
          _0x3a448f = 1.70158,
          _0x3d5a7a = 0x0,
          _0x5ebe08 = 0x1;
        if (_0x1225b6 === 0x0) return 0x0;
        if ((_0x1225b6 /= 0x1) == 0x1) return 0x1;
        return (
          !_0x3d5a7a && (_0x3d5a7a = 0x1 * 0.3),
          _0x5ebe08 < Math[_0x1a4109(0x322)](0x1)
            ? ((_0x5ebe08 = 0x1), (_0x3a448f = _0x3d5a7a / 0x4))
            : (_0x3a448f =
                (_0x3d5a7a / (0x2 * Math["PI"])) *
                Math[_0x1a4109(0x388)](0x1 / _0x5ebe08)),
          _0x5ebe08 *
            Math[_0x1a4109(0x3fa)](0x2, -0xa * _0x1225b6) *
            Math[_0x1a4109(0x1c8)](
              ((_0x1225b6 * 0x1 - _0x3a448f) * (0x2 * Math["PI"])) / _0x3d5a7a,
            ) +
            0x1
        );
      },
      easeInOutElastic: function (_0x15526e) {
        var _0xd8fedc = _0x397e69,
          _0x1c0e93 = 1.70158,
          _0x338127 = 0x0,
          _0x3ace05 = 0x1;
        if (_0x15526e === 0x0) return 0x0;
        if ((_0x15526e /= 0x1 / 0x2) == 0x2) return 0x1;
        !_0x338127 && (_0x338127 = 0x1 * (0.3 * 1.5));
        _0x3ace05 < Math[_0xd8fedc(0x322)](0x1)
          ? ((_0x3ace05 = 0x1), (_0x1c0e93 = _0x338127 / 0x4))
          : (_0x1c0e93 =
              (_0x338127 / (0x2 * Math["PI"])) *
              Math[_0xd8fedc(0x388)](0x1 / _0x3ace05));
        if (_0x15526e < 0x1)
          return (
            -0.5 *
            (_0x3ace05 *
              Math[_0xd8fedc(0x3fa)](0x2, 0xa * (_0x15526e -= 0x1)) *
              Math["sin"](
                ((_0x15526e * 0x1 - _0x1c0e93) * (0x2 * Math["PI"])) /
                  _0x338127,
              ))
          );
        return (
          _0x3ace05 *
            Math[_0xd8fedc(0x3fa)](0x2, -0xa * (_0x15526e -= 0x1)) *
            Math[_0xd8fedc(0x1c8)](
              ((_0x15526e * 0x1 - _0x1c0e93) * (0x2 * Math["PI"])) / _0x338127,
            ) *
            0.5 +
          0x1
        );
      },
      easeInBack: function (_0x1434f6) {
        var _0x4d0dee = 1.70158;
        return (
          0x1 *
          (_0x1434f6 /= 0x1) *
          _0x1434f6 *
          ((_0x4d0dee + 0x1) * _0x1434f6 - _0x4d0dee)
        );
      },
      custom: function (_0x54cdd6, _0x153ee3) {
        if (_0x54cdd6 < 0.5) return 0x0;
        else return Math["sin"](_0x54cdd6 * Math["PI"] * 0x2 + Math["PI"]);
      },
      easeOutBack: function (_0x4fec58) {
        var _0x2d54fd = 1.70158;
        return (
          0x1 *
          ((_0x4fec58 / 0x1 - 0x1) *
            (_0x4fec58 / 0x1 - 0x1) *
            ((1.70158 + 0x1) * (_0x4fec58 / 0x1 - 0x1) + 1.70158) +
            0x1)
        );
      },
      easeInOutBack: function (_0x3392ce) {
        var _0x349969 = 1.70158;
        if ((_0x3392ce /= 0x1 / 0x2) < 0x1)
          return (
            (0x1 / 0x2) *
            (_0x3392ce *
              _0x3392ce *
              (((_0x349969 *= 1.525) + 0x1) * _0x3392ce - _0x349969))
          );
        return (
          (0x1 / 0x2) *
          ((_0x3392ce -= 0x2) *
            _0x3392ce *
            (((_0x349969 *= 1.525) + 0x1) * _0x3392ce + _0x349969) +
            0x2)
        );
      },
      easeInBounce: function (_0x38f47d) {
        var _0x48a131 = _0x397e69;
        return (
          0x1 - _0x3b9b16[_0x48a131(0x2f6)][_0x48a131(0x3c3)](0x1 - _0x38f47d)
        );
      },
      easeOutBounce: function (_0x47e163) {
        if (_0x47e163 < 0x1 / 2.75)
          return 0x1 * (7.5625 * _0x47e163 * _0x47e163);
        else {
          _0x47e163 -= 1.5 / 2.75;
          if (7.5625 * _0x47e163 * _0x47e163 + 0.8575 > 0x1) return 0x1;
          else return 7.5625 * _0x47e163 * _0x47e163 + 0.8575;
        }
      },
      easeInOutBounce: function (_0x5762b2) {
        var _0x55a45e = _0x397e69;
        if (_0x5762b2 < 0x1 / 0x2)
          return easingEffects[_0x55a45e(0x3cf)](_0x5762b2 * 0x2) * 0.5;
        return (
          easingEffects["easeOutBounce"](_0x5762b2 * 0x2 - 0x1) * 0.5 +
          0x1 * 0.5
        );
      },
    }),
    _0x3b9b16
  );
})();
function Animable(_0x197efe) {
  var _0x2d98ed = _0x4a128a;
  (PIXI["Sprite"]["call"](this, _0x197efe),
    (this[_0x2d98ed(0x2b4)] = {}),
    (this[_0x2d98ed(0x25f)] = 0x0),
    (this[_0x2d98ed(0x257)] = 0x0),
    (this[_0x2d98ed(0x216)] = 0xa),
    (this[_0x2d98ed(0x207)] = null),
    (this[_0x2d98ed(0x34f)] = []),
    (this[_0x2d98ed(0x38d)] = ![]),
    (this[_0x2d98ed(0x223)] = null));
}
((Animable[_0x4a128a(0x333)] = Object[_0x4a128a(0x454)](
  PIXI[_0x4a128a(0x385)][_0x4a128a(0x333)],
)),
  (Animable[_0x4a128a(0x333)][_0x4a128a(0x320)] = function (
    _0x5c4a5a,
    _0x3ba9b9,
    _0x44c50f,
    _0x13d9ea,
  ) {
    var _0x35b5a0 = _0x4a128a;
    if (_0x44c50f) {
      this["_animations"][_0x5c4a5a] = [];
      for (
        var _0x1a7854 = 0x0;
        _0x1a7854 < _0x44c50f[_0x35b5a0(0x182)];
        _0x1a7854++
      )
        this[_0x35b5a0(0x2b4)][_0x5c4a5a][_0x35b5a0(0x3b0)](
          _0x3ba9b9[_0x44c50f[_0x1a7854]],
        );
    } else this[_0x35b5a0(0x2b4)][_0x5c4a5a] = _0x3ba9b9;
    if (_0x13d9ea) {
      var _0x2fc04d = []["concat"](this[_0x35b5a0(0x2b4)][_0x5c4a5a]);
      (_0x2fc04d["reverse"](),
        this["_animations"][_0x5c4a5a]["pop"](),
        (this[_0x35b5a0(0x2b4)][_0x5c4a5a] =
          this["_animations"][_0x5c4a5a]["concat"](_0x2fc04d)));
    }
  }),
  (Animable["prototype"][_0x4a128a(0x115)] = function (
    _0x4e8957,
    _0x38c8b5,
    _0x4297c7,
  ) {
    var _0x33238f = _0x4a128a;
    this["_animations"][_0x4e8957] = [];
    for (
      var _0x5007da = 0x0;
      _0x5007da < _0x4297c7[_0x33238f(0x182)];
      _0x5007da++
    ) {
      var _0x4bfc3e = [];
      for (
        var _0x997292 = 0x0;
        _0x997292 < _0x4297c7[_0x5007da][_0x33238f(0x182)];
        _0x997292++
      )
        _0x4bfc3e["push"](_0x38c8b5[_0x4297c7[_0x5007da][_0x997292]]);
      this[_0x33238f(0x2b4)][_0x4e8957][_0x33238f(0x3b0)](_0x4bfc3e);
    }
  }),
  (Animable["prototype"][_0x4a128a(0x32b)] = function (
    _0x4610a9,
    _0x59746e,
    _0x1627ef,
    _0x56db99,
  ) {
    var _0x190199 = _0x4a128a;
    if (!this["_animations"][_0x4610a9]) return null;
    ((this[_0x190199(0x1dc)] = _0x4610a9),
      (this[_0x190199(0x207)] = this["getAnimation"](this[_0x190199(0x1dc)])),
      (this[_0x190199(0x257)] = 0x0),
      (this["_loop"] = _0x59746e || 0x0),
      (this[_0x190199(0x216)] = _0x1627ef || this[_0x190199(0x216)]),
      (this[_0x190199(0x38d)] = !![]),
      (this[_0x190199(0x223)] = _0x56db99 || null));
  }),
  (Animable[_0x4a128a(0x333)]["stopAnimation"] = function () {
    var _0x5f34bd = _0x4a128a;
    this[_0x5f34bd(0x38d)] = ![];
  }),
  (Animable["prototype"]["getAnimation"] = function (_0x2eae3d) {
    var _0x3e0ad6 = _0x4a128a;
    if (this[_0x3e0ad6(0x2b4)][_0x2eae3d][0x0][_0x3e0ad6(0x194)] === Array) {
      var _0xe74ba7 = Math["round"](
        Math[_0x3e0ad6(0xec)]() *
          (this[_0x3e0ad6(0x2b4)][_0x2eae3d][_0x3e0ad6(0x182)] - 0x1),
      );
      return this[_0x3e0ad6(0x2b4)][_0x2eae3d][_0xe74ba7];
    } else return this[_0x3e0ad6(0x2b4)][_0x2eae3d];
  }),
  (Animable[_0x4a128a(0x333)][_0x4a128a(0x1f1)] = function (
    _0x16475e,
    _0x13514a,
    _0xeefe0b,
  ) {
    var _0x26e17f = _0x4a128a;
    this[_0x26e17f(0x34f)][_0x26e17f(0x3b0)]({
      name: _0x16475e,
      loops: _0x13514a,
      fps: _0xeefe0b,
    });
  }),
  (Animable[_0x4a128a(0x333)]["clearPlaylist"] = function () {
    var _0x530aad = _0x4a128a;
    this[_0x530aad(0x34f)] = [];
  }),
  (Animable["prototype"][_0x4a128a(0x122)] = function () {
    var _0x451813 = _0x4a128a;
    if (!this[_0x451813(0x34f)][_0x451813(0x182)]) return;
    var _0x433fe4 = this[_0x451813(0x34f)]["pop"]();
    this[_0x451813(0x32b)](
      _0x433fe4[_0x451813(0x34a)],
      _0x433fe4[_0x451813(0x2ab)],
      _0x433fe4[_0x451813(0x4ab)],
    );
  }),
  (Animable["prototype"][_0x4a128a(0x3c8)] = function (_0x26367e) {
    var _0x11abac = _0x4a128a;
    if (!this[_0x11abac(0x38d)] || !this[_0x11abac(0x207)]) return null;
    this[_0x11abac(0x257)] += _0x26367e > 0x0 ? _0x26367e : 0x0;
    var _0x1202dc = this[_0x11abac(0x207)],
      _0x4b92ab =
        (_0x1202dc[_0x11abac(0x182)] - 0x1) / (this[_0x11abac(0x216)] / 0x3c);
    if (this[_0x11abac(0x257)] >= _0x4b92ab) {
      if (this["_loop"])
        (this[_0x11abac(0x25f)]--,
          (this[_0x11abac(0x257)] -= _0x4b92ab),
          (this["_animation"] = this["getAnimation"](this[_0x11abac(0x1dc)])));
      else {
        ((this[_0x11abac(0x257)] = _0x4b92ab), (this["running"] = ![]));
        if (this[_0x11abac(0x34f)]["length"]) {
          var _0x9043f = this[_0x11abac(0x34f)][_0x11abac(0x220)]();
          this["setAnimation"](
            _0x9043f[_0x11abac(0x34a)],
            _0x9043f[_0x11abac(0x2ab)],
            _0x9043f[_0x11abac(0x4ab)],
          );
        } else {
          if (this["_completeCallback"]) this[_0x11abac(0x223)]();
        }
      }
    }
    var _0x1e2626 = Math["round"](
      (this[_0x11abac(0x257)] * this[_0x11abac(0x216)]) / 0x3c,
    );
    this[_0x11abac(0x335)] = _0x1202dc[_0x1e2626];
  }),
  (Animable["prototype"][_0x4a128a(0x261)] = function () {
    var _0x16f740 = _0x4a128a;
    this[_0x16f740(0x257)] = 0x0;
  }));
function _0x3797(_0x18d100, _0x808e76) {
  var _0x3f3a46 = _0x3f3a();
  return (
    (_0x3797 = function (_0x3797c8, _0x24ef7e) {
      _0x3797c8 = _0x3797c8 - 0xcf;
      var _0x47b8e7 = _0x3f3a46[_0x3797c8];
      return _0x47b8e7;
    }),
    _0x3797(_0x18d100, _0x808e76)
  );
}
var ParticleManager = (function () {
  var _0xf4fc19 = _0x4a128a,
    _0x28e37f = {},
    _0x56e041 = [];
  ((_0x28e37f["emit"] = function (_0x34eeb9) {
    var _0x4a58eb = _0x3797;
    (_0x56e041[_0x4a58eb(0x3b0)](_0x34eeb9), _0x34eeb9[_0x4a58eb(0x487)]());
  }),
    (_0x28e37f[_0xf4fc19(0x3c8)] = function (_0x3f1dc9) {
      var _0x4babde = _0xf4fc19;
      for (let _0x4684f5 = 0x0; _0x4684f5 < _0x56e041["length"]; _0x4684f5++) {
        if (_0x56e041[_0x4684f5][_0x4babde(0x4a4)])
          _0x56e041[_0x4684f5][_0x4babde(0x3c8)](_0x3f1dc9);
        else
          (_0x56e041[_0x4684f5][_0x4babde(0x40b)](),
            _0x56e041[_0x4babde(0x242)](_0x4684f5, 0x1));
      }
    }),
    (_0x28e37f[_0xf4fc19(0x29f)] = function () {
      var _0x150a43 = _0xf4fc19;
      for (let _0x55994a = 0x0; _0x55994a < _0x56e041["length"]; _0x55994a++) {
        _0x56e041[_0x55994a][_0x150a43(0x40b)]();
      }
      _0x56e041 = [];
    }));
  var _0x1bbcaf = function (_0x5161f3, _0x5eba49) {
    var _0x29fc60 = _0xf4fc19;
    (PIXI["Sprite"][_0x29fc60(0x37a)](this, _0x5161f3),
      (this[_0x29fc60(0x432)] = _0x5eba49),
      (this[_0x29fc60(0xde)] = { x: 0x0, y: 0x0 }),
      (this[_0x29fc60(0x2bf)] = { x: 0x0, y: 0x0 }),
      (this[_0x29fc60(0x1d4)] = 0x0),
      (this[_0x29fc60(0x269)] = 0x0),
      (this[_0x29fc60(0x347)] = 0x1),
      (this[_0x29fc60(0x377)] = { r: 0xff, g: 0xff, b: 0xff }),
      (this[_0x29fc60(0xdf)] = 0x1),
      (this[_0x29fc60(0x4b0)] = 0x64),
      (this[_0x29fc60(0x2df)] = 0x0),
      (this[_0x29fc60(0x2d7)] = 0x1),
      (this["_endColor"] = { r: 0xff, g: 0xff, b: 0xff }),
      (this["_acceleration"] = { x: 0x0, y: 0x0 }),
      (this[_0x29fc60(0x3fc)] = ![]),
      (this[_0x29fc60(0x411)] = ![]),
      (this["_sizeTransition"] = ![]),
      (this["_alphaTransition"] = ![]),
      (this[_0x29fc60(0x2be)] = 0x0),
      (this[_0x29fc60(0xe9)] = null),
      (this[_0x29fc60(0x3c5)] = 0x1),
      (this["_size"] = 0x1),
      (this[_0x29fc60(0x12f)] = { x: 0x0, y: 0x0 }),
      (this["_rotation"] = 0x0),
      (this[_0x29fc60(0x4a4)] = !![]),
      (this[_0x29fc60(0x1a8)] = 0x0),
      this[_0x29fc60(0x487)](),
      (this[_0x29fc60(0x4a1)]["x"] = 0.5),
      (this[_0x29fc60(0x4a1)]["y"] = 0.5));
  };
  ((_0x1bbcaf[_0xf4fc19(0x333)] = Object[_0xf4fc19(0x454)](
    PIXI[_0xf4fc19(0x385)][_0xf4fc19(0x333)],
  )),
    (_0x1bbcaf["prototype"][_0xf4fc19(0x487)] = function () {
      var _0x493e36 = _0xf4fc19;
      (this[_0x493e36(0x231)][_0x493e36(0x27e)](this[_0x493e36(0x347)]),
        (this[_0x493e36(0x2be)] = 0x0),
        (this[_0x493e36(0x12f)]["x"] = this[_0x493e36(0xde)]["x"]),
        (this[_0x493e36(0x12f)]["y"] = this["startSpeed"]["y"]),
        (this[_0x493e36(0x2f1)] = this[_0x493e36(0x1d4)]));
    }),
    (_0x1bbcaf["prototype"][_0xf4fc19(0x2b6)] = function () {
      var _0x12cac3 = _0xf4fc19;
      ((this[_0x12cac3(0x2be)] = 0x0),
        (this[_0x12cac3(0x12f)]["x"] = this[_0x12cac3(0xde)]["x"]),
        (this["_velocity"]["y"] = this[_0x12cac3(0xde)]["y"]),
        (this[_0x12cac3(0x2f1)] = this[_0x12cac3(0x1d4)]));
    }));
  var _0xadcd64 = function (_0x332bb1) {
    if (_0x332bb1 <= 0.15) return -6.666 * _0x332bb1 + 0x1;
    return _0x332bb1;
  };
  return (
    (_0x1bbcaf["prototype"][_0xf4fc19(0x3c8)] = function (_0x5a7d34) {
      var _0x4b55cf = _0xf4fc19;
      if (this[_0x4b55cf(0x1a8)] > 0x0) {
        this["delay"] -= _0x5a7d34;
        if (this[_0x4b55cf(0x1a8)] <= 0x0) this[_0x4b55cf(0x197)] = !![];
        else this[_0x4b55cf(0x197)] = ![];
        return;
      }
      this[_0x4b55cf(0x2be)] += _0x5a7d34;
      if (this[_0x4b55cf(0x2be)] >= this[_0x4b55cf(0x4b0)])
        return ((this[_0x4b55cf(0x4a4)] = ![]), -0x1);
      var _0x337738 = this[_0x4b55cf(0x2be)] / this["lifeTime"];
      this[_0x4b55cf(0xe9)] && (_0x337738 = this["_ease"](_0x337738));
      if (this[_0x4b55cf(0x19c)])
        this["_alpha"] =
          (this[_0x4b55cf(0x2df)] - this[_0x4b55cf(0xdf)]) * _0x337738 +
          this[_0x4b55cf(0xdf)];
      if (this["_sizeTransition"])
        this["_size"] =
          (this["_endSize"] - this[_0x4b55cf(0x347)]) * _0x337738 +
          this["startSize"];
      if (this["_speedTransition"]) {
        if (this[_0x4b55cf(0x12f)]["x"] < this[_0x4b55cf(0x2bf)]["x"])
          this["_velocity"]["x"] += this[_0x4b55cf(0x13f)]["x"] * _0x5a7d34;
        else {
          if (this[_0x4b55cf(0x12f)]["x"] > this[_0x4b55cf(0x2bf)]["x"])
            this["_velocity"]["x"] -= this[_0x4b55cf(0x13f)]["x"] * _0x5a7d34;
        }
        if (this[_0x4b55cf(0x12f)]["y"] < this[_0x4b55cf(0x2bf)]["y"])
          this[_0x4b55cf(0x12f)]["y"] +=
            this[_0x4b55cf(0x13f)]["y"] * _0x5a7d34;
        else {
          if (this[_0x4b55cf(0x12f)]["y"] > this["endSpeed"]["y"])
            this["_velocity"]["y"] -= this[_0x4b55cf(0x13f)]["y"] * _0x5a7d34;
        }
      }
      if (this[_0x4b55cf(0x3fc)]) {
        var _0x599f05 = _0x337738,
          _0x592d41 =
            Math[_0x4b55cf(0x167)](
              (this[_0x4b55cf(0x403)]["r"] - this[_0x4b55cf(0x377)]["r"]) *
                _0x599f05,
            ) + this[_0x4b55cf(0x377)]["r"],
          _0x40c650 =
            Math[_0x4b55cf(0x167)](
              (this[_0x4b55cf(0x403)]["g"] - this["startColor"]["g"]) *
                _0x599f05,
            ) + this[_0x4b55cf(0x377)]["g"],
          _0x569f10 =
            Math["round"](
              (this[_0x4b55cf(0x403)]["b"] - this["startColor"]["b"]) *
                _0x599f05,
            ) + this["startColor"]["b"];
        this[_0x4b55cf(0x1bd)] = ColorMath[_0x4b55cf(0x2f9)](
          _0x592d41,
          _0x40c650,
          _0x569f10,
        );
      }
      return (
        this[_0x4b55cf(0x269)] &&
          (this[_0x4b55cf(0x2f1)] += this[_0x4b55cf(0x269)]),
        this["apply"](),
        _0x337738
      );
    }),
    (_0x1bbcaf[_0xf4fc19(0x333)][_0xf4fc19(0x290)] = function () {
      var _0x23453f = _0xf4fc19;
      ((this["x"] += this[_0x23453f(0x12f)]["x"]),
        (this["y"] += this[_0x23453f(0x12f)]["y"]),
        (this["rotation"] = this[_0x23453f(0x2f1)]),
        (this["alpha"] = this["_alpha"]),
        (this[_0x23453f(0x199)] = this["_tint"]),
        (this[_0x23453f(0x231)]["x"] = this[_0x23453f(0x231)]["y"] =
          this[_0x23453f(0x2f4)]));
    }),
    (_0x1bbcaf[_0xf4fc19(0x333)][_0xf4fc19(0x40b)] = function () {
      var _0x56b188 = _0xf4fc19;
      if (this["parent"]) this[_0x56b188(0x35d)][_0x56b188(0x28c)](this);
      this[_0x56b188(0x3bc)]();
    }),
    Object[_0xf4fc19(0x211)](_0x1bbcaf[_0xf4fc19(0x333)], {
      endColor: {
        set: function (_0x348b47) {
          var _0x14921a = _0xf4fc19;
          this["_endColor"] = _0x348b47;
          if (_0x348b47 != "0xFFFFFF") this[_0x14921a(0x3fc)] = !![];
        },
      },
      acceleration: {
        get: function () {
          return this["_acceleration"];
        },
        set: function (_0x1221c0) {
          var _0x542535 = _0xf4fc19;
          this[_0x542535(0x13f)] = _0x1221c0;
          if (_0x1221c0["x"] != 0x0 || _0x1221c0["y"] != 0x0)
            this[_0x542535(0x411)] = !![];
        },
      },
      endSize: {
        set: function (_0x50221b) {
          var _0x1f4d62 = _0xf4fc19;
          ((this[_0x1f4d62(0x2d7)] = _0x50221b),
            (this[_0x1f4d62(0x480)] = !![]));
        },
      },
      endAlpha: {
        set: function (_0x4d0228) {
          var _0x458fc1 = _0xf4fc19;
          ((this[_0x458fc1(0x2df)] = _0x4d0228),
            (this[_0x458fc1(0x19c)] = !![]));
        },
      },
    }),
    (_0x28e37f[_0xf4fc19(0x16c)] = _0x1bbcaf),
    _0x28e37f
  );
})();
((PIXI[_0x4a128a(0x36e)] = function (_0x18ea67) {
  var _0x4a68df = _0x4a128a,
    _0x5ec587 =
      PIXI[_0x4a68df(0x27d)][_0x4a68df(0x405)][_0x18ea67[_0x4a68df(0x47f)]];
  if (_0x5ec587) {
    var _0xdd7c5f = [];
    _0x5ec587[_0x4a68df(0x119)] = {};
    var _0x3bbe4d = 0x0,
      _0x5207d1 = 0x0;
    for (var _0x1a529f = 0x0; _0x1a529f < _0x18ea67["frames"]; _0x1a529f++) {
      var _0x3c54fb = _0x18ea67[_0x4a68df(0x47f)] + "_" + _0x1a529f,
        _0x24b19d = new PIXI[_0x4a68df(0x213)](
          _0x3bbe4d,
          _0x5207d1,
          _0x18ea67[_0x4a68df(0x296)],
          _0x18ea67[_0x4a68df(0x1fa)],
        );
      ((_0x5ec587[_0x4a68df(0x119)][_0x3c54fb] = new PIXI[_0x4a68df(0x10e)](
        _0x5ec587[_0x4a68df(0x335)][_0x4a68df(0x2ad)],
        _0x24b19d,
        _0x24b19d[_0x4a68df(0x359)](),
      )),
        (PIXI[_0x4a68df(0x304)]["TextureCache"][_0x3c54fb] =
          _0x5ec587["textures"][_0x3c54fb]),
        _0xdd7c5f[_0x4a68df(0x3b0)](_0x5ec587["textures"][_0x3c54fb]),
        (_0x3bbe4d += _0x18ea67[_0x4a68df(0x296)]));
      if (
        _0x3bbe4d + _0x18ea67["frameWidth"] >
        _0x5ec587["texture"][_0x4a68df(0xfd)]
      ) {
        ((_0x3bbe4d = 0x0), (_0x5207d1 += _0x18ea67[_0x4a68df(0x1fa)]));
        if (
          _0x5207d1 + _0x18ea67[_0x4a68df(0x1fa)] >
          _0x5ec587[_0x4a68df(0x335)][_0x4a68df(0x21c)]
        )
          break;
      }
    }
    return _0xdd7c5f;
  }
  return ![];
}),
  Object[_0x4a128a(0x211)](PIXI[_0x4a128a(0x30a)][_0x4a128a(0x333)], {
    scaleX: {
      get: function () {
        var _0xdbbdbe = _0x4a128a;
        return this[_0xdbbdbe(0x231)]["x"];
      },
      set: function (_0x1e8ab1) {
        this["scale"]["x"] = _0x1e8ab1;
      },
    },
    scaleY: {
      get: function () {
        var _0x488aad = _0x4a128a;
        return this[_0x488aad(0x231)]["y"];
      },
      set: function (_0x4e5c76) {
        var _0x4ddc68 = _0x4a128a;
        this[_0x4ddc68(0x231)]["y"] = _0x4e5c76;
      },
    },
  }),
  Object[_0x4a128a(0x211)](PIXI["Sprite"][_0x4a128a(0x333)], {
    scaleX: {
      get: function () {
        return this["scale"]["x"];
      },
      set: function (_0x37cc19) {
        var _0x50415e = _0x4a128a;
        this[_0x50415e(0x231)]["x"] = _0x37cc19;
      },
    },
    scaleY: {
      get: function () {
        return this["scale"]["y"];
      },
      set: function (_0x2e49c7) {
        var _0x217955 = _0x4a128a;
        this[_0x217955(0x231)]["y"] = _0x2e49c7;
      },
    },
    anchorX: {
      get: function () {
        return this["anchor"]["x"];
      },
      set: function (_0x1c4ba6) {
        var _0x577f48 = _0x4a128a;
        this[_0x577f48(0x4a1)]["x"] = _0x1c4ba6;
      },
    },
    anchorY: {
      get: function () {
        var _0x16c3aa = _0x4a128a;
        return this[_0x16c3aa(0x4a1)]["y"];
      },
      set: function (_0x24abd9) {
        this["anchor"]["y"] = _0x24abd9;
      },
    },
  }));
var ColorMath;
(function (_0x588cdf) {
  var _0x4209cf = _0x4a128a;
  ((_0x588cdf[_0x4209cf(0x36c)] = function (_0x56b5dd) {
    var _0x323caa = _0x4209cf,
      _0x3c3db6 = {};
    if (_0x56b5dd[_0x323caa(0x2d8)](0x0) == "#")
      _0x56b5dd = _0x56b5dd["substr"](0x1);
    else {
      if (_0x56b5dd[_0x323caa(0x1f2)]("0x") === 0x0)
        _0x56b5dd = _0x56b5dd[_0x323caa(0x14c)](0x2);
    }
    return (
      _0x56b5dd[_0x323caa(0x182)] == 0x8 &&
        (_0x56b5dd = _0x56b5dd[_0x323caa(0x14c)](0x2)),
      (_0x3c3db6["r"] = parseInt(_0x56b5dd[_0x323caa(0x14c)](0x0, 0x2), 0x10)),
      (_0x3c3db6["g"] = parseInt(_0x56b5dd["substr"](0x2, 0x2), 0x10)),
      (_0x3c3db6["b"] = parseInt(_0x56b5dd["substr"](0x4, 0x2), 0x10)),
      _0x3c3db6
    );
  }),
    (_0x588cdf[_0x4209cf(0x2f9)] = function (_0x1ec3fb, _0x24be84, _0x4bf7c3) {
      var _0x57adc2 = _0x4209cf;
      return (
        "0x" +
        ((0x1 << 0x18) + (_0x1ec3fb << 0x10) + (_0x24be84 << 0x8) + _0x4bf7c3)
          ["toString"](0x10)
          [_0x57adc2(0x3c6)](0x1)
      );
    }),
    (_0x588cdf[_0x4209cf(0x1ad)] = function (_0x45e48e) {
      return "0x" + _0x45e48e["toString"](0x10);
    }));
})(ColorMath || (ColorMath = {}));
function _0x3f3a() {
  var _0x1c9b5e = [
    "lobby_button_discpool_hover",
    "corner_striker_base_4",
    "_rotation",
    "pageCount",
    "24px\x20Simonetta_white2",
    "_size",
    "assets/tables/4/royal_arena_strike_base_background.png",
    "transitions",
    "progress",
    "webkitHidden",
    "ToHex",
    "shop_tab_stones_hover",
    "textureUp",
    "moveTo",
    "_delay",
    "assets/shop/strike_02.png",
    "assets/tables/0/delhi_lounge_strike_base.png",
    "tut_06_screen_design",
    "assets/shop/strike_yellow_bit.png",
    "unmuteGroup",
    "impact_a_sprite",
    "utils",
    "table_1",
    "_mode",
    "seek",
    "BLACK\x0aBOX",
    "shop",
    "Container",
    "assets/tables/3/Carrom_table_01.png",
    "easeInBack",
    "strike_yellow_bit",
    "assets/matchmaking/Carrom_coins_light.png",
    "_dragPosition",
    "scaleY",
    "applyForceToCenter",
    "ballstrike",
    "scrollUpdate",
    "register",
    "upgrades",
    "40px\x20Simonetta_white2",
    "assets/matchmaking/carrom_spinning_wheel_base_brights.png",
    "PURPLE\x0aFLOWER",
    "assets/check_filled.png",
    "tut_02_title",
    "shop_button_buy_hover",
    "onfocus",
    "assets/tables/4/logo.png",
    "mozvisibilitychange",
    "removeAllListeners",
    "addAnimation",
    "step",
    "abs",
    "innerWidth",
    "results_claim_button_hover",
    "light",
    "assets/tutorial/tut_04_title.png",
    "assets/tutorial/tut_02_title.png",
    "shop_button_upgrade_arrow",
    "assets/tutorial/tut_01_title.png",
    "matchmaking_bg_mumbaiplaza_slices",
    "setAnimation",
    "dist",
    "foul_background",
    "Equip",
    "LABELS",
    "assets/sounds/Win_coins.mp3",
    "24nqTgly",
    "assets/wheel/confetti_01.png",
    "prototype",
    "assets/lobby/lobby_button_freestyle_hover.png",
    "texture",
    "43px\x20Simonetta_white2",
    "onDown",
    "stone_04",
    "beginFill",
    "stones",
    "assets/result/loser_01.png",
    "onfocusout",
    "assets/Carrom_circle_around_strike.png",
    "100px\x20Simonetta_white2",
    "assets/select/tableselect_royalarena_title_with_glow.png",
    "spin",
    "onpageshow",
    "try_button_hover",
    "objectType",
    "assets/avatars/frame_empty.png",
    "assets/matchmaking/reward_pot_coins.png",
    "carrom_spinning_wheel_base",
    "startSize",
    "fromFrame",
    "assets/result/results_title_stones.png",
    "name",
    "assets/matchmaking/matchmaking_bg_royalarena_slices.png",
    "assets/result/text_opponent.png",
    "button_yes",
    "_button",
    "_playlist",
    "music_button",
    "stone_05",
    "bonus",
    "assets/avatars/red_bg.png",
    "_prms",
    "assets/select/tableselect_fee_base.png",
    "assets/tables/0/delhi_lounge_strike_base_background.png",
    "lobby_title",
    "table_2",
    "clone",
    "corners_0",
    "left",
    "keys",
    "parent",
    "rules",
    "assets/sprites/impact_a.png",
    "onStart",
    "marginLeft",
    "avatar",
    "score",
    "assets/tutorial/ARROW_RIGHT.png",
    "Carrom_black",
    "resize",
    "assets/wheel/confetti_05.png",
    "assets/tables/0/delhi_lounge_corner_TR.png",
    "once",
    "trimVelocity",
    "restitution",
    "ToRGB",
    "assets/shop/shop_tab_strikers.png",
    "ParseTile",
    "swipeLeft",
    "coin_counter_base",
    "strike_05",
    "_goal",
    "assets/tables/3/Carrom_strike_base.png",
    "bind",
    "number",
    "assets/tables/1/golden_city_corner_TR.png",
    "startColor",
    "renderer",
    "playerAvatar",
    "call",
    "addChild",
    "assets/settings/button_play_pressed.png",
    "friction",
    "assets/pause/tutorial_button_hover.png",
    "settings_pause_base",
    "assets/tutorial/2_6.png",
    "from",
    "strike_module_base",
    "play",
    "assets/shop/stones/shop_button_upgrade_arrow.png",
    "Sprite",
    "getFixtureA",
    "valueField",
    "asin",
    "tut_4_6",
    "striker",
    "text_spin_now",
    "PAGES",
    "running",
    "_btnBonus",
    "single_coin",
    "_angle",
    "assets/pause/settings_pause_base.png",
    "TilingSprite",
    "oponent",
    "audio",
    "assets/tables/2/mahal_palace_corner_BL.png",
    "assets/Carrom_strike.png",
    "lobby_button_dailybonus_hover",
    "rewardPotValue",
    "red",
    "frame",
    "tut_04_screen_design",
    "pointerup",
    "table_4",
    "assets/select/tableselect_mumbaiplaza_base.png",
    "starting_player_base",
    "addTween",
    "force",
    "ready",
    "empty",
    "assets/tables/2/mahal_palace_corner_TR.png",
    "_dist",
    "assets/pause/pause_text.png",
    "matchmaking_bg_mahalpalace_slices",
    "55px\x20Simonetta_white2",
    "_aimSlots",
    "assets/tutorial/WOODEN_BASE.png",
    "strike_08",
    "YOU\x20",
    "loadTable",
    "variant",
    "assets/wheel/text_good_luck.png",
    "push",
    "assets/shop/shop_strikers_module_dimmed.png",
    "pointerUpHandler",
    "line",
    "assets/Carrom_white.png",
    "notification_dot",
    "EMERALD\x0aLOTUS",
    "startSwipe",
    "_btnPlayFreestyle",
    "assets/wheel/confetti_02.png",
    "btnClaimAd",
    "sqrt",
    "destroy",
    "assets/tutorial/tut_01_screen_design.png",
    "assets/preloader/loading_title.png",
    "music_button_sfx",
    "isdown",
    "shop_button_buy",
    "sound",
    "easeOutBounce",
    "assets/shop/strike_04.png",
    "_alpha",
    "slice",
    "top",
    "update",
    "carrom_spinning_wheel_shadow",
    "data",
    "assets/avatars/silhouette_cha05.png",
    "game",
    "results_you_profile",
    "btnClaim",
    "easeInBounce",
    "hideAdButton",
    "assets/tables/3/Carrom_table_01_background.png",
    "back",
    "assets/select/coin_counter_base.png",
    "registerState",
    "assets/select/tableselect_prize_base.png",
    "_btnLeft",
    "add",
    "tut_1_6",
    "assets/tutorial/3_4.png",
    "_btnSound",
    "moveSlide",
    "assets/tables/0/delhi_lounge_corner_TL.png",
    "assets/sounds/Stone_Hit_1.mp3",
    "assets/result/results_you_profile.png",
    "addChildAt",
    "setCover",
    "stone_06",
    "_value",
    "logo_1",
    "assets/tables/2/mahal_palace_table_01_background.png",
    "storage",
    "rewardPotIcon",
    "assets/avatars/blue_bg.png",
    "assets/shop/strike_module_base.png",
    "assets/Carrom_player_frame.png",
    "frame_white_filled",
    "blendMode",
    "fromImage",
    "text_opponent",
    "assets/pause/button_no.png",
    "available",
    "hDot",
    "overlay",
    "autoStart",
    "_scrollSpeed",
    "green",
    "_enable",
    "updateStoneStates",
    "onfocusin",
    "lobby_button_tutorial_pressed",
    "children",
    "pow",
    "GOLDEN\x0aBUDDHA",
    "_colorTransition",
    "assets/shop/stones/stone_module_base.png",
    "_btnSettings",
    "assets/pause/exit_question.png",
    "figure",
    "assets/pause/pause_play_button.png",
    "BitmapText",
    "_endColor",
    "MAX",
    "resources",
    "1065888zyTLBz",
    "assets/select/tableselect_arrow_right.png",
    "_btnMusic",
    "bg_3",
    "finish",
    "kill",
    "tableselect_goldencity_base",
    "assets/sounds/Stone_Hit_2.mp3",
    "Carrom_line",
    "change_mute_music",
    "pushable",
    "_speedTransition",
    "strikers",
    "assets/settings/button_home.png",
    "getTime",
    "lobby_button_freestyle",
    "assets/tables/0/delhi_lounge_table.png",
    "_side",
    "tut_1_4",
    "assets/update/text_spin_now_pressed.png",
    "assets/shop/stones/stone_05.png",
    "bg_4",
    "isEnabled",
    "tut_04_title",
    "assets/preloader/loading_bar_purple.png",
    "winner_glow",
    "lobby_button_dailybonus",
    "stop",
    "22px\x20Simonetta_white2",
    "OPPONENT\x20",
    "corner_striker_base_1",
    "\x0a\x20focus\x20change",
    "easeOutBack",
    "beforeReward",
    "tutorialOverlay",
    "innerHeight",
    "tweens",
    "_btnPlayDisk",
    "results_you_profile_lose",
    "assets/tutorial/2_4.png",
    "assets/result/results_claim_button.png",
    "shape",
    "cos",
    "start",
    "_parentEmitter",
    "text_good_luck",
    "unlocked",
    "idle",
    "assets/sounds/Stone_Hit_3.mp3",
    "results_claimx2_button",
    "tut_5_6",
    "assets/avatars/silhouette_cha02.png",
    "assets/lobby/lobby_button_shop_hover_v02.png",
    "striker_highlight_5",
    "parse",
    "zOrder",
    "pointerdown",
    "state",
    "assets/sounds/puck.mp3",
    "now",
    "assets/tables/4/royal_arena_corner_BL.png",
    "_btnShop",
    "down",
    "cacheAsBitmap",
    "assets/select/tableselect_select_button_hover.png",
    "label_freestyle",
    "select_stone",
    "assets/striker_overlay.png",
    "_timeSlots",
    "assets/tables/3/Carrom_corner_BL.png",
    "tut_3_6",
    "shop_button_upgrade",
    "assets/wheel/carrom_spinning_wheel_base.png",
    "back_button_hover",
    "Purchase",
    "hover",
    "assets/pause/button_yes.png",
    "_isSensor",
    "create",
    "assets/tutorial/4_4.png",
    "assets/pause/button_no_hover.png",
    "stopPropagation",
    "shop_tab_strikers_hover",
    "strike_06",
    "gm4html5_div_id",
    "0px",
    "assets/tutorial/tut_04_screen_design.png",
    "_btnRight",
    "assets/sounds/Stone_Hit_4.mp3",
    "onblur",
    "assets/tables/1/logo.png",
    "fixture",
    "Vec2",
    "hackcoins",
    "mozHidden",
    "coins",
    "avatar_red_bg",
    "black",
    "pause_play_button_hover",
    "extract",
    "getPosition",
    "text_spin_now_pressed",
    "assets/shop/stones/stone_02.png",
    "assets/matchmaking/matchmaking_bg_mumbaiplaza_slices.png",
    "_btnBack",
    "logo_3",
    "table",
    "createFixture",
    "random\x20shot!",
    "lobby_button_tutorial",
    "shop_bg",
    "circle",
    "_coins",
    "goRight",
    "assets/tables/2/mahal_palace_corner_TL.png",
    "assets/select/tableselect_coins.png",
    "button_no_hover",
    "Carrom_white",
    "invulnerable",
    "_sliding",
    "_field",
    "source",
    "_sizeTransition",
    "doCoinParticles",
    "home_button_sfx",
    "levelComplete",
    "updateState",
    "tableselect_coins",
    "white",
    "init",
    "assets/tables/1/golden_city_strike_base_background.png",
    "getAngle",
    "AMBER\x0aPATTERN",
    "corner_striker_3",
    "tut_4_4",
    "bg_0",
    "density",
    "endAlpha",
    "assets/update/spin_now_base.png",
    "setMode",
    "getItem",
    "assets/shop/shop_button_buy.png",
    "animid",
    "trace",
    "assets/tutorial/1_4.png",
    "showStartingShuffle",
    "goalValueLabel",
    "RailHit05",
    "assets/shop/strike_green_stroke.png",
    "corner_striker_1",
    "putcoin",
    "break",
    "tmp",
    "tut_2_4",
    "removeFromWorld",
    "anchor",
    "arrow_outline",
    "onUp",
    "alive",
    "puck_sprite",
    "stone_green_stroke",
    "_strength",
    "25px\x20Simonetta_white2",
    "assets/shop/shop_button_upgrade.png",
    "assets/shop/stones/stone_09.png",
    "fps",
    "music_button_off",
    "_btnSelect",
    "body",
    "assets/lobby/lobby_button_discpool.png",
    "lifeTime",
    "tableselect_mahalpalace_title",
    "553861TYcTPL",
    "addEventListener",
    "content",
    "matchmaking_bg_goldencity_slices",
    "matchmaking_bg_royalarena_slices",
    "value",
    "assets/shop/button_settings.png",
    "stonesHeader",
    "assets/wheel/coins.png",
    "inDown",
    "assets/starting/arrow.png",
    "corners_1",
    "assets/shop/stones/stone_green_stroke.png",
    "tables",
    "assets/sounds/bigwin_var1_5s_byAbsintheMedia.mp3",
    "pushed",
    "assets/select/tableselect_select_button.png",
    "setSensor",
    "close",
    "isOver",
    "assets/wheel/carrom_spinning_wheel_background.png",
    "subscribe",
    "assets/settings/button_home_pressed.png",
    "assets/sounds/tap_wood5.mp3",
    "assets/tutorial/tut_02_screen_design.png",
    "onComplete",
    "stage",
    "DRAG\x20THE\x20STRIKER\x20TO\x0aAIM\x20AND\x20CHOOSE\x20THE\x0aPOWER\x20OF\x20YOUR\x20STRIKE",
    "1199816bZTWgq",
    "pos",
    "_drag",
    "_fieldIcon",
    "setLinearDamping",
    "assets/matchmaking/matchmaking_bg_goldencity_slices.png",
    "close_button_hover",
    "wheelSpark_a",
    "assets/wheel/confetti_03.png",
    "_state",
    "assets/select/tableselect_goldencity_title_with_glow.png",
    "matchmaking_bg_delhilounge_slices",
    "log",
    "assets/tutorial/tut_03_screen_design.png",
    "settings_text",
    "strike_blue_bit",
    "_propsQueue",
    "startSpeed",
    "startAlpha",
    "resetMassData",
    "tutorial_button_hover",
    "assets/tutorial/3_6.png",
    "assets/tutorial/4_6.png",
    "shop_tab_strikers",
    "alpha",
    "def",
    "assets/update/text_free_spin.png",
    "winner_background",
    "_ease",
    "tableselect_select_button_hover",
    "easeOutCirc",
    "random",
    "redraw",
    "avatar_frame_empty",
    "assets/tables/1/golden_city_strike_base.png",
    "assets/label_freestyle.png",
    "assets/shop/shop_tick.png",
    "assets/select/tableselect_delhilounge_title_with_glow.png",
    "icon",
    "_enabled",
    "assets/shop/strike_blue_bit.png",
    "updateStates",
    "737660qcxcHL",
    "queen",
    "stopSlide",
    "_frame",
    "strike_07",
    "tableselect_mumbaiplaza_title",
    "width",
    "emit",
    "results_title_stones",
    "moveWhenInside",
    "gameOver",
    "cast",
    "_btnHome",
    "assets/tables/4/royal_arena_table.png",
    "home_button",
    "Application",
    "Tween",
    "assets/tables/4/royal_arena_corner_TR.png",
    "pointermove",
    "home",
    "startSpin",
    "assets/label_carrom.png",
    "shop_button_upgrade_hover",
    "Texture",
    "onUpdate",
    "results_opponent_profile_win",
    "button",
    "assets/shop/button_settings_hover.png",
    "assets/result/loser_05.png",
    "reward",
    "addMultiAnimation",
    "pause_text",
    "tut_03_title",
    "cover",
    "textures",
    "tut_01_title",
    "assets/lobby/lobby_button_free_spin.png",
    "interaction",
    "max",
    "assets/update/button_video.png",
    "assets/tables/3/Carrom_strike_base_background.png",
    "stone_03",
    "assets/wheel/test_you_won.png",
    "gotoNext",
    "Carrom_coins_light",
    "hideRest",
    "music",
    "remove",
    "33px\x20Simonetta_white2",
    "getLinearVelocity",
    "Carrom_red",
    "Circle",
    "assets/tables/2/logo.png",
    "loop",
    "setEnable",
    "type",
    "_velocity",
    "oponnentAvatar",
    "hidden",
    "tut_3_4",
    "assets/matchmaking/matchmaking_bg_mahalpalace_slices.png",
    "label_carrom",
    "updateStats",
    "assets/pause/sfx_button.png",
    "Active",
    "spinwin",
    "3078018LNrUXl",
    "Carrom_circle_around_strike",
    "arrRight",
    "strike_09",
    "showAdButton",
    "assets/tables/4/royal_arena_corners.png",
    "_acceleration",
    "assets/shop/strike_06.png",
    "assets/tables/0/logo.png",
    "setAwake",
    "order",
    "sfx_button",
    "assets/settings/pause_base.png",
    "playerNameLabel",
    "claim",
    "Graphics",
    "time",
    "ceil",
    "assets/tables/2/mahal_palace_strike_base.png",
    "substr",
    "focus",
    "assets/result/try_button_hover.png",
    "assets/wheel/carrom_spinning_wheel_base_bright.png",
    "assets/lobby/lobby_title.png",
    "_selected",
    "test2",
    "assets/wheel/coins_big.png",
    "assets/tables/4/royal_arena_corner_TL.png",
    "Carrom_player_black",
    "arrLeft",
    "assets/shop/shop_tab_strikers_hover.png",
    "assets/result/results_you_profile_lose.png",
    "sprite",
    "showBonusMark",
    "avatar_frame_filled",
    "static",
    "pause_play_button",
    "assets/foul_base.png",
    "MIDNIGHT\x0aDREAM",
    "valueLabel",
    "assets/wheel/carrom_spinning_wheel_base_brights.png",
    "showShopMark",
    "tut_02_screen_design",
    "tableselect_fee_base",
    "assets/striker_highlight_05.png",
    "numbers_shadow",
    "round",
    "PAGE_COUNTER",
    "logo_4",
    "try_button",
    "pause_button",
    "Particle",
    "equiped",
    "tap_wood5",
    "carrom_spinning_wheel_arrow",
    "back_button",
    "results_coins",
    "bigwin_b",
    "assets/tables/1/golden_city_table.png",
    "assets/tutorial/ARROW_LEFT.png",
    "_inSwipe",
    "sfx_button_hover",
    "fee",
    "label_discpool",
    "Carrom_strike",
    "striker_overlay",
    "assets/result/results_title.png",
    "corners",
    "assets/tables/1/golden_city_corner_BR.png",
    "keyCode",
    "reward_pot_coins",
    "full",
    "cpx_",
    "length",
    "showWin",
    "buy_stone",
    "setCoins",
    "assets/Carrom_player_white.png",
    "mute",
    "playLoop",
    "lobby_bg",
    "assets/starting/2.png",
    "assets/select/back_button_hover.png",
    "toString",
    "assets/sounds/BilliardBallStrike.mp3",
    "assets/result/results_coins.png",
    "_swipePoint",
    "Text",
    "assets/shop/button_settings_hover_v02.png",
    "global",
    "_propsStart",
    "constructor",
    "carrom_spinning_wheel_base_brights",
    "atan2",
    "visible",
    "updateAudio",
    "tint",
    "plugins",
    "tan",
    "_alphaTransition",
    "_hintMode",
    "coinsIcon",
    "dynamic",
    "puck",
    "indestructible",
    "restart",
    "assets/select/tableselect_mahalpalace_title_with_glow.png",
    "table_0",
    "_stonesItems",
    "linear",
    "stonesContent",
    "delay",
    "tap_wood9",
    "text",
    "assets/result/loser_02.png",
    "sortChildren",
    "DecToHex",
    "100%",
    "_chainSum",
    "assets/result/winner_outer_glow.png",
    "undefined",
    "bg_1",
    "carrom_spin_button_hover",
    "assets/tables/1/golden_city_corner_TL.png",
    "stone_09",
    "corner_striker_base_3",
    "setState",
    "assets/lobby/lobby_button_carrom.png",
    "keydown",
    "pointerDownHandler",
    "assets/Carrom_line.png",
    "_forceSlots",
    "_tint",
    "_elapse",
    "interactive",
    "concat",
    "Stone_Hit_3",
    "impact_b_sprite",
    "GameSnacks",
    "endSwipe",
    "lose",
    "bar_2",
    "_pointer",
    "sin",
    "tut_01_screen_design",
    "assets/Carrom_coins_light.png",
    "appendChild",
    "setItem",
    "test",
    "transition",
    "roll",
    "sfx_button_off",
    "assets/shop/stones/stone_04.png",
    "assets/wheel/Congratulations.png",
    "245144uKVcBL",
    "angle",
    "arrow",
    "tut_03_screen_design",
    "view",
    "stone_01",
    "assets/result/results_opponent_profile.png",
    "_tempPosition",
    "assets/sounds/music.mp3",
    "_animationName",
    "worldY",
    "42px\x20Simonetta_white2",
    "assets/pause/music_button.png",
    "load",
    "assets/matchmaking/single_coin.png",
    "_music",
    "strike_02",
    "edge",
    "assets/tables/0/delhi_lounge_corner_BR.png",
    "results_claim_button",
    "close_button",
    "stone_pot",
    "getElementById",
    "upgrade",
    "stone_08",
    "rotation",
    "carrom_spinning_wheel_background",
    "logo",
    "assets/tables/1/golden_city_corners.png",
    "onpagehide",
    "addToPlaylist",
    "indexOf",
    "infoBox",
    "assets/shop/shop_tab_stones_hover.png",
    "frame_red_filled",
    "assets/avatars/frame_white_filled.png",
    "base",
    "floor",
    "easeOutQuad",
    "frameHeight",
    "assets/shop/shop_button_upgrade_hover.png",
    "brights_behind_numbers",
    "369086PFhTwO",
    "startRoll",
    "VIOLET\x0aNIGHT",
    "impact_a",
    "assets/avatars/frame_filled.png",
    "assets/avatars/frame_black_filled.png",
    "createBody",
    "pointerMoveHandler",
    "bow",
    "assets/shop/stones/stone_03.png",
    "_animation",
    "lobby_button_shop_hover_v02",
    "assets/pause/home_button_sfx.png",
    "mask",
    "assets/pause/close_button.png",
    "assets/update/text_spin_now.png",
    "tutorial_button",
    "Edge",
    "select",
    "assets/shop/stones/stone_06.png",
    "defineProperties",
    "logo_2",
    "Rectangle",
    "assets/result/results_win_stones.png",
    "ticker",
    "_fps",
    "coins_big",
    "right",
    "startSlide",
    "wincoins",
    "playerPuck",
    "height",
    "assets/select/back_button.png",
    "_btnSpin",
    "timer",
    "pop",
    "center",
    "assets/tables/0/delhi_lounge_corners.png",
    "_completeCallback",
    "oldZOrder",
    "_sound",
    "assets/select/tableselect_royalarena_base.png",
    "aim",
    "strike_01",
    "aimFactor",
    "corner_striker_base_2",
    "assets/tables/3/Carrom_corner_BR.png",
    "textureOver",
    "sort",
    "corner_striker_base_0",
    "assets/shop/shop_stones_module_dimmed.png",
    "begin-contact",
    "scale",
    "release",
    "assets/tables/2/mahal_palace_strike_base_background.png",
    "check_filled",
    "easeOutQuint",
    "70px\x20Simonetta_white2",
    "addChildZ",
    "results_claimx2_button_hover",
    "assets/Carrom_coins_symbol.png",
    "stringify",
    "test_you_won",
    "corners_2",
    "assets/sounds/putcoin.mp3",
    "oponnentNameLabel",
    "assets/wheel/numbers_shadow.png",
    "assets/Carrom_red.png",
    "msvisibilitychange",
    "splice",
    "assets/sounds/bigwin_var2_5s_byAbsintheMedia.mp3",
    "assets/avatars/frame_red_filled.png",
    "tableselect_prize_base",
    "purple",
    "assets/update/text_free_spin_pressed.png",
    "assets/tables/3/logo.png",
    "assets/settings/lobby_button_tutorial.png",
    "assets/wheel/confetti_04.png",
    "assets/sounds/RailHit05.mp3",
    "strike_03",
    "tutorial",
    "assets/result/results_claimx2_button.png",
    "assets/shop/strike_07.png",
    "assets/shop/stones/stone_08.png",
    "tut_2_6",
    "settings",
    "_btnPlayCarrom",
    "strikersHeader",
    "shop_single_coin",
    "tut_05_screen_design",
    "_elapsed",
    "assets/arrow_motion.png",
    "assets/pause/music_button_sfx.png",
    "title",
    "bar",
    "marginTop",
    "easeInQuad",
    "isSensor",
    "_loop",
    "assets/pause/sfx_button_hover.png",
    "reset",
    "isAwake",
    "corners_4",
    "pause_base",
    "MOVE\x20THE\x20STRIKER\x20LEFT\x0aOR\x20RIGHT\x20USING\x20THE\x20BAR\x0aAT\x20THE\x20BOTTOM",
    "assets/wheel/brights_behind_numbers.png",
    "tableselect_select_button",
    "muteGroup",
    "angularSpeed",
    "drawRect",
    "blur",
    "oponnentPuck",
    "results_win_stones",
    "assets/tables/2/mahal_palace_corner_BR.png",
    "assets/avatars/silhouette_cha01.png",
    "assets/wheel/carrom_spinning_wheel_arrow.png",
    "assets/sprites/title.png",
    "prize",
    "next",
    "setLinearVelocity",
    "goal",
    "strike_04",
    "confirm",
    "Music",
    "text_free_spin",
    "updateBonusTime",
    "addFrameTween",
    "table_3",
    "loader",
    "set",
    "_tick",
    "_icon",
    "title_sprite",
    "pause",
    "_items",
    "_type",
    "SFX",
    "adBreakDone",
    "assets/pause/button_yes_hover.png",
    "wheel",
    "assets/result/winner_background.png",
    "lobby_button_shop_v02",
    "Carrom_player_white",
    "removeChild",
    "_running",
    "goLeft",
    "stone_02",
    "apply",
    "congText",
    "blue",
    "hpBar",
    "worldX",
    "pause_button_hover",
    "frameWidth",
    "_boosters",
    "style",
    "TextureCache",
    "tableselect_arrow_right",
    "isPlaying",
    "assets/pause/pause_play_button_hover.png",
    "assets/sounds/bigwin_var3_5s_byAbsintheMedia.mp3",
    "pot",
    "clear",
    "strength",
    "assets/shop/shop_coins_cointer_base.png",
    "35px\x20Simonetta_white2",
    "assets/wheel/confetti_07.png",
    "label",
    "shop_button_upgrade_arrow_hover",
    "assets/sprites/impact_b.png",
    "pointertap",
    "results_win_title",
    "logo_0",
    "assets/tutorial/1_6.png",
    "loops",
    "text_you",
    "baseTexture",
    "dir",
    "corner_striker_0",
    "assets/shop/stones/stone_01.png",
    "textureDisabled",
    "setPosition",
    "assets/result/text_you.png",
    "_animations",
    "assets/lobby/lobby_button_discpool_hover.png",
    "resetProps",
    "Stone_Hit_4",
    "_btnHelp",
    "tableselect_delhilounge_title",
    "buy",
    "assets/shop/shop_header_base.png",
    "fill",
    "_page",
    "_elapsedTime",
    "endSpeed",
    "check_unfilled",
    "upgradeCost",
    "period",
    "shine",
    "3ypIbyW",
    "textureDown",
    "render",
    "assets/tables/4/royal_arena_corner_BR.png",
    "locked",
    "avatar_silhouette_cha03",
    "assets/shop/strike_09.png",
    "sprites",
    "results_opponent_profile",
    "assets/settings/lobby_button_tutorial_pressed.png",
    "mark",
    "wheelUpdate",
    "_btnPlay",
    "25px\x20Arial",
    "20px\x20Simonetta_white2",
    "tut_ARROW_LEFT",
    "_speed",
    "avatar_blue_bg",
    "assets/result/loser_04.png",
    "_endSize",
    "charAt",
    "lineTo",
    "assets/result/loser_03.png",
    "disabled",
    "stone_pot_sprite",
    "assets/shop/shop_single_coin.png",
    "change_mute_sound",
    "_endAlpha",
    "POWER\x20OF\x0aEARTH",
    "arrivalOrder",
    "visibilitychange",
    "endSize",
    "stone_00",
    "player",
    "buttonMode",
    "assets/sounds/tap_wood9.mp3",
    "_propsEnd",
    "_target",
    "pointerupoutside",
    "swipeRight",
    "assets/shop/strike_01.png",
    "assets/pause/close_button_hover.png",
    "lastRewardTime",
  ];
  _0x3f3a = function () {
    return _0x1c9b5e;
  };
  return _0x3f3a();
}
