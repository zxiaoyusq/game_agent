# 竞品 ARM64 原生库：交叉引用定位（候选证据）

文件：`libgame-CARROM-GooglePlay-Gold-Release-Module-1491.so`；SHA-256 `4cf2ba474fc9aefda142fbdca46cf7b4d3ebf06a2114ecd8487a3e48448710b4`；架构 AArch64。以下均为 ELF link virtual address（不是文件偏移、不是模拟器运行地址）。候选来源与完整指令见 `../02_静态分析/native_字符串交叉引用候选.json` 和 `../02_静态分析/ARM64反汇编_候选/`，产生脚本在 `../00_分析脚本/`。

## 方法及限制
扫描 `.text` 中 ADRP 后至多 8 条指令内使用同一寄存器的 ADD 立即数，当计算地址恰为目标字符串起点时登记；再以 `.eh_frame` 中 FDE 回溯可能的指令范围，使用 Capstone 逐条反汇编。静态扫描不会覆盖 literal load、间接引用、重定位与寄存器转移，扫描命中也不保证寄存器在两指令间没有被改写；FDE 是栈展开范围，不能单独证明语义函数、入口可达或参数。未根据未匹配版本套用其他 APK 地址。

|线索|引用指令 link VA|FDE 范围（左闭右开）|解释与边界|
|---|---|---|---|
|shotPowerLimits|0x18b0a64|0x18b09d4–0x18b15a4|定位到读取该字符串的候选代码范围；变量结构和真实力度曲线仍未确定|
|MatchShotSolver 构造相关类型名|0x18bc61c|0x18bc618–0x18bc634|仅 28 字节的字符串/类型名访问相关范围，不能当作求解算法|
|MatchShotSolver startSolving 类型名|0x18bc81c / 0x18bc8c0|0x18bc818–0x18bc834 / 0x18bc8bc–0x18bc8d8|两个短范围支持该命名存在，未证实函数实现|
|MatchShotSolver simulateShot 类型名|0x18bca54 / 0x18bccd0|0x18bca50–0x18bca6c / 0x18bcccc–0x18bcce8|两个短范围更像与类型名相关的辅助代码；不得报告为模拟击球实现|
|MatchControllerCarrom physicsStoppedExtra 类型名|0x1a855bc|0x1a855b8–0x1a855d4|短范围，不能据此还原停球后规则|
|MatchControllerTurnBased physicsStopped 类型名|0x1a94c40|0x1a94c3c–0x1a94c58|短范围，不能据此证明回合交接次序|
|queenCovered|0x1aa3708|0x1aa3458–0x1aa38b8|定位到一个直接引用键名的较长 FDE 范围；读写方向、字段协议和实际规则仍未确认|
|gameplay_aim_event|0x1fa8e74|0x1fa8e70–0x1fa8e80|短字符串引用，不能证明线上发送或传输内容|

## 下一步
针对 `shotPowerLimits` 和 `queenCovered` 两个较长范围，先做控制流与直接调用者定位，结合已解析 plist 和可用符号，证明读取还是写入、条件与状态 owner；对 MatchShotSolver 的类型名访问点需继续寻找其 vtable/函数体引用，不能把 28 字节辅助范围误当主算法。欲得到运行时地址需按匹配进程的 maps/PT_LOAD 单独计算 load bias，再进行只读观察；尚未执行该步骤。

## 补充：直接调用边

对 `.text` 中 AArch64 `BL` 立即数目标进行只读扫描，仅匹配上述两个较长 FDE 的起始地址，结果见 `../02_静态分析/native_候选函数直接调用.json`。`0x18b31fc–0x18b35e0` 范围中 `0x18b3374` 与 `0x18b339c` 两处直接调用 `0x18b09d4`；`0x1aa2eb0–0x1aa328c` 范围中 `0x1aa30b0` 直接调用 `0x1aa3458`。两个调用方范围的反汇编为 `ARM64反汇编_候选/caller_18b31fc.txt` 和 `caller_1aa2eb0.txt`。

这证明在此配对的静态机器码中存在直接调用指令及其目标地址；尚未确认调用方业务身份、实际触发条件、字符串读写语义与完整调用图。扫描只覆盖 BL 直连，不包含间接调用、尾调用和进入范围中部的跳转；未命中不代表没有调用。

## 补充：类型名重定位

扫描本构建 `.rela.dyn` 及 `.rela.plt` 共 671,217 条重定位，针对 7 个类型名字符串发现对应的 `R_AARCH64_RELATIVE`（类型 1027）加数引用；完整结果见 `native_字符串relocation候选.json`。进一步搜索这些指针附近 ±24 字节的重定位得到 2 条邻近候选，见 `native_RTTI附近引用候选.json`。这与短函数返回类型名的解释相容，但未完成 C++ RTTI/vtable 结构验证，也未定位 `MatchShotSolver::simulateShot` 的实际函数体，不能据此声称已拆出机器人的击球算法。

## 未解析配置：加载链线索（2026-11-11）

本机对原库做全量可打印字符串筛选，找到 `GameConfiguration.plist`、`decryptAES128`、`downloadClientConfiguration` 与 `Configuration reload start` 等独立字符串；见 `../02_静态分析/native_配置与加密字符串.txt`。随后用与前述相同的 AArch64 静态扫描定位到 `GameConfiguration.plist` 字符串引用候选 `0x1e3f710`（FDE 仅 12 字节）、`decryptAES128` 候选 `0x2711cc4`（FDE 仅 36 字节）、`Configuration reload start` 候选 `0x1e418fc`（FDE 628 字节），完整映射见 `native_配置加载交叉引用候选.json`。

这些命名与代码候选不足以证明 `GameConfiguration.plist` 使用 AES、密钥位置、解密成功，或者配置取自线上；`decryptAES128` 可能服务其他模块，短范围也可能只是名称/分发辅助。下一步须追踪配置文件读取者、两者之间可达的实际调用路径与返回数据，不把文本中的算法名称或字节熵直接写成配置加密结论。
