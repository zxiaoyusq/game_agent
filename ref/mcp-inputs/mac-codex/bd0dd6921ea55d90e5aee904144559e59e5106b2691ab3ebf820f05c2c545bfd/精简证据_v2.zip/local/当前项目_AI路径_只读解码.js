    function _0x50a0ff() {
      var _0x50f23a = _0x157421;
      ((_0x3a1262 = !![]),
        (_0x1a373b = _0x1f57de),
        (_0x44d1ad["frame"]["value"] = 0x64),
        (_0x530863 = ![]),
        (_0x5ebd99 = ![]),
        (_0x209883 = ![]),
        _0x147a99["setEnable"](![]),
        (_0x27e1b4["visible"] = !![]),
        (_0x27e1b4["alpha"] = 0x1),
        (_0x27e1b4["overlay"]["visible"] = ![]),
        _0x27e1b4["setSensor"](!![]),
        (_0x27e1b4["sprite"]["texture"] =
          PIXI["utils"]["TextureCache"][_0x427440[0x0]["texture"]]),
        (_0x27e1b4["worldX"] = 0x140),
        (_0x27e1b4["worldY"] = _0x429ae3 - 0xc8),
        (_0x27e1b4["alpha"] = 0x0),
        Tweener["addTween"](
          _0x27e1b4,
          {
            worldX: 0x140,
            worldY: _0x429ae3,
            alpha: 0x1,
            scaleX: 0x1,
            scaleY: 0x1,
          },
          { time: 0xf, transition: "easeOutQuad" },
        ),
        _0x338c29(function () {
          var _0x46f397 = _0x50f23a;
          if (!_0x3fddb3) return;
          _0x27e1b4[_0x46f397(0x152)]();
          let _0x3a3b87, _0x28e19e, _0x51885a, _0x34f6fb;
          _0x5d148e == 0x2
            ? ((_0x3a3b87 = _0x52106f(
                _0x2fc10d[0x0],
                _0x2a9c75["concat"](_0x3e4566, _0x3231b3),
                !![],
              )),
              (_0x28e19e = _0x25af2a(
                _0x2fc10d[0x1],
                _0x2a9c75["concat"](_0x3e4566, _0x3231b3),
                !![],
              )),
              (_0x51885a = _0x521eef(
                _0x2fc10d[0x2],
                _0x2a9c75[_0x46f397(0x1c0)](_0x3e4566, _0x3231b3),
                !![],
              )),
              (_0x34f6fb = _0x30849b(
                _0x2fc10d[0x3],
                _0x2a9c75[_0x46f397(0x1c0)](_0x3e4566, _0x3231b3),
                !![],
              )))
            : _0x2a9c75["length"] == 0x1 && _0x3231b3[_0x46f397(0x182)]
              ? ((_0x3a3b87 = _0x52106f(_0x2fc10d[0x0], _0x3231b3, !![])),
                (_0x28e19e = _0x25af2a(_0x2fc10d[0x1], _0x3231b3, !![])),
                (_0x51885a = _0x521eef(_0x2fc10d[0x2], _0x3231b3, !![])),
                (_0x34f6fb = _0x30849b(_0x2fc10d[0x3], _0x3231b3, !![])))
              : ((_0x3a3b87 = _0x52106f(_0x2fc10d[0x0], _0x2a9c75, !![])),
                (_0x28e19e = _0x25af2a(_0x2fc10d[0x1], _0x2a9c75, !![])),
                (_0x51885a = _0x521eef(_0x2fc10d[0x2], _0x2a9c75, !![])),
                (_0x34f6fb = _0x30849b(_0x2fc10d[0x3], _0x2a9c75, !![])));
          let _0x17e77e = [][_0x46f397(0x1c0)](
            _0x3a3b87,
            _0x28e19e,
            _0x51885a,
            _0x34f6fb,
          );
          if (_0x17e77e[_0x46f397(0x182)]) {
            _0x17e77e[_0x46f397(0x22d)](
              (_0x52fdd4, _0x196fad) =>
                _0x196fad[_0x46f397(0x3f0)] - _0x52fdd4[_0x46f397(0x3f0)],
            );
            let _0x321dde = _0x17e77e[0x0][_0x46f397(0x32c)];
            _0xd6b627(
              _0x17e77e[0x0],
              (_0x321dde / 0x64) * 0x3c * 0.2 * 1.1 * 1.25,
            );
          } else _0xd6b627(_0x3d12d7(), 0x64);
        }, 0x1f4));
    }
    function _0x5e7a5f() {
      var _0x57aab0 = _0x157421;
      ((_0x3a1262 = !![]),
        (_0x1a373b = _0x1f57de),
        (_0x2cf38a["frame"]["value"] = 0x64),
        (_0x530863 = ![]),
        (_0x5ebd99 = ![]),
        (_0x55e693 = !![]),
        (_0x209883 = !![]),
        _0x147a99["setEnable"](!![]),
        (_0x147a99["value"] = 0.5),
        (_0x27e1b4["visible"] = !![]),
        (_0x27e1b4["zOrder"] = 0x32),
        (_0x27e1b4["alpha"] = 0x1),
        (_0x27e1b4["overlay"]["visible"] = ![]),
        _0x27e1b4["setSensor"](!![]),
        (_0x27e1b4["sprite"]["texture"] =
          PIXI["utils"]["TextureCache"][
            _0x427440[_0x4b3012]["texture"]
          ]),
        (_0x27e1b4["worldX"] = 0x140),
        (_0x27e1b4["worldY"] = 0x2be + 0x7e + 0xc8),
        (_0x27e1b4["alpha"] = 0x0),
        Tweener["addTween"](
          _0x27e1b4,
          {
            worldX: 0x140,
            worldY: 0x2be + 0x7e,
            alpha: 0x1,
            scaleX: 0x1,
            scaleY: 0x1,
          },
          {
            time: 0xf,
            transition: "easeOutQuad",
            onComplete: function () {
              var _0x4e7759 = _0x57aab0;
              (_0x41684e(), (_0x27e1b4[_0x4e7759(0x325)]["visible"] = !![]));
            },
          },
        ),
        _0x183856 && _0x14cbdd == 0x0 && _0x25e9ed(0x0));
    }
    function _0x41684e() {
      var _0xfe66ed = _0x157421;
      if (_0x23a7dc(_0x27e1b4, _0x133600 + _0x3ce1ab)) {
        let _0x3e8706 = _0x27e1b4["x"],
          _0xc9112e = _0x27e1b4["y"];
        for (
          let _0x4a1b72 = 0x0;
          _0x4a1b72 < _0x187453 - _0x55e1a0;
          _0x4a1b72 += 0x2
        ) {
          if (
            _0x3e8706 + _0x4a1b72 < _0x187453 &&
            !_0x23a7dc(
              { x: _0x3e8706 + _0x4a1b72, y: _0xc9112e },
              _0x133600 + _0x3ce1ab,
            )
          ) {
            ((_0x27e1b4["worldX"] = _0x3e8706 + _0x4a1b72),
              (_0x147a99["value"] =
                (_0x27e1b4["worldX"] - _0x55e1a0) /
                (_0x187453 - _0x55e1a0)),
              (_0x27e1b4["alpha"] = 0x1),
              (_0x27e1b4["overlay"]["visible"] = ![]));
            return;
          } else {
            if (
              _0x3e8706 - _0x4a1b72 > _0x55e1a0 &&
              !_0x23a7dc(
                { x: _0x3e8706 - _0x4a1b72, y: _0xc9112e },
                _0x133600 + _0x3ce1ab,
              )
            ) {
              ((_0x27e1b4["worldX"] = _0x3e8706 - _0x4a1b72),
                (_0x147a99["value"] =
                  (_0x27e1b4["worldX"] - _0x55e1a0) /
                  (_0x187453 - _0x55e1a0)),
                (_0x27e1b4["alpha"] = 0x1),
                (_0x27e1b4["overlay"]["visible"] = ![]));
              return;
            }
          }
        }
      }
    }
    function _0x36ab44() {
      var _0x29ef4e = _0x157421;
      if (_0x183856 && _0x14cbdd == 0x0) return;
      if (!_0x55e693 || !_0x209883) return;
      if (_0xf86500) return;
      ((_0xf86500 = !![]),
        _0x183856 && _0x14cbdd == 0x1 && _0x279414(0x1),
        (_0xc5bee4["visible"] = !![]),
        (_0xc5bee4["strength"] = 0x0),
        (_0xc5bee4["x"] = _0x27e1b4["x"]),
        (_0xc5bee4["y"] = _0x27e1b4["y"]));
    }
    function _0x1e39ba(_0x30192f) {
      var _0x10c900 = _0x157421;
      if (!_0xf86500) return;
      ((_0xf86500 = ![]),
        (_0xc5bee4["visible"] = ![]),
        _0xc5bee4["strength"] >= 0.25 &&
          (_0x27e1b4["test"](
            _0xc5bee4["strength"] * _0x301cde * 1.25,
            0x2 * Math["PI"] - _0xc5bee4["angle"],
          ),
          _0x24bb4a(),
          _0x338c29(function () {
            _0xbdafb3();
          }, 0x8fc)));
    }
    function _0x536112(_0x20d729) {
      var _0x4630df = _0x157421;
      if (!_0xf86500) return;
      let _0x24dee2 = {
          x:
            _0x20d729["data"]["global"]["x"] -
            _0x24b13c / 0x2,
          y: _0x20d729["data"]["global"]["y"] - _0x376ce3 / 0x2,
        },
        _0x26ab5d = _0x2bd695(_0x27e1b4, _0x24dee2),
        _0x1d5eea = _0x8b2762(_0x27e1b4, _0x24dee2);
      if (_0x26ab5d > _0x647bf3) _0x26ab5d = _0x647bf3;
      ((_0xc5bee4["strength"] = _0x26ab5d / _0x647bf3),
        (_0xc5bee4["angle"] = _0x1d5eea));
    }
    function _0xd6b627(_0x232fd1, _0x1f0de3) {
      var _0x18b010 = _0x157421;
      ((_0x27e1b4["worldY"] = _0x232fd1["pos"]["y"]),
        _0x4662ac(_0x232fd1, _0x1f0de3, 0x0));
      return;
      ((_0x27e1b4["worldX"] = _0x232fd1["pos"]["x"]),
        (_0x27e1b4["worldY"] = _0x232fd1["pos"]["y"]),
        _0x27e1b4["test"](
          _0x1f0de3,
          Math["PI"] - _0x232fd1["dir"],
        ),
        _0x24bb4a(),
        _0x338c29(function () {
          _0xbdafb3();
        }, 0x1388));
    }
    function _0x4662ac(_0x2c688c, _0x491246, _0x17bf57) {
      var _0x16cdcf = _0x157421;
      let _0x37f716 = 0x0;
      if (Math["random"]() > 0.5 || _0x17bf57 > 0x2)
        ((_0x37f716 = _0x2c688c["pos"]["x"]),
          Tweener["addTween"](
            _0x27e1b4,
            { x: _0x37f716 },
            {
              time: 0x14 + Math["random"]() * 0xa,
              transition: "linear",
              onComplete: function () {
                _0x223471(_0x2c688c, _0x491246);
              },
            },
          ));
      else {
        _0x37f716 =
          _0x2c688c["pos"]["x"] - 0x46 + Math["random"]() * 0x8c;
        if (_0x37f716 < _0x55e1a0) _0x37f716 = _0x55e1a0;
        else {
          if (_0x37f716 > _0x187453) _0x37f716 = _0x187453;
        }
        Tweener["addTween"](
          _0x27e1b4,
          { x: _0x37f716 },
          {
            time: 0x14 + Math["random"]() * 0xa,
            transition: "linear",
            onComplete: function () {
              _0x4662ac(_0x2c688c, _0x491246, ++_0x17bf57);
            },
          },
        );
      }
    }
    function _0x223471(_0xcc3517, _0x464ba8) {
      var _0x34ee5c = _0x157421;
      let _0x11e6d1 = _0x18e0e1[_0x408018];
      ((_0xc5bee4["visible"] = !![]),
        (_0xc5bee4["x"] = _0x27e1b4["x"]),
        (_0xc5bee4["y"] = _0x27e1b4["y"]));
      let _0x3de4be =
          (Math["PI"] - _0xcc3517["dir"] - 0x2 * Math["PI"]) * -0x1,
        _0x3c208d = _0x464ba8 / _0x301cde,
        _0x30de27 = 0x0;
      if (_0x3c208d > 0x1) _0x3c208d = 0x1;
      (Math["random"]() < _0x11e6d1 &&
        (Math["random"]() > 0.5
          ? (_0x30de27 = -0.05 - Math["random"]() * 0.05)
          : (_0x30de27 = 0.05 + Math["random"]() * 0.05)),
        (_0x3de4be += _0x30de27),
        (_0xc5bee4["angle"] = _0x3de4be),
        (_0xc5bee4["strength"] = 0x0),
        Tweener["addTween"](
          _0xc5bee4,
          { strength: _0x3c208d, angle: _0x3de4be },
          {
            time: 0xa + Math["random"]() * 0xa,
            transition: "linear",
            onComplete: function () {
              _0x338c29(function () {
                if (!_0x3fddb3) return;
                _0x4b3cc6(_0xcc3517, _0x464ba8, _0x30de27);
              }, 0x1f4);
            },
          },
        ));
    }
    function _0x4b3cc6(_0x412177, _0x3e3780, _0x323212) {
      var _0x2643c5 = _0x157421;
      ((_0xc5bee4["visible"] = ![]),
        (_0x27e1b4["worldX"] = _0x412177["pos"]["x"]),
        (_0x27e1b4["worldY"] = _0x412177["pos"]["y"]),
        _0x27e1b4["test"](
          _0x3e3780,
          Math["PI"] - _0x412177["dir"] + _0x323212,
        ),
        _0x24bb4a(),
        _0x338c29(function () {
          _0xbdafb3();
        }, 0x8fc));
    }
    function _0x3d12d7() {
      var _0x385866 = _0x157421;
      let _0x3a50e5 = []["concat"](_0x2a9c75);
      !_0x3a50e5["length"] &&
        (_0x3a50e5 = _0x3a50e5["concat"](_0x3e4566, _0x3231b3));
      let _0xe88441 =
          _0x3a50e5[
            Math["floor"](
              Math["random"]() * _0x3a50e5["length"],
            )
          ],
        _0x4b85cd = {
          x: _0x55e1a0 + Math["random"]() * (_0x187453 - _0x55e1a0),
          y: _0x429ae3,
        };
      if (_0x23a7dc(_0x4b85cd, _0x133600 + _0x3ce1ab)) {
        let _0x2cdbc8 = _0x4b85cd["x"],
          _0x7c680f = _0x4b85cd["y"];
        for (
          let _0x280ad6 = 0x0;
          _0x280ad6 < _0x187453 - _0x55e1a0;
          _0x280ad6 += 0x2
        ) {
          if (
            _0x2cdbc8 + _0x280ad6 < _0x187453 &&
            !_0x23a7dc(
              { x: _0x2cdbc8 + _0x280ad6, y: _0x7c680f },
              _0x133600 + _0x3ce1ab,
            )
          ) {
            _0x4b85cd["x"] = _0x2cdbc8 + _0x280ad6;
            break;
          } else {
            if (
              _0x2cdbc8 - _0x280ad6 > _0x55e1a0 &&
              !_0x23a7dc(
                { x: _0x2cdbc8 - _0x280ad6, y: _0x7c680f },
                _0x133600 + _0x3ce1ab,
              )
            ) {
              _0x4b85cd["x"] = _0x2cdbc8 - _0x280ad6;
              break;
            }
          }
        }
      }
      return { pos: _0x4b85cd, dir: _0x8b2762(_0x4b85cd, _0xe88441) };
    }
    function _0x52106f(
      _0x3796e7,
      _0x31dcf9,
      _0x9b1349,
      _0x393f58,
      _0x1c8c11,
      _0x158572,
    ) {
      var _0x2b4d0b = _0x157421;
      let _0x3ed68d = 0x5,
        _0x227745 = 0x3;
      var _0x2dec07 = [];
      for (
        let _0x3b2c0d = 0x0;
        _0x3b2c0d < _0x31dcf9["length"];
        _0x3b2c0d++
      ) {
        let _0x5bf2f1 = _0x31dcf9[_0x3b2c0d],
          _0x2708bd = _0x5ccc96;
        if (
          _0x5bf2f1["y"] >
          _0x24c0ca["y"] +
            _0x24c0ca["height"] -
            (_0x429ae3 + _0x3ce1ab - _0x24c0ca["y"])
        )
          continue;
        if (_0x5bf2f1["y"] < _0x3796e7["y"]) continue;
        if (_0x5bf2f1["x"] < _0x3796e7["x"]) continue;
        let _0x3bd0a2 = _0x8b2762(_0x5bf2f1, _0x3796e7),
          _0x3bfc4a = _0x2bd695(_0x5bf2f1, _0x3796e7),
          _0x1602ce = _0x393f58
            ? Math["abs"](
                Math["cos"](_0x1c8c11) *
                  Math["cos"](_0x3bd0a2) +
                  Math["sin"](_0x1c8c11) *
                    Math["sin"](_0x3bd0a2),
              )
            : 0x1;
        if (_0x1602ce < 0.5) continue;
        let _0x3f1eca =
          _0x9b1349 &&
          _0x3ea989(_0x5bf2f1, _0x3ce1ab * 0x2, _0x3bd0a2, _0x3bfc4a);
        if (_0x3f1eca) continue;
        let _0x445ac0 = {
          x:
            _0x5bf2f1["x"] -
            Math["cos"](_0x3bd0a2) * (_0x3ce1ab + _0x133600),
          y:
            _0x5bf2f1["y"] -
            Math["sin"](_0x3bd0a2) * (_0x3ce1ab + _0x133600),
        };
        if (_0x5bf2f1["y"] < _0x429ae3)
          for (let _0x20a52d = -0x1; _0x20a52d <= _0x3ed68d; _0x20a52d++) {
            let _0x1d6680 = 0x0;
            if (_0x20a52d < 0x0) {
              _0x1d6680 =
                _0x5bf2f1["x"] -
                (_0x5bf2f1["y"] - _0x429ae3) / Math["tan"](_0x3bd0a2);
              if (_0x1d6680 < _0x55e1a0 || _0x1d6680 > _0x187453) continue;
            } else {
              _0x1d6680 =
                _0x55e1a0 + (_0x187453 - _0x55e1a0) * (_0x20a52d / _0x3ed68d);
              if (_0x1d6680 > _0x5bf2f1["x"] - _0x3ce1ab - _0x133600) continue;
            }
            let _0x2c664d = { x: _0x1d6680, y: _0x429ae3 };
            if (_0x23a7dc(_0x2c664d, _0x133600 + _0x3ce1ab)) continue;
            let _0x1cd0f4 = _0x8b2762(_0x2c664d, _0x445ac0),
              _0x3291e7 = _0x2bd695(_0x2c664d, _0x445ac0),
              _0x4db6fc = Math["abs"](
                Math["cos"](_0x3bd0a2) *
                  Math["cos"](_0x1cd0f4) +
                  Math["sin"](_0x3bd0a2) * Math["sin"](_0x1cd0f4),
              ),
              _0x523a92 = _0x16430c(_0x3bd0a2, _0x1cd0f4),
              _0x24a99c = _0x3bfc4a + _0x3291e7 + (_0x158572 || 0x0);
            _0x4db6fc *= _0x1602ce;
            let _0x448747 = 0xa + (0x1 - _0x4db6fc) * _0x301cde;
            if (_0x4db6fc > _0x5ccc96 && _0x4db6fc > _0x2708bd) {
              let _0x53086d = _0x3ea989(
                _0x2c664d,
                _0x133600 * 0x2,
                _0x1cd0f4,
                _0x3291e7,
              );
              if (_0x53086d) continue;
              _0x2708bd = _0x4db6fc;
              if (_0x393f58)
                _0x393f58["push"]({
                  pos: _0x2c664d,
                  dir: _0x1cd0f4,
                  speed: _0x448747,
                  hDot: _0x4db6fc,
                  dist: _0x24a99c,
                });
              else
                _0x2dec07["push"]({
                  pos: _0x2c664d,
                  dir: _0x1cd0f4,
                  speed: _0x448747,
                  hDot: _0x4db6fc,
                  dist: _0x24a99c,
                });
              if (_0x20a52d < 0x0) break;
            }
          }
        if (_0x2708bd < 0.7) {
          let _0x198e4d =
            _0x24c0ca["y"] +
            _0x24c0ca["height"] -
            0x1a -
            _0x133600 +
            (_0x24c0ca["y"] +
              _0x24c0ca["height"] -
              0x1a -
              _0x133600 -
              _0x445ac0["y"]);
          for (let _0x3961f5 = 0x0; _0x3961f5 <= _0x227745; _0x3961f5++) {
            let _0x3723ac =
              _0x55e1a0 + (_0x187453 - _0x55e1a0) * (_0x3961f5 / _0x227745);
            if (_0x3723ac < _0x5bf2f1["x"] + _0x3ce1ab + _0x133600) continue;
            let _0x3442b5 = { x: _0x3723ac, y: _0x429ae3 };
            if (_0x23a7dc(_0x3442b5, _0x133600 + _0x3ce1ab)) continue;
            let _0x248c6b = _0x8b2762(_0x3442b5, {
                x: _0x445ac0["x"],
                y: _0x198e4d,
              }),
              _0x4199d5 =
                _0x3723ac +
                (0x1 / Math["tan"](_0x248c6b)) *
                  (_0x24c0ca["y"] +
                    _0x24c0ca["height"] -
                    0x1a -
                    _0x133600 -
                    _0x429ae3),
              _0x5b4aca = {
                x: _0x4199d5,
                y:
                  _0x24c0ca["y"] +
                  _0x24c0ca["height"] -
                  0x1a -
                  _0x133600,
              },
              _0xa1fc64 = _0x2bd695(_0x5b4aca, _0x3442b5),
              _0x63ef0a = _0x8b2762(_0x5b4aca, _0x445ac0),
              _0x157794 = _0x2bd695(_0x5b4aca, _0x445ac0),
              _0x3099e5 = Math["abs"](
                Math["cos"](_0x3bd0a2) *
                  Math["cos"](_0x63ef0a) +
                  Math["sin"](_0x3bd0a2) *
                    Math["sin"](_0x63ef0a),
              ),
              _0x1ce3bb =
                _0x3bfc4a + _0xa1fc64 + _0x157794 + (_0x158572 || 0x0);
            _0x3099e5 *= _0x1602ce;
            let _0x4677c1 = 0xa + (0x1 - _0x3099e5) * _0x301cde;
            if (_0x3099e5 > _0x5ccc96 && _0x3099e5 > _0x2708bd) {
              let _0x1dab44 = _0x3ea989(
                _0x3442b5,
                _0x133600 * 0x2,
                _0x248c6b,
                _0xa1fc64,
              );
              if (_0x1dab44) continue;
              let _0x478446 = _0x3ea989(
                _0x5b4aca,
                _0x133600 * 0x2,
                _0x63ef0a,
                _0x157794,
              );
              if (_0x478446) continue;
              _0x2708bd = _0x3099e5;
              if (_0x393f58)
                _0x393f58["push"]({
                  pos: _0x3442b5,
                  dir: _0x248c6b,
                  speed: _0x4677c1,
                  hDot: _0x3099e5,
                  dist: _0x1ce3bb,
                });
              else
                _0x2dec07["push"]({
                  pos: _0x3442b5,
                  dir: _0x248c6b,
                  speed: _0x4677c1,
                  hDot: _0x3099e5,
                  dist: _0x1ce3bb,
                });
            }
          }
        }
        if (_0x2708bd <= 0.5 && !_0x393f58) {
          var _0x4191c3 = {
              x:
                _0x5bf2f1["x"] -
                Math["cos"](_0x3bd0a2) * (_0x3ce1ab + _0x3ce1ab),
              y:
                _0x5bf2f1["y"] -
                Math["sin"](_0x3bd0a2) * (_0x3ce1ab + _0x3ce1ab),
            },
            _0x5bee96 = _0x2a9c75["concat"](_0x3e4566, _0x3231b3);
          _0x52106f(
            _0x4191c3,
            _0x5bee96,
            !![],
            _0x2dec07,
            _0x3bd0a2,
            _0x3bfc4a,
          );
          continue;
        }
      }
      return _0x2dec07;
    }
    function _0x25af2a(
      _0xc72ab3,
      _0x4a4db6,
      _0x19427c,
      _0x362db2,
      _0x5bd84c,
      _0x199793,
    ) {
      var _0x218670 = _0x157421;
      let _0x385c6d = 0x5,
        _0xbd7d34 = 0x3;
      var _0x192a08 = [];
      for (
        let _0x2a1151 = 0x0;
        _0x2a1151 < _0x4a4db6["length"];
        _0x2a1151++
      ) {
        let _0x5ccf72 = _0x4a4db6[_0x2a1151],
          _0x28180b = _0x5ccc96;
        if (
          _0x5ccf72["y"] >
          _0x24c0ca["y"] +
            _0x24c0ca["height"] -
            (_0x429ae3 + _0x3ce1ab - _0x24c0ca["y"])
        )
          continue;
        if (_0x5ccf72["y"] < _0xc72ab3["y"]) continue;
        if (_0x5ccf72["x"] > _0xc72ab3["x"]) continue;
        let _0x4ea0a1 = _0x8b2762(_0x5ccf72, _0xc72ab3),
          _0x5a9326 = _0x2bd695(_0x5ccf72, _0xc72ab3),
          _0x4fcd0f = _0x362db2
            ? Math["abs"](
                Math["cos"](_0x5bd84c) * Math["cos"](_0x4ea0a1) +
                  Math["sin"](_0x5bd84c) *
                    Math["sin"](_0x4ea0a1),
              )
            : 0x1;
        if (_0x4fcd0f < 0.5) continue;
        let _0x1f5a98 =
          _0x19427c &&
          _0x3ea989(_0x5ccf72, _0x3ce1ab * 0x2, _0x4ea0a1, _0x5a9326);
        if (_0x1f5a98) continue;
        let _0x549a1b = {
          x: _0x5ccf72["x"] - Math["cos"](_0x4ea0a1) * (_0x3ce1ab + _0x133600),
          y:
            _0x5ccf72["y"] -
            Math["sin"](_0x4ea0a1) * (_0x3ce1ab + _0x133600),
        };
        if (_0x5ccf72["y"] < _0x429ae3)
          for (let _0x9c63b = -0x1; _0x9c63b <= _0x385c6d; _0x9c63b++) {
            let _0x37641b = 0x0;
            if (_0x9c63b < 0x0) {
              _0x37641b =
                _0x5ccf72["x"] -
                (_0x5ccf72["y"] - _0x429ae3) /
                  Math["tan"](_0x4ea0a1);
              if (_0x37641b < _0x55e1a0 || _0x37641b > _0x187453) continue;
            } else {
              _0x37641b =
                _0x55e1a0 + (_0x187453 - _0x55e1a0) * (_0x9c63b / _0x385c6d);
              if (_0x37641b > _0x5ccf72["x"] - _0x3ce1ab - _0x133600) continue;
            }
            let _0x259ced = { x: _0x37641b, y: _0x429ae3 };
            if (_0x23a7dc(_0x259ced, _0x133600 + _0x3ce1ab)) continue;
            let _0x33ad63 = _0x8b2762(_0x259ced, _0x549a1b),
              _0x51ba9e = _0x2bd695(_0x259ced, _0x549a1b),
              _0x3c8aae = Math["abs"](
                Math["cos"](_0x4ea0a1) *
                  Math["cos"](_0x33ad63) +
                  Math["sin"](_0x4ea0a1) *
                    Math["sin"](_0x33ad63),
              ),
              _0x394a5d = _0x16430c(_0x4ea0a1, _0x33ad63),
              _0xbeb150 = _0x5a9326 + _0x51ba9e + (_0x199793 || 0x0);
            _0x3c8aae *= _0x4fcd0f;
            let _0x33c3f5 = 0xa + (0x1 - _0x3c8aae) * _0x301cde;
            if (_0x3c8aae > _0x5ccc96 && _0x3c8aae > _0x28180b) {
              let _0x281f85 = _0x3ea989(
                _0x259ced,
                _0x133600 * 0x2,
                _0x33ad63,
                _0x51ba9e,
              );
              if (_0x281f85) continue;
              _0x28180b = _0x3c8aae;
              if (_0x362db2)
                _0x362db2["push"]({
                  pos: _0x259ced,
                  dir: _0x33ad63,
                  speed: _0x33c3f5,
                  hDot: _0x3c8aae,
                  dist: _0xbeb150,
                });
              else
                _0x192a08["push"]({
                  pos: _0x259ced,
                  dir: _0x33ad63,
                  speed: _0x33c3f5,
                  hDot: _0x3c8aae,
                  dist: _0xbeb150,
                });
              if (_0x9c63b < 0x0) break;
            }
          }
        if (_0x28180b < 0.7) {
          let _0x224747 =
            _0x24c0ca["y"] +
            _0x24c0ca["height"] -
            0x1a -
            _0x133600 +
            (_0x24c0ca["y"] +
              _0x24c0ca["height"] -
              0x1a -
              _0x133600 -
              _0x549a1b["y"]);
          for (let _0x4cb531 = 0x0; _0x4cb531 <= _0xbd7d34; _0x4cb531++) {
            let _0x225639 =
              _0x55e1a0 + (_0x187453 - _0x55e1a0) * (_0x4cb531 / _0xbd7d34);
            if (_0x225639 > _0x5ccf72["x"] - _0x3ce1ab - _0x133600) continue;
            let _0x38960c = { x: _0x225639, y: _0x429ae3 };
            if (_0x23a7dc(_0x38960c, _0x133600 + _0x3ce1ab)) continue;
            let _0x37f94f = _0x8b2762(_0x38960c, {
                x: _0x549a1b["x"],
                y: _0x224747,
              }),
              _0x3db71e =
                _0x225639 +
                (0x1 / Math["tan"](_0x37f94f)) *
                  (_0x24c0ca["y"] +
                    _0x24c0ca["height"] -
                    0x1a -
                    _0x133600 -
                    _0x429ae3),
              _0x8ead75 = {
                x: _0x3db71e,
                y:
                  _0x24c0ca["y"] +
                  _0x24c0ca["height"] -
                  0x1a -
                  _0x133600,
              },
              _0x277390 = _0x2bd695(_0x8ead75, _0x38960c),
              _0x15aa97 = _0x8b2762(_0x8ead75, _0x549a1b),
              _0x244b79 = _0x2bd695(_0x8ead75, _0x549a1b),
              _0x10d489 = Math["abs"](
                Math["cos"](_0x4ea0a1) * Math["cos"](_0x15aa97) +
                  Math["sin"](_0x4ea0a1) * Math["sin"](_0x15aa97),
              ),
              _0x3a85e7 =
                _0x5a9326 + _0x277390 + _0x244b79 + (_0x199793 || 0x0);
            _0x10d489 *= _0x4fcd0f;
            let _0x57f7a8 = 0xa + (0x1 - _0x10d489) * _0x301cde;
            if (_0x10d489 > _0x5ccc96 && _0x10d489 > _0x28180b) {
              let _0x333e22 = _0x3ea989(
                _0x38960c,
                _0x133600 * 0x2,
                _0x37f94f,
                _0x277390,
              );
              if (_0x333e22) continue;
              let _0xceb28 = _0x3ea989(
                _0x8ead75,
                _0x133600 * 0x2,
                _0x15aa97,
                _0x244b79,
              );
              if (_0xceb28) continue;
              _0x28180b = _0x10d489;
              if (_0x362db2)
                _0x362db2["push"]({
                  pos: _0x38960c,
                  dir: _0x37f94f,
                  speed: _0x57f7a8,
                  hDot: _0x10d489,
                  dist: _0x3a85e7,
                });
              else
                _0x192a08["push"]({
                  pos: _0x38960c,
                  dir: _0x37f94f,
                  speed: _0x57f7a8,
                  hDot: _0x10d489,
                  dist: _0x3a85e7,
                });
            }
          }
        }
        if (_0x28180b <= 0.5 && !_0x362db2) {
          var _0x592de6 = {
              x:
                _0x5ccf72["x"] -
                Math["cos"](_0x4ea0a1) * (_0x3ce1ab + _0x3ce1ab),
              y:
                _0x5ccf72["y"] -
                Math["sin"](_0x4ea0a1) * (_0x3ce1ab + _0x3ce1ab),
            },
            _0x3d49b8 = _0x2a9c75["concat"](_0x3e4566, _0x3231b3);
          _0x25af2a(
            _0x592de6,
            _0x3d49b8,
            !![],
            _0x192a08,
            _0x4ea0a1,
            _0x5a9326,
          );
          continue;
        }
      }
      return _0x192a08;
    }
    function _0x521eef(
      _0x49dbe0,
      _0x4a1699,
      _0x1df4ed,
      _0x44ed86,
      _0x4385f7,
      _0x2c42e5,
    ) {
      var _0xba44b = _0x157421;
      let _0x54d63f = 0x5,
        _0x120ffb = 0x3;
      var _0x10409d = [];
      for (
        let _0x1105a3 = 0x0;
        _0x1105a3 < _0x4a1699["length"];
        _0x1105a3++
      ) {
        let _0x401fea = _0x4a1699[_0x1105a3],
          _0x5d6e03 = _0x5ccc96;
        if (_0x401fea["y"] < _0x429ae3 + _0x3ce1ab) continue;
        if (_0x401fea["y"] >= _0x49dbe0["y"]) continue;
        if (_0x401fea["x"] < _0x49dbe0["x"]) continue;
        let _0x398643 = _0x8b2762(_0x401fea, _0x49dbe0),
          _0x2df9cc = _0x2bd695(_0x401fea, _0x49dbe0),
          _0x873a71 = _0x44ed86
            ? Math["abs"](
                Math["cos"](_0x4385f7) *
                  Math["cos"](_0x398643) +
                  Math["sin"](_0x4385f7) * Math["sin"](_0x398643),
              )
            : 0x1;
        if (_0x873a71 < 0.5) continue;
        let _0x58abc0 =
          _0x1df4ed &&
          _0x3ea989(_0x401fea, _0x3ce1ab * 0x2, _0x398643, _0x2df9cc);
        if (_0x58abc0) continue;
        let _0x10f68c = {
          x:
            _0x401fea["x"] -
            Math["cos"](_0x398643) * (_0x3ce1ab + _0x133600),
          y:
            _0x401fea["y"] -
            Math["sin"](_0x398643) * (_0x3ce1ab + _0x133600),
        };
        for (let _0x1ee85a = -0x1; _0x1ee85a <= _0x54d63f; _0x1ee85a++) {
          let _0x2a011a = 0x0;
          if (_0x1ee85a < 0x0) {
            _0x2a011a =
              _0x401fea["x"] -
              (_0x401fea["y"] - _0x429ae3) / Math["tan"](_0x398643);
            if (_0x2a011a < _0x55e1a0 || _0x2a011a > _0x187453) continue;
          } else
            _0x2a011a =
              _0x55e1a0 + (_0x187453 - _0x55e1a0) * (_0x1ee85a / _0x54d63f);
          let _0x41e2cf = { x: _0x2a011a, y: _0x429ae3 };
          if (_0x23a7dc(_0x41e2cf, _0x133600 + _0x3ce1ab)) continue;
          let _0x395f57 = _0x8b2762(_0x41e2cf, _0x10f68c),
            _0x3013bf = _0x2bd695(_0x41e2cf, _0x10f68c),
            _0x5f04cc = Math["abs"](
              Math["cos"](_0x398643) * Math["cos"](_0x395f57) +
                Math["sin"](_0x398643) *
                  Math["sin"](_0x395f57),
            ),
            _0x50a676 = _0x16430c(_0x398643, _0x395f57),
            _0x593986 = _0x2df9cc + _0x3013bf + (_0x2c42e5 || 0x0);
          _0x5f04cc *= _0x873a71;
          let _0x33de1f = 0xa + (0x1 - _0x5f04cc) * _0x301cde;
          if (_0x5f04cc > _0x5ccc96 && _0x5f04cc > _0x5d6e03) {
            let _0x529618 = _0x3ea989(
              _0x41e2cf,
              _0x133600 * 0x2,
              _0x395f57,
              _0x3013bf,
            );
            if (_0x529618) continue;
            _0x5d6e03 = _0x5f04cc;
            if (_0x44ed86)
              _0x44ed86["push"]({
                pos: _0x41e2cf,
                dir: _0x395f57,
                speed: _0x33de1f,
                hDot: _0x5f04cc,
                dist: _0x593986,
              });
            else
              _0x10409d["push"]({
                pos: _0x41e2cf,
                dir: _0x395f57,
                speed: _0x33de1f,
                hDot: _0x5f04cc,
                dist: _0x593986,
              });
            if (_0x1ee85a < 0x0) break;
          }
        }
        if (_0x5d6e03 < 0.7) {
          let _0xadd7ef =
            _0x24c0ca["x"] +
            _0x24c0ca["width"] -
            0x1a -
            _0x133600 +
            (_0x24c0ca["x"] +
              _0x24c0ca["width"] -
              0x1a -
              _0x133600 -
              _0x10f68c["x"]);
          for (let _0x146638 = 0x0; _0x146638 <= _0x120ffb; _0x146638++) {
            let _0x17c8b4 =
                _0x55e1a0 + (_0x187453 - _0x55e1a0) * (_0x146638 / _0x120ffb),
              _0x1590c9 = { x: _0x17c8b4, y: _0x429ae3 };
            if (_0x23a7dc(_0x1590c9, _0x133600 + _0x3ce1ab)) continue;
            let _0x3e3b8f = _0x8b2762(_0x1590c9, {
                x: _0xadd7ef,
                y: _0x10f68c["y"],
              }),
              _0x5d04eb =
                _0x429ae3 -
                Math["tan"](_0x3e3b8f) *
                  (_0x17c8b4 -
                    (_0x24c0ca["x"] + _0x24c0ca["width"] - 0x1a - _0x133600)),
              _0x2fcc90 = {
                x:
                  _0x24c0ca["x"] + _0x24c0ca["width"] - 0x1a - _0x133600,
                y: _0x5d04eb,
              },
              _0x3542cc = _0x2bd695(_0x2fcc90, _0x1590c9),
              _0x163ae8 = _0x8b2762(_0x2fcc90, _0x10f68c),
              _0x1a5851 = _0x2bd695(_0x2fcc90, _0x10f68c),
              _0x112b48 = Math["abs"](
                Math["cos"](_0x398643) *
                  Math["cos"](_0x163ae8) +
                  Math["sin"](_0x398643) *
                    Math["sin"](_0x163ae8),
              ),
              _0x23aa0c =
                _0x2df9cc + _0x3542cc + _0x1a5851 + (_0x2c42e5 || 0x0);
            _0x112b48 *= _0x873a71;
            let _0x24bdd3 = 0xa + (0x1 - _0x112b48) * _0x301cde;
            if (_0x112b48 > _0x5ccc96 && _0x112b48 > _0x5d6e03) {
              let _0x2ddf6e = _0x3ea989(
                _0x1590c9,
                _0x133600 * 0x2,
                _0x3e3b8f,
                _0x3542cc,
              );
              if (_0x2ddf6e) continue;
              let _0x559514 = _0x3ea989(
                _0x2fcc90,
                _0x133600 * 0x2,
                _0x163ae8,
                _0x1a5851,
              );
              if (_0x559514) continue;
              _0x5d6e03 = _0x112b48;
              if (_0x44ed86)
                _0x44ed86["push"]({
                  pos: _0x1590c9,
                  dir: _0x3e3b8f,
                  speed: _0x24bdd3,
                  hDot: _0x112b48,
                  dist: _0x23aa0c,
                });
              else
                _0x10409d["push"]({
                  pos: _0x1590c9,
                  dir: _0x3e3b8f,
                  speed: _0x24bdd3,
                  hDot: _0x112b48,
                  dist: _0x23aa0c,
                });
            }
          }
        }
        if (_0x5d6e03 <= 0.5 && !_0x44ed86) {
          var _0x2b4a5f = {
              x:
                _0x401fea["x"] -
                Math["cos"](_0x398643) * (_0x3ce1ab + _0x3ce1ab),
              y:
                _0x401fea["y"] -
                Math["sin"](_0x398643) * (_0x3ce1ab + _0x3ce1ab),
            },
            _0x252e97 = _0x2a9c75["concat"](_0x3e4566, _0x3231b3);
          _0x521eef(
            _0x2b4a5f,
            _0x252e97,
            !![],
            _0x10409d,
            _0x398643,
            _0x2df9cc,
          );
          continue;
        }
      }
      return _0x10409d;
    }
    function _0x30849b(
      _0x2e9b0d,
      _0x5b36c6,
      _0x19556e,
      _0x53788d,
      _0x5e3826,
      _0x40ebad,
    ) {
      var _0x35324e = _0x157421;
      let _0x22c7cf = 0x5,
        _0x4bdfc3 = 0x3;
      var _0x1c4f05 = [];
      for (
        let _0x45f2f7 = 0x0;
        _0x45f2f7 < _0x5b36c6["length"];
        _0x45f2f7++
      ) {
        let _0x42b5f4 = _0x5b36c6[_0x45f2f7],
          _0x42c127 = _0x5ccc96;
        if (_0x42b5f4["y"] < _0x429ae3 + _0x3ce1ab) continue;
        if (_0x42b5f4["y"] >= _0x2e9b0d["y"]) continue;
        if (_0x42b5f4["x"] > _0x2e9b0d["x"]) continue;
        let _0x89089b = _0x8b2762(_0x42b5f4, _0x2e9b0d),
          _0x354580 = _0x2bd695(_0x42b5f4, _0x2e9b0d),
          _0x5b321d = _0x53788d
            ? Math["abs"](
                Math["cos"](_0x5e3826) * Math["cos"](_0x89089b) +
                  Math["sin"](_0x5e3826) *
                    Math["sin"](_0x89089b),
              )
            : 0x1;
        if (_0x5b321d < 0.5) continue;
        let _0x4356f9 =
          _0x19556e &&
          _0x3ea989(_0x42b5f4, _0x3ce1ab * 0x2, _0x89089b, _0x354580);
        if (_0x4356f9) continue;
        let _0xb71b68 = {
          x:
            _0x42b5f4["x"] -
            Math["cos"](_0x89089b) * (_0x3ce1ab + _0x133600),
          y:
            _0x42b5f4["y"] -
            Math["sin"](_0x89089b) * (_0x3ce1ab + _0x133600),
        };
        for (let _0x1e6dec = -0x1; _0x1e6dec <= _0x22c7cf; _0x1e6dec++) {
          let _0x297c0a = 0x0;
          if (_0x1e6dec < 0x0) {
            _0x297c0a =
              _0x42b5f4["x"] -
              (_0x42b5f4["y"] - _0x429ae3) / Math["tan"](_0x89089b);
            if (_0x297c0a < _0x55e1a0 || _0x297c0a > _0x187453) continue;
          } else
            _0x297c0a =
              _0x55e1a0 + (_0x187453 - _0x55e1a0) * (_0x1e6dec / _0x22c7cf);
          let _0x296671 = { x: _0x297c0a, y: _0x429ae3 };
          if (_0x23a7dc(_0x296671, _0x133600 + _0x3ce1ab)) continue;
          let _0x17d54f = _0x8b2762(_0x296671, _0xb71b68),
            _0xa2dec0 = _0x2bd695(_0x296671, _0xb71b68),
            _0x3e0e94 = Math["abs"](
              Math["cos"](_0x89089b) *
                Math["cos"](_0x17d54f) +
                Math["sin"](_0x89089b) * Math["sin"](_0x17d54f),
            ),
            _0x183a5f = _0x16430c(_0x89089b, _0x17d54f),
            _0x2133dd = _0x354580 + _0xa2dec0 + (_0x40ebad || 0x0);
          _0x3e0e94 *= _0x5b321d;
          let _0xe463f6 = 0xa + (0x1 - _0x3e0e94) * _0x301cde;
          if (_0x3e0e94 > _0x5ccc96 && _0x3e0e94 > _0x42c127) {
            let _0x1fe197 = _0x3ea989(
              _0x296671,
              _0x133600 * 0x2,
              _0x17d54f,
              _0xa2dec0,
            );
            if (_0x1fe197) continue;
            _0x42c127 = _0x3e0e94;
            if (_0x53788d)
              _0x53788d["push"]({
                pos: _0x296671,
                dir: _0x17d54f,
                speed: _0xe463f6,
                hDot: _0x3e0e94,
                dist: _0x2133dd,
              });
            else
              _0x1c4f05["push"]({
                pos: _0x296671,
                dir: _0x17d54f,
                speed: _0xe463f6,
                hDot: _0x3e0e94,
                dist: _0x2133dd,
              });
            if (_0x1e6dec < 0x0) break;
          }
        }
        if (_0x42c127 < 0.7) {
          let _0x4ca4fd =
            _0x24c0ca["x"] +
            0x1a +
            _0x133600 -
            (_0xb71b68["x"] - (_0x24c0ca["x"] + 0x1a + _0x133600));
          for (let _0x38cf59 = 0x0; _0x38cf59 <= _0x4bdfc3; _0x38cf59++) {
            let _0x380256 =
                _0x55e1a0 + (_0x187453 - _0x55e1a0) * (_0x38cf59 / _0x4bdfc3),
              _0x226e70 = { x: _0x380256, y: _0x429ae3 };
            if (_0x23a7dc(_0x226e70, _0x133600 + _0x3ce1ab)) continue;
            let _0x2851b3 = _0x8b2762(_0x226e70, {
                x: _0x4ca4fd,
                y: _0xb71b68["y"],
              }),
              _0x57086c =
                _0x429ae3 -
                Math["tan"](_0x2851b3) *
                  (_0x380256 - (_0x24c0ca["x"] + 0x1a + _0x133600)),
              _0x2cc74c = {
                x: _0x24c0ca["x"] + 0x1a + _0x133600,
                y: _0x57086c,
              },
              _0x14830a = _0x2bd695(_0x2cc74c, _0x226e70),
              _0x2f02a9 = _0x8b2762(_0x2cc74c, _0xb71b68),
              _0x3f8514 = _0x2bd695(_0x2cc74c, _0xb71b68),
              _0x59bbeb = Math["abs"](
                Math["cos"](_0x89089b) *
                  Math["cos"](_0x2f02a9) +
                  Math["sin"](_0x89089b) *
                    Math["sin"](_0x2f02a9),
              ),
              _0x2989a7 =
                _0x354580 + _0x14830a + _0x3f8514 + (_0x40ebad || 0x0);
            _0x59bbeb *= _0x5b321d;
            let _0x5f2cb1 = 0xa + (0x1 - _0x59bbeb) * _0x301cde;
            if (_0x59bbeb > _0x5ccc96 && _0x59bbeb > _0x42c127) {
              let _0x2796f2 = _0x3ea989(
                _0x226e70,
                _0x133600 * 0x2,
                _0x2851b3,
                _0x14830a,
              );
              if (_0x2796f2) continue;
              let _0x54cc49 = _0x3ea989(
                _0x2cc74c,
                _0x133600 * 0x2,
                _0x2f02a9,
                _0x3f8514,
              );
              if (_0x54cc49) continue;
              _0x42c127 = _0x59bbeb;
              if (_0x53788d)
                _0x53788d["push"]({
                  pos: _0x226e70,
                  dir: _0x2851b3,
                  speed: _0x5f2cb1,
                  hDot: _0x59bbeb,
                  dist: _0x2989a7,
                });
              else
                _0x1c4f05["push"]({
                  pos: _0x226e70,
                  dir: _0x2851b3,
                  speed: _0x5f2cb1,
                  hDot: _0x59bbeb,
                  dist: _0x2989a7,
                });
            }
          }
        }
        if (_0x42c127 <= 0.5 && !_0x53788d) {
          var _0xf51964 = {
              x:
                _0x42b5f4["x"] -
                Math["cos"](_0x89089b) * (_0x3ce1ab + _0x3ce1ab),
              y:
                _0x42b5f4["y"] -
                Math["sin"](_0x89089b) * (_0x3ce1ab + _0x3ce1ab),
            },
            _0x4531c0 = _0x2a9c75["concat"](_0x3e4566, _0x3231b3);
          _0x30849b(
            _0xf51964,
            _0x4531c0,
            !![],
            _0x1c4f05,
            _0x89089b,
            _0x354580,
          );
          continue;
        }
      }
      return _0x1c4f05;
    }
    function _0x23a7dc(_0x15152b, _0x25ee0d) {
      var _0x1fef48 = _0x157421;
      let _0x555326 = _0x2a9c75["concat"](_0x3e4566, _0x3231b3);
      for (let _0x14acea = 0x0; _0x14acea < _0x555326["length"]; _0x14acea++) {
        if (_0x2bd695(_0x15152b, _0x555326[_0x14acea]) < _0x25ee0d) return !![];
      }
      return ![];
    }
    function _0x3ea989(_0x3e50b6, _0x192a9b, _0x372c57, _0x501ec4) {
      var _0x5ef868 = _0x157421;
      let _0x9e3c7c = { x: _0x3e50b6["x"], y: _0x3e50b6["y"] },
        _0x5b4ed9 = []
          ["concat"](_0x3e4566)
          ["concat"](_0x2a9c75, _0x3231b3);
      for (
        let _0x290de6 = 0x0;
        _0x290de6 < Math["floor"](_0x501ec4 / _0x192a9b);
        _0x290de6++
      ) {
        ((_0x9e3c7c["x"] += Math["cos"](_0x372c57) * _0x192a9b),
          (_0x9e3c7c["y"] += Math["sin"](_0x372c57) * _0x192a9b));
        if (_0x247dad(_0x9e3c7c, _0x5b4ed9, _0x192a9b * 0.9)) return !![];
      }
      return ![];
    }
    function _0x247dad(_0x250221, _0x1a62e0, _0x1f1c9e) {
      var _0x2ddb9c = _0x157421;
      for (
        let _0x567082 = 0x0;