# Carrom Disc Pool 拆解记录（进行中）

## 版本与来源
- 名称：Carrom Disc Pool；包名 `com.miniclip.carrom`；版本 19.6.0 / versionCode 1491；ARM64。
- 来源：MuMu Android 12 模拟器，ADB 127.0.0.1:7555；本次来自 `pm path` 列出的 base 与 arm64 split。拉取后本地与设备 SHA-256 相同。
- `01_apk/base.apk`：189042103 字节，SHA-256 `29f14e3893a703a7be67e1360e60cd00ca657bd6540f2b8e655fadd7b5fd9ecd`。
- `01_apk/split_config.arm64_v8a.apk`：54970145 字节，SHA-256 `eee5f03d4031561b92766660495f3e3df12546072390f6ba8d29d5370b76f714`。
- 游戏原生库：`libgame-CARROM-GooglePlay-Gold-Release-Module-1491.so`，AArch64，SHA-256 `4cf2ba474fc9aefda142fbdca46cf7b4d3ebf06a2114ecd8487a3e48448710b4`。
- 采样时未发现对应的外置 OBB / Android/data files 目录；不等于游戏没有动态下载内容。

## 已有证据
- `02_静态分析/base_files.json` 和 `split_config.arm64_v8a_files.json`：原包 ZIP 条目、长度、CRC 清单。
- `02_静态分析/原始资源/`：从 APK 提取的 assets/unpack 和主游戏 so；保留原始字节与后缀。
- `02_静态分析/native_elf_符号.json`：ELF 动态符号表；`native_关键词字符串.txt`：玩法关键词筛选字符串。字符串/符号名称是线索，不等于已证明运行行为。
- `03_运行证据/启动.png`：MuMu 首次登录页；`引导01_定位.png`：母球定位引导；`对局_开局.png`：实机对局开局画面。实际对手身份与完整对局尚未确认。
- `04_游戏工厂/参考分卷/`：为适配服务器上传上限对 base 按 APK 条目重打包的分析分卷，非原 APK；示例报告为 Tile Connect，不能混用结论。

## 静态初步观察
- base.apk 12,989 个条目，其中 assets/unpack 10,600 项；按 APK 条目扩展名统计包括 8,833 个 .png、638 个 .plist、822 个 .ccbi、510 个 .skel 与 510 个 .atlas。统计不代表运行时全部加载或全部为游戏画面。
- assets/unpack 根目录中后缀为 .png 的 7,814 个文件按魔数识别为 7,780 个 WebP、34 个 PNG；不能按后缀批量认定真实格式。
- 根目录 plist 616 个可由 Python plistlib 读取，14 个未能直接解析；`GameConfiguration.plist` 非标准明文/bplist，尚未确定格式及内容，不能称为解密成功。
- 原生库 ELF `.dynsym` 含 7,923 个具名条目；Cocos2D/MCEngine 相关字符串、CCBI 资源与原生库路径支持存在相关框架线索，**具体引擎及版本未充分确认**。`scc_info_*carrom*proto` 等是符号名称，尚未证明可还原完整消息协议与实际规则。

## 游戏工厂 MCP
- 项目 `e51ebeab4e8f470caa19ccd54fc9b9ac`，第一阶段运行 `d194bfeaede746e0985526c44c0bd0ac`。
- base 全条目按卷上传；主游戏 so 单条超过服务器上限，服务器仅收到本地关键词索引，没有完整 so。示例报告和基础包分卷已作为参考传入。
- MCP 提示当前工作流没有完整 APK 解包与反编译工具，也没有联网检索；其结果只能针对实际读到的参考资料。服务端分析不等于本地完整代码逆向或实机验收。

## 待完成
1. MCP 阶段产物生成后逐项读取、核实证据、保存到 `04_游戏工厂`。
2. 在匹配该 ELF 的静态分析工具中建立字符串引用、函数调用与消息结构证据；分析控制输入、物理、规则、判定及匹配流程，无法定位的标未知。
3. 按需要自然记录新手引导、击球、回合、进洞、胜负结算；真实对手与广告等需独立证据。
4. 按 DSH 示例编写版本、引导流程、机制、资源、代码、差异建议、未确认事项等系列文档，标记实测/静态/推断。

## 后续解析补充
- 全部子目录合计 638 个 plist：624 个可解析（含图集 frames/metadata、粒子参数、布局边距、文案等），14 个未解析；结果见 02_静态分析/可读取plist/ 与 plist解析索引.json。
- 资源文件魔数、字节数清单见 02_静态分析/素材格式索引.csv。
