# BlockMaster（V27 工程）SDK 全量盘点与启动联网拉取清单

> 目标读者：安全 / 合规 / 运维 / 广告对接。
> 依据：`work/stage2_sdk`（V27 apktool 工程）AndroidManifest / lib / assets 配置、`modified_main_index_7d3cd.js`（主逻辑 17MB，773 个 URL / 48 个域）、`arc_config.json` / `mediation.json` / `hisavana_ab_data.json`、`BlockMaster_Android_SDK接入分析.md` / `BlockMaster_启动链路与SDK接入总结.md`。
> 说明：✅=配置/代码确认；⚠️=推断；版本号以包内为准。

---

## 一、SDK 全量清单

### 1.1 广告类（聚合 + 网络，9 个）

| SDK | 包/类特征 | 证据 | 归属 |
|---|---|---|---|
| **Hisavana Mediation**（聚合主） | `com.cloud.hisavana.sdk.*`、`ConfigContentProvider`、HisavanaFileProvider/HisavanaContentProvider | ✅ Manifest + assets（mediation.json） | BM 注入 |
| **AdMob** | `com.google.android.gms.ads.MobileAdsInitProvider`、`ca-app-pub-3665476663852390~1435958481`（BM）与 `ca-app-pub-9495093642646304~3665876364`（基座 arc）双 app_id | ✅ Manifest + mediation.json + arc_config.json | 双份（基座+BM） |
| **AppLovin MAX** | `com.applovin.sdk.AppLovinInitProvider`、`FullscreenAdService`、`libapplovin-native-crash-reporter.so`、MAX sdk_key `CzXnh9Lt4083uWpsmEICTtlxgkVMvNP6w3N69nouIT3zCXoIJkiVnQ8nIlwin4H2ErCdWcmPbk9LKQS5iO9JGo` | ✅ arc_config.json + Manifest + so | BB 基座 |
| **Pangle（字节）** | `com.bytedance.sdk.openadsdk.*`（BinderPoolService）、`libbuffer_pgl.so`/`libpglarmor.so`/`libtt_ugen_layout.so`/`libfile_lock_pgl.so` | ✅ Manifest + so | BB 基座 |
| **Vungle** | `com.vungle.ads.VungleProvider` | ✅ Manifest | BB 基座 |
| **Bigo Ads** | `sg.bigo.ads.controller.provider.BigoAdsProvider` | ✅ Manifest | BB 基座 |
| **Facebook Audience Network** | `com.facebook.ads.AudienceNetworkContentProvider`、`com.facebook.internal.FacebookInitProvider` | ✅ Manifest | BB 基座 |
| **APS（Amazon Publisher Services）** | `aps_mobile_client_config.json`（om_sdk/采样率配置） | ✅ assets | BB 基座 |
| **ADX（hisavana 自家）** | mediation.json `adxShowRate=100`、arc `adx.app_key=X2eyd6FCfXTgLtgZ` | ✅ | 双份 |

> 广告位（mediation.json ✅）：激励 `260428mX7wkxmr`、插屏 `26042893qlR57i`、页底横幅 `260428LY5BXBxm` + `260428HB3UWwCs`；每广告位双网络（source=0 hisavana / source=1 AdMob），`cloudControlVersion=50`、`cloudControlCacheInterval=72`（云控 72 小时缓存）。

### 1.2 统计 / 埋点 / 归因（5 个）

| SDK | 证据 | 用途 |
|---|---|---|
| **Firebase Analytics + Crashlytics + Remote Config + Messaging** | FirebaseInitProvider、AppMeasurementService、FirebaseMessagingService、`MyFirebaseMessagingService`、datatransport | 统计/崩溃/远程配置/推送 |
| **Athena（传音）** | `com.transsion.athena.aidl.AthenaTrackService`、TRACK_DEFAULT_TYPE=5943 | 行为埋点 |
| **SnowBall / Athena Attribution** | athena-attribution 依赖 | 归因 |
| **AppsFlyer** | `com.appsflyer.FirebaseMessagingServiceListener`、JS 中 `app.appsflyer.com` 链接 | 归因 |
| **Bugsnag** | `BugsnagContentProvider`、`libbugsnag-ndk.so`/`libbugsnag-plugin-android-anr.so`/`libbugsnag-root-detection.so` | 崩溃监控 |

### 1.3 渠道 / 私有 SDK（PS 系）

| SDK | 证据 | 用途 |
|---|---|---|
| **PalmUpdateSDK** | `APP_KEY=2b9158986d6c9969374e93a2e7d3df78` | 升级检测 |
| **AhaLocalPush** | `net.bat.pushCore`（MMKV 依赖，已知 NoSuchMethodError 被捕获） | 本地推送 |
| **ABTest（传音 galileo）** | `ABTestSDKConfig.APP_KEY="blockGames"`，等 GAID 最多 2 秒 | A/B 实验 |
| **DStudioUtilsSDK** | 国家码/MCC 工具 | 设备信息 |

### 1.4 基座/基础设施（BB NIS Shell 自带）

| 组件 | 证据 | 用途 |
|---|---|---|
| **RN（React Native）** | `libreactnative.so`/`libhermes.so`/`libjsi.so`/`libhermestooling.so`/`libjsctooling.so`/`libfbjni.so`、arc `rn.bundle_name=block.hot.bundle`、bridge 1.5.9 | 基座 RN 运行环境 |
| **NIS（网易）** | `libnesec.so`/`libnesec-x86.so`/`libnms.so`/`libtask.so` | 网易安全壳 |
| **Fresco/Glide（图片）** | `libimagepipeline.so`/`libglide-webp.so`/`libnative-filters.so`/PicassoProvider | 图片加载 |
| **MMKV** | `libmmkv.so` | 本地 KV |
| **TheRouter** | `InnerTheRouterContentProvider` | 路由 |
| **APM Insight** | `libapminsighta.so`/`libapminsightb.so` | 性能监控 |
| **FaceBack** | `com.faceback.share.ShareFileProvider` | 分享 |
| **Cocos 2d-js** | `libcocos2djs.so` | 游戏引擎 |
| **AndroidX 全家桶** | startup/work/camera/room/transport | 基础库 |
| **GMS 套件** | ads/measurement/auth/api/datatransport | 谷歌服务 |

---

## 二、启动初始化链（谁在什么时候启动）

```
进程创建（ContentProvider 阶段，先于 Application）：
  androidx.startup.InitializationProvider（WorkManager/EmojiCompat…）
  FirebaseInitProvider（Analytics/RC/Crashlytics/Messaging 全套）
  MobileAdsInitProvider（AdMob，双 app_id 其一）
  AppLovinInitProvider（MAX）
  VungleProvider / BigoAdsProvider / FacebookInitProvider / FAN ContentProvider
  BugsnagContentProvider
  HisavanaFileProvider / HisavanaContentProvider / ConfigContentProvider（拉云端广告配置）
  TheRouter / Picasso / ShareFileProvider
  com.blockmaster.sdk.BMInitProvider（BM 自定义初始化：DeviceInfo → Firebase → RC → ChannelSdkBridge(ABTest+AhaPush)）
      └─ BMInitProvider$1.onActivityCreated：DStudioUtils → PalmUpdate → DeepLink
Application.onCreate（GameApplication/MyApplication）：
  DeviceInfoBridge → ChannelSdkBridge.initApplication（AhaLocalPush + ABTest[等 GAID≤2s]）
  → AthenaSDK.initSDK → FirebaseRemoteConfigBridge.init
Activity：
  SDKWrapper.init → LoadingOverlay → Athena track("game_logo_ga") → DStudioUtils
  → HisavanaSDK.initWebPath/setActivity → FirebaseBridge.init → PalmUpdate.init → DeepLink
  onResume+1s：PalmUpdate.checkUpdate
JS 引擎：
  main.js → 游戏主逻辑 → HisavanaSDK.InitSDK(appId=26042852QVdSm3, 4 监听器)
  → 广告预加载（开局插屏立即 + 激励 30s 延迟）→ 远程 bundle 按需下载
```

---

## 三、启动后联网拉取清单（核心）

### 3.1 原生层（启动即拉）

| # | 拉取内容 | 目标 | 时机 | 证据 |
|---|---|---|---|---|
| 1 | Firebase Remote Config | `firebaseinstallations.googleapis.com` / RC 端点 | Application 阶段 | ✅ FirebaseRemoteConfigBridge.init（真机验证"开始拉取远程配置"） |
| 2 | hisavana 广告云控配置 | hisavana 配置 CDN（mediation 云控，72h 缓存） | ConfigContentProvider + InitSDK | ✅ mediation.json `cloudControlCacheInterval=72` |
| 3 | hisavana 广告请求（激励/插屏/横幅） | hisavana ad 端点 | 预加载（开局插屏 + 激励 30s 延迟） | ✅ LoadRewardAd/LoadInterstitialAd 日志 |
| 4 | ABTest 配置 | `net.bat.store` abTest 服务 | Application（等 GAID ≤2s） | ✅ ABTestSDKBridge.init |
| 5 | PalmUpdate 升级检测 | Palm Store 升级服务 | onResume +1s | ✅ checkUpdate |
| 6 | AppsFlyer 归因 | `appsflyersdk.com` | SDK 初始化 | ✅ Manifest listener |
| 7 | Bugsnag 上报 | `notify.bugsnag.com` | 崩溃时 | ✅ provider/so |
| 8 | Athena 埋点上报 | `athena` 传音端点 | 全程事件驱动 | ✅ AthenaTrackService |
| 9 | Firebase Analytics 上报 | `app-measurement.com` | 全程 | ✅ |

### 3.2 JS 层（游戏自身，afafb.com 域族）

| # | 服务 | 域 | 用途 | 时机 |
|---|---|---|---|---|
| 1 | **主 CDN（远程资源）** | `bband1.afafb.com` | jsList 远程库、patch 热更、remote bundle（皮肤/trait/ecpmConfig/market_active 市场活动/chapter_lev 关卡/atom-engine 配置/comment.json） | 启动 + 按需（remote_manifest_full 4,885 bundle） |
| 2 | **AI 推理集群** | `ai-robot-hub` / `ai-server` / `ai-server-commerce` / `ai-commom-model` / `block-hard-recom` / `block-ucb` / `block-alg-recom` / `block-algo-online` | 棋盘初始化（board_init_gp_v3/ios_v6）、新手题（new_user_api）、用户偏好（user_prefer）、难度（user_recent_adjust）、UCB 区块池（block_pool_ban）、hard puzzle 推荐、模型表（safe7_daily_roll/policy_table） | 开局/对局/按模型 |
| 3 | **网关/会话** | `hella-game-gateway-server` / `hella-ping` / `session-control` / `horizon` / `ucw` | 会话控制、网关、地平线（活动？） | 启动心跳 |
| 4 | **数据上报（加密）** | `ali-minos.afafb.com/data_encrypted(_v2)` | 埋点/数据上报 | 全程事件 |
| 5 | **订阅/推荐** | `subscribes.afafb.com` | 订阅状态 | 相关页面 |
| 6 | **分享/社交** | `share.blockblast.com`、`apps.apple.com`、`play.google.com`、facebook/instagram/tiktok/youtube | 分享链接 | 用户操作 |
| 7 | **归因链接** | `app.appsflyer.com` | 买量/归因链接 | 分享/回流 |
| 8 | 阿里 PAI-EAS 推理网关 | `gw-2f0q6df1jpfxmw8dtz-vpc.us-east-1.pai-eas.aliyuncs.com/api/predict/hs_usergrowth_material_api` | 用户增长素材 API | 按需 |
| 9 | 测试/内网 | `10.254.32.147` / `192.168.16.140` / `127.0.0.1` | 测试环境端点（残留） | 测试环境 |

### 3.3 启动即拉的最小集合（冷启动一次会话）

```
① Firebase RC（配置）           ② hisavana 广告配置 + 预加载（插屏立即/激励 30s）
③ ABTest 配置                   ④ PalmUpdate 检测（+1s）
⑤ 游戏 CDN：jsList + patch + 远程 bundle 清单（bband1.afafb.com）
⑥ 网关/会话心跳（hella-gateway/ping、session-control）
⑦ AI 服务：棋盘初始化/新手推荐（ai-robot-hub 等，按配置）
⑧ 埋点/归因：Athena、Firebase Analytics、AppsFlyer、ali-minos
```

---

## 四、已知遗留/风险点

1. ⚠️ **双 AdMob app_id**（BM `...852390` vs 基座 `...3646304`）与**双 ADX**——初始化可能冲突，需确认实际生效实例
2. ⚠️ **AppLovin MAX sdk_key / ADX key 明文存在** `arc_config.json`——换皮后若复用基座 MAX，广告归因/收益归属基座账号
3. ⚠️ AhaLocalPush 的 MMKV `NoSuchMethodError`（V8 实测）——功能未真正可用
4. ⚠️ 内网/测试域（10.254.32.147 等）残留于 JS——正式包应清理
5. ⚠️ hisavana 后台三广告位是否配源决定广告是否填充（当前 70011）

---

## 附：证据文件

- `work/stage2_sdk/AndroidManifest.xml`（16 provider / 15+ service）
- `work/stage2_sdk/lib/*.so`（29 个）
- `work/stage2_sdk/assets/mediation.json`、`hisavana_ab_data.json`、`arc_config.json`、`aps_mobile_client_config.json`
- `work/modified_main_index_7d3cd.js`（773 URL / 48 域）
- `E:\codex_apk_work\BlockMaster_Android_SDK接入分析.md`、`BlockMaster_启动链路与SDK接入总结.md`、`四SDK可接入性评估报告.md`
