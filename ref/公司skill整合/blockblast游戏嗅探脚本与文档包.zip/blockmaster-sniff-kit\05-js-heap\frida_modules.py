#!/usr/bin/env python3
"""List loaded modules matching JS engine keywords."""
import frida
import sys

JS = r"""
'use strict';
function modules(kws) {
    var out = [];
    Process.enumerateModules().forEach(function (m) {
        kws.forEach(function (kw) {
            if (m.name.indexOf(kw) !== -1) {
                out.push({name: m.name, base: m.base.toString(), size: m.size});
            }
        });
    });
    return out;
}
rpc.exports = { modules: modules };
"""

PID = int(sys.argv[1]) if len(sys.argv) > 1 else 5829
KEYWORDS = ["js", "JS", "hermes", "moz", "spidermonkey", "cocos", "jsc", "nesec", "atom"]

dev = frida.get_device_manager().add_remote_device('127.0.0.1:27042')
session = dev.attach(PID)
script = session.create_script(JS)
script.load()
out = script.exports_sync.modules(KEYWORDS)
for m in sorted(out, key=lambda x: x["name"]):
    print(m["base"], hex(m["size"]), m["name"])
session.detach()
