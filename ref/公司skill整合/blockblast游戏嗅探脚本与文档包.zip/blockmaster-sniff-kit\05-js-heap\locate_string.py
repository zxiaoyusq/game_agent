import os

needle = "window.boot = function".encode("utf-16-le")
files = [
    r"E:\codex_apk_work\memdump\heap\0x3030001c0000_7200000.bin",
    r"E:\codex_apk_work\memdump\heap\0x303007740000_2ec0000.bin",
]
for path in files:
    raw = open(path, "rb").read()
    idx = []
    start = 0
    while True:
        i = raw.find(needle, start)
        if i < 0:
            break
        idx.append(i)
        start = i + 1
    print(os.path.basename(path), "hits:", len(idx))
    for i in idx[:3]:
        lo = max(0, i - 64)
        hi = min(len(raw), i + len(needle) + 64)
        chunk = raw[lo:hi]
        print("offset", hex(i))
        for off in range(0, len(chunk), 16):
            row = chunk[off:off + 16]
            asc = "".join(chr(b) if 32 <= b < 127 else "." for b in row)
            print("  ", hex(lo + off), row.hex(" "), asc)
        print()
