# -*- coding: utf-8 -*-
"""Build a debuggable A2/B capture APK from the trusted V36 MITM base.

This artifact is test-only.  It preserves the diagnostic manifest/certificate
trust configuration while replacing the exact production payloads under test.
"""
from __future__ import annotations

import hashlib
import os
import subprocess
import zipfile
from pathlib import Path


W = Path(__file__).resolve().parent
STAGE = os.environ.get("BLOCKMASTER_V36_STAGE", "B").strip().upper()
if STAGE not in {"A2", "B"}:
    raise RuntimeError("BLOCKMASTER_V36_STAGE must be A2 or B")
SLUG = STAGE.lower()
BASE = W / "net_capture" / "BlockMaster_v36_stage_a_1019_mitm.apk"
SOURCE = W / f"BlockMaster_v36_stage_{SLUG}_1019_canary.apk"
MERGED = W / "net_capture" / f"BlockMaster_v36_stage_{SLUG}_1019_mitm_merged.apk"
ALIGNED = W / "net_capture" / f"BlockMaster_v36_stage_{SLUG}_1019_mitm_aligned.apk"
FINAL = W / "net_capture" / f"BlockMaster_v36_stage_{SLUG}_1019_mitm.apk"
OVERLAYS = ["classes3.dex", "classes10.dex", "assets/mediation.json"]
if STAGE == "B":
    OVERLAYS.append("classes13.dex")


def run(args: list[str]) -> None:
    print(">>", " ".join(args))
    subprocess.run(args, check=True)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def main() -> None:
    build_tools = Path(os.environ["BLOCKMASTER_ANDROID_BUILD_TOOLS"])
    keystore = Path(os.environ["BLOCKMASTER_KEYSTORE"])
    alias = os.environ.get("BLOCKMASTER_KEY_ALIAS", "blockmaster")

    with zipfile.ZipFile(SOURCE) as source, zipfile.ZipFile(BASE) as base:
        payloads = {name: source.read(name) for name in OVERLAYS}
        with zipfile.ZipFile(MERGED, "w") as target:
            for item in base.infolist():
                upper = item.filename.upper()
                if upper == "META-INF/MANIFEST.MF" or upper.endswith((".RSA", ".DSA", ".EC", ".SF")):
                    continue
                data = payloads.get(item.filename, base.read(item.filename))
                compression = zipfile.ZIP_STORED if (
                    item.filename.endswith(".dex") or
                    (item.filename.startswith("lib/") and item.filename.endswith(".so"))
                ) else item.compress_type
                target.writestr(item, data, compress_type=compression)

    run([str(build_tools / "zipalign.exe"), "-f", "-p", "4", str(MERGED), str(ALIGNED)])
    run([
        "cmd", "/c", str(build_tools / "apksigner.bat"), "sign",
        "--ks", str(keystore), "--ks-key-alias", alias,
        "--ks-pass", "env:BLOCKMASTER_KS_PASS",
        "--key-pass", "env:BLOCKMASTER_KEY_PASS",
        "--out", str(FINAL), str(ALIGNED),
    ])
    run([str(build_tools / "apksigner.bat"), "verify", "--verbose", "--print-certs", str(FINAL)])

    with zipfile.ZipFile(FINAL) as archive:
        assert b"BM_V36_HSDATA_HTTP_POST_DISABLED" in archive.read("classes3.dex")
        assert b"BM_V36_HSDATA_DISABLED" in archive.read("classes10.dex")
        if STAGE == "B":
            assert b"BM_V36_ORIGINAL_ADX_DISABLED" in archive.read("classes13.dex")
        assert hashlib.sha256(archive.read("assets/mediation.json")).hexdigest() == (
            "52812c1a34bfee3cf4d365caa5852f6af623f26547745b43d5a3891d0be2161d"
        )
    print("FINAL", FINAL)
    print("SHA256", sha256(FINAL))


if __name__ == "__main__":
    main()
