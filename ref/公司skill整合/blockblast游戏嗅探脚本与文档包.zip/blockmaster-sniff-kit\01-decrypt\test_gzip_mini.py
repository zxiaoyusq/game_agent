import gzip

import io

probe = gzip.compress(b"hello world" * 100)
print("probe first:", probe[:2].hex())
try:
    print("probe decompress:", gzip.decompress(probe)[:20])
except Exception as e:
    print("probe ERR", e)

orig = gzip._read_gzip_header


def patched(fp):
    magic = fp.read(2)
    print("patched saw:", magic.hex())
    fp.seek(0)
    return orig(fp)


gzip._read_gzip_header = patched

data = open(r"E:\codex_apk_work\memdump\jsc_test.bin", "rb").read()
print("first:", data[:2].hex())
try:
    out = gzip.decompress(data)
    print("OK", len(out))
    print(out[:100])
except Exception as e:
    print("ERR", e)
