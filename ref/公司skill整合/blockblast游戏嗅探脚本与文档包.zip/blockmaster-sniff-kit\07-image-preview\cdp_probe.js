// CDP probe: load a preview.html in headless Chrome, collect console/errors,
// read DOM state, and capture a screenshot.
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const PORT = 9333 + Math.floor(Math.random() * 1000);
const PROFILE = 'E:/codex_apk_work/shots/cdp_profile_' + Date.now();

const label = process.argv[2] || 'our';
const g = process.argv[3] || '0';
const animIdxArg = process.argv[4];
const animIdx = animIdxArg !== undefined && /^\d+$/.test(animIdxArg) ? parseInt(animIdxArg, 10) : null;
const seek = process.argv[5] !== undefined ? parseFloat(process.argv[5]) : null;
const htmlPath = process.argv[6] || 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810/spine-preview/preview.html';
const pageUrl = pathToFileURL(htmlPath) + '?g=' + g;

function pathToFileURL(p) {
  return new URL('file:///' + p.replace(/\\/g, '/')).href;
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function main() {
  const chrome = spawn(CHROME, [
    '--headless=new',
    '--enable-unsafe-swiftshader',
    '--remote-allow-origins=*',
    '--window-size=1280,800',
    '--hide-scrollbars',
    '--remote-debugging-port=' + PORT,
    '--user-data-dir=' + PROFILE,
    'about:blank',
  ], { stdio: 'ignore' });

  // wait for devtools endpoint
  let targets = null;
  for (let i = 0; i < 40; i++) {
    try {
      const r = await fetch('http://127.0.0.1:' + PORT + '/json/version');
      if (r.ok) { targets = await r.json(); break; }
    } catch (e) {}
    await sleep(250);
  }
  if (!targets) { console.error('CDP not reachable'); chrome.kill(); process.exit(1); }

  const list = await (await fetch('http://127.0.0.1:' + PORT + '/json/list')).json();
  const page = list.find(t => t.type === 'page');
  const ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });

  let msgId = 0;
  const pending = new Map();
  const events = [];
  ws.onmessage = (ev) => {
    const m = JSON.parse(ev.data);
    if (m.id && pending.has(m.id)) {
      pending.get(m.id)(m);
      pending.delete(m.id);
    } else if (m.method) {
      if (m.method === 'Runtime.consoleAPICalled') {
        const args = (m.params.args || []).map(a => a.value !== undefined ? a.value : a.description).join(' ');
        events.push('CONSOLE[' + m.params.type + '] ' + args.slice(0, 500));
      } else if (m.method === 'Runtime.exceptionThrown') {
        events.push('EXCEPTION ' + JSON.stringify(m.params.exceptionDetails).slice(0, 800));
      } else if (m.method === 'Log.entryAdded') {
        events.push('LOG[' + m.params.entry.level + '] ' + m.params.entry.text.slice(0, 500));
      } else if (m.method === 'Network.loadingFailed') {
        events.push('NETFAIL ' + (m.params.errorText || '') + ' ' + (m.params.blockedReason || ''));
      }
    }
  };
  const send = (method, params) => new Promise((res) => {
    const id = ++msgId;
    pending.set(id, res);
    ws.send(JSON.stringify({ id, method, params: params || {} }));
  });

  await send('Page.enable');
  await send('Runtime.enable');
  await send('Log.enable');
  await send('Network.enable');

  const evalJs = async (expr) => {
    const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
    if (r.result && r.result.exceptionDetails) {
      return { evalError: r.result.exceptionDetails.text };
    }
    return r.result && r.result.result ? r.result.result.value : null;
  };

  await send('Page.navigate', { url: pageUrl });
  await sleep(9000);

  let animSwitchResult = null;
  if (animIdx !== null) {
    animSwitchResult = await evalJs(`(() => {
      if (typeof player === 'undefined' || !player) return 'no player';
      const anims = player.skeleton.data.animations.map(a => a.name);
      if (${animIdx} < 0 || ${animIdx} >= anims.length) return 'bad idx, anims=' + JSON.stringify(anims);
      const sel = document.getElementById('animSel');
      if (sel && sel.options.length) {
        sel.value = anims[${animIdx}];
        sel.dispatchEvent(new Event('change'));
        return 'switched via select to ' + anims[${animIdx}];
      }
      player.animationState.setAnimation(0, anims[${animIdx}], true);
      return 'switched directly to ' + anims[${animIdx}];
    })()`);
    await sleep(1500);
  }

  if (seek !== null) {
    await evalJs(`(() => {
      if (typeof player.pause === 'function') player.pause();
      const track = player.animationState.getCurrent(0);
      if (track) track.trackTime = ${seek};
      return 'seeked to ' + ${seek};
    })()`);
    await sleep(500);
  }

  let pixelStats = null;
  if (seek !== null) {
    pixelStats = await evalJs(`(() => {
      try {
        const track = player.animationState.getCurrent(0);
        if (track) track.trackTime = ${seek};
        player.animationState.update(0);
        player.animationState.apply(player.skeleton);
        player.skeleton.updateWorldTransform();
        if (typeof player.drawFrame === 'function') player.drawFrame();
        const canvas = player.canvas;
        const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
        const w = canvas.width, h = canvas.height;
        const buf = new Uint8Array(w * h * 4);
        gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, buf);
        let nonTransparent = 0, nonBlack = 0, colored = 0, bright = 0, rSum = 0, gSum = 0, bSum = 0;
        const step = Math.max(1, Math.floor(w * h / 300000));
        for (let i = 0; i < w * h * 4; i += 4 * step) {
          const r = buf[i], g = buf[i + 1], b = buf[i + 2], a = buf[i + 3];
          if (a > 10) nonTransparent++;
          const lum = 0.299 * r + 0.587 * g + 0.114 * b;
          if (a > 10 && lum > 25) nonBlack++;
          const maxc = Math.max(r, g, b), minc = Math.min(r, g, b);
          if (a > 10 && (maxc - minc) > 40 && maxc > 60) colored++;
          if (a > 10 && lum > 160) bright++;
          rSum += r; gSum += g; bSum += b;
        }
        const n = Math.max(1, Math.floor(w * h / step));
        return {
          w, h,
          nonTransparentPct: Math.round(10000 * nonTransparent / n) / 100,
          nonBlackPct: Math.round(10000 * nonBlack / n) / 100,
          coloredPct: Math.round(10000 * colored / n) / 100,
          brightPct: Math.round(10000 * bright / n) / 100,
          avgRGB: [Math.round(rSum / n), Math.round(gSum / n), Math.round(bSum / n)],
          slots: (() => {
            const list = [];
            for (const s of player.skeleton.slots) {
              if (s.attachment) {
                const at = s.attachment;
                list.push({
                  slot: s.data.name,
                  type: at.type !== undefined ? at.type : '?',
                  name: at.name,
                  region: at.region ? at.region.name : null,
                  color: at.color ? [Math.round(at.color.r * 255), Math.round(at.color.g * 255), Math.round(at.color.b * 255), Math.round(at.color.a * 255)] : null
                });
              }
            }
            return list.slice(0, 15);
          })()
        };
      } catch (e) { return { error: String(e) }; }
    })()`);
  }

  const domInfo = await evalJs(`(() => {
    const err = document.getElementById('errInfo');
    const errDiv = document.querySelector('.spine-player-error');
    const canvas = document.querySelector('.spine-player-canvas');
    const stage = document.getElementById('stage');
    const animInfo = document.getElementById('animInfo');
    const missInfo = document.getElementById('missInfo');
    const glCtx = canvas ? (canvas.getContext('webgl2') || canvas.getContext('webgl')) : null;
    const stageRect = stage ? (() => { const r = stage.getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; })() : null;
    return {
      title: document.title,
      err: err ? err.textContent : null,
      animInfo: animInfo ? animInfo.textContent : null,
      missInfo: missInfo ? missInfo.textContent : null,
      errDivHidden: errDiv ? errDiv.classList.contains('spine-player-hidden') : null,
      errDivHtml: errDiv ? errDiv.innerHTML.slice(0, 200) : null,
      canvas: canvas ? { w: canvas.width, h: canvas.height, cw: canvas.clientWidth, ch: canvas.clientHeight } : null,
      stageBg: stage ? getComputedStyle(stage).backgroundImage : null,
      hasWebGL: !!glCtx,
      stageRect,
      spineVersion: window.spine ? (spine.version || spine.VERSION || '?') : 'no spine'
    };
  })()`);

  const playerInfo = await evalJs(`(() => {
    let out = { hasPlayer: typeof player !== 'undefined' && !!player };
    if (out.hasPlayer) {
      out.assetErrors = player.assetManager ? player.assetManager.getErrors() : null;
      out.loadedCount = player.assetManager ? player.assetManager.getLoaded() : null;
      out.toLoad = player.assetManager ? player.assetManager.getToLoad() : null;
      out.curAnim = player.animationState && player.animationState.getCurrent(0) ?
        { name: player.animationState.getCurrent(0).animation.name, loop: player.animationState.getCurrent(0).loop } : null;
      out.skeleton = player.skeleton ? {
        slots: player.skeleton.slots.length,
        bones: player.skeleton.bones.length,
        skin: player.skeleton.skin ? player.skeleton.skin.name : null,
        anims: player.skeleton.data.animations.map(a => a.name).slice(0, 5),
        bounds: (() => {
          try {
            const off = new spine.Vector2(0, 0), sz = new spine.Vector2(0, 0);
            player.skeleton.getBounds(off, sz);
            return { x: off.x, y: off.y, w: sz.width, h: sz.height };
          } catch (e) { return String(e); }
        })(),
        attachments: (() => {
          const map = {};
          for (const s of player.skeleton.slots) {
            if (s.attachment) {
              const k = s.attachment.type !== undefined ? s.attachment.type : '?';
              map[s.data.name] = String(k) + ':' + (s.attachment.name || '');
            }
          }
          const names = Object.keys(map);
          return { count: names.length, first: names.slice(0, 12).map(n => n + '=' + map[n]) };
        })(),
        drawOrderCount: player.skeleton.drawOrder ? player.skeleton.drawOrder.length : null
      } : null;
      out.canvasSize = player.canvas ? [player.canvas.width, player.canvas.height] : null;
      out.viewport = player.viewport ? { x: player.viewport.x, y: player.viewport.y, w: player.viewport.width, h: player.viewport.height } : null;
      out.dataBounds = typeof DATA !== 'undefined' && DATA[cur] ? DATA[cur].bounds : null;
      out.deep = (() => {
        try {
          const res = {};
          const skins = player.skeleton.data.skins;
          res.skinNames = skins.map(s => s.name);
          const atts = {};
          for (const s of skins) {
            const perSlot = {};
            for (let slotIdx = 0; slotIdx < s.attachments.length; slotIdx++) {
              const m = s.attachments[slotIdx];
              if (m) perSlot[slotIdx] = Object.keys(m);
            }
            atts[s.name] = perSlot;
          }
          res.skinAttachments = atts;
          const atlas = player.assetManager.get(player.config.atlasUrl);
          if (atlas) {
            res.atlasRegions = atlas.regions.map(r => r.name).slice(0, 30);
            res.atlasRegionCount = atlas.regions.length;
          }
          res.skeletonImagesPath = player.skeleton.data.imagesPath;
          return res;
        } catch (e) { return String(e); }
      })();
      out.hasErrorDiv = !!document.querySelector('.spine-player-error:not(.spine-player-hidden)');
    }
    return out;
  })()`);

  const sampling = await evalJs(`(() => {
    if (typeof player === 'undefined' || !player) return null;
    const times = [0, 0.05, 0.1, 0.2, 0.35, 0.5, 0.75, 1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0];
    const out = [];
    const track = player.animationState.getCurrent(0);
    const dur = track ? track.animation.duration : 0;
    for (const t of times) {
      if (track) track.trackTime = t;
      player.animationState.update(0);
      player.animationState.apply(player.skeleton);
      player.skeleton.updateWorldTransform();
      let cnt = 0;
      for (const s of player.skeleton.slots) if (s.attachment) cnt++;
      out.push({ t, dur: Math.round(dur * 100) / 100, attachments: cnt });
    }
    return out;
  })()`);

  const textureProbe = await evalJs(`(() => {
    return new Promise((resolve) => {
      try {
        const it = DATA[cur];
        const atlasText = decodeURIComponent(escape(atob(it.atlasUrl.split(',')[1])));
        const firstLine = atlasText.split('\\n').find(l => l.trim()) || '';
        const img = new Image();
        img.onload = () => {
          const c = document.createElement('canvas');
          c.width = img.width; c.height = img.height;
          const ctx = c.getContext('2d');
          ctx.drawImage(img, 0, 0);
          let data = null;
          try { data = ctx.getImageData(0, 0, c.width, c.height).data; } catch (e) { data = null; }
          let nonTrans = 0, nonBlack = 0, colored = 0;
          if (data) {
            const step = Math.max(1, Math.floor(data.length / 4 / 300000));
            for (let i = 0; i < data.length; i += 4 * step) {
              const r = data[i], g = data[i + 1], b = data[i + 2], a = data[i + 3];
              if (a > 10) nonTrans++;
              const lum = 0.299 * r + 0.587 * g + 0.114 * b;
              if (a > 10 && lum > 25) nonBlack++;
              const maxc = Math.max(r, g, b), minc = Math.min(r, g, b);
              if (a > 10 && (maxc - minc) > 40 && maxc > 60) colored++;
            }
            const n = Math.max(1, Math.floor(data.length / 4 / step));
            nonTrans = Math.round(10000 * nonTrans / n) / 100;
            nonBlack = Math.round(10000 * nonBlack / n) / 100;
            colored = Math.round(10000 * colored / n) / 100;
          }
          resolve({
            imgLinePrefix: firstLine.slice(0, 60),
            naturalW: img.naturalWidth, naturalH: img.naturalHeight,
            decoded: img.naturalWidth > 0 && img.naturalHeight > 0,
            pct: { nonTrans, nonBlack, colored }
          });
        };
        img.onerror = () => resolve({ error: 'img.onerror for ' + firstLine.slice(0, 40) });
        img.src = 'data:text/' + firstLine;
      } catch (e) { resolve({ error: String(e) }); }
    });
  })()`);

  const textureReadback = await evalJs(`(() => {
    try {
      const atlas = player.assetManager.get(player.config.atlasUrl);
      if (!atlas) return { error: 'no atlas' };
      const region = atlas.regions[0];
      const tex = region.page.texture;
      const canvas = player.canvas;
      const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
      const img = tex._image;
      if (!img) return { error: 'no _image' };
      const w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
      if (!w || !h) return { error: 'image no size', w, h };
      const fbo = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex.texture, 0);
      const buf = new Uint8Array(w * h * 4);
      gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, buf);
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.deleteFramebuffer(fbo);
      let nonTrans = 0, nonBlack = 0, colored = 0;
      const step = Math.max(1, Math.floor(w * h / 300000));
      for (let i = 0; i < w * h * 4; i += 4 * step) {
        const r = buf[i], g = buf[i + 1], b = buf[i + 2], a = buf[i + 3];
        if (a > 10) nonTrans++;
        const lum = 0.299 * r + 0.587 * g + 0.114 * b;
        if (a > 10 && lum > 25) nonBlack++;
        const maxc = Math.max(r, g, b), minc = Math.min(r, g, b);
        if (a > 10 && (maxc - minc) > 40 && maxc > 60) colored++;
      }
      const n = Math.max(1, Math.floor(w * h / step));
      return {
        texSize: [w, h],
        pct: {
          nonTrans: Math.round(10000 * nonTrans / n) / 100,
          nonBlack: Math.round(10000 * nonBlack / n) / 100,
          colored: Math.round(10000 * colored / n) / 100
        },
        disableUnpack: (() => {
          try {
            const G = (spine.webgl && spine.webgl.GLTexture) || null;
            return G ? G.DISABLE_UNPACK_PREMULTIPLIED_ALPHA_WEBGL : 'n/a';
          } catch (e) { return 'err'; }
        })(),
        glParams: (() => {
          const p = gl.getParameter(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL);
          const ctx = canvas.getContext('webgl2') || canvas.getContext('webgl');
          const attrs = ctx.getContextAttributes ? ctx.getContextAttributes() : null;
          return { unpackPremultiply: p, contextPremultipliedAlpha: attrs ? attrs.premultipliedAlpha : null };
        })()
      };
    } catch (e) { return { error: String(e) }; }
  })()`);

  const atlasCheck = await evalJs(`(() => {
    try {
      const it = DATA[cur];
      const atlasText = decodeURIComponent(escape(atob(it.atlasUrl.split(',')[1])));
      const atlas = player.assetManager.get(player.config.atlasUrl);
      const tex = atlas.regions[0].page.texture;
      const img = tex._image;
      const w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
      const canvas = player.canvas;
      const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
      const fbo = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex.texture, 0);
      const buf = new Uint8Array(w * h * 4);
      gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, buf);
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.deleteFramebuffer(fbo);
      const sample = (u, v) => {
        const x = Math.max(0, Math.min(w - 1, Math.round(u * w)));
        const y = Math.max(0, Math.min(h - 1, Math.round((1 - v) * h)));
        const i = (y * w + x) * 4;
        return [buf[i], buf[i + 1], buf[i + 2], buf[i + 3]];
      };
      const pageSize = (atlasText.match(/size:\s*(\d+)\s*,\s*(\d+)/) || []).slice(1, 3);
      const regionSamples = atlas.regions.slice(0, 6).map(r => {
        const cx = r.u + (r.u2 - r.u) / 2;
        const cy = r.v + (r.v2 - r.v) / 2;
        return { name: r.name, uvs: [Math.round(r.u * 1000) / 1000, Math.round(r.v * 1000) / 1000, Math.round(r.u2 * 1000) / 1000, Math.round(r.v2 * 1000) / 1000], centerSample: sample(cx, cy) };
      });
      const whiteSample = sample(0.5, 0.5);
      return {
        atlasSizeFromText: pageSize.map(Number),
        textureSize: [w, h],
        regionSamples,
        texCenter: whiteSample,
        firstLines: atlasText.split('\\n').slice(0, 12)
      };
    } catch (e) { return { error: String(e) }; }
  })()`);

  const filterFixTest = await evalJs(`(() => {
    try {
      const atlas = player.assetManager.get(player.config.atlasUrl);
      const regions = atlas.regions;
      const pages = new Set();
      for (const r of regions) pages.add(r.page);
      for (const page of pages) {
        const tex = page.texture;
        tex.setFilters(spine.TextureFilter.Linear, spine.TextureFilter.Linear);
        tex.update(false);
      }
      const track = player.animationState.getCurrent(0);
      if (track) track.trackTime = 0.5;
      player.animationState.update(0);
      player.animationState.apply(player.skeleton);
      player.skeleton.updateWorldTransform();
      player.drawFrame();
      const canvas = player.canvas;
      const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
      const w = canvas.width, h = canvas.height;
      const buf = new Uint8Array(w * h * 4);
      gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, buf);
      let nonTrans = 0, nonBlack = 0, colored = 0, bright = 0;
      const step = Math.max(1, Math.floor(w * h / 300000));
      for (let i = 0; i < w * h * 4; i += 4 * step) {
        const r = buf[i], g = buf[i + 1], b = buf[i + 2], a = buf[i + 3];
        if (a > 10) nonTrans++;
        const lum = 0.299 * r + 0.587 * g + 0.114 * b;
        if (a > 10 && lum > 25) nonBlack++;
        const maxc = Math.max(r, g, b), minc = Math.min(r, g, b);
        if (a > 10 && (maxc - minc) > 40 && maxc > 60) colored++;
        if (a > 10 && lum > 160) bright++;
      }
      const n = Math.max(1, Math.floor(w * h / step));
      return {
        nonTransparentPct: Math.round(10000 * nonTrans / n) / 100,
        nonBlackPct: Math.round(10000 * nonBlack / n) / 100,
        coloredPct: Math.round(10000 * colored / n) / 100,
        brightPct: Math.round(10000 * bright / n) / 100
      };
    } catch (e) { return { error: String(e) }; }
  })()`);

  const glVersion = await evalJs(`(() => {
    const canvas = player.canvas;
    const gl2 = canvas.getContext('webgl2');
    const gl1 = canvas.getContext('webgl');
    const used = player.context && player.context.gl;
    return {
      playerUsesWebGL2: !!(used && used instanceof WebGL2RenderingContext),
      playerUsesWebGL1: !!(used && used instanceof WebGLRenderingContext && !(used instanceof WebGL2RenderingContext)),
      webgl2Available: !!gl2,
      webgl1Available: !!gl1
    };
  })()`);

  const shot = await send('Page.captureScreenshot', { format: 'png' });
  const pngPath = 'E:/codex_apk_work/shots/cdp_' + label + '_g' + g + '.png';
  if (shot.result && shot.result.data) {
    fs.writeFileSync(pngPath, Buffer.from(shot.result.data, 'base64'));
  }

  console.log(JSON.stringify({ label, g, animIdx, animSwitchResult, pageUrl, domInfo, playerInfo, sampling, pixelStats, textureProbe, textureReadback, atlasCheck, filterFixTest, glVersion, events: events.slice(0, 30) }, null, 1));
  ws.close();
  chrome.kill();
}

main().catch(e => { console.error('ERR', e); process.exit(1); });
