@echo off
rem rebuild the resource index (about 10 seconds)
setlocal
set "PY=C:\Program Files\Python312\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" -X utf8 "%~dp0build_index.py" %*
