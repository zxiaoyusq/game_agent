import os, struct, sys, re

def read_uleb128(data, off):
    result = 0
    shift = 0
    while True:
        b = data[off]; off += 1
        result |= (b & 0x7f) << shift
        if not (b & 0x80):
            break
        shift += 7
    return result, off

def read_mutf8(data, off):
    # skip uleb128 size
    _, off = read_uleb128(data, off)
    cps = []
    while True:
        b = data[off]; off += 1
        if b == 0:
            break
        if b & 0x80:
            # decode 2/3-byte sequence
            b2 = data[off]; off += 1
            if (b & 0xe0) == 0xc0:
                cps.append(((b & 0x1f) << 6) | (b2 & 0x3f))
            else:
                b3 = data[off]; off += 1
                cps.append(((b & 0x0f) << 12) | ((b2 & 0x3f) << 6) | (b3 & 0x3f))
        else:
            cps.append(b)
    return ''.join(chr(c) for c in cps), off

def parse_dex(path):
    with open(path, 'rb') as f:
        data = f.read()
    if data[:8] != b'dex\n035\x00' and data[:8] != b'dex\n037\x00' and data[:8] != b'dex\n038\x00' and data[:8] != b'dex\n039\x00':
        return None
    string_ids_size, string_ids_off = struct.unpack_from('<II', data, 0x38)
    type_ids_size, type_ids_off = struct.unpack_from('<II', data, 0x40)
    method_ids_size, method_ids_off = struct.unpack_from('<II', data, 0x58)
    class_defs_size, class_defs_off = struct.unpack_from('<II', data, 0x60)

    strings = []
    for i in range(string_ids_size):
        off = struct.unpack_from('<I', data, string_ids_off + i*4)[0]
        s, _ = read_mutf8(data, off)
        strings.append(s)

    types = []
    for i in range(type_ids_size):
        idx = struct.unpack_from('<I', data, type_ids_off + i*4)[0]
        types.append(strings[idx])

    methods = []
    for i in range(method_ids_size):
        class_idx, proto_idx, name_idx = struct.unpack_from('<HHI', data, method_ids_off + i*8)
        methods.append((types[class_idx], strings[name_idx]))

    classes = []
    for i in range(class_defs_size):
        off = class_defs_off + i*32
        class_idx, access, super_idx, iface_off, src_idx, ann_off, class_data_off, static_off = struct.unpack_from('<IIIIIIII', data, off)
        classes.append((types[class_idx], class_data_off))
    return strings, types, methods, classes, data

def class_methods(data, class_data_off):
    if class_data_off == 0:
        return []
    off = class_data_off
    _, off = read_uleb128(data, off)  # static_fields_size
    _, off = read_uleb128(data, off)  # instance_fields_size
    direct_size, off = read_uleb128(data, off)
    virtual_size, off = read_uleb128(data, off)
    res = []
    method_idx = 0
    for _ in range(direct_size):
        diff, off = read_uleb128(data, off)
        method_idx += diff
        _, off = read_uleb128(data, off)  # access_flags
        code_off, off = read_uleb128(data, off)
        res.append(('direct', method_idx, code_off))
    method_idx = 0
    for _ in range(virtual_size):
        diff, off = read_uleb128(data, off)
        method_idx += diff
        _, off = read_uleb128(data, off)
        code_off, off = read_uleb128(data, off)
        res.append(('virtual', method_idx, code_off))
    return res

KEYWORDS = ['JsCallJava', 'RctNative', 'datareport', 'almax', 'hsdata', 'HSAnalytics',
            'hisavana', 'athena', 'hs/ads', 'hs/adx', 'ADataFunc', 'ThinkingData', 'HSData',
            'appsflyer', 'firebase', 'GlDataManager', 'HSTracker', 'WThinkingDataAdapter']

def main():
    src = r'E:\codex_apk_work\blockblast_decrypted'
    out_path = r'E:\codex_apk_work\main_algo_extract\_sdk_bridge_dump.txt'
    hits = []
    with open(out_path, 'w', encoding='utf-8') as out:
        for fn in sorted(os.listdir(src)):
            if not (fn.startswith('classes') and fn.endswith('.dex')):
                continue
            p = os.path.join(src, fn)
            try:
                parsed = parse_dex(p)
            except Exception as e:
                out.write(f'== {fn} PARSE ERROR: {e}\n')
                continue
            if parsed is None:
                continue
            strings, types, methods, classes, data = parsed
            out.write(f'\n===== {fn} =====\n')
            for cls, cdata_off in classes:
                if not any(k in cls for k in KEYWORDS):
                    continue
                try:
                    cm = class_methods(data, cdata_off)
                except Exception as e:
                    out.write(f'\n# {cls} METHOD-PARSE ERROR: {e}\n')
                    continue
                lines = [f'\n# {cls} ({len(cm)} methods)']
                for kind, midx, code_off in cm:
                    if midx >= len(methods):
                        lines.append(f'  {kind:7s} <bad idx {midx}>')
                        continue
                    cname, mname = methods[midx]
                    lines.append(f'  {kind:7s} {mname}  (code_off={code_off})')
                block = '\n'.join(lines)
                out.write(block + '\n')
                hits.append(cls)
        out.write(f'\n\n== TOTAL MATCHED CLASSES: {len(hits)} ==\n')
    print(f'done, matched {len(hits)} classes -> {out_path}')

if __name__ == '__main__':
    main()
