#!/usr/bin/env python3
"""Build the final acceptance report for the 262 trait directories +
main algorithm system coverage, merging every evidence source."""
import collections
import glob
import json
import os

ROOT = r"E:\codex_apk_work"


def load(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return json.load(f)


def main():
    assoc = load(r"main_algo_extract\trait_dir_association.json")
    ev_rows = {r["dir"]: r for r in load(r"main_algo_extract\trait_dir_evidence.json")["rows"]}
    mapping = load(r"main_algo_extract\local_dir_to_remote_bundle.json")
    manifest = load(r"main_algo_extract\remote_manifest_full.json")
    dl_rep = load(r"remote_traits\download_report.json")
    failed = {r["name"] for r in dl_rep["fail"]}
    downloaded = set(os.path.basename(os.path.dirname(p))
                     for p in glob.glob(os.path.join(ROOT, r"remote_traits\dec", "*", "config.*.json")))
    assets_root = os.path.join(ROOT, "remote_traits", "assets")

    # index local project dirs by basename (one pass)
    local_dir_files = collections.defaultdict(list)
    for root2, dirs2, files2 in os.walk(os.path.join(ROOT, "blockblast_project", "assets")):
        for fn in files2:
            local_dir_files.setdefault(os.path.basename(root2), []).append(fn)

    def remote_assets(bundle):
        if not bundle:
            return 0, []
        exts = collections.Counter()
        for p in glob.glob(os.path.join(assets_root, bundle, "**", "*.*"), recursive=True):
            if os.path.isfile(p):
                exts[os.path.splitext(p)[1]] += 1
        return sum(exts.values()), dict(exts)

    rows = []
    for r in assoc["rows"]:
        d = r["dir"]
        remote_name = mapping.get(d)
        if remote_name is None:
            # still check manifest (bundle exists but download failed, or Remote_ prefixed)
            if d in manifest["bundleVers"]:
                remote_name = d
            elif ("Remote_" + d) in manifest["bundleVers"]:
                remote_name = "Remote_" + d
        local_files = local_dir_files.get(d, [])
        local_exts = collections.Counter(os.path.splitext(f)[1] for f in local_files)
        n_assets, a_exts = remote_assets(remote_name)
        ev = ev_rows.get(d)
        status = []
        if remote_name:
            if remote_name in failed:
                status.append("remote-403")
            elif remote_name in downloaded:
                status.append("remote-config-ok")
            if n_assets:
                status.append("remote-assets-ok")
        if ev and ev.get("classIdRegistered"):
            status.append("heap-classid")
        if ev and ev.get("inDecoratorConfigs"):
            status.append("heap-decorator")
        if local_files:
            status.append("local-files")
        rows.append({
            "dir": d,
            "remote_bundle": remote_name,
            "remote_ver": manifest["bundleVers"].get(remote_name) if remote_name else None,
            "remote_config": remote_name in downloaded,
            "remote_403": remote_name in failed if remote_name else False,
            "remote_asset_count": n_assets,
            "remote_asset_exts": a_exts,
            "local_file_count": len(local_files),
            "local_exts": dict(local_exts),
            "heap_occurrences": ev.get("occurrences", 0) if ev else 0,
            "heap_classIdRegistered": bool(ev and ev.get("classIdRegistered")),
            "heap_inNameLists": (ev or {}).get("inNameLists", 0),
            "heap_inDecoratorConfigs": (ev or {}).get("inDecoratorConfigs", 0),
            "status": ";".join(status) or "empty",
        })

    uniq = {}
    for r in rows:
        uniq.setdefault(r["dir"], r)
    uniq_rows = list(uniq.values())

    remote_traits = {k: v for k, v in manifest["bundleVers"].items() if "Trait" in k}
    algo_kw = ["Algo", "Algorithm", "LightGBM", "UCB", "Entropy", "RandomNoDeath",
               "BinaryBoard", "Puzzle", "FillSort", "ClearBoard", "Strategy", "GBM", "TKXC"]
    algo_bundles = {k: v for k, v in remote_traits.items() if any(x in k for x in algo_kw)}

    summary = {
        "user_count_262": len(rows),
        "unique_dirs": len(uniq_rows),
        "local_with_files": sum(1 for r in uniq_rows if r["local_file_count"] > 0),
        "remote_bundle_exists": sum(1 for r in uniq_rows if r["remote_bundle"]),
        "remote_config_downloaded": sum(1 for r in uniq_rows if r["remote_config"]),
        "remote_403": sum(1 for r in uniq_rows if r["remote_403"]),
        "remote_with_assets": sum(1 for r in uniq_rows if r["remote_asset_count"] > 0),
        "heap_evidence": sum(1 for r in uniq_rows if r["heap_occurrences"] > 0),
        "heap_classid": sum(1 for r in uniq_rows if r["heap_classIdRegistered"]),
        "full_trait_bundles_remote_manifest": len(remote_traits),
        "algo_related_remote_bundles": len(algo_bundles),
        "remote_bundles_downloaded": len(downloaded),
        "remote_bundle_total": len(manifest["bundleVers"]),
        "jsList_scripts": len(manifest["jsList"]),
    }

    out = {"summary": summary, "unique_dirs": uniq_rows, "all_rows": rows}
    with open(os.path.join(ROOT, "main_algo_extract", "trait_dir_acceptance.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
