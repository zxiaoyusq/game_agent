const fs = require('fs');
const data = JSON.parse(fs.readFileSync('E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810/spine-preview/spine_index.json', 'utf8'));
const counts = {};
let mipmap = 0;
for (const it of data) {
  const payload = it.atlasUrl.split(',')[1];
  const text = Buffer.from(payload, 'base64').toString('utf8');
  const m = text.match(/^filter:\s*(.+)$/m);
  const f = m ? m[1].trim() : '(none)';
  counts[f] = (counts[f] || 0) + 1;
  if (f.startsWith('MipMap')) mipmap++;
}
console.log('entries:', data.length, ' mipmap-filtered:', mipmap);
console.log(counts);
