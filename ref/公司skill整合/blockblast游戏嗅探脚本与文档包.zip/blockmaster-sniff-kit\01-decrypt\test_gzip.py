import gzip
import io
import os
import sys

sys.path.insert(0, r"E:\codex_apk_work\scripts")
from decrypt_jsc import KEY, xxtea_decrypt

raw = open(r"E:\codex_apk_work\blockblast_extracted\assets\assets\gl_fruit\index.701f6.jsc", "rb").read()
r = xxtea_decrypt(raw, KEY)
print("len", len(r), "first bytes:", r[:4].hex())
print("gzip file:", gzip.__file__)
print("same object check:", r[:2] == b"\x1f\x8b")
open(r"E:\codex_apk_work\memdump\jsc_test.bin", "wb").write(r)
print("type:", type(r), "id:", id(r))
r2 = open(r"E:\codex_apk_work\memdump\jsc_test.bin", "rb").read()
print("r2 first bytes:", r2[:4].hex(), "equal:", r == r2)
fp = io.BytesIO(r2)
print("bytesio read2:", fp.read(2).hex())
try:
    d = gzip.decompress(r2)
    print("JS len", len(d))
    print(d[:200])
except Exception as e:
    print("gzip error:", e)
