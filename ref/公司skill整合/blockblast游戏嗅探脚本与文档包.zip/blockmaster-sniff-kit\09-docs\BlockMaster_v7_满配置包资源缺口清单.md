# BlockMaster v7 满配置离线包 · 资源缺口清单

> 目标：把 `work\BlockMaster_v7.apk`（304.4 MB）升级为**满配置离线包**——所有远程内容直接内置，任何环境（无网络/飞行模式）零 CDN 下载、功能与线上满配一致。
> 依据：v7.apk 实包逐项统计 + `bb_1047_base.apk`（Block Blast 10.4.7 原始 base）对比 + `main_algo_extract/remote_manifest_full.json`（服务端全量远程 bundle 清单，4,885 项）+ `美术表现规则文档.md`。
> 结论先行：**本体与 Lottie 已完整，缺口集中在"远程层"：远程 JS 库 9 个、皮肤包约 100 个、远程 Trait/资源 bundle 约 4,600 个。**
> ❌ **特别决策：小游戏（more games）模块整体删除（不补齐、不保留）**——13 个小游戏 bundle、28 个 Remote_gl_* 补丁、MiniGame*/MoreGames* 入口 trait 全部从包中移除（详见 2.5 节，与低端机清单 H 类一致）。

---

## 一、已内置 vs 全量 对比总表（实测）

| 类别 | v7 已内置 | 全量（服务端/原始） | 缺口 |
|---|---|---|---|
| 本体 `assets/assets/`（429 个 bundle 目录） | 429（与 bb_1047_base **0 差集**） | 429 | **0 ✓ 完整**（❌ 但其中 13 个小游戏 bundle 将按 2.5 节**从包中删除**） |
| Lottie 动画 | 458 文件 | 458（base 同数） | **0 ✓ 完整** |
| 远程 JS 库 `assets/libs/` | **0 个** | 9 个（jsList） | **9 ❌ 完全缺失** |
| 远程皮肤包 | 20 个目录（18 纯色 + 24Colors + Common；1,922 文件 / 20.19 MB） | ~120 个 bundle（60+ 皮肤 ID + `_Atlas` 高清包） | **~100 ❌** |
| 远程 Trait/资源 bundle | 76 个 gamecaches trait 目录 + 193 个 patch 文件 | 4,885 个（remote_manifest_full） | **~4,600 ❌** |

> v7 的 `remote_seed/`（46.2 MB）来自某台模拟器当时的 gamecaches 快照——只覆盖了"该设备当时激活/下载过"的子集，远非全量。

---

## 二、缺口清单（详细）

### 2.1 远程 JS 库（9 个）—— 必补，且是功能缺口

`remote_manifest_full.json` 的 `jsList`（对应 CDN `remoteRes/0/jsList/`），**v7 完全未内置**：

| 远程库 | 作用 | 缺失影响 |
|---|---|---|
| `algorithmStrategy.1918b.js` | **算法策略库（核心）** | 离线时策略层功能缺失 ⚠️ |
| `rulesEngine.bd613.js` | **规则引擎** | 规则类逻辑缺失 ⚠️ |
| `gameBase.8deb3.js` | 游戏基础库 | 基础功能缺失 ⚠️ |
| `mbh-hotupdate.0b2c5.js` | 热更模块 | 热更链缺失 |
| `axios.min.a0864.js` | HTTP 库 | 网络请求兜底 |
| `jszip.min.ba8db.js` | zip 解压 | 资源解压兜底 |
| `macro.editor.d41d8.js` | 宏编辑器 | 活动功能 |
| `sha256.min.a7a6a.js` / `spark-md5.c218f.js` | 校验 | 完整性校验兜底 |

> ⚠️ 前 3 个（algorithmStrategy / rulesEngine / gameBase）疑似运行时必需，缺了可能影响启动或玩法，**必须补齐并验证**。

### 2.2 远程皮肤包（缺 ~100 个）

**已内置（20 个）：** `Remote_Skin_Material_2004/2005/2006/2011/2012/2014/2015/2017/2018/2019/2021/2026/2028/2030/2032/2033/2035/2037` + `Remote_SkinThree_24Colors_18Mat` + `Remote_SkinThree_Material_Common`

**缺失（全量约 120 - 已内置 20）：**

| 组 | 皮肤 ID | 说明 |
|---|---|---|
| 3000 系 | 3011 / 3012 / 3017 / 3032 / 3033 | 纯色/主题变体 |
| **4000 系材质皮肤（29 个材质名，商业卖点）** | 4001 fruit、4003 brick、4004 embroidery、4005 wool、4007 plasticbricks、4009 frostedacrylic、4012 argil、4013 bread、4019 jade、4020 yarn、4027 iron、4028 balloons、4033 potion、4035 starwar、4036 gold、4039 stamp、4041 velvet、4042 marble、4048 cobblestone、4054 gems、4060 ice、4061 paint、4063 cookie、4066 cardboard、4072 dust、4078 friedegg、4079/4081/4082 tablecloth | 完整材质包（方块贴图+背景+动效+字体+音效） |
| 4000 系无材质名 | 4008 / 4010 / 4021 / 4026 / 4037 / 4045 / 4051 / 4055 | 配色变体 |
| 5000 系 | 5005 / 5006 | 特殊包 |
| **全部 `_Atlas` 高清图集包** | 每个皮肤 ID 对应的 `Remote_Skin_Material_<id>_Atlas` | 高清贴图独立包，满配置必须一起内置 |

> 体积参考：全量皮肤包解密后约 **104 MB**（此前 remote_skins/dec 统计 8,795 文件）；压缩进 APK 约增加 **30~50 MB**。
> ⚠️ 全量皮肤 ID 清单此前在 `remote_skins/skins清单.md`（该目录已移出工作区），如需要可从 CDN `https://bband1.afafb.com/update/block_android_online/remoteRes/0/remote/` 按 125 个 bundle 版本清单重新拉取。

### 2.3 远程 Trait / 资源 bundle（缺 ~4,600 个）

`remote_manifest_full.json` 全量 **4,885 项** vs v7 内置 76 个 trait 目录。分类明细：

| 分类 | 全量数 | v7 内置 | 缺口 | 说明 |
|---|---|---|---|---|
| `*Trait`（机制/美术 bundle） | 3,814 | ~76 | **~3,700** | 如 Mosaic*（27）、NewUser*（90+）、Revive*（150+）、Score*（100+）、PerfectPlacement*（15）、YourName*（13）、YXHD_*（12）、Promo*（8）、Valentine 活动系列、ClearScreen 系列 |
| `Remote_gl_*`（小游戏远程补丁） | 28 | 0 | ❌ **删除，不补齐** | ❌ 小游戏整体删除（见 2.5）：gl_fruit 7 个、gl_oneline 10 个、gl_mahjong/gl_onet/gl_sudoku/gl_tictactoe/gl_hall 等全部不内置 |
| `l_*`（配置/开关类） | 545 | 0 | **545** | l_changeSkin、l_materialCard*、l_flowerStar*、l_daxiao*、l_classicBaseSkin 等远程配置 |
| `r_*`（资源类） | 228 | 0 | **228** | r_flowerSeries（80 个）、r_materialCard（40 个）、r_valentine* 活动资源、r_daxiao* 背景 11 个等 |
| 小游戏 bundle | 18 | 0（内置在本体 assets/assets） | ❌ **从包中删除** | gl_fruit/gl_hall/gl_mahjong/gl_oneline/gl_onet/gl_sudoku/gl_tictactoe/gl_watersort/hsgame/sand_audio/sand_mini/sand_prefab/sandcrush——**已内置但将整体移除**（见 2.5） |
| `clear_effect*` | 4 | 0 | 4 | 清屏特效替换包 |
| main / mainRes / 其他 | 14 | — | 部分 | — |

> 说明：4,885 是"服务端可下发的全部 bundle"。**其中大部分是纯配置/纯逻辑（无美术）**，离线包是否全量内置取决于"满配置"的定义：
> - **严格满配**：4,885 全部内置（体积大，估增 50~80 MB）——**不含小游戏相关（Remote_gl_*、小游戏 bundle 已删除）**
> - **业务满配**：只内置"有美术资产 + 激活概率高"的（r_* 资源 228 + 皮肤 120 + 活动系列），约 400~500 个，估增 40~60 MB——**不含 Remote_gl_*（已删除）**

### 2.5 ❌ 小游戏（more games）整体删除清单（不补齐、不保留）

> 与《低端机专用包资源剔除清单》H 类一致，两个包统一执行：

| 删除项 | 内容 | 数量 |
|---|---|---|
| 小游戏 bundle（本体已内置，**从包中移除**） | `assets/assets/gl_fruit`、`gl_hall`、`gl_mahjong`、`gl_oneline`、`gl_onet`、`gl_sudoku`、`gl_tictactoe`、`gl_watersort`、`hsgame`、`sandcrush`、`sand_mini`、`sand_prefab`、`sand_audio` | 13 |
| 小游戏远程补丁（**不补齐**） | `Remote_gl_fruit_*` 7、`Remote_gl_oneline_*` 10、`Remote_gl_hall_*` 2、`Remote_gl_mahjong_*` 2、`Remote_gl_onet_*` 2、`Remote_gl_sudoku_*` 3、`Remote_gl_tictactoe_*` 2 | 28 |
| 小游戏入口/控制 trait（**firing=0，不内置**） | `MiniGameEnterChangeColor`、`MiniGameMainEnterChangeColor`、`MiniGameSetEnterChangeColor`、`MiniGameSetShowLock`、`MiniGameSetShowProgress`、`MiniGameShowOnlineCount`、`MiniGameSpeedUp`、`MiniGameUnlockByDays`、`MiniGameUnlockNotification`、`MiniGameUnlock`、`MiniGameUseColorfulBtn`、`MiniIconAddEffect(_main)`、`MoreGameBtnFixBug`、`MoreGameContinueLastMiniGame`、`MoreGameRandomEnter`、`MoreGamesAdventureExchange`、`MoreGamesToMiniGames`、`MoreGamesUnlockByBreakHighScore`、`MoreGamesUnlockByDays`、`RecentMiniGames`、`CampaignAcceptFirstLaunchToMiniGame`、`GameOverShowMiniGameIcon`、`NoNetMiniGameBlock`、`NoNetworkNoMiniGame` | 25 |
| 小游戏美术 | 小游戏 Spine 约 39 组（水果 12/麻将 7/井字棋 3/水排序 4/数独 2/连连看 2/连线 2/大厅 3/沙块 4）+ 各 bundle 内 DB/贴图/音频 + 小游戏场景 `gl_*.fire` 11 个 + 大厅小游戏/MoreGames 入口按钮与跳转 | — |

**同步动作：** 大厅入口代码路径失效处理（无小游戏入口/无报错）；`Remote_gl_*` 与相关 trait 不内置不下载。

### 2.4 patch 热更内容（193 文件，可能不全）

- v7 内置 `assets/remote_seed/patch/patch/assets/`（193 文件 / 20.77 MB，来自 bb1047_remote_content 设备快照）
- ⚠️ 全量 patch 清单未知（CDN `remoteRes/0/patch/`），如要严格满配需从 CDN 全量拉取核对

---

## 三、补齐方案（按优先级）

| 优先级 | 内容 | 动作 | 预估增体积 |
|---|---|---|---|
| P0 | 远程 JS 库 9 个 | 从 CDN `jsList/` 下载 → 放入 `assets/libs/`（注意 settings/加载路径） | <1 MB |
| P0 | 4000 系 29 个材质皮肤 + `_Atlas` 高清包 | 从 CDN `remote/` 全量下载皮肤 bundle → HEK:XOR 解密 → 内置（命名与 CDN 一致） | +30~50 MB |
| P1 | `r_*` 资源类 | 全量内置（用户可见内容） | +10~15 MB |
| P1 | `l_*` 配置类 545 个 | 内置（体积小，json 为主） | +2~5 MB |
| P2 | 全部 `*Trait` 3,814 个 | 全量内置（严格满配）或按产品策略精选 | +30~60 MB |
| P2 | patch 全量 | CDN 拉取核对 | 未知 |

**补完后预估包体：** 304.4 + 80~130 MB ≈ **390~435 MB**（严格满配）；业务满配 ≈ **360~380 MB**。
**❌ 小游戏删除减项：** 移除 13 个小游戏 bundle（+28 补丁不补）约减 **8~15 MB**（本体 bundle 体积）——上述预估值请再减 8~15 MB。

---

## 四、需要同步修改的配置（内置后禁止再走 CDN）

1. **bundle 加载路径**：`settings.js` / 热更配置中的远程地址 `https://bband1.afafb.com/update/block_android_online/remoteRes/0/` 改为本地（assets/remote_seed 或直接 assets/），确保零网络请求
2. **版本校验**：内置 bundle 的 config/index 版本号与 `remote_manifest_full.json` 一致（如皮肤 4005 主包 `3f17e`），避免客户端检测版本不符回退 CDN
3. **加载目录结构**：皮肤/trait 需还原为 gamecaches 的加载格式（`gamecaches/<bundle>/<时间戳>.js/.json` 或标准 bundle 结构，以现有 remote_seed 成功加载的格式为准）
4. **jsList**：9 个远程库放入 `assets/libs/` 后，确认 jsb 加载顺序（main.js 引用）

---

## 五、验证清单（满配置离线验收）

- [ ] 飞行模式冷启动 → 无任何 `bband1.afafb.com` 请求（抓包确认 0）
- [ ] 皮肤列表全部可见可切换（含 29 个材质皮肤 + 高清图集，不出现加载失败）
- [ ] ❌ **小游戏（more games）不存在**：无小游戏入口/按钮/跳转，无残留报错；`Remote_gl_*` 无下载请求
- [ ] 活动功能（Valentine/花系列/达笑等 r_* 资源）正常
- [ ] 规则引擎/算法策略（jsList 库）在线下对局正常（50 回合无异常）
- [ ] 热更链（mbh-hotupdate）离线不报错
- [ ] 内存/启动时长不劣化（相比 v7）

---

## 附：数据来源与局限

- ✅ v7 内置清单：`BlockMaster_v7.apk` zip 逐项统计（13,804 条目）
- ✅ 本体完整性：与 `bb_1047_base.apk`（11,259 条目）目录级 0 差集
- ✅ 全量远程清单：`main_algo_extract/remote_manifest_full.json`（4,885 键 + 9 jsList，含 CDN server 地址）
- ⚠️ 全量皮肤 ID 精确清单：原 `remote_skins/skins清单.md` 已不在工作区，本文按此前统计（120 包 / 29 材质名）与已知编号段列示，如需精确清单从 CDN 按版本清单重拉
- ⚠️ patch 全量未知；部分远程库/配置的"运行必需性"需实机验证
