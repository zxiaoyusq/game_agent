#!/usr/bin/env python3
"""Download Block Blast remote skin bundles (Remote_Skin_Material_*) from the game CDN.

The bundle version manifest is recovered from the runtime heap dump.  Each bundle is
a standard Cocos Creator 2.x remote bundle served under
    https://bband1.afafb.com/update/block_android_online/remoteRes/0/remote/<bundle>/

Files are encrypted with the game's "HEK:" scheme (XOR keystream, key recovered from
the APK), optionally gzip-compressed.
"""
import base64
import gzip
import json
import os
import re
import sys
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

KEY = b"65485d8a-8161-4c"
BASE = "https://bband1.afafb.com/update/block_android_online/remoteRes/0/remote/"
OUT_ROOT = r"E:\codex_apk_work\remote_skins"

HEAP_FILES = [
    r"E:\codex_apk_work\memdump\heap\0x3030001c0000_7200000.bin",
    r"E:\codex_apk_work\memdump\heap\0x303000040000_103000.bin",
    r"E:\codex_apk_work\memdump\big_region_119MB_probe.bin",
]


def extract_manifest():
    """Rebuild {bundle_name: version_hash} from heap strings."""
    manifest = {}
    pat = re.compile(r'([A-Za-z0-9_]+): "([0-9a-f]{5})"')
    for p in HEAP_FILES:
        try:
            text = open(p, "rb").read().decode("latin1")
        except OSError:
            continue
        for name, ver in pat.findall(text):
            if name.startswith("Remote_Skin"):
                manifest[name] = ver
    # SkinThree bundles use a slightly different format in the heap
    for name, ver in (
        ("Remote_SkinThree_Material_Common", "4216c"),
        ("Remote_SkinThree_24Colors_18Mat", "f5b24"),
    ):
        manifest.setdefault(name, ver)
    return manifest


def decode_uuid(compressed):
    """Decode a Cocos Creator compressed uuid (22 chars) to hex with dashes."""
    if len(compressed) != 22:
        return compressed
    rest = base64.b64decode(compressed[2:] + "==")  # 15 bytes
    hexs = compressed[0:2] + rest.hex()
    return "%s-%s-%s-%s-%s" % (
        hexs[0:8], hexs[8:12], hexs[12:16], hexs[16:20], hexs[20:32])


def decrypt(data):
    if not data.startswith(b"HEK:"):
        return data
    body = data[8:]
    ks = (KEY * (len(body) // 16 + 1))[:len(body)]
    pt = bytes(a ^ b for a, b in zip(body, ks))
    if pt[:2] == b"\x1f\x8b":
        try:
            pt = gzip.decompress(pt)
        except Exception:
            pass
    return pt


def http_get(url, timeout=30):
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "Accept": "*/*",
    })
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


EXT_BY_TYPE = {
    "cc.Texture2D": ["png", "jpg", "webp"],
    "cc.SpriteFrame": ["png", "jpg", "webp"],
    "sp.SkeletonData": ["bin", "json", "skel"],
    "cc.BitmapFont": ["fnt"],
    "cc.AudioClip": ["mp3", "ogg", "wav"],
    "cc.Asset": ["json", "atlas", "bin", "plist", "txt", "xml"],
}


class Bundle:
    def __init__(self, name, version):
        self.name = name
        self.version = version
        self.config = None
        self.type_by_uuid = {}
        self.ext_known = {}      # uuid -> extension from heap ground truth
        self.import_map = {}     # uuid -> hash
        self.native_map = {}     # uuid -> hash

    @property
    def base_url(self):
        return BASE + self.name + "/"

    def load_config(self):
        raw = http_get(self.base_url + "config.%s.json" % self.version)
        self.config = json.loads(decrypt(raw))
        types = self.config.get("types") or []
        uuids = self.config.get("uuids") or []
        paths = self.config.get("paths") or {}
        for idx, info in paths.items():
            uuid = uuids[int(idx)]
            t = info[1] if len(info) > 1 and info[1] < len(types) else 0
            self.type_by_uuid[uuid] = types[t] if t < len(types) else "cc.Asset"
        v = self.config.get("versions") or {}
        imp = v.get("import") or []
        for i in range(0, len(imp), 2):
            self.import_map[uuids[imp[i]]] = imp[i + 1]
        nat = v.get("native") or []
        for i in range(0, len(nat), 2):
            self.native_map[uuids[nat[i]]] = nat[i + 1]

    def set_heap_exts(self, ext_map):
        self.ext_known = ext_map

    def native_candidates(self, uuid):
        if uuid in self.ext_known:
            return [self.ext_known[uuid]]
        t = self.type_by_uuid.get(uuid, "cc.Asset")
        return EXT_BY_TYPE.get(t, ["json"])


def build_heap_ext_map():
    """uuid -> ext for bundles observed in the heap (ground truth)."""
    result = {}
    pat = re.compile(
        r"remoteRes/0/remote/(Remote_Skin_[A-Za-z0-9_]*)/native/"
        r"[0-9a-f]{2}/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})"
        r"\.([0-9a-f]{5})(\.[a-z0-9]+)?")
    for p in HEAP_FILES:
        try:
            text = open(p, "rb").read().decode("latin1")
        except OSError:
            continue
        for m in pat.finditer(text):
            bn, uuid, _h, ext = m.groups()
            if ext:
                result.setdefault(bn, {})[uuid] = ext[1:]
    return result


def download_bundle(bundle, out_dir):
    bundle.load_config()
    name = bundle.name
    bdir = os.path.join(out_dir, "raw", name)
    os.makedirs(bdir, exist_ok=True)

    def fetch(rel, url_exts):
        dst = os.path.join(bdir, rel)
        if os.path.exists(dst) and os.path.getsize(dst) > 0:
            return ("skip", rel)
        ddir = os.path.dirname(dst)
        if ddir and os.path.isdir(ddir) and any(
                f.startswith(os.path.basename(dst) + ".")
                for f in os.listdir(ddir)):
            return ("skip", rel)
        for url, ext in url_exts:
            try:
                data = http_get(url)
                final = dst if not ext else dst + "." + ext
                os.makedirs(os.path.dirname(final), exist_ok=True)
                with open(final, "wb") as f:
                    f.write(data)
                return ("ok", rel)
            except Exception:
                continue
        return ("fail", rel)

    tasks = []
    # config + index
    tasks.append(("config.%s.json" % bundle.version,
                  [(bundle.base_url + "config.%s.json" % bundle.version, "")]))
    tasks.append(("index.%s.js" % bundle.version,
                  [(bundle.base_url + "index.%s.js" % bundle.version, "")]))
    # import + native per uuid
    for uuid, h in bundle.import_map.items():
        hexu = decode_uuid(uuid)
        rel = "import/%s/%s.%s.json" % (hexu[:2], hexu, h)
        tasks.append((rel, [(bundle.base_url + rel, "")]))
    for uuid, h in bundle.native_map.items():
        hexu = decode_uuid(uuid)
        rel = "native/%s/%s.%s" % (hexu[:2], hexu, h)
        url_exts = [(bundle.base_url + rel + "." + ext, ext)
                    for ext in bundle.native_candidates(uuid)]
        tasks.append((rel, url_exts))

    ok = fail = 0
    with ThreadPoolExecutor(max_workers=12) as ex:
        futs = {ex.submit(fetch, rel, url): rel for rel, url in tasks}
        for fut in as_completed(futs):
            try:
                st, rel = fut.result()
                if st == "ok":
                    ok += 1
                elif st == "fail":
                    fail += 1
            except Exception:
                fail += 1
    return ok, fail, len(tasks)


def decrypt_tree(out_dir):
    """Decrypt all HEK files under raw/ into dec/ preserving relative layout."""
    raw_root = os.path.join(out_dir, "raw")
    dec_root = os.path.join(out_dir, "dec")
    n = 0
    for root, _dirs, files in os.walk(raw_root):
        for fn in files:
            src = os.path.join(root, fn)
            rel = os.path.relpath(src, raw_root)
            dst = os.path.join(dec_root, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            data = open(src, "rb").read()
            pt = decrypt(data)
            open(dst, "wb").write(pt)
            n += 1
    return n


def main():
    only = None
    if len(sys.argv) > 1:
        only = set(sys.argv[1:])
    manifest = extract_manifest()
    heap_ext = build_heap_ext_map()
    bundles = []
    for name, ver in sorted(manifest.items()):
        if only and name not in only:
            continue
        b = Bundle(name, ver)
        b.set_heap_exts(heap_ext.get(name, {}))
        bundles.append(b)
    print("bundles to download:", len(bundles))
    summary = {}
    for b in bundles:
        try:
            ok, fail, total = download_bundle(b, OUT_ROOT)
            summary[b.name] = {"ok": ok, "fail": fail, "total": total,
                               "version": b.version}
            print("%-42s ok=%-4d fail=%-4d total=%d" % (b.name, ok, fail, total))
        except Exception as e:
            summary[b.name] = {"error": str(e)}
            print("%-42s ERROR %s" % (b.name, e))
    n = decrypt_tree(OUT_ROOT)
    print("decrypted files:", n)
    with open(os.path.join(OUT_ROOT, "download_summary.json"), "w",
              encoding="utf-8") as f:
        json.dump({"manifest": manifest, "summary": summary}, f,
                  ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
