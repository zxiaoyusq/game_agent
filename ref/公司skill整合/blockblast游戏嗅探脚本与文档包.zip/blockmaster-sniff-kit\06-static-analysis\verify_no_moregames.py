# -*- coding: utf-8 -*-
"""Verify no MoreGames/MiniGame entries in assets/manifests/cacheList (JS may still contain strings in no-op bodies)."""
import argparse
import json
import os
import sys
import zipfile

KEYWORDS = [
    'GameLobbyAddMoreGame',
    'CommonGameEntrance',
    'CommonGameList',
    'GLHallMoreGames',
    'GameOverShowMiniGame',
    'ChangeMoreGamesDoubleCol',
    'MoreGamesUnlockByDays',
    'MoreGamesUnlockByBreakHighScore',
    'MiniGame',
    'JewelGame',
]


def scan_stage2(stage2):
    failures = []
    remote_seed = os.path.join(stage2, 'assets', 'remote_seed')
    for dp, _, fs in os.walk(remote_seed):
        for fn in fs:
            p = os.path.join(dp, fn)
            rel = os.path.relpath(p, stage2).replace('\\', '/')
            # index JS allowed to keep strings inside no-op bodies; only check manifests/cache/baseM/resources
            if rel.endswith('.js'):
                continue
            try:
                data = open(p, 'rb').read()
            except Exception:
                continue
            hits = [k for k in KEYWORDS if k.encode() in data]
            if hits:
                failures.append((rel, hits))
    return failures


def scan_apk(apk):
    failures = []
    z = zipfile.ZipFile(apk)
    for info in z.infolist():
        name = info.filename
        if name.endswith('.js'):
            continue
        try:
            data = z.read(name)
        except Exception:
            continue
        hits = [k for k in KEYWORDS if k.encode() in data]
        if hits:
            failures.append((name, hits))
    return failures


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--stage2')
    ap.add_argument('--apk')
    args = ap.parse_args()
    if args.stage2:
        failures = scan_stage2(args.stage2)
        src = args.stage2
    elif args.apk:
        failures = scan_apk(args.apk)
        src = args.apk
    else:
        print('need --stage2 or --apk')
        return 3
    print('scan', src)
    if failures:
        print('FAIL MoreGames entries in manifests/resources:')
        for f in failures:
            print(' ', f)
        return 1
    print('PASS no MoreGames entries outside JS')
    return 0


if __name__ == '__main__':
    sys.exit(main())
