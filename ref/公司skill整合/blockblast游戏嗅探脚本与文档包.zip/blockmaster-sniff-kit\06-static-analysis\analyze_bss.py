import re

data = open(r"E:\codex_apk_work\memdump\bss_dump.bin", "rb").read()
print("bss dump len:", len(data))
strs = re.findall(rb"[\x20-\x7e]{4,}", data)
seen = set()
for s in strs:
    if s not in seen:
        seen.add(s)
        print(repr(s))
print("total strings:", len(strs))

# hexdump around key table region
i = data.find(b"65485d8a-8161-4c")
print("key at", hex(i))
if i >= 0:
    lo = max(0, i - 256)
    hi = min(len(data), i + 512)
    chunk = data[lo:hi]
    for off in range(0, len(chunk), 16):
        row = chunk[off:off + 16]
        asc = "".join(chr(b) if 32 <= b < 127 else "." for b in row)
        print(hex(lo + off), row.hex(" "), asc)
