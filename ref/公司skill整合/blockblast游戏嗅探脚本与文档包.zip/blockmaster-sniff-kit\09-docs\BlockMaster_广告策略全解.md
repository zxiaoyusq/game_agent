# BlockMaster（Block Blast 1047 改道版）广告策略全解

> 目标读者：策划 / 运营 / 广告对接。把游戏源码里的广告机制完整翻译成触发规则。
> 依据：`modified_main_index_7d3cd.js`（主逻辑 17MB 明文，含 Advertisement_Load_Proxy / Advertisement_FullScreen_Proxy / AdvertisementGameInfo 完整源码 + 装饰器注册表）、`广告场景与触发机制盘点.md`（原版全景）、`ad_logcat_20260818_153326.txt`（2026-08-18 实测）、`交接_广告加载问题专项.md`（改道状态）。
> 符号：✅=源码确认；⚠️=推断/待运行时确认；🔧=改道版现状（hisavana）。

---

## 〇、速答：初始游玩连续死亡五轮后才拉取到广告，正常吗？

**结论：基本正常，是"设计行为 + 当前后台未配源"叠加的结果，不是 bug。** 原因链（全部 ✅ 源码确认）：

1. **激励视频（复活广告）预加载默认延迟 30 秒，且每次开局都会重置计时**（`Advertisement_Load_Proxy.loadAdTrait`：开局先加载插屏，`setTimeout(30s)` 后才加载激励）。快速死亡重开的局会不断重置这个 30 秒——直到某一局撑过 30 秒或激励被其他事件补载，`LoadRewardAd` 才会真正发出。
2. **冷启动保护**：`ColdStartNoAdWithin30sTrait`（冷启动 30 秒内无广告）、`ColdStartSkipFirstInterstitialTrait`（跳过首个插屏）、`ColdStartExemptFirstInterstitialTrait`（首个插屏豁免）、`$21036_f_coldPlayerInterAdTrait`（冷启用户插屏控制）——刚启动的几分钟内插屏被屏蔽。
3. **首次/每日豁免**：`FirstEntryInterstitialExemptTrait`（首次进入豁免）、`DayExemptFirstInterstitialTrait`（每日首个插屏豁免）。
4. **新用户策略**：`NewUserAdPolicyTrait` / `NewPlayerAdShowTrait` / `NewUserInterstitialStrategyTrait` / `NoBannerAdNewUserTrait` / `NoBannerAdNewUserByDaysTrait`（新用户 N 天无横幅）。
5. 死亡后的广告是**激励视频（用户主动点"看广告复活"才触发展示）**，不是自动弹；"拉取到广告"= 激励预加载完成，而它在 30 秒延迟 + 多次重置下确实要到第 N 轮才落地。
6. 🔧 当前改道版 hisavana 后台**广告位未配置广告源（70011）**，即使加载请求发出也是 `network is empty` / `204 / 429`——"拉不到广告"的另一半原因在后台配置。

> 一句话：**前几轮看不到广告 = 冷启动/新用户豁免 + 激励 30 秒延迟重置；之后拉不到 = 后台未配源。**

---

## 一、广告体系总览

| 类型 | JS 类型串 | AD_TYPE | 用途 | 改道状态 |
|---|---|---|---|---|
| 激励视频 | reward | TYPE_5("500") / 501-504 / 701 / 705 | 复活、道具、皮肤、大厅奖励 | 🔧 LoadRewardAd 已通，展示待配源 |
| 插屏 | inter/fullscreen | 401-409 / 700 / 704 | 回前台、超时、结算、大厅 | 🔧 LoadInterstitialAd 已通，展示待配源 |
| 横幅 | banner | TYPE_3("3") / 400 | 主页/大厅/局中 | 🔧 hideBanner 循环实测每 1 秒一次 |
| 品牌广告 | LaunchBrandAd*Trait | — | 冷启动品牌页 | 未改道 |

**展示链路（✅ 源码）**：业务事件 → Proxy（showRewardVideo / showFullScreenAdvertisement）→ `getIsCanPlayAd()` 门控 → `setAdRegists`（5 秒超时兜底）→ `shieldPlayAdvertisement()` trait 链 → `processingAdInterface()`（`traitCanShowAd()` 再拦截）→ **`NativeAd.callNativeAd(json)`** 原生展示。

---

## 二、广告加载机制（什么时候"拉取"广告）—— 核心

源码：`Advertisement_Load_Proxy`（✅ 完整提取）。

### 2.1 四个加载触发事件

| 事件 | 动作 |
|---|---|
| `E_Game_Start`（每局开始） | `OnLoadAd()` → **loadAdTrait()**（见 2.2） |
| `E_Advertisement_SceneLoad`（场景加载） | 同上 OnLoadAd()（重新走一遍加载流程） |
| `E_Advertisement_RewardOver`（激励播放结束） | `loadRewardAdInterface()` 立即补载激励 |
| `E_Game_InitComplete`（游戏初始化完成） | `registerLoadADWithEmitter([])` 注册按需补载 |

### 2.2 loadAdTrait：插屏立即加载，激励延迟 30 秒（每局重置！）

```
loadAdTrait(e=false, t=false, a=30)：
  默认分支（e=false）：
    ① loadFullScreenAdInterface()   ← 插屏：立即预加载（这局一开就拉插屏）
    ② setTimeout(30 秒) 后，若 _loadVideoAd 仍为 false：
       loadRewardAdInterface()       ← 激励：延迟 30 秒才预加载
  分支 e=true（某些 trait 调用）：200ms 后 gameStartLoadAd → 插屏+激励同时加载
  分支 t=true：useNoClearTimeoutLoad(30) → 插屏立即 + 激励 30 秒后
```

**关键语义**：`E_Game_Start` 每局都触发 `loadAdTrait()`，**每次都会 clearLoadTimeout 重置 30 秒定时器**——所以"短命局连开"时，激励预加载会被无限推迟，直到某一局存活/持续超过 30 秒才真正发出 `LoadRewardAd`。这**直接解释了"连续死亡五轮才拉取到激励广告"**。

### 2.3 加载开关（按模式/局数）

| 开关 | 逻辑（✅） |
|---|---|
| `isCanLoadClassFullScreenAd` | `classGameNum >= 0`（classGameNum 被特定 trait 置负时会停载插屏） |
| `isCanLoadChapterFullScreenAd` | 恒 true |
| `isCanLoadOtherFullScreenAd` | 恒 true |
| `isCanLoadClass/ChapterRewardAd` | 恒 true |

### 2.4 按需补载（onLoadADFire）

`getReadyByAdType("inter"/"reward")` 已就绪则**不再重复加载**；未就绪才 `showLoad(type)`（✅ 避免重复请求）。

---

## 三、展示链路四道门控（✅ 源码）

| 门控 | 逻辑 | 证据 |
|---|---|---|
| ① `getIsCanPlayAd()` | **剩余内存 < 300MB → 禁播**（report -1）；**VIP 用户 → 禁播**（report -2） | ✅ |
| ② `setAdRegists` | 注册回调，**原生 5 秒无回调 → goOnGame 强制继续并视为成功** | ✅ |
| ③ `shieldPlayAdvertisement()` | 各 Proxy 上被 **20+ 个 trait 挂载拦截**（见第四节全表） | ✅ 装饰器表 |
| ④ `traitCanShowAd(type)` | processingAdInterface 内再拦截（默认放行） | ✅ |

> 被任一拦截 → 回调 cb(1)（**视为"跳过成功"**，游戏继续，不产生广告展示）。

---

## 四、屏蔽与频率策略全表（谁在管广告能不能弹）

### 4.1 插屏屏蔽链（`Advertisement_FullScreen_Proxy.shieldPlayAdvertisement` 装饰器，20 个 trait ✅）

| Trait | 策略 | 类型 |
|---|---|---|
| `ColdStartNoAdWithin30sTrait` | **冷启动 30 秒内无广告** | 冷启动 |
| `ColdStartSkipFirstInterstitialTrait` | **冷启动跳过第一个插屏** | 冷启动 |
| `ColdStartExemptFirstInterstitialTrait` | **冷启动首个插屏豁免** | 冷启动 |
| `ColdStartInterstitialExemptComboTrait` | 冷启动插屏豁免（连击场景） | 冷启动 |
| `ColdStartEscapeInterstitialCompensationTrait` / `ColdStartEscapeBoostInterstitialTrait` | 冷启动"逃离插屏"补偿/增强（挂 onShowAdSuccess） | 冷启动 |
| `$21036_f_coldPlayerInterAdTrait` / `...AdjustParamsTrait` | **冷启用户插屏控制**（feature-flag 系列） | 冷启动 |
| `FirstEntryInterstitialExemptTrait` | **首次进入游戏豁免插屏** | 首次 |
| `DayExemptFirstInterstitialTrait` / `...ExpTrait` | **每日第一个插屏豁免**（Exp=实验版） | 每日 |
| `NewSessionEndGameAdTrait` | 新会话结束广告策略 | 会话 |
| `NoShowInterAdRateTrait` | **按概率不显示插屏**（概率值服务端下发 ⚠️） | 概率 |
| `AdIntervalTrait` | **插屏最小间隔**（秒数服务端下发 ⚠️） | 频率 |
| `AdProtectTrait` / `AdProtectAdjustParamsTrait` | **广告保护**（全局保护开关+调参） | 全局 |
| `ChurnModelAdExemptionTrait` / `ChurnLtvOptAdOptimizationTrait` | 流失模型/LTV 优化豁免 | 模型 |
| `HighEcpmUserAddAdTrait` | **高 ecpm 用户加广告** | 模型 |
| `IsOpenIosLtvMaximizeExperimentPlanTrait` | iOS LTV 实验（iOS 专属） | 平台 |
| `MiniGameDeliveryUndertakeTrait` | 小游戏分发承接（❌ 小游戏已删，此 trait 应同步关闭） | 业务 |
| `AdSensitivityRefactorTrait` | 广告敏感度（挂 advertisementCallBack） | 全局 |

### 4.2 频率/间隔类（原版盘点 + 注册表补充 ⚠️ 数值服务端下发）

| Trait | 作用 |
|---|---|
| `AdIntervalTrait` | 插屏展示间隔 |
| `GLShowInsertAdsBySecondsTrait` | 局中按秒插屏 |
| `GLShowAdsByGameTimeTrait` / `GLShowAdsPopupByCountTrait` | 局中按游戏时长/次数 |
| `SessionProbNoInterAdTrait` | 按会话概率屏蔽插屏 |
| `NoShowInterAdRateTrait` | 按概率不显示 |
| `AdvertisementLoadDelayTimeTrait` / `...NoClear30Trait` | 加载延迟 |
| `AppShowPlayInterstitialAdTrait` | 回前台插屏开关 |
| `IsOpenLowRoundNoAdByEcpmTrait` | **低局数按 ecpm 无广告** |
| `IsOpenNextGameIsAddInterByEcpmTrait` / `IsOpenEcpmTooLowNoInterTrait` | ecpm 过低不插屏 |
| `SimilarUserAdIntervalTrait` | 相似用户间隔 |
| `BadExpFreeInterstitialTrait` | 差体验免插屏 |
| `IsOpenRefuseReviveNotInterTrait` | 拒绝复活后不插屏 |
| `DynamicChangeInterAdPlayTrait` | 动态调整插屏 |
| `ColdStartNoAdWithin30sECPMTrait` | 冷启动 30 秒无广告（ecpm 版） |
| `PlacementReturnMitigationTrait` | 广告位回归缓解 |

### 4.3 新用户/回归保护

| Trait | 作用 |
|---|---|
| `NewUserAdPolicyTrait` | **新用户广告策略总控** |
| `NewPlayerAdShowTrait` | 新玩家广告展示策略 |
| `NewUserInterstitialStrategyTrait` | 新用户插屏策略（前 N 局/前 N 天 ⚠️ 数值服务端下发） |
| `NoBannerAdNewUserTrait` / `NoBannerAdNewUserByDaysTrait` | **新用户 N 天无横幅** |
| `NoBannerAdAllSceneTrait` / `NoBannerOnceShowByAdCompleteCountTrait` / `NoBannerDurationByAdCompleteCountTrait` | 横幅屏蔽（全场景/按完成数/按时长） |
| `ResilientPlayerComebackAdReduceTrait` / `PushBackNoAdTrait` / `ChangeNoAdTrait` | 回归玩家降频/免广告 |
| `ReturnUserAbilityStrategyTrait` 等 | 回归用户策略 |

### 4.4 广告位锁定（ADLOCK_TYPE ✅）

按模式/时机锁定广告位：`CLASS_END / CLASS_FRESH / CLASS_LIFE / MERGE_BLOCKS_END/FRESH/REVIVE / ROYAL_MATCH_STORY_* / TRAVEL_* / PUZZLE_* / MOREGAME_* / MXN_* / ATOM_ENGINE_REWARD`——结算插屏是否弹出由"模式结束事件 + 锁定类型 + 频率 trait"共同决定。

---

## 五、触发场景全表（何时展示）

| # | 场景 | 广告类型 | AD_TYPE | 说明 |
|---|---|---|---|---|
| 1 | 回到前台 | 插屏 | 401 | onAppShow → FullScreen_AppShow |
| 2 | 无操作超时 | 插屏 | 401 | onInactivity |
| 3 | 经典模式复活 | 激励 | 705 | 死亡点"看广告复活"（**用户主动触发**） |
| 4 | 通用激励请求 | 激励 | 500 | 道具/奖励等各业务场景 |
| 5 | 游戏大厅插屏 | 插屏 | 700 | 进大厅 |
| 6 | 游戏大厅激励 | 激励 | 701 | 大厅奖励 |
| 7 | 结算/结束插屏 | 插屏 | 400-409 | 按 ADLOCK_TYPE + 频率 trait（**死亡结算时**） |
| 8 | 皮肤奖励 | 激励 | 500 | 换皮奖励 |
| 9 | 主页/大厅横幅 | 横幅 | 3/400 | 常驻/轮询 |
| 10 | 局中横幅 | 横幅 | — | 按游戏时长/局数 |
| 11 | 冷启动品牌页 | 品牌 | — | LaunchBrandAd*Trait 系列 |

> 死亡相关的广告有两类：**复活 = 激励（用户点击才弹）**；**死亡结算 = 插屏（受冷启动/每日/首次豁免 + 间隔控制）**。

---

## 六、新用户冷启动时间线（回答"第 5 轮才拉广告"）

```
T+0s    启动游戏（HisavanaFileProvider onCreate）
T+0~30s 冷启动窗口：ColdStartNoAdWithin30s 屏蔽一切广告；插屏预加载已发（E_Game_Start）
T+0~30s 第一局开始：loadAdTrait → 插屏立即预加载；激励 30 秒定时器启动
T+20s   第一局死亡 → 点复活：getReadyByAdType("reward") 未就绪（激励还没加载）
         → 触发补载/等待（hisavana 无源 → 70011/204/429）
T+35s   第二局开始（快速重开）：loadAdTrait 重置 → 激励定时器重新计时 30 秒
T+55s   第三局…（重复重置）
T+~N 轮 某一局撑过 30 秒 / 或累计触发补载 → LoadRewardAd 真正发出（logcat 实测
         T+4.5min 出现）→ 激励"拉取到"广告
之后    死亡点复活 → ShowRewardAd(scene:400) → 🔧 后台无源 → error 4001/70011
```

**实测佐证（ad_logcat 2026-08-18）**：
- 15:17:49 进程启动（HisavanaFileProvider）
- 15:22:16 `执行[LoadRewardAd]` —— 距启动约 4.5 分钟（30 秒延迟 × 多局重置 + 重试后的真实落点）→ `network is empty` / 70011
- 15:23:36 死亡点复活 `ShowRewardAd scene:400` → 插屏未加载 error 4001（激励未就绪）

---

## 七、🔧 改道版（hisavana）现状与断点

| 链路 | 状态 | 说明 |
|---|---|---|
| 预加载 showLoad(0/2) | ✅ 已通 | BMAdBridge → hisavana Load |
| 就绪查询 getReadyByAdType | ✅ 已通 | |
| 横幅 hideBanner | ✅ 已通（实测每秒 1 次轮询） | |
| 激励/插屏展示 callNativeAd | ⚠️ 已分派 | 但 hisavana 后台**三个广告位（激励 260428mX7wkxmr / 插屏 26042893qlR57i / 横幅 260428LY5BXBxm）未配置广告源** → 70011/204/429 |
| 原生回调→JS | ❌ 断链 | 需 BM dex 回调通道 + main.js 翻译层（见交接文档） |

---

## 八、结论与建议

1. **"死亡五轮才拉广告"= 冷启动豁免 + 激励 30 秒延迟每局重置 + 新用户策略**，原版设计如此，正常；但**改道版拉不到广告的根因是 hisavana 后台未配源（70011）**，配源后激励在首局 30 秒后即可就绪。
2. 想让"更早看到广告"（运营向）：服务端把 `ColdStartNoAdWithin30sTrait` / `ColdStartSkipFirstInterstitialTrait` / `NewUserInterstitialStrategyTrait` 关闭或缩短参数；代码侧可把 `loadAdTrait` 的激励延迟 30s 改短（改包）。
3. 想让"更晚看到广告"（体验向）：加大 `AdIntervalTrait` 间隔、提高 `NoShowInterAdRateTrait` 屏蔽概率、延长新用户保护天数。
4. 全部参数数值由**服务端 trait 配置下发**（本地静态无法取到具体秒数/概率/轮数），上线调参需抓包或查后台。

---

## 附：证据与局限

- ✅ `Advertisement_Load_Proxy`（加载时机/30 秒延迟/重置/按需补载）：modified_main_index_7d3cd.js 完整代码块
- ✅ `getIsCanPlayAd`（内存 300MB/VIP）、`processingAdInterface`、`traitCanShowAd`：同上
- ✅ 插屏屏蔽 20 trait 装饰器表：`Advertisement_FullScreen_Proxy.shieldPlayAdvertisement` 注册表
- ✅ 实测时间线：ad_logcat_20260818_153326.txt（hisavana SDK 日志）
- ⚠️ trait 参数数值（30s/概率/间隔/局数阈值）：服务端下发，静态不可见
- ⚠️ `NewUserInterstitialStrategyTrait` 等的"前 N 局"具体阈值：同上
- 关联文档：`广告场景与触发机制盘点.md`（原版 20 场景全表）、`交接_广告加载问题专项.md`、`BlockMaster_Android_SDK接入分析.md`
