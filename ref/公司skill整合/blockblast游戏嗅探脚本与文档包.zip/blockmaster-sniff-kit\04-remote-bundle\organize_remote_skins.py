#!/usr/bin/env python3
"""Organize downloaded remote skin bundles into a named, readable asset tree.

For every Remote_Skin_Material_* bundle:
  - decrypts everything (idempotent; skips already decrypted)
  - rebuilds bundle config path -> asset file mapping
  - copies each asset to
        named/<bundle>/<path>/<filename>.<ext>
    using the human-readable path from the bundle config (e.g.
    res/game_cube_1_material_4005, effect/gameplay_eliminate_005,
    sound/wool_streak, font/gameplay_combo_fnt_material_4005, ...)
  - emits a JSON report (bundle -> material + asset list) and a markdown summary
"""
import base64
import gzip
import json
import os
import re
import shutil

KEY = b"65485d8a-8161-4c"
ROOT = r"E:\codex_apk_work\remote_skins"
RAW = os.path.join(ROOT, "raw")
DEC = os.path.join(ROOT, "dec")
NAMED = os.path.join(ROOT, "named")


def decode_uuid(compressed):
    if len(compressed) != 22:
        return compressed
    rest = base64.b64decode(compressed[2:] + "==")
    hexs = compressed[0:2] + rest.hex()
    return "%s-%s-%s-%s-%s" % (
        hexs[0:8], hexs[8:12], hexs[12:16], hexs[16:20], hexs[20:32])


def decrypt(data):
    if not data.startswith(b"HEK:"):
        return data
    body = data[8:]
    ks = (KEY * (len(body) // 16 + 1))[:len(body)]
    pt = bytes(a ^ b for a, b in zip(body, ks))
    if pt[:2] == b"\x1f\x8b":
        try:
            pt = gzip.decompress(pt)
        except Exception:
            pass
    return pt


def decrypt_tree():
    n = 0
    for root, _dirs, files in os.walk(RAW):
        for fn in files:
            src = os.path.join(root, fn)
            rel = os.path.relpath(src, RAW)
            dst = os.path.join(DEC, rel)
            if os.path.exists(dst) and os.path.getsize(dst) > 0:
                n += 1
                continue
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            open(dst, "wb").write(decrypt(open(src, "rb").read()))
            n += 1
    return n


def load_config(bundle):
    cfg_path = os.path.join(DEC, bundle, "config." + ver_for(bundle) + ".json")
    return json.load(open(cfg_path, encoding="utf-8"))


def ver_for(bundle):
    # find config file in dec/<bundle>
    d = os.path.join(DEC, bundle)
    if not os.path.isdir(d):
        return None
    for fn in os.listdir(d):
        if fn.startswith("config.") and fn.endswith(".json"):
            return fn[len("config."):-len(".json")]
    return None


def build_bundle_index(bundle):
    """Return {uuid: {import_file, native_file}} plus path list for a bundle."""
    ver = ver_for(bundle)
    if not ver:
        return None
    cfg = load_config(bundle)
    uuids = cfg["uuids"]
    types = cfg.get("types") or []
    paths = cfg.get("paths") or {}
    versions = cfg.get("versions") or {}

    uuid_import = {}
    imp = versions.get("import") or []
    for i in range(0, len(imp), 2):
        uuid_import[uuids[imp[i]]] = imp[i + 1]
    uuid_native = {}
    nat = versions.get("native") or []
    for i in range(0, len(nat), 2):
        uuid_native[uuids[nat[i]]] = nat[i + 1]

    entries = {}
    for idx, info in paths.items():
        pname = info[0]
        uuid = uuids[int(idx)]
        typ = types[info[1]] if len(info) > 1 and info[1] < len(types) else "cc.Asset"
        e = entries.setdefault(uuid, {
            "path": pname, "type": typ, "import": None, "native": None})
        if uuid in uuid_import:
            h = uuid_import[uuid]
            rel = "import/%s/%s.%s.json" % (
                decode_uuid(uuid)[:2], decode_uuid(uuid), h)
            e["import"] = rel
        if uuid in uuid_native:
            h = uuid_native[uuid]
            base = "native/%s/%s.%s" % (decode_uuid(uuid)[:2],
                                        decode_uuid(uuid), h)
            d = os.path.join(DEC, bundle, "native",
                             decode_uuid(uuid)[:2])
            found = None
            if os.path.isdir(d):
                for fn in os.listdir(d):
                    if fn.startswith(decode_uuid(uuid) + "." + h + "."):
                        found = fn
                        break
            if found:
                e["native"] = base + "." + found.rsplit(".", 1)[1]
    return {"cfg": cfg, "entries": entries, "ver": ver,
            "uuids": uuids, "types": types}


def material_from_bundle(idx):
    entries = idx["entries"]
    sounds = [e["path"] for e in entries.values()
              if e["path"].startswith("sound/")]
    mat = None
    for s in sounds:
        m = re.match(r"sound/(\w+)_streak", s)
        if m:
            mat = m.group(1)
            break
    return mat, sounds


def organize():
    decrypt_tree()
    bundles = sorted(d for d in os.listdir(DEC)
                     if os.path.isdir(os.path.join(DEC, d)))
    report = {}
    orphan_map = {}   # bundle -> {uuid: [native files]}
    md = ["# Block Blast 材质皮肤远程资源（Remote_Skin_Material_*）\n"]
    md.append("> 来源：游戏 CDN `bband1.afafb.com/update/block_android_online/remoteRes/0/remote/`\n")
    md.append("| 皮肤ID | 材质 | bundle版本 | 方块贴图 | 背景 | 消除特效 | 预消除特效 | 其他特效 | 字体 | 声音 |")
    md.append("|---|---|---|---|---|---|---|---|---|---|")

    for bundle in bundles:
        if not bundle.startswith("Remote_Skin_Material_"):
            continue
        idx = build_bundle_index(bundle)
        if not idx:
            continue
        mat, sounds = material_from_bundle(idx)
        skin_id = bundle.replace("Remote_Skin_Material_", "")
        entry = {
            "bundle": bundle,
            "version": idx["ver"],
            "material": mat,
            "sounds": sounds,
            "assets": [],
        }
        for uuid, e in idx["entries"].items():
            rel = e["native"] or e["import"]
            if not rel:
                continue
            src = os.path.join(DEC, bundle, rel)
            if not os.path.exists(src):
                continue
            dst = os.path.join(NAMED, bundle, e["path"])
            ext = rel.rsplit(".", 1)[1] if "." in rel else ""
            base, n = os.path.splitext(dst)
            final = dst + "." + ext if ext else dst
            os.makedirs(os.path.dirname(final), exist_ok=True)
            if not os.path.exists(final):
                shutil.copy2(src, final)
            entry["assets"].append({
                "path": e["path"], "type": e["type"],
                "file": os.path.relpath(final, NAMED).replace("\\", "/"),
            })

        def has(pred):
            return [a["file"] for a in entry["assets"] if pred(a)]

        cubes = has(lambda a: "game_cube_" in a["path"] and a["path"].startswith("res/"))
        bg = has(lambda a: "background" in a["path"] or "backgroundkuai" in a["path"])
        elim = has(lambda a: "eliminate" in a["path"] and a["path"].startswith("effect/"))
        pre = has(lambda a: "ready_eliminate" in a["path"] or "pre" in a["path"])
        combo = has(lambda a: "combo" in a["path"] or "pointadd" in a["path"]
                    or "combotips" in a["path"])
        fonts = has(lambda a: a["path"].startswith("font/"))
        snd = has(lambda a: a["path"].startswith("sound/"))
        md.append("| %s | %s | %s | %d | %d | %d | %d | %d | %d | %d |" % (
            skin_id, mat or "-", idx["ver"],
            len(cubes), len(bg), len(elim), len(pre), len(combo),
            len(fonts), len(snd)))
        report[bundle] = entry
        # natives not referenced by any path entry (e.g. AutoAtlas texture)
        known = set()
        for uuid in idx["entries"]:
            known.add(uuid)
        orphans = []
        nd = os.path.join(DEC, bundle, "native")
        if os.path.isdir(nd):
            for dp, _dn, files in os.walk(nd):
                for fn in files:
                    if fn.split(".")[0] not in known:
                        src = os.path.join(dp, fn)
                        dst = os.path.join(NAMED, bundle, "misc", fn)
                        os.makedirs(os.path.dirname(dst), exist_ok=True)
                        if not os.path.exists(dst):
                            shutil.copy2(src, dst)
                        orphans.append(os.path.relpath(dst, NAMED).replace("\\", "/"))
        orphan_map[bundle] = orphans

    with open(os.path.join(ROOT, "skins_report.json"), "w",
              encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=1)
    with open(os.path.join(ROOT, "orphan_natives.json"), "w",
              encoding="utf-8") as f:
        json.dump(orphan_map, f, ensure_ascii=False, indent=1)
    with open(os.path.join(ROOT, "skins清单.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(md) + "\n")
    print("organized", len(report), "bundles")


if __name__ == "__main__":
    organize()
