﻿'use strict';
const fs = require('fs');
const vm = require('vm');

const HTML = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810/spine-preview/preview.html';
const SPINE_LIB = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/blast-block-spine/lib/spine-player.js';
const html = fs.readFileSync(HTML, 'utf8');
const m = html.match(/const DATA = (\[[\s\S]*?\]);\r?\nlet cur = -1;/);
const DATA = JSON.parse(m[1]);

const spineSrc = fs.readFileSync(SPINE_LIB, 'utf8');
const sandbox = {
  console, setTimeout, clearTimeout, setInterval, clearInterval,
  window: {}, document: {}, navigator: { userAgent: 'node' },
  atob: (b64) => Buffer.from(b64, 'base64').toString('latin1'),
  btoa: (s) => Buffer.from(s, 'latin1').toString('base64'),
  ArrayBuffer, DataView, Uint8Array, Uint16Array, Uint32Array,
  Int8Array, Int16Array, Int32Array, Float32Array, Float64Array,
  Math, JSON, Object, Array, Date, String, Number, Boolean,
  Error, TypeError, RangeError, Map, Set, parseFloat, parseInt, isNaN, isFinite,
};
vm.createContext(sandbox);
vm.runInContext(spineSrc, sandbox, { filename: 'spine-player.js' });
sandbox.DATA = DATA;

const sim = `
(function(){
  function b64ToU8(b64){ var bin=atob(b64); var u=new Uint8Array(bin.length);
    for(var i=0;i<bin.length;i++) u[i]=bin.charCodeAt(i); return u; }
  function decodeText(b64){ try { return decodeURIComponent(b64ToU8(b64).reduce(function(s,b){ return s+String.fromCharCode(b); }, '')); } catch(e){ return ''; } }
  function revMap(s){
    var bytes = [];
    for (var i=0;i<s.length;i++){
      var c = s.charCodeAt(i);
      if (c >= 0xFF00 && c < 0x10000) { bytes.push(c - 0xFF00); }
      else if (c < 0x80) { bytes.push(c); }
      else return null;
    }
    try { return new TextDecoder('utf-8').decode(new Uint8Array(bytes)); } catch(e){ return null; }
  }
  function fakeTexture(){ return { setFilters:function(){}, setWraps:function(){}, getImage:function(){ return {width:2048,height:2048}; }, dispose:function(){} }; }
  var fails = [];
  for (var i=0;i<DATA.length;i++){
    var it = DATA[i];
    var atlasText = decodeText(it.atlasUrl.split(',')[1]);
    var atlas = new spine.TextureAtlas(atlasText, function(p){ return fakeTexture(); });
    var regionNames = atlas.regions.map(function(r){ return r.name; });
    var origLoader = new spine.AtlasAttachmentLoader(atlas);
    var loader = {
      newRegionAttachment: function(skin,name,p){
        try { return origLoader.newRegionAttachment(skin,name,p); }
        catch(e){
          var alt = revMap(p);
          if (alt && regionNames.indexOf(alt) >= 0) {
            var a = new spine.RegionAttachment(p);
            var r = atlas.findRegion(alt);
            a.region = r; a.path = p;
            a.x=0;a.y=0;a.scaleX=1;a.scaleY=1;a.rotation=0;a.width=r.width;a.height=r.height;
            a.color=new spine.Color(1,1,1,1); a.updateOffset(); a.uvs=new Float32Array(8); a.setRegion(r);
            return a;
          }
          throw e;
        }
      },
      newMeshAttachment: function(skin,name,p){
        try { return origLoader.newMeshAttachment(skin,name,p); }
        catch(e){
          var alt = revMap(p);
          if (alt && regionNames.indexOf(alt) >= 0) {
            var a = new spine.MeshAttachment(p);
            var r = atlas.findRegion(alt);
            a.region = r; a.path = p;
            a.width = r.originalWidth; a.height = r.originalHeight;
            a.color=new spine.Color(1,1,1,1);
            return a;
          }
          throw e;
        }
      },
      newBoundingBoxAttachment: function(skin,name){ return origLoader.newBoundingBoxAttachment(skin,name); },
      newClippingAttachment: function(skin,name){ return origLoader.newClippingAttachment(skin,name); },
      newPathAttachment: function(skin,name){ return origLoader.newPathAttachment(skin,name); },
      newPointAttachment: function(skin,name){ return origLoader.newPointAttachment(skin,name); }
    };
    try {
      if (it.fmt === 'json') {
        var jsonText = decodeText(it.skelUrl.split(',')[1]);
        new spine.SkeletonJson(loader).readSkeletonData(JSON.parse(jsonText));
      } else {
        new spine.SkeletonBinary(loader).readSkeletonData(b64ToU8(it.skelUrl.split(',')[1]));
      }
    } catch(e) {
      fails.push({ name: it.name, bundle: it.bundle, err: (e && e.message) || String(e) });
    }
  }
  return fails;
})();
`;
const fails = vm.runInContext(sim, sandbox);
console.log('remaining failures:', fails.length);
for (const f of fails) console.log(' ', f.bundle + '/' + f.name, '->', f.err);
