﻿# -*- coding: utf-8 -*-
import json, sys
sys.stdout.reconfigure(encoding="utf-8")
p = r"E:\参考图\block录屏\解包素材\BlastBlock-美术资源全量-20260810\材质皮肤-远程bundle-20260810\spine-preview\spine_index.json"
data = json.load(open(p, encoding="utf-8"))
zero = [d for d in data if not (d["bounds"] and d["bounds"][2] > 0 and d["bounds"][3] > 0)]
print("entries:", len(data), "zero bounds:", len(zero))
print("anims total:", sum(len(d["anims"] or []) for d in data))
print("parseErr:", sum(1 for d in data if d.get("parseErr")))
