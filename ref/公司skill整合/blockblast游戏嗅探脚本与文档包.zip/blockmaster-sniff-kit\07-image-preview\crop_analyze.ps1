param(
  [Parameter(Mandatory=$true)][string]$Path,
  [int]$Left = 0,
  [int]$Top = 0,
  [int]$Width = -1,
  [int]$Height = -1
)
Add-Type -AssemblyName System.Drawing
$src = New-Object System.Drawing.Bitmap($Path)
if ($Width -le 0) { $Width = $src.Width }
if ($Height -le 0) { $Height = $src.Height }
$rect = New-Object System.Drawing.Rectangle($Left, $Top, $Width, $Height)
$bmp = $src.Clone($rect, $src.PixelFormat)
$src.Dispose()
$total = $bmp.Width * $bmp.Height
$dark = 0; $black = 0; $colored = 0; $bright = 0
$rSum = [long]0; $gSum = [long]0; $bSum = [long]0
$step = [Math]::Max(1, [int]($total / 200000))
for ($y = 0; $y -lt $bmp.Height; $y += $step) {
  for ($x = 0; $x -lt $bmp.Width; $x += $step) {
    $c = $bmp.GetPixel($x, $y)
    $lum = (0.299 * $c.R + 0.587 * $c.G + 0.114 * $c.B)
    $rSum += $c.R; $gSum += $c.G; $bSum += $c.B
    if ($lum -lt 30) { $dark++ }
    if ($lum -lt 12) { $black++ }
    $maxc = [Math]::Max($c.R, [Math]::Max($c.G, $c.B))
    $minc = [Math]::Min($c.R, [Math]::Min($c.G, $c.B))
    if (($maxc - $minc) -gt 40 -and $maxc -gt 60) { $colored++ }
    if ($lum -gt 160) { $bright++ }
  }
}
$n = [Math]::Ceiling($total / $step / $step)
$bmp.Dispose()
"crop=${Left},${Top} ${Width}x${Height} sampled=$n"
"darkPct=$([Math]::Round(100.0*$dark/$n,1)) blackPct=$([Math]::Round(100.0*$black/$n,1)) coloredPct=$([Math]::Round(100.0*$colored/$n,1)) brightPct=$([Math]::Round(100.0*$bright/$n,1))"
"avgRGB=$([Math]::Round($rSum/$n)) $([Math]::Round($gSum/$n)) $([Math]::Round($bSum/$n))"
