# -*- coding: utf-8 -*-
"""Build/sign the V39 arm64 Firebase format-compatibility fix from V38."""
from __future__ import annotations

import os
import sys
import zipfile

import build_v38_palm as v38


base = v38.base
W = base.W
STAGE = base.STAGE
OUT = os.path.abspath(os.environ.get("BLOCKMASTER_OUTPUT_DIR", W))
os.makedirs(OUT, exist_ok=True)

base.BASELINE = os.path.join(W, "BlockMaster_v38_palm_full_arm64.apk")
base.APKTOOL_ATTEMPT = os.path.join(OUT, "stage2_sdk_unsigned_v39_arm64.apk")
base.MERGED = os.path.join(OUT, "stage2_v39_arm64_merged.apk")
base.ALIGNED = os.path.join(OUT, "stage2_v39_arm64_aligned.apk")
base.FINAL = os.path.join(OUT, "BlockMaster_v39_palm_full_arm64.apk")
base.DEX_VERIFY = os.path.join(OUT, "tmp", "v39_verify_classes13")

DEX15 = os.path.join(STAGE, "build", "apk", "classes15.dex")
FORMAT_MARKERS = (b"sanitizeEventName", b"sanitizeParamString")

# V38 already contains the classes13/classes14 adapter and dual-report fixes.
# V39 changes only FirebaseBridge in classes15.
base.REPLACEMENTS = {"classes15.dex": DEX15}


def verify_final() -> None:
    base.verify_final_entries()
    with zipfile.ZipFile(base.FINAL, "r") as archive:
        names = archive.namelist()
        abis = sorted({name.split("/")[1] for name in names if name.startswith("lib/")})
        if abis != ["arm64-v8a"]:
            raise RuntimeError(f"unexpected ABI set: {abis}")
        dex15 = archive.read("classes15.dex")
        for marker in FORMAT_MARKERS:
            if marker not in dex15:
                raise RuntimeError(f"Firebase format marker missing: {marker!r}")
        if v38.ADAPTER_DESCRIPTOR not in archive.read("classes13.dex"):
            raise RuntimeError("V38 Firebase adapter was not preserved")
        if b"logEventWithParams" not in archive.read("classes14.dex"):
            raise RuntimeError("V38 Firebase dual-report bridge was not preserved")

    dump = base.run(f'"{base.BT}\\aapt2.exe" dump badging "{base.FINAL}"', 120)
    badging = (dump.stdout or "") + (dump.stderr or "")
    if "versionCode='1019'" not in badging or "versionName='1.0.1.9'" not in badging:
        raise RuntimeError("final version mismatch")
    if "native-code: 'arm64-v8a'" not in badging:
        raise RuntimeError("final APK is not arm64-only")


def main() -> None:
    base.run(
        f'"{sys.executable}" "{os.path.join(W, "verify_v37_transsion_only.py")}"',
        120,
    )
    base.run(
        f'"{sys.executable}" "{os.path.join(W, "verify_v38_firebase_adapter.py")}"',
        120,
    )
    v38.compile_and_verify_classes13()
    dex15 = open(DEX15, "rb").read()
    for marker in FORMAT_MARKERS:
        if marker not in dex15:
            raise RuntimeError(f"rebuilt classes15 marker missing: {marker!r}")
    base.overlay_baseline()
    verify_final()


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("BUILD FAILED:", error, file=sys.stderr)
        sys.exit(1)
