﻿# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding="utf-8")
s = "椭圆 2"
b = s.encode("utf-8")
print("utf8 bytes:", b.hex())
for codec in ("cp949", "euc-kr", "gbk", "cp936"):
    try:
        print(codec, "->", b.decode(codec, errors="replace"), [hex(ord(c)) for c in b.decode(codec, errors="replace")])
    except Exception as e:
        print(codec, "ERR", e)
# reverse direction test
mojibake = "￦ﾤﾭ￥ﾜﾆ 2"
mb = mojibake.encode("cp949", errors="replace")
print("mojibake cp949 bytes:", mb.hex())
try:
    print("decoded as utf8:", mb.decode("utf-8"))
except Exception as e:
    print("utf8 decode err:", e)
