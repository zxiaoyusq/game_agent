# -*- coding: utf-8 -*-
"""Merge missing Hisavana SDK resources from blockmaster_apktool into stage2_sdk.

Only touches stage2_sdk. Adds resources and public.xml entries with new IDs.
Also generates a JSON mapping old_id -> (type, name, new_id) for DEX patching.
"""
import io
import json
import os
import re
import shutil
import sys

WORK = r'E:\codex_apk_work\blockmaster_pro_swap\work'
REF = os.path.join(WORK, 'blockmaster_apktool')
DST = os.path.join(WORK, 'stage2_sdk')
MISSING_JSON = os.path.join(WORK, 'hisavana_missing.json')
OUT_JSON = os.path.join(WORK, 'hisavana_id_map.json')

# New IDs allocation start per stage2_sdk type (from public.xml max+1)
NEW_ID_START = {
    'color': 0x7f060402,
    'dimen': 0x7f070514,
    'drawable': 0x7f0803c0,
    'mipmap': 0x7f100030,
    'id': 0x7f0a05f2,
    'layout': 0x7f0d01f9,
    'string': 0x7f14037d,
    'style': 0x7f15053a,
    'attr': 0x7f04061c,
    'array': 0x7f030008,
}

# Types that live in values XML rather than files
VALUE_TYPES = {'color', 'dimen', 'string', 'style', 'id', 'attr', 'integer', 'bool'}

# Map class -> actual resource type for file/resource lookup (correcting o0)
CLASS_TYPE_OVERRIDE = {
    'Lcom/cloud/hisavana/sdk/o0;': 'mipmap',
}

# Styleable class s0: old attr ids used in <clinit> arrays need remap.
# We'll collect them from the smali file separately.


def parse_public(path):
    """Return dict (type,name)->id and id->(type,name)."""
    by_name = {}
    by_id = {}
    with io.open(path, encoding='utf-8') as f:
        txt = f.read()
    for m in re.finditer(r'<public type="([^"]+)" name="([^"]+)" id="(0x[0-9a-fA-F]+)"', txt):
        typ, name, rid = m.group(1), m.group(2), int(m.group(3), 16)
        by_name[(typ, name)] = rid
        by_id[rid] = (typ, name)
    return by_name, by_id


def read_xml_entries(path):
    """Read a values XML file and return list of (name, full_element_xml)."""
    if not os.path.exists(path):
        return []
    with io.open(path, encoding='utf-8') as f:
        txt = f.read()
    entries = []
    tags = ('color', 'dimen', 'string', 'item', 'style', 'attr')
    # Find every start tag for these tags; skip matches inside comments.
    for m in re.finditer(r'<(color|dimen|string|item|style|attr)\b', txt):
        start = m.start()
        tag = m.group(1)
        # skip if inside XML comment
        prefix = txt[max(0, start-10):start]
        # Find end of opening tag (respect quotes)
        i = m.end()
        in_quote = False
        while i < len(txt):
            ch = txt[i]
            if ch == '"':
                in_quote = not in_quote
            elif ch == '>' and not in_quote:
                break
            i += 1
        if i >= len(txt):
            continue
        open_tag_end = i + 1
        open_tag = txt[start:open_tag_end]
        # If self-closing
        if open_tag.rstrip().endswith('/>'):
            element = open_tag
        else:
            close_tag = '</' + tag + '>'
            close_idx = txt.find(close_tag, open_tag_end)
            if close_idx == -1:
                continue
            element = txt[start:close_idx + len(close_tag)]
        nm = re.search(r'name="([^"]+)"', open_tag)
        if not nm:
            continue
        name = nm.group(1)
        entries.append((name, element))
    return entries


def value_entry_matches(typ, name, xml):
    if typ == 'string' and '<string' in xml:
        return True
    if typ == 'color' and '<color' in xml:
        return True
    if typ == 'dimen' and '<dimen' in xml:
        return True
    if typ == 'style' and '<style' in xml:
        return True
    if typ == 'attr' and '<attr' in xml:
        return True
    if typ == 'integer' and '<integer' in xml:
        return True
    if typ == 'bool' and '<bool' in xml:
        return True
    if '<item' in xml and ('type="%s"' % typ) in xml:
        return True
    return False


def find_value_entry(ref, typ, name):
    """Find default value entry in REF res/values for resource type/name."""
    files = [os.path.join(ref, 'res', 'values', f) for f in os.listdir(os.path.join(ref, 'res', 'values')) if f.endswith('.xml')]
    for fp in files:
        for nm, xml in read_xml_entries(fp):
            if nm == name and value_entry_matches(typ, name, xml):
                return xml
    return None


def find_value_entries_all(ref, typ, name):
    """Return list of (rel_values_dir, file_name, xml_entry) for all res/values* dirs."""
    results = []
    ref_res = os.path.join(ref, 'res')
    if not os.path.isdir(ref_res):
        return results
    for dirpath, dirnames, filenames in os.walk(ref_res):
        rel = os.path.relpath(dirpath, ref_res)
        base = os.path.basename(rel)
        if not base.startswith('values'):
            continue
        for fn in filenames:
            if not fn.endswith('.xml'):
                continue
            fp = os.path.join(dirpath, fn)
            for nm, xml in read_xml_entries(fp):
                if nm == name and value_entry_matches(typ, name, xml):
                    results.append((rel, fn, xml))
    return results


def value_file_for_type(typ):
    if typ == 'color':
        return 'colors.xml'
    elif typ == 'dimen':
        return 'dimens.xml'
    elif typ == 'string':
        return 'strings.xml'
    elif typ == 'style':
        return 'styles.xml'
    elif typ == 'attr':
        return 'attrs.xml'
    elif typ == 'id':
        return 'ids.xml'
    elif typ == 'integer':
        return 'integers.xml'
    elif typ == 'bool':
        return 'bools.xml'
    else:
        return 'values.xml'


def append_to_values(dst_values_dir, typ, name, xml_entry):
    """Append xml_entry to appropriate values file in stage2_sdk."""
    fn = value_file_for_type(typ)
    os.makedirs(dst_values_dir, exist_ok=True)
    path = os.path.join(dst_values_dir, fn)
    if not os.path.exists(path):
        # create with basic resources tag
        with io.open(path, 'w', encoding='utf-8') as f:
            f.write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n</resources>\n')
    with io.open(path, encoding='utf-8') as f:
        txt = f.read()
    # avoid duplicate by name
    if ('name="%s"' % name) in txt:
        return False
    idx = txt.rfind('</resources>')
    if idx == -1:
        raise RuntimeError('No </resources> in ' + path)
    indent = '    '
    new = txt[:idx].rstrip() + '\n' + indent + xml_entry + '\n' + txt[idx:]
    with io.open(path, 'w', encoding='utf-8') as f:
        f.write(new)
    return True


def copy_file_resources(ref, dst, typ, name):
    """Copy all files res/<type...>/<name>.* from ref to dst."""
    copied = []
    ref_res = os.path.join(ref, 'res')
    dst_res = os.path.join(dst, 'res')
    for dirpath, dirnames, filenames in os.walk(ref_res):
        # only directories that match typ or typ-qualifier
        rel = os.path.relpath(dirpath, ref_res)
        # rel is like 'layout', 'layout-land', 'drawable-hdpi'
        base = rel.split('-')[0] if rel != '.' else ''
        if base != typ:
            continue
        for fn in filenames:
            if fn == name or fn.startswith(name + '.'):
                src = os.path.join(dirpath, fn)
                dst_dir = os.path.join(dst_res, rel)
                os.makedirs(dst_dir, exist_ok=True)
                dst_file = os.path.join(dst_dir, fn)
                if not os.path.exists(dst_file):
                    shutil.copy2(src, dst_file)
                    copied.append(os.path.join(rel, fn))
    return copied


def main():
    with io.open(MISSING_JSON, encoding='utf-8') as f:
        missing = json.load(f)
    ref_public, ref_by_id = parse_public(os.path.join(REF, 'res', 'values', 'public.xml'))
    dst_public, _ = parse_public(os.path.join(DST, 'res', 'values', 'public.xml'))

    # Normalize missing list: class override type, skip nonexistent? We'll still add if possible.
    normalized = []
    for r in missing:
        typ = CLASS_TYPE_OVERRIDE.get(r['class'], r['type'])
        r['type'] = typ
        normalized.append(r)

    # For styleable attrs from s0, add actual attr resources referenced by old IDs.
    # We'll gather from s0.smali (already disassembled in _bm_sel_test).
    s0_path = os.path.join(WORK, '_bm_sel_test', 'com', 'cloud', 'hisavana', 'sdk', 's0.smali')
    styleable_old_ids = set()
    if os.path.exists(s0_path):
        with io.open(s0_path, encoding='utf-8') as f:
            txt = f.read()
        for m in re.finditer(r'0x[0-9a-fA-F]{8}', txt):
            styleable_old_ids.add(int(m.group(0), 16))
    for old_id in styleable_old_ids:
        if old_id in ref_by_id:
            typ, name = ref_by_id[old_id]
            if typ == 'attr':
                normalized.append({'type': 'attr', 'name': name, 'class': 'Lcom/cloud/hisavana/sdk/s0;', 'old_id': old_id})

    # Deduplicate by (type,name)
    seen = set()
    uniq = []
    for r in normalized:
        key = (r['type'], r['name'])
        if key not in seen:
            seen.add(key)
            uniq.append(r)
    normalized = uniq

    # Allocate new IDs
    counters = {typ: start for typ, start in NEW_ID_START.items()}
    id_map = []  # old_id, type, name, new_id
    public_entries = []
    value_added = 0
    file_added = 0
    missing_src = []

    for r in normalized:
        typ = r['type']
        name = r['name']
        old_id = r['old_id']
        if (typ, name) in dst_public:
            # already exists (maybe added earlier)
            new_id = dst_public[(typ, name)]
            id_map.append({'old_id': old_id, 'type': typ, 'name': name, 'new_id': new_id})
            continue
        # allocate next id
        new_id = counters[typ]
        counters[typ] += 1
        # add resource source
        if typ in VALUE_TYPES:
            entry = find_value_entry(REF, typ, name)
            if entry is None and typ == 'id':
                # ids can be declared as <item type="id" name="..."/>
                entry = '<item type="id" name="%s"/>' % name
            if entry is None:
                # search all values qualifiers
                all_entries = find_value_entries_all(REF, typ, name)
                if all_entries:
                    added_any = False
                    for rel_dir, fn, xml_entry in all_entries:
                        dst_dir = os.path.join(DST, 'res', rel_dir)
                        ok = append_to_values(dst_dir, typ, name, xml_entry)
                        if ok:
                            added_any = True
                            value_added += 1
                    if added_any:
                        # proceed to public entry
                        pass
                    else:
                        missing_src.append((typ, name))
                        continue
                else:
                    missing_src.append((typ, name))
                    # do not add public entry if no source
                    continue
            else:
                ok = append_to_values(os.path.join(DST, 'res', 'values'), typ, name, entry)
                if ok:
                    value_added += 1
        else:
            copied = copy_file_resources(REF, DST, typ, name)
            if not copied:
                # for mipmap maybe in drawable? try drawable as fallback
                if typ == 'mipmap':
                    copied = copy_file_resources(REF, DST, 'drawable', name)
                if not copied:
                    missing_src.append((typ, name))
                    continue
            file_added += len(copied)
        public_entries.append((typ, name, new_id))
        id_map.append({'old_id': old_id, 'type': typ, 'name': name, 'new_id': new_id})

    # Append public entries
    if public_entries:
        pub_path = os.path.join(DST, 'res', 'values', 'public.xml')
        with io.open(pub_path, encoding='utf-8') as f:
            txt = f.read()
        block = []
        for typ, name, new_id in sorted(public_entries, key=lambda x: (x[0], x[2])):
            block.append('    <public type="%s" name="%s" id="0x%08x" />' % (typ, name, new_id))
        idx = txt.rfind('</resources>')
        if idx == -1:
            raise RuntimeError('No </resources> in public.xml')
        txt = txt[:idx].rstrip() + '\n' + '\n'.join(block) + '\n' + txt[idx:]
        with io.open(pub_path, 'w', encoding='utf-8') as f:
            f.write(txt)

    with io.open(OUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(id_map, f, ensure_ascii=False, indent=2)

    print('value_added', value_added)
    print('file_added', file_added)
    print('public_entries', len(public_entries))
    print('id_map', len(id_map))
    print('missing_src', len(missing_src))
    for x in missing_src[:100]:
        print('MISSING_SRC', x)


if __name__ == '__main__':
    main()
