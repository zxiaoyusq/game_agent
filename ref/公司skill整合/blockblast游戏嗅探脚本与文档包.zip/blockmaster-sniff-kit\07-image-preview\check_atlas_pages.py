﻿# -*- coding: utf-8 -*-
import os, re, sys
sys.stdout.reconfigure(encoding="utf-8")
root = r"E:\参考图\block录屏\解包素材\BlastBlock-美术资源全量-20260810\材质皮肤-远程bundle-20260810"
multi = []
total = 0
for bundle in sorted(os.listdir(os.path.join(root, "named"))):
    bp = os.path.join(root, "named", bundle)
    if not os.path.isdir(bp):
        continue
    for d, _, files in os.walk(bp):
        rel = os.path.relpath(d, bp).replace("\\", "/")
        if rel.split("/")[0] == "misc":
            continue
        for f in files:
            if not f.endswith(".atlas"):
                continue
            total += 1
            text = open(os.path.join(d, f), encoding="utf-8").read()
            # count pages: non-empty segments where 2nd non-empty line starts with 'size:'
            segs = re.split(r"\n\s*\n", text)
            pages = 0
            for seg in segs:
                lines = [l.strip() for l in seg.splitlines() if l.strip()]
                if len(lines) >= 2 and lines[1].startswith("size:"):
                    pages += 1
            if pages > 1:
                multi.append((bundle, f, pages))
print("atlas files:", total, "multi-page:", len(multi))
for b, f, p in multi[:30]:
    print(" ", b, f, p)
