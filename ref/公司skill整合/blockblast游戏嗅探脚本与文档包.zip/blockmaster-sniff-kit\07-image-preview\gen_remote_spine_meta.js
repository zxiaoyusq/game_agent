'use strict';
/*
 * gen_remote_spine_meta.js
 *
 * Parse every Spine 3.8 binary skeleton (*.bin) under
 *   <全量>/材质皮肤-远程bundle-20260810/named
 * with the real bundled spine-player.js runtime (inside a vm sandbox),
 * then write spine_meta.json:
 *   { "<bundle>/<stem>": { anims:[...], skins:[...], bounds:[x,y,w,h] } | { err:"..." } }
 *
 * Usage: node gen_remote_spine_meta.js [--root <素材根>] [--out <meta.json>]
 *                                      [--spine-lib <spine-player.js 路径>]
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

function arg(name, def) {
  const i = process.argv.indexOf('--' + name);
  return i >= 0 && i + 1 < process.argv.length ? process.argv[i + 1] : def;
}

const ROOT = arg('root', 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810');
const NAMED = path.join(ROOT, 'named');
const SPINE_LIB = arg('spine-lib', 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/blast-block-spine/lib/spine-player.js');
const OUT = arg('out', path.join(ROOT, 'spine-preview', 'spine_meta.json'));

function readVarint(data, pos) {
  let b = data[pos++];
  let result = b & 0x7f;
  if (b & 0x80) {
    b = data[pos++];
    result |= (b & 0x7f) << 7;
    if (b & 0x80) {
      b = data[pos++];
      result |= (b & 0x7f) << 14;
      if (b & 0x80) {
        b = data[pos++];
        result |= (b & 0x7f) << 21;
        if (b & 0x80) {
          b = data[pos++];
          result |= (b & 0x7f) << 28;
        }
      }
    }
  }
  return result;
}

function readSpineString(data, pos) {
  const byteCount = readVarint(data, pos);
  let p = pos;
  // find how many bytes the varint occupied
  let b = data[p++];
  while (b & 0x80) b = data[p++];
  if (byteCount === 0) return { value: null, pos: p };
  if (byteCount === 1) return { value: '', pos: p };
  const n = byteCount - 1;
  return { value: data.toString('latin1', p, p + n), pos: p + n };
}

function isSpineBinary(data) {
  try {
    const hash = readSpineString(data, 0);
    if (hash.value === null) return false;
    const ver = readSpineString(data, hash.pos);
    return !!ver.value && ver.value.startsWith('3.');
  } catch (e) {
    return false;
  }
}

function collectBins() {
  const bins = [];
  for (const bundle of fs.readdirSync(NAMED).sort()) {
    const bpath = path.join(NAMED, bundle);
    if (!fs.statSync(bpath).isDirectory()) continue;
    const seen = new Set();
    (function walk(dir, rel) {
      for (const d of fs.readdirSync(dir, { withFileTypes: true })) {
        const p = path.join(dir, d.name);
        const rel2 = rel ? rel + '/' + d.name : d.name;
        if (d.isDirectory()) {
          if (rel2.split('/')[0] === 'misc') continue;
          walk(p, rel2);
        } else if (d.name.endsWith('.bin')) {
          const stem = d.name.slice(0, -4);
          if (seen.has(stem)) continue;
          seen.add(stem);
          const atlas = path.join(dir, stem + '.atlas');
          const png = path.join(dir, stem + '.png');
          if (!fs.existsSync(atlas) || !fs.existsSync(png)) continue;
          const data = fs.readFileSync(p);
          if (!isSpineBinary(data)) continue;
          bins.push({ key: bundle + '/' + stem, b64: data.toString('base64') });
        }
      }
    })(bpath, '');
  }
  return bins;
}

function main() {
  const bins = collectBins();
  console.log('bins found:', bins.length);
  if (!bins.length) {
    console.error('no .bin skeletons found, abort');
    process.exit(1);
  }

  const spineSrc = fs.readFileSync(SPINE_LIB, 'utf8');
  const sandbox = {
    console: console,
    setTimeout: setTimeout,
    clearTimeout: clearTimeout,
    setInterval: setInterval,
    clearInterval: clearInterval,
    window: {},
    document: {},
    navigator: { userAgent: 'node' },
    atob: (b64) => Buffer.from(b64, 'base64').toString('latin1'),
    btoa: (s) => Buffer.from(s, 'latin1').toString('base64'),
    ArrayBuffer: ArrayBuffer,
    DataView: DataView,
    Uint8Array: Uint8Array,
    Uint16Array: Uint16Array,
    Uint32Array: Uint32Array,
    Int8Array: Int8Array,
    Int16Array: Int16Array,
    Int32Array: Int32Array,
    Float32Array: Float32Array,
    Float64Array: Float64Array,
    Math: Math,
    JSON: JSON,
    Object: Object,
    Array: Array,
    Date: Date,
    String: String,
    Number: Number,
    Boolean: Boolean,
    Error: Error,
    TypeError: TypeError,
    RangeError: RangeError,
    Map: Map,
    Set: Set,
    parseFloat: parseFloat,
    parseInt: parseInt,
    isNaN: isNaN,
    isFinite: isFinite,
  };
  vm.createContext(sandbox);
  vm.runInContext(spineSrc, sandbox, { filename: 'spine-player.js' });
  if (!sandbox.spine || !sandbox.spine.SkeletonBinary) {
    console.error('spine runtime failed to load in sandbox');
    process.exit(1);
  }

  sandbox.ENTRIES = bins;
  const parseSrc = `
    (function () {
      function b64ToU8(b64) {
        var bin = atob(b64);
        var u = new Uint8Array(bin.length);
        for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
        return u;
      }
      function dummyRegion() {
        return { u: 0, v: 0, u2: 1, v2: 1,
                 originalWidth: 1, originalHeight: 1,
                 offsetX: 0, offsetY: 0, width: 1, height: 1, rotate: false };
      }
      var loader = {
        newRegionAttachment: function (skin, name, p) {
          var a = new spine.RegionAttachment(p || name);
          a.region = dummyRegion();
          return a;
        },
        newMeshAttachment: function (skin, name, p) {
          var a = new spine.MeshAttachment(p || name);
          a.region = dummyRegion();
          return a;
        },
        newBoundingBoxAttachment: function (skin, name) {
          return new spine.BoundingBoxAttachment(name);
        },
        newClippingAttachment: function (skin, name) {
          return new spine.ClippingAttachment(name);
        },
        newPathAttachment: function (skin, name) {
          return new spine.PathAttachment(name);
        },
        newPointAttachment: function (skin, name) {
          return new spine.PointAttachment(name);
        }
      };
      var out = [];
      for (var i = 0; i < ENTRIES.length; i++) {
        var it = ENTRIES[i];
        try {
          var sd = new spine.SkeletonBinary(loader).readSkeletonData(b64ToU8(it.b64));
          var bounds = [sd.x, sd.y, sd.width, sd.height];
          if (!(bounds[2] > 0 && bounds[3] > 0)) {
            try {
              var sk = new spine.Skeleton(sd);
              var skinNames = sd.skins.map(function (s) { return s.name; });
              if (skinNames.length) sk.setSkinByName(skinNames[0]);
              sk.setToSetupPose();
              sk.updateWorldTransform();
              function manualBounds(skel) {
                var minX = Number.POSITIVE_INFINITY, minY = Number.POSITIVE_INFINITY;
                var maxX = Number.NEGATIVE_INFINITY, maxY = Number.NEGATIVE_INFINITY;
                var temp = new Array(2);
                var draw = skel.drawOrder;
                for (var i = 0; i < draw.length; i++) {
                  var slot = draw[i];
                  if (!slot.bone.active) continue;
                  var att = slot.getAttachment();
                  var vs = null, n = 0;
                  if (att instanceof spine.RegionAttachment) {
                    vs = spine.Utils.setArraySize(temp, 8, 0);
                    n = 8;
                    att.computeWorldVertices(slot.bone, vs, 0, 2);
                  } else if (att instanceof spine.MeshAttachment) {
                    vs = spine.Utils.setArraySize(temp, att.worldVerticesLength, 0);
                    n = att.worldVerticesLength;
                    att.computeWorldVertices(slot, 0, att.worldVerticesLength, vs, 0, 2);
                  }
                  if (!vs) continue;
                  for (var v = 0; v < n; v += 2) {
                    var x = vs[v], y = vs[v + 1];
                    if (!isFinite(x) || !isFinite(y)) return null;
                    if (x < minX) minX = x;
                    if (y < minY) minY = y;
                    if (x > maxX) maxX = x;
                    if (y > maxY) maxY = y;
                  }
                }
                if (minX === Number.POSITIVE_INFINITY) return null;
                if (!(maxX > minX && maxY > minY)) return null;
                return [minX, minY, maxX - minX, maxY - minY];
              }
              bounds = manualBounds(sk) || bounds;
              if (!(bounds[2] > 0 && bounds[3] > 0)) {
                // fallback: union of per-animation sampled bounds
                var union = null;
                function add(b) {
                  if (!b) return;
                  if (!union) {
                    union = b;
                  } else {
                    var x1 = Math.min(union[0], b[0]);
                    var y1 = Math.min(union[1], b[1]);
                    var x2 = Math.max(union[0] + union[2], b[0] + b[2]);
                    var y2 = Math.max(union[1] + union[3], b[1] + b[3]);
                    union = [x1, y1, x2 - x1, y2 - y1];
                  }
                }
                var sd2 = new spine.AnimationStateData(sd);
                for (var a = 0; a < sd.animations.length; a++) {
                  var anim = sd.animations[a];
                  var times = [0, anim.duration / 2, anim.duration];
                  for (var t = 0; t < 3; t++) {
                    var st = new spine.AnimationState(sd2);
                    st.setAnimation(0, anim.name, false);
                    st.update(times[t]);
                    st.apply(sk);
                    sk.updateWorldTransform();
                    add(manualBounds(sk));
                    sk.setToSetupPose();
                  }
                }
                if (union) bounds = union;
              }
            } catch (e2) { /* keep original bounds */ }
          }
          out.push({
            key: it.key,
            anims: sd.animations.map(function (a) { return a.name; }).sort(),
            skins: sd.skins.map(function (s) { return s.name; }).sort(),
            bounds: bounds
          });
        } catch (e) {
          out.push({ key: it.key, err: (e && e.message) || String(e) });
        }
      }
      return out;
    })();
  `;
  const results = vm.runInContext(parseSrc, sandbox);

  const meta = {};
  let ok = 0;
  let err = 0;
  for (const r of results) {
    if (r.err) {
      meta[r.key] = { err: r.err };
      err++;
    } else {
      meta[r.key] = { anims: r.anims, skins: r.skins, bounds: r.bounds };
      ok++;
    }
  }
  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  fs.writeFileSync(OUT, JSON.stringify(meta, null, 1), 'utf8');

  console.log('parsed ok:', ok, 'errors:', err);
  const keys = Object.keys(meta).sort();
  for (const k of keys.slice(0, 8)) {
    const m = meta[k];
    console.log(' ', k, m.err ? ('ERR: ' + m.err) :
      (m.anims.length + ' anims, ' + m.skins.length + ' skins, bounds=' +
       JSON.stringify(m.bounds)));
  }
  if (err) {
    console.log('--- error details ---');
    for (const k of keys) {
      if (meta[k].err) console.log(' ', k, '->', meta[k].err);
    }
  }
  console.log('meta written:', OUT);
}

main();
