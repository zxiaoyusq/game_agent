#!/usr/bin/env python3
"""Try hypotheses for the AFFA inner payload of Block Blast v01 JS."""
import gzip
import struct
import sys

KEY_B = b"65485d8a-8161-4c"
KEY_A = b"93274615-a57e-4d"
DELTA = 0x9E3779B9
MASK = 0xFFFFFFFF


def _mx(y, z, s, p, e, k):
    return (((z >> 5) ^ (y << 2)) + ((y >> 3) ^ (z << 4))) ^ ((s ^ y) + (k[(p & 3) ^ e] ^ z))


def xxtea_decrypt(data: bytes, key: bytes) -> bytes:
    if len(data) < 8:
        return data
    n = len(data) // 4
    v = list(struct.unpack("<%dI" % n, data[: n * 4]))
    k = list(struct.unpack("<4I", key[:16].ljust(16, b"\x00")))
    y = v[0]
    q = 6 + 52 // n
    s = (q * DELTA) & MASK
    while s:
        e = (s >> 2) & 3
        for p in range(n - 1, 0, -1):
            z = v[p - 1]
            v[p] = (v[p] - _mx(y, z, s, p, e, k)) & MASK
            y = v[p]
        z = v[n - 1]
        v[0] = (v[0] - _mx(y, z, s, 0, e, k)) & MASK
        y = v[0]
        s = (s - DELTA) & MASK
    return struct.pack("<%dI" % n, *v)


def look_ok(data: bytes) -> str:
    if data[:2] == b"\x1f\x8b":
        try:
            d = gzip.decompress(data)
            return "gzip-> " + look_ok(d)
        except Exception:
            return "gzip-fail"
    if data[:5] == b"window" or data[:4] == b"(fun" or data[:6] == b"System" or b"require" in data[:128]:
        return "JS! " + repr(data[:80])
    printable = sum(1 for b in data[:256] if 32 <= b < 127)
    return f"other printable_ratio={printable / min(len(data), 256):.2f} head={data[:32].hex(' ')}"


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else r"E:\codex_apk_work\blockblast_extracted\assets\main.js"
    data = open(path, "rb").read()
    body = data[8:]
    pt = xxtea_decrypt(body, KEY_B)
    assert pt[:4] == b"\xaf\xfa\x00\x00", pt[:8].hex()
    meta = pt[4:12]
    payload = pt[12:]
    print("meta8:", meta.hex(" "))
    print("payload len:", len(payload), "payload%8:", len(payload) % 8)

    trials = {
        "XXTEA(meta8)": lambda: xxtea_decrypt(payload, meta),
        "XXTEA(meta8*2)": lambda: xxtea_decrypt(payload, meta * 2),
        "XXTEA(meta8+zeros8)": lambda: xxtea_decrypt(payload, meta + b"\x00" * 8),
        "XXTEA(KEY_B again)": lambda: xxtea_decrypt(payload, KEY_B),
        "XXTEA(KEY_A)": lambda: xxtea_decrypt(payload, KEY_A),
        "XXTEA(meta xor KEY_B)": lambda: xxtea_decrypt(payload, bytes(a ^ b for a, b in zip(meta * 2, KEY_B))),
        "XXTEA(meta + KEY_B[:8])": lambda: xxtea_decrypt(payload, meta + KEY_B[:8]),
        "XXTEA(KEY_B[:8] + meta)": lambda: xxtea_decrypt(payload, KEY_B[:8] + meta),
    }
    for name, fn in trials.items():
        try:
            r = fn()
            print(f"[{name}] -> {look_ok(r)}")
        except Exception as e:
            print(f"[{name}] ERROR {e}")

    # stream-cipher trials: XOR with meta repeated
    ks = (meta * (len(payload) // 8 + 1))[: len(payload)]
    print("[XOR meta8] ->", look_ok(bytes(a ^ b for a, b in zip(payload, ks))))
    ks2 = (KEY_B * (len(payload) // 16 + 1))[: len(payload)]
    print("[XOR KEY_B] ->", look_ok(bytes(a ^ b for a, b in zip(payload, ks2))))

    try:
        from Crypto.Cipher import AES, ARC4, ChaCha20
        from Crypto.Util.Padding import unpad

        def try_aes(name, key, iv, mode_factory):
            try:
                c = mode_factory(key, iv)
                r = c.decrypt(payload[: len(payload) // 16 * 16])
                print(f"[{name}] ->", look_ok(r))
            except Exception as e:
                print(f"[{name}] ERROR {e}")

        try_aes("AES-CBC KEY_B iv=meta8", KEY_B, meta, AES.new)
        try_aes("AES-CBC meta8+0 iv=0", meta + b"\x00" * 8, b"\x00" * 16, AES.new)
        try_aes("AES-CBC KEY_B iv=0", KEY_B, b"\x00" * 16, AES.new)
        try_aes("AES-ECB KEY_B", KEY_B, None, lambda k, iv: AES.new(k, AES.MODE_ECB))
        for name, key in [("RC4 KEY_B", KEY_B), ("RC4 meta8", meta), ("RC4 KEY_A", KEY_A)]:
            r = ARC4.new(key).decrypt(payload)
            print(f"[{name}] ->", look_ok(r))
        for name, key, nonce in [("ChaCha KEY_B n=meta8", KEY_B, meta), ("ChaCha meta8 n=0", meta, b"\x00" * 8), ("ChaCha KEY_A n=meta8", KEY_A, meta)]:
            r = ChaCha20.new(key=key, nonce=nonce).decrypt(payload)
            print(f"[{name}] ->", look_ok(r))
    except ImportError as e:
        print("crypto libs missing:", e)


if __name__ == "__main__":
    main()
