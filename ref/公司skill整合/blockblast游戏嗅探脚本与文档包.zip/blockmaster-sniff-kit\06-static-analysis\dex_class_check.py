# -*- coding: utf-8 -*-
"""Minimal dex class-def lister: verify which classes are actually DEFINED in a dex."""
import struct, sys, zipfile

def u32(b, o):
    return struct.unpack_from('<I', b, o)[0]

def get_str(dex, string_ids_off, idx):
    off = u32(dex, string_ids_off + idx * 4)
    # uleb128 length then MUTF-8 data
    p = off
    result = 0
    shift = 0
    while True:
        byte = dex[p]
        p += 1
        result |= (byte & 0x7F) << shift
        if not (byte & 0x80):
            break
        shift += 7
    end = dex.index(b'\x00', p)
    return dex[p:end].decode('utf-8', errors='replace')

def defined_classes(dex):
    string_ids_size = u32(dex, 0x38)
    string_ids_off = u32(dex, 0x3C)
    type_ids_size = u32(dex, 0x40)
    type_ids_off = u32(dex, 0x44)
    class_defs_size = u32(dex, 0x60)
    class_defs_off = u32(dex, 0x64)
    out = []
    for i in range(class_defs_size):
        off = class_defs_off + i * 32
        type_idx = u32(dex, off)
        desc_idx = u32(dex, type_ids_off + type_idx * 4)
        out.append(get_str(dex, string_ids_off, desc_idx))
    return out

if __name__ == '__main__':
    apk = sys.argv[1]
    z = zipfile.ZipFile(apk)
    want = sys.argv[2] if len(sys.argv) > 2 else None
    for i in range(1, 20):
        name = f'classes{i}.dex' if i > 1 else 'classes.dex'
        try:
            data = z.read(name)
        except KeyError:
            continue
        classes = defined_classes(data)
        hits = [c for c in classes if 'AppActivity' in c] if want is None else [c for c in classes if want in c]
        if hits:
            print(name, '->', hits)
