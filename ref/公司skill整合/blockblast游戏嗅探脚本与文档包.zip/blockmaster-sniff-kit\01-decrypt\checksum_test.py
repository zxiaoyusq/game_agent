#!/usr/bin/env python3
"""Compute simple checksums of AFFA payloads and compare with meta[7]."""
import struct
import sys

KEY = b"65485d8a-8161-4c"
DELTA = 0x9E3779B9
MASK = 0xFFFFFFFF


def _mx(y, z, s, p, e, k):
    return (((z >> 5) ^ (y << 2)) + ((y >> 3) ^ (z << 4))) ^ ((s ^ y) + (k[(p & 3) ^ e] ^ z))


def xxtea_decrypt(data: bytes, key: bytes) -> bytes:
    n = len(data) // 4
    v = list(struct.unpack("<%dI" % n, data[: n * 4]))
    k = list(struct.unpack("<4I", key[:16].ljust(16, b"\x00")))
    y = v[0]
    q = 6 + 52 // n
    s = (q * DELTA) & MASK
    while s:
        e = (s >> 2) & 3
        for p in range(n - 1, 0, -1):
            z = v[p - 1]
            v[p] = (v[p] - _mx(y, z, s, p, e, k)) & MASK
            y = v[p]
        z = v[n - 1]
        v[0] = (v[0] - _mx(y, z, s, 0, e, k)) & MASK
        y = v[0]
        s = (s - DELTA) & MASK
    return struct.pack("<%dI" % n, *v)


def checksums(b: bytes):
    x = 0
    s = 0
    for byte in b:
        x ^= byte
        s = (s + byte) & 0xFFFFFFFF
    crc8 = 0
    for byte in b:
        crc8 ^= byte
        for _ in range(8):
            if crc8 & 0x80:
                crc8 = ((crc8 << 1) ^ 0x07) & 0xFF
            else:
                crc8 = (crc8 << 1) & 0xFF
    return x, s & 0xFF, (s >> 8) & 0xFF, crc8


FILES = [
    (r"E:\codex_apk_work\blockblast_extracted\assets\assets\LaunchBrandAdJumpTrait\index.86f11.js", "07a21ba10700c4be"),
    (r"E:\codex_apk_work\blockblast_extracted\assets\assets\LaunchBrandAdSkipTrait\index.9fa88.js", "07a21ba10700c4cf"),
    (r"E:\codex_apk_work\blockblast_extracted\assets\assets\SkinUGCUseBtnTrait\index.0111d.js", "07b01baf0700c44f"),
]

for path, meta_hex in FILES:
    raw = open(path, "rb").read()
    pt = xxtea_decrypt(raw[8:], KEY)
    payload = pt[12:]
    x, s1, s2, crc8 = checksums(payload)
    meta = bytes.fromhex(meta_hex)
    print(path.split("\\")[-1], "meta[7]=0x%02x" % meta[7])
    print("  payload len", len(payload), "xor=0x%02x suml=0x%02x sumh=0x%02x crc8=0x%02x" % (x, s1, s2, crc8))
