﻿# -*- coding: utf-8 -*-
from PIL import Image
import sys
sys.stdout.reconfigure(encoding="utf-8")
p = r"E:\codex_apk_work\shots\our_g0.png"
im = Image.open(p)
print("format:", im.format, "size:", im.size, "mode:", im.mode)
im.convert("RGB").save(r"E:\codex_apk_work\shots\our_g0_rgb.png")
print("saved rgb")
# also check colorfulness
import collections
small = im.resize((64, 64))
hist = small.getcolors(64*64)
print("distinct colors in 64x64:", len(hist) if hist else ">4096")
