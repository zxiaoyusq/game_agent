import frida

JS = r"""
'use strict';
function dump(addrHex, size) {
    return ptr(addrHex).readByteArray(size);
}
rpc.exports = { dump: dump };
"""

dev = frida.get_device_manager().add_remote_device('127.0.0.1:27042')
session = dev.attach(5829)
script = session.create_script(JS)
script.load()
# dump the whole .bss (228KB) plus surrounding .data
data = script.exports_sync.dump('0x763872af7000', 0x38000)
with open(r"E:\codex_apk_work\memdump\bss_dump.bin", "wb") as f:
    f.write(data)
print("dumped", len(data))
session.detach()
