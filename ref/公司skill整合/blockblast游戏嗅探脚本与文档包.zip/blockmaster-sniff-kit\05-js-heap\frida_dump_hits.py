import frida
import os

JS = r"""
'use strict';
function scan(pat) {
    var results = [];
    var ranges = Process.enumerateRanges('r--');
    ranges.forEach(function (range) {
        try {
            var matches = Memory.scanSync(range.base, range.size, pat);
            matches.forEach(function (m) {
                results.push(m.address.toString());
            });
        } catch (e) { }
    });
    return results;
}
function dump(addrHex, size) {
    return ptr(addrHex).readByteArray(size);
}
rpc.exports = { scan: scan, dump: dump };
"""

OUT = r"E:\codex_apk_work\memdump\hits"
os.makedirs(OUT, exist_ok=True)

PAT = "36 35 34 38 35 64 38 61"

dev = frida.get_device_manager().add_remote_device('127.0.0.1:27042')
session = dev.attach(5829)
script = session.create_script(JS)
script.load()
addrs = script.exports_sync.scan(PAT)
print("hits:", len(addrs))
for idx, a in enumerate(addrs):
    try:
        base = int(a, 16) - 0x800
        data = script.exports_sync.dump(hex(base), 0x1000)
        with open(os.path.join(OUT, f"hit_{idx:03d}_{a}.bin"), "wb") as f:
            f.write(data)
    except Exception as e:
        print("skip", a, e)
session.detach()
