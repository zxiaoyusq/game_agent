# -*- coding: utf-8 -*-
"""Build and formally sign BlockMaster V34 from the signed V33 baseline."""
import hashlib
import os
import shutil
import subprocess
import sys
import time
import zipfile

import build_config

W = str(build_config.WORK)
BT = str(build_config.resolve_build_tools())
APKTOOL = str(build_config.resolve_apktool())

STAGE = os.path.join(W, 'stage2_sdk')
BASELINE = os.path.join(W, 'BlockMaster_v33_palm_full.apk')
APKTOOL_ATTEMPT = os.path.join(W, 'stage2_sdk_unsigned_v34.apk')
MERGED = os.path.join(W, 'stage2_v34_merged.apk')
ALIGNED = os.path.join(W, 'stage2_v34_aligned.apk')
FINAL = os.path.join(W, 'BlockMaster_v34_palm_full.apk')
DEX15 = os.path.join(STAGE, 'build', 'apk', 'classes15.dex')
DEX_VERIFY = os.path.join(W, 'tmp', 'v34_verify_classes15')

REPLACEMENTS = {
    'classes15.dex': DEX15,
    'assets/assets/main/index.7d3cd.js': os.path.join(
        STAGE, 'assets', 'assets', 'main', 'index.7d3cd.js'),
    'assets/remote_seed/patch/patch/assets/main/index.146a7.js': os.path.join(
        STAGE, 'assets', 'remote_seed', 'patch', 'patch', 'assets', 'main', 'index.146a7.js'),
}


def run(command, timeout=900, check=True):
    print('>>', command, flush=True)
    result = subprocess.run(
        command,
        shell=True,
        capture_output=True,
        text=True,
        encoding='utf-8',
        errors='replace',
        timeout=timeout,
    )
    output = (result.stdout or '') + (result.stderr or '')
    if check and result.returncode != 0:
        print(output[-6000:])
        raise RuntimeError('command failed: %s' % command)
    if output:
        print(output[-6000:])
    return result


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def verify_smali_text(text):
    method = '.method public static initSDK(Landroid/content/Context;)V'
    start = text.find(method)
    end = text.find('.end method', start)
    if start < 0 or end < 0:
        raise RuntimeError('AthenaSDK.initSDK is missing from rebuilt classes15.dex')
    init_body = text[start:end]
    outside = text[:start] + text[end + len('.end method'):]
    if '0x137b' not in init_body or init_body.count('AthenaAnalytics;->a0(I)V') != 1:
        raise RuntimeError('4987 referrer registration is not exactly once in initSDK')
    if '0x137b' in outside:
        raise RuntimeError('4987 is used outside referrer registration')
    if text.count('0x1737') < 3 or 'new-instance p1, LU0/a;' not in text:
        raise RuntimeError('5943 Athena business-event path is missing')


def compile_and_verify_classes15():
    if os.path.exists(DEX15):
        os.remove(DEX15)
    if os.path.exists(APKTOOL_ATTEMPT):
        os.remove(APKTOOL_ATTEMPT)

    started = time.time()
    result = run(
        'java -jar "%s" b "%s" -o "%s"' % (APKTOOL, STAGE, APKTOOL_ATTEMPT),
        1800,
        check=False,
    )
    output = (result.stdout or '') + (result.stderr or '')
    if result.returncode != 0 and 'failed assigning IDs' not in output:
        raise RuntimeError('apktool failed before the known resource-link boundary')
    if not os.path.isfile(DEX15) or os.path.getmtime(DEX15) < started:
        raise RuntimeError('classes15.dex was not freshly assembled')

    if os.path.isdir(DEX_VERIFY):
        shutil.rmtree(DEX_VERIFY)
    os.makedirs(DEX_VERIFY)
    mini_apk = os.path.join(DEX_VERIFY, 'classes15.apk')
    with zipfile.ZipFile(mini_apk, 'w') as archive:
        archive.write(DEX15, 'classes.dex', compress_type=zipfile.ZIP_STORED)
    decoded = os.path.join(DEX_VERIFY, 'decoded')
    run('java -jar "%s" d -f -r "%s" -o "%s"' % (APKTOOL, mini_apk, decoded), 600)
    athena_smali = os.path.join(decoded, 'smali', 'com', 'driftsand', 'game', 'athena', 'AthenaSDK.smali')
    with open(athena_smali, 'r', encoding='utf-8') as stream:
        verify_smali_text(stream.read())
    print('VERIFIED classes15', sha256_file(DEX15), flush=True)


def overlay_baseline():
    keystore, key_alias = build_config.signing_environment()
    for path in (MERGED, ALIGNED, FINAL):
        if os.path.exists(path):
            os.remove(path)
    for path in REPLACEMENTS.values():
        if not os.path.isfile(path):
            raise RuntimeError('replacement missing: %s' % path)

    signature_suffixes = ('.RSA', '.DSA', '.EC', '.SF')
    with zipfile.ZipFile(BASELINE, 'r') as source, zipfile.ZipFile(MERGED, 'w') as target:
        infos = {item.filename: item for item in source.infolist()}
        if len(infos) != len(source.infolist()):
            raise RuntimeError('baseline contains duplicate ZIP entries')
        missing = set(REPLACEMENTS) - set(infos)
        if missing:
            raise RuntimeError('baseline replacement entries missing: %s' % sorted(missing))

        for item in source.infolist():
            upper = item.filename.upper()
            if upper == 'META-INF/MANIFEST.MF' or upper.endswith(signature_suffixes):
                continue
            path = REPLACEMENTS.get(item.filename)
            if path:
                with open(path, 'rb') as stream:
                    data = stream.read()
            else:
                data = source.read(item.filename)
            compression = zipfile.ZIP_STORED if (
                item.filename.endswith('.dex') or
                (item.filename.startswith('lib/') and item.filename.endswith('.so'))
            ) else item.compress_type
            target.writestr(item, data, compress_type=compression)

    run('"%s\\zipalign.exe" -f -p 4 "%s" "%s"' % (BT, MERGED, ALIGNED), 300)
    run(
        'cmd /c ""%s\\apksigner.bat" sign --ks "%s" --ks-key-alias %s '
        '--ks-pass env:BLOCKMASTER_KS_PASS --key-pass env:BLOCKMASTER_KEY_PASS '
        '--out "%s" "%s""' % (
            BT, keystore, key_alias, FINAL, ALIGNED),
        300,
    )
    run('"%s\\apksigner.bat" verify --verbose --print-certs "%s"' % (BT, FINAL), 300)
    run('"%s\\zipalign.exe" -c -p 4 "%s"' % (BT, FINAL), 300)


def verify_final_entries():
    with zipfile.ZipFile(FINAL, 'r') as archive:
        infos = archive.infolist()
        names = [item.filename for item in infos]
        if len(names) != len(set(names)):
            raise RuntimeError('final APK contains duplicate ZIP entries')
        for name, path in REPLACEMENTS.items():
            actual = hashlib.sha256(archive.read(name)).hexdigest()
            expected = sha256_file(path)
            if actual != expected:
                raise RuntimeError('final entry mismatch: %s' % name)
        bad_libs = [
            item.filename for item in infos
            if item.filename.startswith('lib/') and item.filename.endswith('.so')
            and item.compress_type != zipfile.ZIP_STORED
        ]
        if bad_libs:
            raise RuntimeError('compressed native libraries: %s' % bad_libs[:5])
    print('FINAL', FINAL)
    print('SIZE', os.path.getsize(FINAL))
    print('SHA256', sha256_file(FINAL).upper())


def main():
    run('powershell -NoProfile -ExecutionPolicy Bypass -File "%s"' %
        os.path.join(W, 'verify_v34_athena_routing.ps1'), 120)
    run('"%s" "%s"' % (sys.executable, os.path.join(W, 'verify_v32_regressions.py')), 120)
    compile_and_verify_classes15()
    overlay_baseline()
    verify_final_entries()


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('BUILD FAILED:', error, file=sys.stderr)
        sys.exit(1)
