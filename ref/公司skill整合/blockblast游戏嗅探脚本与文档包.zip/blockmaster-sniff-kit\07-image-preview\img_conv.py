﻿# -*- coding: utf-8 -*-
from PIL import Image
p = r"E:\codex_apk_work\shots\our_g0.png"
im = Image.open(p).convert("RGB")
im.thumbnail((640, 400))
im.save(r"E:\codex_apk_work\shots\our_g0_small.jpg", quality=85)
print("saved", im.size)
