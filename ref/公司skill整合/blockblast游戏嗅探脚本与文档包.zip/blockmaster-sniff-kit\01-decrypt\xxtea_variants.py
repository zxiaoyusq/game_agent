#!/usr/bin/env python3
"""Test XXTEA variants/keys/endianness on jsc + v01 samples."""
import gzip
import struct

KEY_B = b"65485d8a-8161-4c"
KEY_A = b"93274615-a57e-4d"
DELTA = 0x9E3779B9
MASK = 0xFFFFFFFF


def mx(y, z, s, p, e, k):
    return (((z >> 5) ^ (y << 2)) + ((y >> 3) ^ (z << 4))) ^ ((s ^ y) + (k[(p & 3) ^ e] ^ z))


def xxtea(data: bytes, key: bytes, little_endian: bool) -> bytes:
    if len(data) < 8:
        return data
    n = len(data) // 4
    fmt = "<%dI" if little_endian else ">%dI"
    v = list(struct.unpack(fmt % n, data[: n * 4]))
    k = list(struct.unpack(fmt % 4, key[:16].ljust(16, b"\x00")))
    q = 6 + 52 // n
    s = (q * DELTA) & MASK
    y = v[0]
    while s:
        e = (s >> 2) & 3
        for p in range(n - 1, 0, -1):
            z = v[p - 1]
            v[p] = (v[p] - mx(y, z, s, p, e, k)) & MASK
            y = v[p]
        z = v[n - 1]
        v[0] = (v[0] - mx(y, z, s, 0, e, k)) & MASK
        y = v[0]
        s = (s - DELTA) & MASK
    return struct.pack(fmt % n, *v)


def main():
    samples = [
        (r"E:\codex_apk_work\blockblast_extracted\assets\assets\gl_fruit\index.701f6.jsc", "jsc_gl_fruit"),
        (r"E:\codex_apk_work\blockblast_extracted\assets\main.js", "v01_main"),
    ]
    for path, name in samples:
        raw = open(path, "rb").read()
        body = raw[8:] if raw[:4] == b"HEK:" else raw
        print("=====", name, "bodylen", len(body))
        for kname, key in [("B", KEY_B), ("A", KEY_A)]:
            for endian in [True, False]:
                r = xxtea(body, key, endian)
                desc = []
                if r[:2] == b"\x1f\x8b":
                    try:
                        d = gzip.decompress(r)
                        desc.append("GZIP_OK len=%d head=%r" % (len(d), d[:40]))
                    except Exception as e:
                        desc.append("gzip_bad")
                if r[:2] == b"\xaf\xfa":
                    desc.append("AFFA")
                if r[:1] == b"(" or r[:6] == b"window" or b"require" in r[:64]:
                    desc.append("JS? " + repr(r[:60]))
                if len(r) >= 4:
                    desc.append("head=" + r[:8].hex())
                print(kname, "LE" if endian else "BE", "; ".join(desc))


if __name__ == "__main__":
    main()
