#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""resindex - 本项目美术资源索引的唯一查询入口（不要再用 grep 扫文件内容找资源）。

用法（在 E:\\codex_apk_work 下）:
    python -X utf8 resindex/resindex.py find <关键词>          # 按资源名/路径查
    python -X utf8 resindex/resindex.py zh 结算背景            # 中文词 -> 英文资源名规则，自动查
    python -X utf8 resindex/resindex.py get <id>               # 看某条明细 + 落盘文件
    python -X utf8 resindex/resindex.py uuid <uuid>            # 反查 uuid（任意形态）
    python -X utf8 resindex/resindex.py extract <关键词> -o 目录 # 解密/解包导出真图
    python -X utf8 resindex/resindex.py cheat                  # 命名对照表（中/英/皮肤ID）
    python -X utf8 resindex/resindex.py stats                  # 库统计 + 建库时间
    python -X utf8 resindex/resindex.py where                  # 库位置与新鲜度
    python -X utf8 resindex/resindex.py sql "select ..."       # 逃生舱

常用例子:
    resindex.py find backgroundbg --ext .png            # 全屏渐变背景（含皮肤版）
    resindex.py find BG_01                              # res-game 通用图集里的纯色紫底
    resindex.py find ChapterScoreWin                    # 结算 prefab
    resindex.py zh 结算界面                              # 一次拿到所有结算相关名字
    resindex.py extract Remote_Skin_Material_3012/backgroundbg -o out
"""
import base64
import io
import json
import os
import sqlite3
import sys
import zipfile

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "resindex.db")
META = os.path.join(HERE, "index_meta.json")
NAMING = os.path.join(HERE, "naming_map.json")
HEK_KEY = b"65485d8a-8161-4c"


# --------------------------------------------------------------------------- #
def die(msg):
    print("ERROR:", msg)
    sys.exit(1)


def con():
    if not os.path.isfile(DB):
        die(f"索引不存在：{DB}\n请先运行: python -X utf8 {os.path.join(HERE,'build_index.py')}")
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c


def argval(argv, flag, default=None):
    if flag in argv:
        i = argv.index(flag)
        if i + 1 < len(argv):
            return argv[i + 1]
    return default


def has(argv, flag):
    return flag in argv


def flat(argv, flags=()):
    """去掉选项和它们的值，返回剩余位置参数（任何以 - 开头的都算选项）"""
    out, i = [], 0
    while i < len(argv):
        a = argv[i]
        if a.startswith("-"):
            if a in flags and i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                i += 2
                continue
            i += 1
            continue
        out.append(a)
        i += 1
    return out


# --------------------------------------------------------------------------- #
def where_sql(argv):
    cond, params = [], []
    if argval(argv, "--kind"):
        cond.append("kind = ?")
        params.append(argval(argv, "--kind"))
    if argval(argv, "--bundle"):
        cond.append("bundle LIKE ?")
        params.append("%" + argval(argv, "--bundle") + "%")
    if argval(argv, "--src"):
        cond.append("src = ?")
        params.append(argval(argv, "--src"))
    if argval(argv, "--ext"):
        cond.append("name LIKE ?")
        params.append("%" + argval(argv, "--ext"))
    return (" AND ".join(cond), params)


def do_find(argv):
    pats = flat(argv, ("--kind", "--bundle", "--src", "--ext", "--limit", "--exclude-kind"))
    if not pats:
        die("find 需要一个关键词，例如: find backgroundbg")
    limit = int(argval(argv, "--limit", "60"))
    excl = argval(argv, "--exclude-kind")
    where, params = where_sql(argv)
    like = " OR ".join("(name LIKE ? OR path LIKE ? OR uuid LIKE ? OR bundle LIKE ?)" for _ in pats)
    sql = "SELECT * FROM assets WHERE (" + like + ")"
    q = []
    for p in pats:
        q += ["%" + p + "%"] * 4
    if where:
        sql += " AND " + where
        q += params
    if excl:
        sql += " AND kind <> ?"
        q += [excl]
    # 排序：有真图/具体资源优先，通用 file/apk-entry 最后
    sql += """
        ORDER BY
          CASE kind WHEN 'spriteFrame' THEN 0 WHEN 'subimage' THEN 1 WHEN 'skin-res' THEN 1
                    WHEN 'texture' THEN 2 WHEN 'prefab' THEN 2 WHEN 'spineData' THEN 2
                    WHEN 'native' THEN 3 WHEN 'skin-file' THEN 3
                    WHEN 'apk-entry' THEN 4 ELSE 4 END,
          CASE WHEN COALESCE(native,'')<>'' THEN 0 WHEN COALESCE(file,'')<>'' THEN 1 ELSE 2 END,
          length(path), id
        LIMIT ?
    """
    q.append(limit * 6)
    rows = con().execute(sql, q).fetchall()
    seen, out = set(), []
    for r in rows:
        key = (r["bundle"], r["name"], r["path"])
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
        if len(out) >= limit:
            break
    print(f"# {len(out)} 条（pattern={pats}）")
    print(f"{'id':>6}  {'src':<13} {'kind':<12} {'bundle':<30} {'name':<32} file")
    for r in out:
        f = r["native"] or r["file"] or (f"<inside {r['enc'][4:]}>" if r["enc"].startswith("apk:") else "")
        print(f"{r['id']:>6}  {r['src']:<13} {r['kind']:<12} {(r['bundle'] or '')[:30]:<30} {(r['name'] or '')[:32]:<32} {f}")
    print("\n下一步: resindex.py get <id>   /   resindex.py extract <关键词> -o <目录>")


def do_get(argv):
    ids = flat(argv)
    if not ids:
        die("get 需要 id")
    c = con()
    for i in ids:
        r = c.execute("SELECT * FROM assets WHERE id=?", (i,)).fetchone()
        if not r:
            print(f"# id {i} 不存在")
            continue
        print("#" * 60)
        for k in r.keys():
            print(f"{k:<8}: {r[k]}")
        n = r["native"] or r["file"]
        if n and os.path.isfile(n):
            print(f"[存在] {n}  enc={r['enc'] or 'plain'}")


def do_uuid(argv):
    us = flat(argv)
    if not us:
        die("uuid 需要参数")
    c = con()
    for u in us:
        base = u.split("@")[0]
        rows = c.execute(
            "SELECT * FROM assets WHERE uuid LIKE ? OR uuid LIKE ? LIMIT 40",
            (u + "%", base + "%"),
        ).fetchall()
        if not rows:
            try:
                s = base.replace("-", "+").replace("_", "/")
                pad = "=" * ((4 - len(s) % 4) % 4)
                hx = base64.b64decode(s[:22] + pad).hex()
                rows = c.execute("SELECT * FROM assets WHERE uuid LIKE ? LIMIT 40", (hx + "%",)).fetchall()
                print(f"# 用解压 hex {hx} 反查")
            except Exception:
                pass
        print(f"## {u} -> {len(rows)} 条")
        for r in rows:
            print(f"  {r['id']:>6} {r['src']:<13} {r['kind']:<12} {r['bundle']} :: {r['path']} :: {r['uuid']}")


def do_zh(argv):
    words = flat(argv, ("--kind", "--bundle", "--src", "--ext", "--limit", "--exclude-kind"))
    if not words:
        die("zh 需要中文词，例如: zh 结算背景")
    m = json.load(io.open(NAMING, encoding="utf-8")) if os.path.isfile(NAMING) else {}
    rules = m.get("rules", {})
    pats = []
    for w in words:
        hit = None
        for key, val in rules.items():
            if key in w or w in key:
                hit = val
                break
        if hit:
            print(f"# 「{w}」-> {hit}")
            pats += hit
        else:
            print(f"# 「{w}」无对照，按原词搜")
            pats.append(w)
    flags = []
    for f in ("--kind", "--bundle", "--src", "--ext", "--limit", "--exclude-kind"):
        v = argval(argv, f)
        if v:
            flags += [f, v]
    do_find(flags + list(dict.fromkeys(pats)))


def do_cheat(argv):
    if not os.path.isfile(NAMING):
        die("缺少 naming_map.json")
    m = json.load(io.open(NAMING, encoding="utf-8"))
    print(m.get("doc", ""))
    for k, v in m.get("rules", {}).items():
        print(f"\n## {k}")
        print("   " + "  ".join(v))


# --------------------------------------------------------------------------- #
def decrypt_bytes(b, name=""):
    if b.startswith(b"HEK:"):
        body = b[8:]
        ks = (HEK_KEY * (len(body) // 16 + 1))[: len(body)]
        b = bytes(x ^ y for x, y in zip(body, ks))
    if b[:2] == b"\x1f\x8b":
        import gzip
        try:
            b = gzip.decompress(b)
        except Exception:
            pass
    return b


def do_extract(argv):
    out = argval(argv, "-o") or argval(argv, "--out") or "resindex_out"
    limit = int(argval(argv, "--limit", "8"))
    pats = flat(argv, ("-o", "--out", "--limit", "--kind", "--bundle", "--ext", "--src"))
    rows, seen = [], set()
    c = con()
    where, wparams = where_sql(argv)
    for p in pats:
        sql = """SELECT * FROM assets WHERE (name LIKE ? OR path LIKE ?)"""
        q = ["%" + p + "%", "%" + p + "%"]
        if where:
            sql += " AND " + where
            q += wparams
        sql += """ ORDER BY CASE kind WHEN 'skin-file' THEN 0 WHEN 'skin-res' THEN 0 WHEN 'spriteFrame' THEN 1
                         WHEN 'texture' THEN 1 WHEN 'native' THEN 1 WHEN 'subimage' THEN 2
                         WHEN 'prefab' THEN 3 WHEN 'apk-entry' THEN 6 ELSE 4 END,
                    CASE WHEN COALESCE(native,'')<>'' THEN 0 WHEN COALESCE(file,'')<>'' THEN 1 ELSE 2 END
               LIMIT ?"""
        q.append(limit * 4)
        for r in c.execute(sql, q):
            key = (r["bundle"], r["name"], r["path"])
            if key in seen:
                continue
            seen.add(key)
            rows.append(r)
    if not rows:
        die("没匹配到，先用 find 看看名字")
    os.makedirs(out, exist_ok=True)
    done = 0
    for r in rows:
        if done >= limit * 2:
            break
        data = None
        if r["enc"].startswith("apk:") and r["path"]:
            apk = r["enc"][4:]
            try:
                with zipfile.ZipFile(apk) as z:
                    data = z.read(r["path"])
            except Exception as e:
                print("  !! 读 apk 失败", e)
                continue
        elif r["native"] and os.path.isfile(r["native"]):
            data = io.open(r["native"], "rb").read()
        elif r["file"] and os.path.isfile(r["file"]):
            data = io.open(r["file"], "rb").read()
        if data is None:
            continue
        was_enc = data[:4] == b"HEK:"
        data = decrypt_bytes(data)
        ext = os.path.splitext(r["name"])[1]
        if data[:8] == b"\x89PNG\r\n\x1a\n":
            ext, kind = ".png", "PNG"
        elif data[:2] == b"\xff\xd8":
            ext, kind = ".jpg", "JPEG"
        elif ext.lower() in (".json", ".txt", ".atlas", ".fnt"):
            kind = "TEXT"
        else:
            kind = ""
        stem = os.path.splitext(r["name"])[0]
        fn = f"{r['bundle']}__{stem}{ext}" if r["bundle"] else f"{stem}{ext}"
        fn = fn.replace("/", "_").replace("\\", "_").replace(":", "_")[:180]
        dst = os.path.join(out, fn)
        io.open(dst, "wb").write(data)
        print(f"  {dst}  {len(data)}B  {'(HEK解密)' if was_enc else ''} {kind}")
        done += 1
    print(f"# 导出 {done} 个 -> {os.path.abspath(out)}")


def do_stats(argv):
    c = con()
    print(json.dumps(json.load(io.open(META, encoding="utf-8")), ensure_ascii=False, indent=2) if os.path.isfile(META) else "{}")
    print("\n-- 抽样 --")
    for r in c.execute("SELECT src,kind,COUNT(*) n FROM assets GROUP BY src,kind ORDER BY n DESC LIMIT 25"):
        print(f"  {r['src']:<14} {r['kind']:<12} {r['n']}")
    print("\n提示: 索引可能过期，重建：python -X utf8 resindex/build_index.py")


def do_where(argv):
    print("db   :", DB, "exists=", os.path.isfile(DB))
    print("meta :", META)
    if os.path.isfile(META):
        print(json.dumps(json.load(io.open(META, encoding="utf-8")), ensure_ascii=False)[:400])
    print("build:", os.path.join(HERE, "build_index.py"))


def do_sql(argv):
    q = argval(argv, "--q") or " ".join(flat(argv, ("--q",)))
    for r in con().execute(q):
        print(dict(r))


# --------------------------------------------------------------------------- #
USAGE = __doc__


def main():
    argv = sys.argv[1:]
    if not argv:
        print(USAGE)
        return
    cmd, rest = argv[0], argv[1:]
    table = {
        "find": do_find, "get": do_get, "uuid": do_uuid, "zh": do_zh,
        "cheat": do_cheat, "extract": do_extract, "stats": do_stats,
        "where": do_where, "sql": do_sql,
    }
    if cmd in ("-h", "--help", "help"):
        print(USAGE)
        return
    if cmd not in table:
        print(USAGE)
        die(f"未知命令 {cmd}")
    table[cmd](rest)


if __name__ == "__main__":
    main()
