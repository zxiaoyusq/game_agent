# -*- coding: utf-8 -*-
"""Apply Block Master settings simplification to the decrypted main JS source."""
import io, os

WORK = r'E:\codex_apk_work\blockmaster_pro_swap\work'
SRC = os.path.join(WORK, 'js_dumps', 'current', 'main_index_7d3cd.js')

with io.open(SRC, 'r', encoding='utf-8') as f:
    txt = f.read()

repls = [
    # Home page setting popup: remove More Games button
    (
        'var e = [ m.enSetupKeys.sound, m.enSetupKeys.BGM, m.enSetupKeys.vibration, m.enSetupKeys.moreGames, m.enSetupKeys.moreSettings ];',
        'var e = [ m.enSetupKeys.sound, m.enSetupKeys.BGM, m.enSetupKeys.vibration, m.enSetupKeys.moreSettings ];',
    ),
    # SetupConfig bottomList: remove More Games and Share with Friends
    (
        'bottomList: [ "exit", "home", "moreGames", "moreSettings", "noAds", "replay", "noads2", "share", "aeGameEntry4", "SetAddDefultSkinBtn", "languageSwitch", "ActivityEnter", "accountPlayerHead", "account", "SetAddCloseSkinBtn", "revive" ]',
        'bottomList: [ "exit", "home", "moreSettings", "noAds", "replay", "noads2", "aeGameEntry4", "SetAddDefultSkinBtn", "languageSwitch", "ActivityEnter", "accountPlayerHead", "account", "SetAddCloseSkinBtn", "revive" ]',
    ),
]

for old, new in repls:
    c = txt.count(old)
    if c != 1:
        raise SystemExit('MISMATCH count=%d for: %s' % (c, old[:80]))
    txt = txt.replace(old, new)

with io.open(SRC, 'w', encoding='utf-8') as f:
    f.write(txt)
print('applied settings patch to', SRC)
