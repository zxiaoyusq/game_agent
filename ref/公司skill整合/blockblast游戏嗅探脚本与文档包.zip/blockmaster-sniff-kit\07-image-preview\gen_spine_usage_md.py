# -*- coding: utf-8 -*-
import json

with open(r'E:\codex_apk_work\spine_usage_index.json', encoding='utf-8') as f:
    usage = json.load(f)
with open(r'E:\codex_apk_work\spine_prefab_refs.json', encoding='utf-8') as f:
    refs = json.load(f)

by_rel = {u['rel']: u for u in usage}

# (rel, category, usage_text, how_text, evidence)
E = []
def add(rel, cat, usage_text, how_text, ev=''):
    E.append((rel, cat, usage_text, how_text, ev))

# ---------- 1. guide ----------
add('assets/UEExploreBeginnerDragTargetHighlightTrait/spine/gameplay_xinshou.atlas', 'guide',
    '新用户探索引导：高亮“可拖方块 + 目标落点 + 手部动画”，教新手把方块拖到目标位置',
    'highlight.prefab 挂 Skeleton，默认播 in（出现），in2 用于循环强调',
    '静态引用 highlight.prefab；主包脚本未解密，依据命名推断')
add('assets/UEExploreGuideCompleteLikeTrait/spines/gameplay_jlc_WellDone.atlas', 'guide',
    '引导任务完成时的点赞/成功反馈（“Well Done”）',
    'effect.prefab 默认播 in，一次性播完回收',
    '静态引用 effect.prefab；主包未解密，推断')
add('assets/UEExplorePopViewGuideTrait/spine/gameplay_tanchuan.atlas', 'guide',
    '引导弹窗背景动效：1hang（1 行文案）与 3hang（3 行文案）两种版式',
    'popView.prefab 按文案行数切换 1hang / 3hang',
    '静态引用 popView.prefab；主包未解密，推断')
add('assets/ReplaceGuideSchemeTrait/spine/gameplay_xinshou.atlas', 'guide',
    '“替换引导方案”功能：更换引导策略时的手部演示',
    'ReplaceGuideScheme.prefab 默认播 in',
    '静态引用 ReplaceGuideScheme.prefab；主包未解密，推断')
add('assets/OneStepClearGuideTrait/spine/gameplay_Guide_glow.atlas', 'guide',
    '一步清空引导：提示玩家当前棋盘可一次清空时的光效',
    'guideEffect.prefab 默认播 init',
    '静态引用 guideEffect.prefab；主包未解密，推断')
add('assets/ClassGuideConfigEnhanceTrait/spine/gameplay_guide_eff.atlas', 'guide',
    '关卡配置教学提示特效（in1/in2/in3 三档，对应不同提示内容/强度）',
    'guideInfo.prefab 默认播 in1，按配置切换',
    '静态引用 guideInfo.prefab；主包未解密，推断')
add('assets/ClassGuideDirectThreeBlockTrait/spine/gameplay_biankuang_efc.atlas', 'guide',
    '“直接三块”玩法教学：目标区域边框高亮',
    'effect.prefab 默认播 in',
    '静态引用 effect.prefab；主包未解密，推断')
add('assets/NewUserEarlyRoundsBoardTrait/spine/board1/gameplay_xinshou.atlas', 'guide',
    '新用户早期回合的棋盘新手引导（board1 指早期棋盘 1）',
    '该 bundle 内只有此骨架、无预制体/场景，判断由脚本按 bundle 动态加载后赋给运行时 Skeleton 播放 in',
    '无静态引用；config.original.json 仅含骨架+图集+纹理+帧 4 项；主包未解密，判定为脚本动态加载（推断）')

# ---------- 2. gameplay ----------
add('assets/ChapterReplaySkipGoalTrait/spine/gameplay_shuaping.atlas', 'gameplay',
    '章节回放“跳过目标”弹窗的计数/刷屏动画：40 帧数字序列（10000–10039），推测为逐帧计数值',
    'ChapterReplaySkipGoal.prefab 默认播 10000，按数值切到对应帧',
    '静态引用 ChapterReplaySkipGoal.prefab；主包未解密，推断')
add('assets/ChapterReplaySkipGoalTrait/spine/gameplay_shuaping2.atlas', 'gameplay',
    '同一弹窗的关卡编号入场动画（101_in–106_in，对应关卡 101–106）',
    'ChapterReplaySkipGoal.prefab 默认播 101_in，按当前关卡选择',
    '静态引用；主包未解密，推断')
add('assets/ReviveUITimeEffectChangeTrait/spines/revive_number.atlas', 'gameplay',
    '复活界面倒计时数字特效（蓝色）',
    'NodeReviveUITimeEffectChange.prefab 默认播 blue',
    '静态引用；主包未解密，推断')
add('assets/TravelMosaicProgressTrait/spine/main_mosaic_eff.atlas', 'gameplay',
    '旅行主题马赛克进度条特效（集卡/地图进度）',
    'mosaicProgress.prefab 默认播 in，进度变化时播 init',
    '静态引用；主包未解密，推断')
add('assets/PreEliminateGemBreathTrait/res/gameplay_xingxing_g.atlas', 'gameplay',
    '预消除宝石的“呼吸”发光提示，6 种颜色对应 6 色宝石',
    'BreathSpine.prefab 按宝石颜色切换 blue/green/orange/purple/red/yellow',
    '静态引用 BreathSpine.prefab；主包未解密，推断')
add('assets/JewelGameUnlockEncourageTrait/spine/gameplay_ma.atlas', 'gameplay',
    '宝石玩法解锁鼓励弹窗中的“更多游戏”标签动画',
    'JewelGameUnlockEncourage.prefab 播放 moregames',
    '静态引用；主包未解密，推断')

# ---------- 3. ops ----------
add('assets/ShowWelcomeEveryDayTrait/spine/main_welcome_popUp.atlas', 'ops',
    '每日回归欢迎弹窗入场动效',
    'effect.prefab 默认播 in_1',
    '静态引用；主包未解密，推断')
add('assets/AdSubScribePopModelTrait/dragonBones/gameplay_popup_kuang.atlas', 'ops',
    '广告订阅弹窗条目的边框动效（init1/init2 两态）',
    'adSubScribePopItem.prefab 默认播 init2',
    '静态引用；目录名是 dragonBones，但实际为 Spine 骨架')
add('assets/AdSubScribePopModelTrait/dragonBones/gameplay_popup_xian.atlas', 'ops',
    '订阅设置面板的线条/描边装饰（in1/in2/init1/init2）',
    'adSubScribePopSetPanel.prefab 两个 Skeleton 节点分别播 init1 / init2',
    '静态引用；实际为 Spine 骨架')

# ---------- 4. gl_fruit ----------
add('assets/gl_fruit/assets/effects/BoardFullPanel/BoardFullPanel.atlas', 'fruit',
    '水果合成棋盘满时的提示面板',
    '代码 playBoardFullPanelEffect() → playEffect(..., NodeEffectUpperRoot, "idle")，在指定位置生成',
    'gl_fruit/index.701f6.js')
add('assets/gl_fruit/assets/effects/GoldWatermelonPanel/GoldWatermelonPanel.atlas', 'fruit',
    '合成出金西瓜时的面板特效',
    'playGoldWatermelonPanelEffect() 播 "idle"，生成后 scale=1.3',
    'gl_fruit/index.701f6.js')
add('assets/gl_fruit/assets/effects/combo/watermelon_gamplay_combo.atlas', 'fruit',
    '连击计数特效（蓝/青/绿/粉/紫 5 色）',
    'GLFruitComboItemNew.prefab 默认播 blue_in，按连击颜色切换',
    '静态引用 + 代码 ComboItem 控制器')
add('assets/gl_fruit/assets/effects/dianzan/dianzan.atlas', 'fruit',
    '点赞动效（combo 连击赞 / dianzhan 点赞两种）',
    'dianzan.prefab 默认播 combo',
    '静态引用；对象池加载')
add('assets/gl_fruit/assets/effects/juzhongdianzan/juzhongdianzan.atlas', 'fruit',
    '居中点赞特效（合成大西瓜达成时）',
    'playJuzhongdianzan() 播 "idle"，再播放传入的具体动画',
    'gl_fruit/index.701f6.js')
add('assets/gl_fruit/assets/effects/Lose_hint_fx/lose_hint_fx.atlas', 'fruit',
    '失败提示特效',
    '对象池预加载 prefabs/effects/lose_hint_fx，失败时生成并播 idle',
    'gl_fruit/index.701f6.js')
add('assets/gl_fruit/assets/effects/samefruit/hcdxg_Prompteff.atlas', 'fruit',
    '同果提示特效（合成大西瓜：相同水果相邻时的提示，idle_1~4 对应 1–4 级水果）',
    'Fruit_01~Fruit_04 四个水果预制体各挂一份',
    '静态引用 Fruit_01/02/03/04')
for stem in ['Fruit_02', 'Fruit_04', 'Fruit_06', 'Fruit_07', 'Fruit_08']:
    add('assets/gl_fruit/assets/effects/Skin3/{0}/{0}.atlas'.format(stem), 'fruit',
        '水果皮肤动画：0_idle/1_idle 基础待机、idle1–idle4 待机变体、change_1_2 / change_1_3 / change_2_1 / change_2_3 / change_3_1 / change_3_2 为合成/变形过渡',
        '{0}.prefab 按水果等级与合成事件切换对应动画'.format(stem),
        '代码中存在 fruitGraySpineName=["prefabs/Fruit_01","prefabs/Fruit_02"] 的远程换灰皮特性（动态替换 SkeletonData）')

# ---------- 5. gl_mahjong ----------
add('assets/gl_mahjong/assets/effects/Mahjong_Selected_V2/Mahjong_Selected_V2.atlas', 'mahjong',
    '麻将牌选中高亮特效',
    'EffectSelected.prefab 默认播 idle；代码 replaceSelectSkeletonData 会从 gl_mahjong bundle load("spine/Mahjong_Selected_V2") 动态替换骨架',
    'gl_mahjong/index.0ebe3.js（“替换选中特效成功”）')
add('assets/gl_mahjong/assets/effects/Mahjong_CanClickEffect/mahjong_gameplay_tips.atlas', 'mahjong',
    '可点击麻将的提示特效',
    'EffectClickable.prefab 默认播 init；麻将牌组件在 onLoad 取子节点 EffectClickable 的 Skeleton',
    'gl_mahjong/index.0ebe3.js')
add('assets/gl_mahjong/assets/effects/Mahjong_Collosion_normal_V2/Mahjong_Collosion_normal_V2.atlas', 'mahjong',
    '普通消除碰撞特效',
    'EffectMerger.prefab 播 idle',
    '静态引用 EffectMerger.prefab')
add('assets/gl_mahjong/assets/effects/Mahjong_Collosion_combo_V2/Mahjong_Collosion_combo_V2.atlas', 'mahjong',
    '连击消除碰撞特效',
    'EffectMergerCombo.prefab 播 idle',
    '静态引用 EffectMergerCombo.prefab')
add('assets/gl_mahjong/assets/effects/Mahjong_Prophint_V2/Mahjong_Prophint_V2.atlas', 'mahjong',
    '道具提示特效（可使用道具时的引导）',
    'EffectPropHint.prefab 播 idle；麻将牌组件在 onLoad 取子节点 EffectPropHint 的 Skeleton',
    'gl_mahjong/index.0ebe3.js')
add('assets/gl_mahjong/assets/effects/Mahjong_AllComboEffect/Mahjong_AllComboEffect.atlas', 'mahjong',
    '全连击特效（一次消除全部可消牌）',
    'EffectAllCombo.prefab 两个 Skeleton 节点分别播 idle / idle2',
    '关联 GLMahjongAllComboDieCtr 的全连击判定逻辑')
add('assets/gl_mahjong/assets/effects/Mahjong_UIGroundEff/Mahjong_UIGroundEff.atlas', 'mahjong',
    '麻将界面地面/背景特效',
    'GLMahjongGameView.prefab、glMahjongPrefab.prefab、gl_mahjong.fire 均引用，播 idle',
    '静态引用 3 处')

# ---------- 6. gl_tictactoe ----------
add('assets/gl_tictactoe/resource/effect/gameplay_word.atlas', 'tictactoe',
    '胜利标语：1_dominated（三步完胜）、2_bigwin（四步胜利）',
    'Word.prefab 默认播 1_dominated；GLTictactoeWinReward 特性按步数（3 或 4）选择播放',
    'gl_tictactoe/index.12707.js（代码日志确认动画名）')
add('assets/gl_tictactoe/resource/effect/Jingziqi_qizi.atlas', 'tictactoe',
    '井字棋棋子：O/X 的 chuxian（出现）/ idle（待机）/ shengli（胜利）/ shengli_dikuang（胜利底框），及 shengli_qipangaoliang（棋盘高亮）',
    'Chess.prefab 与场景引用；代码 setAnimation(0, "shengli_qipangaoliang", !1) 播棋盘高亮',
    'gl_tictactoe/index.12707.js')
add('assets/gl_tictactoe/resource/effect/Jingziqi_qizi_v2.atlas', 'tictactoe',
    'v2 皮肤棋子：动画同上，另加 shengli_qipangaoliang_hong / _lan 两种棋盘高亮',
    'ChessChild / WinEffect2 预制体；GLTictactoeChangeSkin 特性下按玩家红/蓝选择 hong / lan',
    'gl_tictactoe/index.12707.js')

# ---------- 7. gl_watersort ----------
add('assets/gl_watersort/resources/spine/skeleton.atlas', 'watersort',
    '水排序旧版瓶子/水全套 62 动画：空瓶（boliping_1~4_kong）、水位（water_1~4_idle/huang/in_huang）、倒水（xg_water_daoru1/2 ± left/right）、波纹（water_bowen_out1~4）、气泡（xg_water_qipao1~4）、满瓶（xg_water_manping）、选择高亮（xg_water_xuanzhe_0~4/_up）、胜利背景（xg_beijing_win）、锁瓶解说（xg_boliping_jieshuo1/2）、发光（xg_boliping_liang1~4）、侧瓶（y_left/right_1~4_boliping）、瓶盖（pinggai）、W 标（xg_water_W_1~3）、上升（xg_water_up1234/_danzhen）',
    '代码按水量动态拼接动画名：waterData.length+"_idle"、空瓶播 "boliping_"+n+"_kong"、锁瓶播 xg_boliping_jieshuo1；场景 glWatersort.prefab 默认 xg_beijing_win',
    'gl_watersort/index.83b29.js')
add('assets/gl_watersort/resources/spine/spineNew.atlas', 'watersort',
    '新版瓶子/水全套（动画集与 skeleton 完全一致，62 个）',
    'GLWaterItemNew / GLWaterItemNewGuide 预制体，逻辑同上（动态拼接动画名）',
    '静态引用 2 处')
add('assets/gl_watersort/resources/spine/finger.atlas', 'watersort',
    '教学手指动效（animation ~ animation6 共 6 种手势）',
    'glWatersort.prefab / gl_watersort.fire 场景默认播 animation',
    '静态引用 2 处')
add('assets/gl_watersort/resources/spine/nopixel_watersort_gameplay_thumb.atlas', 'watersort',
    '完成一根试管时的点赞大拇指',
    'GLWaterItemDianzan.prefab 播 in',
    '代码含 _dianzanNode 完成点赞控制器')

# ---------- 8. gl_sudoku ----------
add('assets/gl_sudoku/res/spine/aixin/aixin_01.atlas', 'sudoku',
    '数独界面爱心动效（animation1/2/3 三种节奏）',
    'SudokuGame.prefab 中 3 个 Skeleton 节点，默认均播 animation3',
    '静态引用 3 处')
add('assets/gl_sudoku/res/spine/word/gameplay_fzjl.atlas', 'sudoku',
    '数独彩色填充特效（解题正确时的彩色填充）',
    'EffectColorful.prefab；代码 setAnimation(0, "in_colorful", !1) 播完自动销毁',
    'gl_sudoku/index.0e9fc.js')

# ---------- 9. gl_onet / gl_oneline ----------
add('assets/gl_onet/resource/Effect/Experiment/showUpdateCapcityAnima/PowerUP.atlas', 'onet',
    '连连看容量升级动画（实验功能）',
    'UpdateCapacityNode.prefab 播 animation',
    '代码 _prefabPath="resource/prefabs/Experiment/showUpdateCapcityAnima/UpdateCapacityNode"')
add('assets/gl_onet/resource/Effect/spine/lihua.atlas', 'onet',
    '教学结果页礼花',
    'OnetTeachResultView.prefab 播 idle',
    '代码 TeacResultPfbPath = "OnetTeachResultView"')
add('assets/gl_oneline/GameRes/ Effect/oneLine_gameplay_crownTips.atlas', 'onet',
    '一条线（连线消除）玩法皇冠提示（连击/奖励提示）',
    'CrownTips.prefab 默认播 in，结束播 out',
    '代码含 _crownTipsTimerStarted 计时触发逻辑')
add('assets/gl_oneline/GameRes/ Effect/Oneline_gameplay_king.atlas', 'onet',
    '中间提示条的王者/皇冠动画',
    'GLBFMiddleTipsView.prefab 播 animation',
    '静态引用 GLBFMiddleTipsView.prefab')

# ---------- 10. gl_hall ----------
add('assets/gl_hall/gl_result/resource/spine/lihua.atlas', 'hall',
    '小游戏大厅结果页礼花/庆祝',
    'ResultView1.prefab 播 idle',
    '静态引用 ResultView1.prefab')
add('assets/gl_hall/gl_result/resource/spine/pingju.atlas', 'hall',
    '结果页平局动效',
    'ResultView2.prefab 播 in，播完延时隐藏（out）',
    'gl_hall/index.b5edb.js：tweenJingziqi case 2 对 spineDraw 播 "in"')
add('assets/gl_hall/gl_result/resource/spine/shibaijiemian.atlas', 'hall',
    '结果页胜负界面（win / lost 两态）',
    'ResultView2.prefab；代码 case 0 播 "win"+胜利音效、case 1 播 "lost"+失败音效，播完 onClose',
    'gl_hall/index.b5edb.js：tweenJingziqi')

# ---------- 11. sand ----------
add('assets/sand_mini/new/spine/minimalist_sandCrush_gameplay_arrow.atlas', 'sand',
    '沙块消除升级箭头',
    'SandLevelUp.prefab 播 init',
    '静态引用 SandLevelUp.prefab')
add('assets/sand_mini/new/texture/guide/gameplay_teaching_arrow.atlas', 'sand',
    '沙块教学引导箭头',
    'MiniTutorialUI.prefab 播 init',
    '静态引用 MiniTutorialUI.prefab')
add('assets/sandcrush/res/spine/scoreLevelUp/pixel_sandCrush_gameplay_progressBar_efx.atlas', 'sand',
    '分数进度条特效（升级时进度条闪烁/填充）',
    'SandDegree.prefab 播 init；hsgame 预加载清单包含该资源；进度条有 setProgressFullCallback 逻辑',
    'hsgame/index.f2d85.js + sandcrush/index.32ace.js')
add('assets/sandcrush/res/spine/scoreLevelUp/pixel_sandCrush_gameplay_progressBar_goal_efx.atlas', 'sand',
    '目标进度条特效（达成关卡目标时）',
    'SandDegree.prefab 播 in；同样被 hsgame 预加载；注意：资源属 sandcrush bundle，却被 sand_mini 预制体跨 bundle 引用',
    'hsgame/index.f2d85.js + sandcrush/index.32ace.js')

assert len(E) == 56, len(E)

CAT = [
    ('guide', '一、新用户 / 新手引导类（主玩法 bundle）'),
    ('gameplay', '二、玩法功能与关卡 UI 类（主玩法 bundle）'),
    ('ops', '三、弹窗与日常运营类（主玩法 bundle）'),
    ('fruit', '四、小游戏 · 水果合成 gl_fruit'),
    ('mahjong', '五、小游戏 · 麻将 gl_mahjong'),
    ('tictactoe', '六、小游戏 · 井字棋 gl_tictactoe'),
    ('watersort', '七、小游戏 · 水排序 gl_watersort'),
    ('sudoku', '八、小游戏 · 数独 gl_sudoku'),
    ('onet', '九、小游戏 · 连连看/连线消消乐 gl_onet / gl_oneline'),
    ('hall', '十、小游戏大厅结果页 gl_hall'),
    ('sand', '十一、沙块玩法 sandcrush / sand_mini'),
]

def short(rel):
    return rel.replace('assets/', '', 1)

def default_anim(rel):
    r = refs.get(by_rel[rel]['cu'], [])
    da = [x.get('defaultAnimation') for x in r if x.get('defaultAnimation')]
    return ('、'.join(dict.fromkeys(da))) if da else '—'

def ref_paths(rel):
    r = refs.get(by_rel[rel]['cu'], [])
    ps = sorted({x['path'].replace('assets/', '', 1) for x in r})
    return '<br>'.join(ps) if ps else '（无静态引用，脚本动态加载）'

def anims_text(rel):
    a = by_rel[rel]['anims']
    if len(a) > 12:
        return '、'.join(a[:12]) + ' …共 {0} 个'.format(len(a))
    return '、'.join(a)

lines = []
lines.append('# Block Blast（com.block.juggle）全量 Spine 动效用途清单')
lines.append('')
lines.append('> 共 **56 个** `sp.SkeletonData` Spine 骨架。以下“用处/用法”基于：重建工程中的预制体/场景引用、动画命名、已解密 bundle 脚本调用点，以及 bundle 结构推断。主玩法 bundle（main）为 HEK:XOR 加密且未能解密，涉及主玩法 trait 的条目已标注“推断”。')
lines.append('')
lines.append('## 数据来源与验证状态')
lines.append('')
lines.append('- 工程：`E:\\codex_apk_work\\blockblast_project`（由 APK 解包 + HEK:XOR 解密 + cc-reverse 重建）')
lines.append('- 骨架与动画索引：`E:\\codex_apk_work\\spine_usage_index.json`')
lines.append('- 预制体/场景引用索引：`E:\\codex_apk_work\\spine_prefab_refs.json`')
lines.append('- 完整性校验：`E:\\codex_apk_work\\spine_verify_report.json`（PNG 全部可解码、0 损坏；骨架附件与图集覆盖已验证）')
lines.append('- 已解密脚本：`E:\\codex_apk_work\\jsc_decrypted\\`（13 个 bundle：gl_fruit / gl_hall / gl_mahjong / gl_oneline / gl_onet / gl_sudoku / gl_tictactoe / gl_watersort / hsgame / sandcrush / sand_audio / sand_mini / sand_prefab）')
lines.append('- 统计：56 个骨架中 55 个有静态预制体/场景引用，1 个（`NewUserEarlyRoundsBoardTrait/board1/gameplay_xinshou`）无静态引用、判定为脚本动态加载。')
lines.append('')
lines.append('## 图例')
lines.append('')
lines.append('| 字段 | 说明 |')
lines.append('| --- | --- |')
lines.append('| 资源路径 | 相对 `assets\\` 的骨架文件（.atlas 与同名 .json/.png 成组） |')
lines.append('| 动画 | 该骨架内置的全部动画名（超过 12 个省略显示并注明总数） |')
lines.append('| 引用位置 | 引用该骨架的预制体/场景（相对 `assets\\`） |')
lines.append('| 用处 / 用法 / 证据 | 游戏内用途、播放方式、代码证据 |')
lines.append('')

for key, title in CAT:
    rows = [e for e in E if e[1] == key]
    lines.append('## {0}（{1} 个）'.format(title, len(rows)))
    lines.append('')
    lines.append('| 资源路径 | 动画 | 引用位置 | 用处 / 用法 / 证据 |')
    lines.append('| --- | --- | --- | --- |')
    for rel, cat, usage_text, how_text, ev in rows:
        cell4 = '**用处**：{0}<br>**用法**：{1}'.format(usage_text, how_text)
        if ev:
            cell4 += '<br>**证据**：{0}'.format(ev)
        lines.append('| {0} | {1} | {2} | {3} |'.format(short(rel), anims_text(rel), ref_paths(rel), cell4))
    lines.append('')

lines.append('## 附注')
lines.append('')
lines.append('### 1. 同名不同资源（勿混淆）')
lines.append('')
lines.append('| 资源名 | 数量 | 区分 |')
lines.append('| --- | --- | --- |')
lines.append('| `gameplay_xinshou` | 3 | UEExploreBeginnerDragTargetHighlightTrait（in/in2，手+块+演示框）、ReplaceGuideSchemeTrait（in）、NewUserEarlyRoundsBoardTrait/board1（in，无静态引用） |')
lines.append('| `lihua` | 2 | gl_hall 结果页礼花（ResultView1）、gl_onet 教学结果礼花（OnetTeachResultView） |')
lines.append('| `skeleton` / `spineNew` | 2 | 水排序新旧两套瓶子动画，62 个动画名完全一致 |')
lines.append('')
lines.append('### 2. 动画名语义速查')
lines.append('')
lines.append('- `gameplay_shuaping`：10000–10039 共 40 个数字帧，章节回放跳过目标弹窗的计数/刷屏素材。')
lines.append('- `gameplay_shuaping2`：101_in–106_in，关卡编号 101–106 的入场动画。')
lines.append('- `gameplay_xingxing_g`：blue/green/orange/purple/red/yellow，6 色宝石呼吸。')
lines.append('- `Jingziqi_qizi(_v2)`：O/X 的 chuxian（出现）/ idle（待机）/ shengli（胜利）/ shengli_dikuang（胜利底框）；v2 另含 hong/lan 棋盘高亮。')
lines.append('- `gameplay_word`：1_dominated（三步完胜）、2_bigwin（四步胜利）。')
lines.append('- `watermelon_gamplay_combo`：blue_in/cyan_in/green_in/pink_in/purple_in，5 色连击。')
lines.append('- 水排序 skeleton/spineNew（62 动画）：`water_<n>_idle`（n=1~4 水位待机）、`boliping_<n>_kong`（空瓶）、`xg_water_daoru1/2 ±left/right`（倒水）、`xg_water_xuanzhe_0~4/_up`（选中高亮）、`xg_beijing_win`（胜利背景）、`xg_boliping_jieshuo1/2`（锁瓶解说）、`xg_boliping_liang1~4`（发光）、`xg_water_manping`（满瓶）、`xg_water_qipao1~4`（气泡）、`water_bowen_out1~4`（波纹）。')
lines.append('- 麻将：`Mahjong_Selected_V2`（选中，支持运行时动态替换骨架）、`mahjong_gameplay_tips`（可点击提示）、`Mahjong_Collosion_normal_V2`（普通消除）、`Mahjong_Collosion_combo_V2`（连击消除）、`Mahjong_Prophint_V2`（道具提示）、`Mahjong_AllComboEffect`（全连击）、`Mahjong_UIGroundEff`（界面地面）。')
lines.append('- 沙块：`pixel_sandCrush_gameplay_progressBar_efx`（分数进度条）、`pixel_sandCrush_gameplay_progressBar_goal_efx`（目标进度条）、`minimalist_sandCrush_gameplay_arrow`（升级箭头）、`gameplay_teaching_arrow`（教学箭头）。')
lines.append('')
lines.append('### 3. 重要代码证据（已解密脚本）')
lines.append('')
lines.append('- `gl_fruit/index.701f6.js`：`playBoardFullPanelEffect` / `playGoldWatermelonPanelEffect` / `playJuzhongdianzan` 播放函数；`lose_hint_fx` 对象池预加载；`fruitGraySpineName` 远程换灰皮（替换 SkeletonData）。')
lines.append('- `gl_mahjong/index.0ebe3.js`：`replaceSelectSkeletonData` 动态加载 `spine/Mahjong_Selected_V2` 替换选中特效；麻将牌组件 onLoad 获取 EffectSelected / EffectPropHint / EffectClickable 子节点 Skeleton。')
lines.append('- `gl_tictactoe/index.12707.js`：`boardAnimation.setAnimation(0, "shengli_qipangaoliang(_lan/_hong)", !1)`；GLTictactoeWinReward 按步数播放 1_dominated / 2_bigwin。')
lines.append('- `gl_hall/index.b5edb.js`：`tweenJingziqi`：win → 播 "win" + 平台胜利音效；lost → 播 "lost" + 失败音效；平局 → spineDraw 播 "in" 后延时隐藏。')
lines.append('- `gl_watersort/index.83b29.js`：按水量动态拼接 `water_<n>_idle` / `boliping_<n>_kong`；锁瓶播 `xg_boliping_jieshuo1`；含完成点赞控制器。')
lines.append('- `gl_sudoku/index.0e9fc.js`：EffectColorful 加载后 `setAnimation(0, "in_colorful", !1)`，播完销毁。')
lines.append('- `hsgame/index.f2d85.js`：预加载清单包含 sandcrush 两个进度条 Spine（progressBar_efx / progressBar_goal_efx）。')
lines.append('- `sandcrush/index.32ace.js`：进度条刷新与 `setProgressFullCallback` 逻辑。')
lines.append('')
lines.append('### 4. 复用 / 换皮注意点')
lines.append('')
lines.append('- 主玩法 trait 的用途来自“trait 名 + 预制体名 + 动画名”推断，主包脚本未解密，直接复用前建议在游戏内实际验证。')
lines.append('- `NewUserEarlyRoundsBoardTrait/board1/gameplay_xinshou` 无任何预制体引用，bundle 内仅此骨架，必须由脚本按 bundle 加载；换皮时需连同代码里的加载路径一起改。')
lines.append('- `AdSubScribePopModelTrait/dragonBones/` 目录名容易误导，实际是 Spine 骨架（不是 DragonBones）。')
lines.append('- `sandcrush` 的两个进度条 Spine 被 `sand_mini` 预制体跨 bundle 引用，打包/换皮时两个 bundle 都要保留。')
lines.append('- `Mahjong_Selected_V2` 存在运行时动态替换骨架的逻辑，替换后 SkeletonData 与 premultipliedAlpha 会被代码覆盖，导出动画名需保持 `idle`/`in` 不变。')
lines.append('- 水排序的动画名由代码按水量动态拼接，新增瓶数/水位需按 `water_<n>_idle`、`boliping_<n>_kong` 命名规则扩展。')
lines.append('')

out = '\n'.join(lines)
with open(r'E:\codex_apk_work\spine动效用途清单.md', 'w', encoding='utf-8') as f:
    f.write(out)
print('written', len(out), 'chars')
