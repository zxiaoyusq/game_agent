param(
  [string]$Chrome = "C:\Program Files\Google\Chrome\Application\chrome.exe",
  [string]$OutDir = "E:\codex_apk_work\shots"
)

$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

function Get-FileUrl([string]$Path) {
  $uri = [System.Uri]::new($Path)
  return $uri.AbsoluteUri
}

$refHtml = "E:\参考图\block录屏\解包素材\BlastBlock-美术资源全量-20260810\blast-block-spine\preview.html"
$ourHtml = "E:\参考图\block录屏\解包素材\BlastBlock-美术资源全量-20260810\材质皮肤-远程bundle-20260810\spine-preview\preview.html"

$jobs = @(
  @{ Name = "ref_g0";  Url = (Get-FileUrl $refHtml) + "?g=0" },
  @{ Name = "our_g0";  Url = (Get-FileUrl $ourHtml) + "?g=0" },
  @{ Name = "our_g2";  Url = (Get-FileUrl $ourHtml) + "?g=2" },
  @{ Name = "our_g44"; Url = (Get-FileUrl $ourHtml) + "?g=44" },
  @{ Name = "our_g106"; Url = (Get-FileUrl $ourHtml) + "?g=106" },
  @{ Name = "our_g275"; Url = (Get-FileUrl $ourHtml) + "?g=275" },
  @{ Name = "our_g349"; Url = (Get-FileUrl $ourHtml) + "?g=349" }
)

$idx = 0
foreach ($j in $jobs) {
  $idx++
  $profile = Join-Path $OutDir ("profile_" + $j.Name)
  $png = Join-Path $OutDir ($j.Name + ".png")
  $args = @(
    "--headless=new",
    "--window-size=1280,800",
    "--hide-scrollbars",
    "--virtual-time-budget=10000",
    "--screenshot=$png",
    ("--user-data-dir=" + $profile),
    $j.Url
  )
  $null = & $Chrome @args 2>&1
  if (Test-Path $png) {
    $r = & "E:\codex_apk_work\scripts\analyze_png.ps1" -Path $png
    Write-Output ("== " + $j.Name + " ==")
    Write-Output $r
  } else {
    Write-Output ("== " + $j.Name + " : NO SCREENSHOT ==")
  }
}
