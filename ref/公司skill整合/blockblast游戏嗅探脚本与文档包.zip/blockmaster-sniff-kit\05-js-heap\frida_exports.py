#!/usr/bin/env python3
"""List exports of libcocos2djs.so matching keywords."""
import frida
import sys

JS = r"""
'use strict';
function listExports(keywords) {
    var mod = Process.findModuleByName('libcocos2djs.so');
    if (!mod) return {err: 'module not found'};
    var out = [];
    var exps = mod.enumerateExports();
    exps.forEach(function (e) {
        var n = e.name;
        keywords.forEach(function (kw) {
            if (n.indexOf(kw) !== -1) {
                out.push({name: n, addr: e.address.toString()});
            }
        });
    });
    return out;
}
rpc.exports = { listExports: listExports };
"""

PID = int(sys.argv[1]) if len(sys.argv) > 1 else 5829
KEYWORDS = ["Compile", "compile", "Evaluate", "Evaluate", "XDR", "Decode", "decode", "Script", "Eval", "eval", "StringToCompile", "UTF8", "Utf8"]

dev = frida.get_device_manager().add_remote_device('127.0.0.1:27042')
session = dev.attach(PID)
script = session.create_script(JS)
script.load()
out = script.exports_sync.list_exports(KEYWORDS)
if isinstance(out, dict) and "err" in out:
    print(out)
else:
    print("exports:", len(out))
    for e in out:
        print(e["addr"], e["name"])
session.detach()
