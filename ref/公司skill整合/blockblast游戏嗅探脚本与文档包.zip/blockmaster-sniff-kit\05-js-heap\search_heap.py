#!/usr/bin/env python3
"""Search heap dumps for UTF-16LE anchor strings; dump context around hits."""
import os

HEAP_FILES = [
    r"E:\codex_apk_work\memdump\heap\0x3030001c0000_7200000.bin",
    r"E:\codex_apk_work\memdump\heap\0x303007740000_2ec0000.bin",
    r"E:\codex_apk_work\memdump\heap\0x30300adc0000_180000.bin",
]

ANCHORS = {
    "window.__require": "window.__require",
    "System.register": "System.register",
    "cc.sys": "cc.sys",
    "use strict": "use strict",
    "cocos2d-jsb": "cocos2d-jsb",
    "Atomengine": "Atomengine",
}

CTX = 0x8000  # 32KB before and after


def find_all(hay, needle):
    out = []
    start = 0
    while True:
        i = hay.find(needle, start)
        if i < 0:
            break
        out.append(i)
        start = i + 1
    return out


def main():
    total = 0
    for path in HEAP_FILES:
        if not os.path.exists(path):
            print("missing", path)
            continue
        raw = open(path, "rb").read()
        print("===", os.path.basename(path), len(raw))
        for name, anchor in ANCHORS.items():
            needle = anchor.encode("utf-16-le")
            hits = find_all(raw, needle)
            print("  ", name, "UTF16 hits:", len(hits))
            for h in hits[:5]:
                lo = max(0, h - CTX)
                hi = min(len(raw), h + len(needle) + CTX)
                out_path = r"E:\codex_apk_work\memdump\ctx_%s_%s_%x.bin" % (os.path.basename(path)[:8], name, h)
                with open(out_path, "wb") as f:
                    f.write(raw[lo:hi])
                print("     wrote", out_path)
                total += 1
    print("total context files:", total)


if __name__ == "__main__":
    main()
