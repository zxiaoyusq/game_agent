# -*- coding: utf-8 -*-
"""Delete mini-game art/program bundles and More Games popup-list bundles
from both stage2_sdk and stage2_lite apktool projects.
"""
import os
import shutil

WORK = r'E:\codex_apk_work\blockmaster_pro_swap\work'
PROJECTS = ['stage2_sdk', 'stage2_lite']

# Directories under assets/assets that belong to mini-games / More Games popup.
TARGETS = [
    'jewel',
    'CommonGameEntrance1Trait',
    'CommonGameEntrance1SetupTrait',
    'CommonGameListTrait',
    'CommonGameListDependenciesTrait',
    'CommonGameListUI2Trait',
    'CommonGameListUI2BlockFlowExTrait',
    'CommonGameListUI2PixelArtExTrait',
    'ChangeMoreGamesDoubleColTrait',
    'CampaignAcceptFirstLaunchToMiniGameTrait',
    'GameOverShowMiniGameIconTrait',
    'JewelGameReturnOptimizeTrait',
    'JewelGameUnlockEncourageTrait',
    'MiniGameEnterChangeColorTrait',
    'MiniGameMainEnterChangeColorTrait',
    'MiniGameReturnNavigationTrait',
    'MiniGameSetEnterChangeColorTrait',
    'MiniGameSetShowProgressTrait',
    'MiniGameSpeedUpTrait',
]

def main():
    for proj in PROJECTS:
        roots = [
            os.path.join(WORK, proj, 'assets', 'assets'),
            os.path.join(WORK, proj, 'assets', 'remote_seed', 'patch', 'patch', 'assets'),
        ]
        removed = []
        for root in roots:
            for name in TARGETS:
                path = os.path.join(root, name)
                if os.path.isdir(path):
                    size = sum(os.path.getsize(os.path.join(dp, f)) for dp, _, fs in os.walk(path) for f in fs)
                    shutil.rmtree(path)
                    removed.append((os.path.relpath(path, os.path.join(WORK, proj)), size))
                    print('removed', os.path.join(proj, os.path.relpath(path, os.path.join(WORK, proj))), size)
        print(proj, 'removed', len(removed), 'dirs')

if __name__ == '__main__':
    main()