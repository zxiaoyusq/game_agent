﻿'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810';
const NAMED = path.join(ROOT, 'named');
const SPINE_LIB = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/blast-block-spine/lib/spine-player.js';
const spineSrc = fs.readFileSync(SPINE_LIB, 'utf8');
const sandbox = {
  console, setTimeout, clearTimeout, setInterval, clearInterval,
  window: {}, document: {}, navigator: { userAgent: 'node' },
  atob: (b64) => Buffer.from(b64, 'base64').toString('latin1'),
  btoa: (s) => Buffer.from(s, 'latin1').toString('base64'),
  TextEncoder, TextDecoder,
  ArrayBuffer, DataView, Uint8Array, Uint16Array, Uint32Array,
  Int8Array, Int16Array, Int32Array, Float32Array, Float64Array,
  Math, JSON, Object, Array, Date, String, Number, Boolean,
  Error, TypeError, RangeError, Map, Set, parseFloat, parseInt, isNaN, isFinite,
};
vm.createContext(sandbox);
vm.runInContext(spineSrc, sandbox, { filename: 'spine-player.js' });

let binPath = null;
(function walk(d) {
  for (const de of fs.readdirSync(d, { withFileTypes: true })) {
    const p = path.join(d, de.name);
    if (de.isDirectory()) walk(p);
    else if (de.name === 'gameplay_word_011.bin') binPath = p;
  }
})(path.join(NAMED, 'Remote_Skin_Material_3011'));
sandbox.binB64 = fs.readFileSync(binPath).toString('base64');

const sim = `
(function(){
  function b64ToU8(b64){ var bin=atob(b64); var u=new Uint8Array(bin.length);
    for(var i=0;i<bin.length;i++) u[i]=bin.charCodeAt(i); return u; }
  function dummyRegion(){ return { u:0, v:0, u2:1, v2:1, originalWidth:1, originalHeight:1, offsetX:0, offsetY:0, width:1, height:1, rotate:false }; }
  var loader = {
    newRegionAttachment: function(skin,name,p){ var a=new spine.RegionAttachment(p||name); a.region=dummyRegion(); return a; },
    newMeshAttachment: function(skin,name,p){ var a=new spine.MeshAttachment(p||name); a.region=dummyRegion(); return a; },
    newBoundingBoxAttachment: function(skin,name){ return new spine.BoundingBoxAttachment(name); },
    newClippingAttachment: function(skin,name){ return new spine.ClippingAttachment(name); },
    newPathAttachment: function(skin,name){ return new spine.PathAttachment(name); },
    newPointAttachment: function(skin,name){ return new spine.PointAttachment(name); }
  };
  var sd = new spine.SkeletonBinary(loader).readSkeletonData(b64ToU8(binB64));
  var sk = new spine.Skeleton(sd);
  sk.setSkinByName('default');
  sk.setToSetupPose();
  var sd2 = new spine.AnimationStateData(sd);
  var st = new spine.AnimationState(sd2);
  st.setAnimation(0, sd.animations[0].name, false);
  st.update(sd.animations[0].duration / 2);
  st.apply(sk);
  sk.updateWorldTransform();
  var out = { nRegion: 0, nMesh: 0, nNaN: 0, minX: 1e9, minY: 1e9, maxX: -1e9, maxY: -1e9, meshSample: null };
  var temp = new Array(2);
  for (var i=0;i<sk.drawOrder.length;i++){
    var slot = sk.drawOrder[i];
    if (!slot.bone.active) continue;
    var att = slot.getAttachment();
    if (att instanceof spine.RegionAttachment){
      out.nRegion++;
      var vs = spine.Utils.setArraySize(temp, 8, 0);
      att.computeWorldVertices(slot.bone, vs, 0, 2);
      for (var v=0;v<8;v+=2){
        var x=vs[v], y=vs[v+1];
        if (!isFinite(x) || !isFinite(y)) { out.nNaN++; continue; }
        out.minX=Math.min(out.minX,x); out.minY=Math.min(out.minY,y);
        out.maxX=Math.max(out.maxX,x); out.maxY=Math.max(out.maxY,y);
      }
    } else if (att instanceof spine.MeshAttachment){
      out.nMesh++;
      if (!out.meshSample){
        var mv = spine.Utils.setArraySize(new Array(2), att.worldVerticesLength, 0);
        att.computeWorldVertices(slot, 0, att.worldVerticesLength, mv, 0, 2);
        out.meshSample = { slot: slot.data.name, worldVerts: Array.prototype.slice.call(mv, 0, 12) };
      }
    }
  }
  out.bounds = [out.minX, out.minY, out.maxX - out.minX, out.maxY - out.minY];
  return out;
})();
`;
const out = vm.runInContext(sim, sandbox);
console.log(JSON.stringify(out, null, 1));
