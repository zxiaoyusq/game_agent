# -*- coding: utf-8 -*-
"""Patch Athena referrer appId 4987 -> 5943 in bm_rebuilt_dex_clean/classes2.dex."""
import hashlib
import os
import struct
import zlib

DEX = r'E:\codex_apk_work\blockmaster_pro_swap\work\bm_rebuilt_dex_clean\classes2.dex'
OFFSET = 0x6585b4
OLD_BYTES = bytes([0x13, 0x06, 0x7b, 0x13])
NEW_BYTES = bytes([0x13, 0x06, 0x37, 0x17])


def recompute_dex(data):
    data = bytearray(data)
    # zero checksum + signature
    data[0x08:0x0C] = b'\x00' * 4
    data[0x0C:0x20] = b'\x00' * 20
    # signature = SHA1 of bytes from 0x20 to end
    sig = hashlib.sha1(data[0x20:]).digest()
    data[0x0C:0x20] = sig
    # checksum = Adler32 of bytes from 0x0C to end (after zeroing checksum)
    checksum = zlib.adler32(data[0x0C:]) & 0xffffffff
    data[0x08:0x0C] = struct.pack('<I', checksum)
    return bytes(data)


def main():
    with open(DEX, 'rb') as f:
        data = f.read()
    if data[OFFSET:OFFSET+4] != OLD_BYTES:
        print('ERROR: expected bytes not found at offset', hex(OFFSET))
        print('got', data[OFFSET:OFFSET+4].hex())
        raise SystemExit(1)
    data = data[:OFFSET] + NEW_BYTES + data[OFFSET+4:]
    data = recompute_dex(data)
    with open(DEX, 'wb') as f:
        f.write(data)
    print('patched', DEX, '4987 -> 5943')
    # verify
    with open(DEX, 'rb') as f:
        data = f.read()
    print('offset now', data[OFFSET:OFFSET+4].hex())


if __name__ == '__main__':
    main()
