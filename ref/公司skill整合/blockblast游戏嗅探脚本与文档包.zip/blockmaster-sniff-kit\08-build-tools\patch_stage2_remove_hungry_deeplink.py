# -*- coding: utf-8 -*-
"""C3: remove HungryStudio web deep link intent-filter from AndroidManifest."""
import io

MANIFEST = r'E:\codex_apk_work\blockmaster_pro_swap\work\stage2_sdk\AndroidManifest.xml'

def main():
    with io.open(MANIFEST, encoding='utf-8') as f:
        s = f.read()
    block = '''            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.VIEW"/>
                <category android:name="android.intent.category.DEFAULT"/>
                <category android:name="android.intent.category.BROWSABLE"/>
                <data android:scheme="https"/>
                <data android:host="www.hungrystudio.com"/>
                <data android:pathPrefix="/blockblast/gp/apphome"/>
            </intent-filter>
'''
    assert block in s, 'hungrystudio deep link block missing'
    s = s.replace(block, '')
    with io.open(MANIFEST, 'w', encoding='utf-8', newline='\r\n') as f:
        f.write(s)
    print('removed HungryStudio deep link')
    assert 'www.hungrystudio.com' not in s

if __name__ == '__main__':
    main()
