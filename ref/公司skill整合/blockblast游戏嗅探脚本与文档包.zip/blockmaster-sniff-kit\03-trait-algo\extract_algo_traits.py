# -*- coding: utf-8 -*-
"""Scan heap-dump JS string runs for the main algorithm & Trait system.

Extracts:
  - classId("...") registrations (Trait classes + all classes)
  - OFFER_TYPE enum members and usage sites
  - algorithm-related identifiers
  - code windows around named core algorithm classes
"""
import os
import re
import json
import collections

ROOT = r"E:\codex_apk_work\memdump\js_strings"
OUT = r"E:\codex_apk_work\main_algo_extract"

CLASSID_RE = re.compile(r'classId\(\s*"([^"]+)"\s*\)')
OFFER_ASSIGN_RE = re.compile(r'e\[e\.([A-Z0-9_]+)\s*=\s*(-?\d+)\]\s*=\s*"([A-Z0-9_]+)"')
ALGO_ID_RE = re.compile(
    r"\b[A-Za-z_][A-Za-z0-9_]*(?:Algorithm|Algo|Strategy|StrategyLogic|Trait|Entropy|UCB|LightGBM|PileUp|BlockPool)[A-Za-z0-9_]*\b"
)

# Named core algorithm classes to pull code windows for
TARGETS = [
    "AlgoFillSortEdge", "EntropyIncreaseBeforeFill", "RandomNoDeath",
    "AlgoSeekGreat", "UCBBlockPoolStrategy", "LightGBMAlgorithmStrategy",
    "AlgorithmStrategyLogic", "RandomAlgorithmStrategyDistributionWithRoundTrait",
    "applyReplaceAlgorithmV3", "findPileUpPos", "canPutBlock",
    "BinarySupport", "insertAlgorithms",
]


def main():
    class_ids = collections.Counter()
    offer_enum = {}
    algo_ids = collections.Counter()
    windows = {t: [] for t in TARGETS}
    module_refs = []

    files = sorted(f for f in os.listdir(ROOT) if f.endswith(".js"))
    for fn in files:
        path = os.path.join(ROOT, fn)
        with open(path, encoding="utf-8", errors="ignore") as fh:
            txt = fh.read()
        for m in CLASSID_RE.finditer(txt):
            class_ids[m.group(1)] += 1
        for m in OFFER_ASSIGN_RE.finditer(txt):
            offer_enum[m.group(1)] = int(m.group(2))
        for m in ALGO_ID_RE.finditer(txt):
            algo_ids[m.group(0)] += 1
        for m in re.finditer(r'cc\._RF\.push\(\s*[^,]+,\s*"([^"]+)"', txt):
            module_refs.append(m.group(1))
        for name in TARGETS:
            for m in re.finditer(re.escape(name), txt):
                s = max(0, m.start() - 1200)
                e = min(len(txt), m.end() + 2500)
                windows[name].append((fn, txt[s:e]))

    os.makedirs(OUT, exist_ok=True)

    with open(os.path.join(OUT, "class_ids_all.json"), "w", encoding="utf-8") as fh:
        json.dump(class_ids, fh, ensure_ascii=False, indent=1, sort_keys=True)

    trait_classes = {k: v for k, v in class_ids.items() if k.endswith("Trait")}
    with open(os.path.join(OUT, "trait_classes.json"), "w", encoding="utf-8") as fh:
        json.dump(trait_classes, fh, ensure_ascii=False, indent=1, sort_keys=True)

    with open(os.path.join(OUT, "offer_enum_full.json"), "w", encoding="utf-8") as fh:
        json.dump(offer_enum, fh, ensure_ascii=False, indent=1, sort_keys=True)

    with open(os.path.join(OUT, "algo_identifiers.json"), "w", encoding="utf-8") as fh:
        json.dump(algo_ids, fh, ensure_ascii=False, indent=1, sort_keys=True)

    with open(os.path.join(OUT, "code_windows.json"), "w", encoding="utf-8") as fh:
        json.dump(windows, fh, ensure_ascii=False, indent=1)

    print("classIds:", len(class_ids), "trait classes:", len(trait_classes))
    print("OFFER_TYPE members:", len(offer_enum))
    print("algo identifiers:", len(algo_ids))
    for name, w in windows.items():
        print(f"  windows[{name}] = {len(w)}")


if __name__ == "__main__":
    main()
