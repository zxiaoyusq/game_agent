# -*- coding: utf-8 -*-
"""Add Block Master Firebase resource strings to stage2_sdk."""
import io, os

WORK = r'E:\codex_apk_work\blockmaster_pro_swap\work'
STRINGS = os.path.join(WORK, 'stage2_sdk', 'res', 'values', 'strings.xml')
PUBLIC = os.path.join(WORK, 'stage2_sdk', 'res', 'values', 'public.xml')

entries = [
    ('gcm_defaultSenderId', '638272297170', 0x7f14037d),
    ('google_api_key', 'AIzaSyA_9Y_NTqDWhAh5J8HhoeOPqcjmhgpHjqw', 0x7f14037e),
    ('google_app_id', '1:638272297170:android:ab8c495238a3d5b85fb50b', 0x7f14037f),
    ('google_crash_reporting_api_key', 'AIzaSyA_9Y_NTqDWhAh5J8HhoeOPqcjmhgpHjqw', 0x7f140380),
    ('google_storage_bucket', 'crushblock-b58ab.firebasestorage.app', 0x7f140381),
    ('project_id', 'crushblock-b58ab', 0x7f140382),
]

with io.open(STRINGS, 'r', encoding='utf-8') as f:
    s = f.read()
missing = [name for name, _, _ in entries if ('name="%s"' % name) not in s]
if missing:
    block = '\n' + '\n'.join('    <string name="%s">%s</string>' % (n, v) for n, v, _ in entries) + '\n'
    idx = s.rstrip().rfind('</resources>')
    s = s[:idx].rstrip() + '\n' + block + s[idx:]
    with io.open(STRINGS, 'w', encoding='utf-8') as f:
        f.write(s)
    print('strings.xml: added', len(entries))
else:
    print('strings.xml: all present')

with io.open(PUBLIC, 'r', encoding='utf-8') as f:
    p = f.read()
missing = [name for name, _, _ in entries if ('name="%s"' % name) not in p]
if missing:
    block = '\n' + '\n'.join('    <public type="string" name="%s" id="0x%08x" />' % (n, rid) for n, _, rid in entries) + '\n'
    idx = p.rstrip().rfind('</resources>')
    p = p[:idx].rstrip() + '\n' + block + p[idx:]
    with io.open(PUBLIC, 'w', encoding='utf-8') as f:
        f.write(p)
    print('public.xml: added', len(entries))
else:
    print('public.xml: all present')
