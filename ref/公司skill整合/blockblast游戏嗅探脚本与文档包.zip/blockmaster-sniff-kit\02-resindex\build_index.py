#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""resindex build - 把本项目所有美术资源索引汇总成一个 sqlite 库。

用法:
    python -X utf8 resindex/build_index.py            # 增量（表已存在则重建）
    python -X utf8 resindex/build_index.py --stats    # 只打印统计

索引来源（缺哪个就跳过哪个，不报错）:
  1) cocos-bundle : 任意 <root>/<bundle>/cc.config.json  -> uuid/paths/packs + native 文件
  2) ui-manifest  : blast-block-extra/ui_manifest.json   -> 图集子图 / prefab / scene / 纹理 / 字体 / 音频 / lottie
  3) skins        : 皮肤包 skins_report.json + named/ 目录树 -> 每个远程皮肤的每个资源
  4) apk          : *.apk 的 zip 条目（原版包内的 assets/assets/<bundle>/...）
  5) files        : 参考图全局盘点 manifest.csv
  6) docs         : 项目里的 *.md 结论文档

设计原则：**能查到"资源名 -> uuid -> 落盘文件（含加密标记）"这条链**，
其余交给 resindex.py 的 find/get/uuid/extract 去用。
"""
import base64
import csv
import io
import json
import os
import sqlite3
import sys
import time
import zipfile

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "resindex.db")
META = os.path.join(HERE, "index_meta.json")

# --------------------------------------------------------------------------- #
# 路径配置：全部为"软配置"，不存在的自动跳过
# --------------------------------------------------------------------------- #
REF = r"E:\参考图"
BLOCK_REF = os.path.join(REF, "block录屏")
BLAST_PACK = os.path.join(BLOCK_REF, "解包素材", "BlastBlock-美术资源全量-20260810")
BLAST_EXTRA = os.path.join(BLAST_PACK, "blast-block-extra")
SKIN_PACK = os.path.join(BLAST_PACK, "材质皮肤-远程bundle-20260810")

COCOS_BUNDLE_ROOTS = [
    r"E:\codex_apk_work\blockmaster_apk\apk\assets\assets",   # Block Master (res-game/res-lobby...)
]
APKS = [
    r"E:\codex_apk_work\bb_1047_base.apk",
    r"E:\codex_apk_work\com.block.juggle.base.apk",
    r"E:\codex_apk_work\apks\com.block.juggle\base.apk",
]
DOC_ROOTS = [
    r"E:\codex_apk_work",
    r"E:\codex_apk_work\blockblast_规范文档",
    BLAST_PACK,
    SKIN_PACK,
    os.path.join(REF, "_索引"),
]

KIND_BY_CLASS = {
    "cc.SpriteFrame": "spriteFrame",
    "cc.Texture2D": "texture",
    "cc.ImageAsset": "imageAsset",
    "cc.Prefab": "prefab",
    "cc.AnimationClip": "animClip",
    "cc.Material": "material",
    "sp.SkeletonData": "spineData",
    "cc.TextAsset": "textAsset",
}


def log(*a):
    print("[build]", *a, flush=True)


def connect():
    con = sqlite3.connect(DB)
    con.execute("PRAGMA journal_mode=OFF")
    con.execute("PRAGMA synchronous=OFF")
    return con


def init_schema(con):
    con.executescript(
        """
        DROP TABLE IF EXISTS assets;
        CREATE TABLE assets (
            id      INTEGER PRIMARY KEY,
            src     TEXT,   -- cocos-bundle / ui-manifest / skins / apk / files / docs
            kind    TEXT,   -- spriteFrame / subimage / prefab / native / apk-entry / file / doc ...
            bundle  TEXT,   -- res-game / resources / Remote_Skin_Material_4036 / apk 名
            name    TEXT,   -- 资源名 / 文件名
            path    TEXT,   -- 逻辑资源路径（images/ui/common/BG_01）或相对路径
            uuid    TEXT,   -- 任意形态 uuid（含 @f9941/@6c48a 后缀）
            file    TEXT,   -- 本机落盘文件（可直接打开/解密），无则空
            native  TEXT,   -- 猜到的像素文件（图片本体）
            size    INTEGER,
            enc     TEXT,   -- '' / HEK / gzip / apk:<zip>
            note    TEXT
        );
        """
    )
    con.commit()


def emit(con, rows):
    con.executemany(
        "INSERT INTO assets(src,kind,bundle,name,path,uuid,file,native,size,enc,note)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        rows,
    )


# --------------------------------------------------------------------------- #
# uuid / 解密小工具（build 期用）
# --------------------------------------------------------------------------- #
def decompress_uuid(u):
    """Cocos 压缩 uuid -> 32 位 hex；失败返回 ''。"""
    try:
        s = u.replace("-", "+").replace("_", "/")
        pad = "=" * ((4 - len(s) % 4) % 4)
        return base64.b64decode(s[:22] + pad).hex()
    except Exception:
        return ""


def sniff_enc(path):
    try:
        with open(path, "rb") as f:
            h = f.read(8)
    except Exception:
        return ""
    if h.startswith(b"HEK:"):
        return "HEK"
    if h[:2] == b"\x1f\x8b":
        return "gzip"
    return ""


def is_image_ext(ext):
    return ext.lower() in (".png", ".jpg", ".jpeg", ".webp", ".pkm")


# --------------------------------------------------------------------------- #
# 1) Cocos bundle（cc.config.json）
# --------------------------------------------------------------------------- #
SUFFIX_TYPES = {"spriteFrame", "texture", "imageAsset", "asset", "text"}


def resource_name(rel):
    """images/ui/common/BG_01/spriteFrame -> BG_01（子资源用父级名，便于按名字搜）"""
    parts = [x for x in rel.rstrip("/").split("/") if x]
    if len(parts) >= 2 and parts[-1] in SUFFIX_TYPES:
        return parts[-2]
    return parts[-1] if parts else rel


def scan_cocos_bundles(con, counters):
    for root in COCOS_BUNDLE_ROOTS:
        if not os.path.isdir(root):
            continue
        for bundle in sorted(os.listdir(root)):
            bdir = os.path.join(root, bundle)
            cfg = os.path.join(bdir, "cc.config.json")
            if not os.path.isfile(cfg):
                continue
            try:
                d = json.load(io.open(cfg, encoding="utf-8"))
            except Exception as e:
                log("skip cfg", cfg, e)
                continue
            uuids = d.get("uuids", [])
            paths = d.get("paths", {})
            packs = d.get("packs", {})
            types = d.get("types", [])
            idx2pack = {}
            for pk, idxs in packs.items():
                for i in idxs:
                    idx2pack.setdefault(i, []).append(pk)

            # native 文件名 -> 路径，用于给 spriteFrame 猜像素文件
            native_by_stem = {}
            ndir = os.path.join(bdir, "native")
            for dp, _dn, fn in os.walk(ndir):
                for f in fn:
                    native_by_stem[os.path.splitext(f)[0].lower()] = os.path.join(dp, f)

            rows = []
            for k, v in paths.items():
                i = int(k)
                if i >= len(uuids):
                    continue
                rel = str(v[0])
                cls = types[v[1]] if isinstance(v, list) and len(v) > 1 and v[1] < len(types) else ""
                kind = KIND_BY_CLASS.get(cls, "asset")
                base = uuids[i].split("@")[0]
                imp = ""
                pk = idx2pack.get(i, [])
                if pk:
                    imp = os.path.join(bdir, "import", pk[0][:2], pk[0] + ".json")
                    if not os.path.isfile(imp):
                        imp = ""
                nat = native_by_stem.get(base.lower(), "")
                if not nat:
                    hx = decompress_uuid(base)
                    if hx:
                        nat = native_by_stem.get(hx, "") or native_by_stem.get(hx[:9], "")
                rows.append((
                    "cocos-bundle", kind, bundle,
                    resource_name(rel), rel, uuids[i],
                    imp, nat, 0,
                    sniff_enc(nat) if nat else "",
                    cls,
                ))
                counters[kind] = counters.get(kind, 0) + 1

            # native 原图本身也入索引（可按文件名搜）
            for dp, _dn, fn in os.walk(ndir):
                for f in fn:
                    p = os.path.join(dp, f)
                    rows.append((
                        "cocos-bundle", "native", bundle, f,
                        os.path.relpath(p, bdir), "", p, p,
                        os.path.getsize(p), sniff_enc(p), "",
                    ))
                    counters["native"] = counters.get("native", 0) + 1
            emit(con, rows)
            log("bundle", bundle, len(rows), "rows")


# --------------------------------------------------------------------------- #
# 2) ui_manifest.json（BlastBlock-extra 全量清单）
# --------------------------------------------------------------------------- #
def scan_ui_manifest(con, counters):
    mp = os.path.join(BLAST_EXTRA, "ui_manifest.json")
    if not os.path.isfile(mp):
        return
    d = json.load(io.open(mp, encoding="utf-8"))
    atlas_dir = os.path.join(BLAST_EXTRA, "sprite_atlas")
    # 清单里的 file 只是文件名，实际散落在 prefabs/ scenes/ textures/native/ fonts/ ... 里
    filemap = {}
    for dp, _dn, fn in os.walk(BLAST_EXTRA):
        for f in fn:
            filemap.setdefault(f, os.path.join(dp, f))

    def locate(rel):
        if not rel:
            return ""
        b = os.path.basename(rel.replace("\\", "/"))
        p = filemap.get(b, "")
        if p and os.path.isfile(p):
            return p
        p = os.path.join(atlas_dir, b)
        return p if os.path.isfile(p) else ""

    rows = []
    for sa in d.get("sprite_atlases", []):
        bundle, atlas = sa.get("bundle", ""), sa.get("atlas", "")
        for si in sa.get("subimages", []):
            f = locate(si.get("png", ""))
            rows.append((
                "ui-manifest", "subimage", bundle, str(si.get("name", "")),
                f"{bundle}/{atlas}/{si.get('name','')}", f"{bundle}/{atlas}",
                f, f if is_image_ext(os.path.splitext(f)[1]) else "",
                os.path.getsize(f) if f else 0, "",
                json.dumps({"rect": si.get("rect"), "orig": si.get("originalSize"),
                            "texture_uuid": si.get("texture_uuid")}, ensure_ascii=False),
            ))
            counters["subimage"] = counters.get("subimage", 0) + 1
    for key, kind in (("prefabs", "prefab"), ("scenes", "scene"), ("textures", "texture"),
                      ("fonts", "font"), ("bitmap_fonts", "bitmapFont"),
                      ("label_atlases", "labelAtlas"), ("audio", "audio"),
                      ("animclips", "animClip")):
        for it in d.get(key, []) or []:
            if not isinstance(it, dict):
                continue
            f = locate(it.get("file", ""))
            rows.append((
                "ui-manifest", kind, it.get("bundle", ""), str(it.get("name", "")),
                str(it.get("file", "") or it.get("uuid", "")), str(it.get("uuid", "")),
                f, f if is_image_ext(os.path.splitext(f)[1]) else "",
                os.path.getsize(f) if f else 0, sniff_enc(f) if f else "", "",
            ))
            counters[kind] = counters.get(kind, 0) + 1
    emit(con, rows)
    log("ui_manifest", len(rows), "rows")


# --------------------------------------------------------------------------- #
# 3) 远程皮肤包
# --------------------------------------------------------------------------- #
def scan_skins(con, counters):
    rp = os.path.join(SKIN_PACK, "skins_report.json")
    rows = []
    if os.path.isfile(rp):
        d = json.load(io.open(rp, encoding="utf-8"))
        for bundle, info in d.items():
            for a in info.get("assets", []):
                rel = a.get("file", "")
                f = os.path.join(SKIN_PACK, "raw", rel) if rel else ""
                f2 = os.path.join(SKIN_PACK, "dec", rel)
                f3 = os.path.join(SKIN_PACK, "named", rel)
                use = f3 if os.path.isfile(f3) else (f2 if os.path.isfile(f2) else (f if os.path.isfile(f) else ""))
                rows.append((
                    "skins", "skin-res", bundle, a.get("path", "").rstrip("/").split("/")[-1],
                    a.get("path", ""), "", use, use if is_image_ext(os.path.splitext(use)[1]) else "",
                    os.path.getsize(use) if use and os.path.isfile(use) else 0,
                    sniff_enc(use) if use and os.path.isfile(use) else "",
                    f'{a.get("type","")} material={info.get("material")}',
                ))
                counters["skin-res"] = counters.get("skin-res", 0) + 1
    # named/ 目录树（含 report 未列到的 misc）
    named = os.path.join(SKIN_PACK, "named")
    seen = set()
    for dp, _dn, fn in os.walk(named):
        for f in fn:
            p = os.path.join(dp, f)
            rel = os.path.relpath(p, named)
            parts = rel.split(os.sep)
            bundle = parts[0]
            sub = parts[1] if len(parts) > 2 else ""
            key = (bundle, f)
            if key in seen:
                continue
            seen.add(key)
            rows.append((
                "skins", "skin-file", bundle, f, rel, "", p,
                p if is_image_ext(os.path.splitext(f)[1]) else "",
                os.path.getsize(p), "", sub,
            ))
            counters["skin-file"] = counters.get("skin-file", 0) + 1
    emit(con, rows)
    log("skins", len(rows), "rows")


# --------------------------------------------------------------------------- #
# 4) APK zip 条目
# --------------------------------------------------------------------------- #
def scan_apks(con, counters):
    rows = []
    for apk in APKS:
        if not os.path.isfile(apk):
            continue
        apkname = os.path.basename(apk)
        try:
            z = zipfile.ZipFile(apk)
        except Exception as e:
            log("skip apk", apk, e)
            continue
        for n in z.namelist():
            if not n.startswith("assets/"):
                continue
            parts = n.split("/")
            bundle = parts[2] if len(parts) > 2 and parts[1] == "assets" else ""
            rows.append((
                "apk", "apk-entry", f"{apkname}:{bundle}", os.path.basename(n),
                n, "", "", "", 0, f"apk:{apk}", "",
            ))
            counters["apk-entry"] = counters.get("apk-entry", 0) + 1
    emit(con, rows)
    log("apk", len(rows), "rows")


# --------------------------------------------------------------------------- #
# 5) 全局参考图清单
# --------------------------------------------------------------------------- #
def scan_global_manifest(con, counters):
    mp = os.path.join(REF, "_索引", "_data", "manifest.csv")
    if not os.path.isfile(mp):
        return
    rows = []
    with io.open(mp, encoding="utf-8-sig", newline="") as fh:
        for r in csv.DictReader(fh):
            rel = r.get("RelPath", "")
            p = os.path.join(REF, rel)
            ok = os.path.isfile(p)
            ext = os.path.splitext(rel)[1]
            rows.append((
                "files", "file", r.get("Level2", "") or r.get("Top", ""),
                os.path.basename(rel), rel, "", p if ok else "",
                p if ok and is_image_ext(ext) else "",
                int(r.get("SizeBytes") or 0),
                "", r.get("Modified", ""),   # enc 留给 extract 时再探测（build 期不读文件，太慢）
            ))
            counters["file"] = counters.get("file", 0) + 1
    emit(con, rows)
    log("global-manifest", len(rows), "rows")


# --------------------------------------------------------------------------- #
# 6) 结论文档
# --------------------------------------------------------------------------- #
def scan_docs(con, counters):
    rows = []
    for root in DOC_ROOTS:
        if not os.path.isdir(root):
            continue
        for dp, dn, fn in os.walk(root):
            dn[:] = [x for x in dn if x not in ("node_modules", ".git", "__pycache__", ".pytest_cache", "resindex")]
            depth = os.path.relpath(dp, root).count(os.sep)
            if depth > 2:
                dn[:] = []
                continue
            for f in fn:
                if not f.lower().endswith((".md", ".txt")):
                    continue
                p = os.path.join(dp, f)
                rows.append((
                    "docs", "doc", "", f, os.path.relpath(p, root), "", p, "",
                    os.path.getsize(p), "", "",
                ))
                counters["doc"] = counters.get("doc", 0) + 1
    emit(con, rows)
    log("docs", len(rows), "rows")


# --------------------------------------------------------------------------- #
def main():
    t0 = time.time()
    # 上一次被中断可能留下坏库，直接删掉重建（索引可随时重建，无需保留）
    for f in (DB, DB + "-journal", DB + "-wal", DB + "-shm"):
        try:
            if os.path.exists(f):
                os.remove(f)
        except OSError:
            pass
    con = connect()
    init_schema(con)
    counters = {}
    for fn in (scan_cocos_bundles, scan_ui_manifest, scan_skins, scan_apks,
               scan_global_manifest, scan_docs):
        try:
            fn(con, counters)
        except Exception as e:
            log("ERROR in", fn.__name__, repr(e))
    con.execute("CREATE INDEX i_name ON assets(name COLLATE NOCASE)")
    con.execute("CREATE INDEX i_path ON assets(path COLLATE NOCASE)")
    con.execute("CREATE INDEX i_uuid ON assets(uuid)")
    con.execute("CREATE INDEX i_bundle ON assets(bundle COLLATE NOCASE)")
    con.execute("CREATE INDEX i_kind ON assets(kind)")
    con.commit()
    total = con.execute("SELECT COUNT(*) FROM assets").fetchone()[0]
    meta = {
        "built_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "db": DB,
        "rows": total,
        "by_kind": dict(con.execute("SELECT kind, COUNT(*) FROM assets GROUP BY kind ORDER BY 2 DESC").fetchall()),
        "by_src": dict(con.execute("SELECT src, COUNT(*) FROM assets GROUP BY src ORDER BY 2 DESC").fetchall()),
        "elapsed_sec": round(time.time() - t0, 1),
    }
    io.open(META, "w", encoding="utf-8").write(json.dumps(meta, ensure_ascii=False, indent=2))
    con.close()
    print(json.dumps(meta, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
