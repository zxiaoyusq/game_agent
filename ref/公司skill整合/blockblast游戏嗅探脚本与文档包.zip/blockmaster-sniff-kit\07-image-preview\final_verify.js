﻿'use strict';
const fs = require('fs');
const vm = require('vm');

const DIR = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810/spine-preview';
const HTML = DIR + '/preview.html';
const html = fs.readFileSync(HTML, 'utf8');

// 1. extract inline scripts and syntax-check them
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
console.log('inline scripts:', scripts.length);
let ok = 0;
for (let i = 0; i < scripts.length; i++) {
  try { new Function(scripts[i]); ok++; }
  catch (e) { console.log('SYNTAX ERROR script', i, ':', e.message); }
}
console.log('scripts syntax ok:', ok, '/', scripts.length);

// 2. patch script present?
console.log('has compat patch:', html.includes('byteMojibakeToUtf8') && html.includes('AtlasAttachmentLoader.prototype'));

// 3. multi-page atlas embedded twice?
const m = html.match(/const DATA = (\[[\s\S]*?\]);\r?\nlet cur = -1;/);
const DATA = JSON.parse(m[1]);
const summer = DATA.filter(d => d.name.includes('gameplay_word_summer_xin'));
for (const d of summer) {
  const atlasB64 = d.atlasUrl.split(',')[1];
  const text = new TextDecoder('utf-8').decode(Buffer.from(atlasB64, 'base64'));
  const imgCount = (text.match(/data:image\/png;base64,/g) || []).length;
  console.log(d.bundle + '/' + d.name, 'fmt=' + d.fmt, 'embedded images:', imgCount);
}

// 4. header stats present
const hd = html.match(/<span class="sub" id="hdStats"><\/span>/);
console.log('hdStats element present:', !!hd);

// 5. DATA vs spine_index.json
const idx = JSON.parse(fs.readFileSync(DIR + '/spine_index.json', 'utf8'));
console.log('DATA length:', DATA.length, 'index length:', idx.length);
let same = DATA.length === idx.length;
for (let i = 0; i < Math.min(DATA.length, idx.length); i++) {
  if (JSON.stringify(DATA[i]) !== JSON.stringify(idx[i])) { same = false; break; }
}
console.log('DATA == index json:', same);

// 6. entries with zero bounds
const zero = DATA.filter(d => !(d.bounds && d.bounds[2] > 0 && d.bounds[3] > 0));
console.log('entries with zero/invalid bounds (use default viewport):', zero.length);

// 7. anim/skin sanity
const noAnim = DATA.filter(d => !d.anims || !d.anims.length);
const noSkin = DATA.filter(d => !d.skins || !d.skins.length);
console.log('entries without anims:', noAnim.length, 'without skins:', noSkin.length);

// 8. file sizes
for (const f of ['preview.html', 'spine_index.json', 'spine_meta.json']) {
  console.log(f, (fs.statSync(DIR + '/' + f).size / 1024 / 1024).toFixed(1) + ' MB');
}
