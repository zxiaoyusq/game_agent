﻿# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding="utf-8")
target = [0xFFE6, 0xFFA4, 0xFFAD, 0xFFE5, 0xFF9C, 0xFF86]
s = "椭圆"
variants = {}
for ecodec in ("gbk", "cp936", "big5", "cp950", "cp949", "utf-8", "utf-16le", "utf-16be", "euc-kr"):
    try:
        b = s.encode(ecodec)
    except Exception as e:
        continue
    for dcodec in ("gbk", "cp936", "big5", "cp950", "cp949", "utf-8", "euc-kr"):
        try:
            out = b.decode(dcodec, errors="strict")
        except Exception:
            continue
        cps = [ord(c) for c in out]
        if cps == target:
            variants["%s->%s" % (ecodec, dcodec)] = out
        elif len(cps) == len(target):
            variants.setdefault("%s->%s" % (ecodec, dcodec), "diff:" + ",".join(hex(c) for c in cps))
for k, v in variants.items():
    print(k, "=>", v)
print("---- direct candidates ----")
for ecodec in ("gbk", "cp936", "big5", "cp950", "cp949", "utf-8", "euc-kr"):
    try:
        b = s.encode(ecodec)
        print(ecodec, b.hex())
    except Exception:
        pass
