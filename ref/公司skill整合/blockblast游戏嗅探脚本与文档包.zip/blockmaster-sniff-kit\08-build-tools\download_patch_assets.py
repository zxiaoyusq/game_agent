import concurrent.futures as cf
import hashlib
import json
import os
import sys
import urllib.request

MANIFEST = r"E:\codex_apk_work\blockmaster_pro_swap\work\device_project.manifest"
BASE = "https://bband1.afafb.com/update/block_android_online/remoteRes/0/remote/"
STAGE = r"E:\codex_apk_work\blockmaster_pro_swap\work\patch_fill\patch"

m = json.load(open(MANIFEST, encoding="utf-8"))
assets = m["assets"]

def md5_of(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()

pending = []
for key, info in assets.items():
    if info.get("downloadState") == 2:
        continue
    local = os.path.join(STAGE, key)
    if os.path.exists(local) and md5_of(local) == info.get("md5"):
        continue
    url = BASE + key[len("assets/"):]
    pending.append((key, url, info.get("md5"), info.get("size", 0)))

print(f"pending to download: {len(pending)}", flush=True)

def fetch(item):
    key, url, md5, size = item
    local = os.path.join(STAGE, key)
    os.makedirs(os.path.dirname(local), exist_ok=True)
    last_err = None
    for attempt in range(3):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "okhttp/4.9.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                data = r.read()
            if md5 and hashlib.md5(data).hexdigest() != md5:
                raise RuntimeError(f"md5 mismatch (got {hashlib.md5(data).hexdigest()} want {md5})")
            with open(local, "wb") as f:
                f.write(data)
            return (key, True, "")
        except Exception as e:
            last_err = str(e)
    return (key, False, last_err)

ok = fail = 0
failures = []
with cf.ThreadPoolExecutor(max_workers=16) as ex:
    for key, success, err in ex.map(fetch, pending):
        if success:
            ok += 1
            if ok % 500 == 0:
                print(f"  ok={ok} fail={fail}", flush=True)
        else:
            fail += 1
            failures.append((key, err))

print(f"done ok={ok} fail={fail}", flush=True)
for key, err in failures[:40]:
    print("FAIL:", key, err, flush=True)
