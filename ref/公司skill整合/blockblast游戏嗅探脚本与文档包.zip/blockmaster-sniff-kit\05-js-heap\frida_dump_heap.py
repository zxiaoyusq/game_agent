#!/usr/bin/env python3
"""Dump the V8 JS heap of the game process in chunks (host-side writer)."""
import frida
import os
import sys

JS = r"""
'use strict';
function ranges() {
    var out = [];
    Process.enumerateRanges('rw-').forEach(function (r) {
        var b = r.base.toString();
        if (b.indexOf('0x3030') === 0) {
            out.push({base: b, size: r.size});
        }
    });
    return out;
}
function dump(addrHex, size) {
    return ptr(addrHex).readByteArray(size);
}
rpc.exports = { ranges: ranges, dump: dump };
"""

OUT = r"E:\codex_apk_work\memdump\heap"
os.makedirs(OUT, exist_ok=True)
PID = int(sys.argv[1]) if len(sys.argv) > 1 else 5829
CHUNK = 4 * 1024 * 1024

dev = frida.get_device_manager().add_remote_device('127.0.0.1:27042')
session = dev.attach(PID)
script = session.create_script(JS)
script.load()

ranges = script.exports_sync.ranges()
print("rw ranges in 0x3030*:", ranges)
total = 0
for r in ranges:
    base = int(r["base"], 16)
    size = r["size"]
    name = f"{r['base']}_{size:x}"
    off = 0
    with open(os.path.join(OUT, name + ".bin"), "wb") as f:
        while off < size:
            n = min(CHUNK, size - off)
            data = script.exports_sync.dump(hex(base + off), n)
            if data is None:
                print("EMPTY at", hex(base + off))
                break
            f.write(data)
            off += n
            total += n
            if off % (16 * 1024 * 1024) == 0:
                print("  ", name, hex(off), "/", hex(size))
    print("done", name, "total so far", total)
print("ALL DONE, total", total)
session.detach()
