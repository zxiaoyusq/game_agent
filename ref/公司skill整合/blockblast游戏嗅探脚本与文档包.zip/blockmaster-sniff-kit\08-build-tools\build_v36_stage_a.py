# -*- coding: utf-8 -*-
"""Build the current V36 isolation canary (A2 or B)."""
import os
import struct
import sys
import zipfile

import build_v35_palm as v35


W = v35.W
OUT = os.path.abspath(os.environ.get("BLOCKMASTER_OUTPUT_DIR", W))
os.makedirs(OUT, exist_ok=True)
STAGE_LABEL = os.environ.get("BLOCKMASTER_V36_STAGE", "B").strip().upper()
if STAGE_LABEL not in {"A2", "B"}:
    raise RuntimeError("BLOCKMASTER_V36_STAGE must be A2 or B")
STAGE_SLUG = STAGE_LABEL.lower()

v35.base.APKTOOL_ATTEMPT = os.path.join(OUT, f"stage2_sdk_unsigned_v36_stage_{STAGE_SLUG}.apk")
v35.base.MERGED = os.path.join(OUT, f"stage2_v36_stage_{STAGE_SLUG}_merged.apk")
v35.base.ALIGNED = os.path.join(OUT, f"stage2_v36_stage_{STAGE_SLUG}_aligned.apk")
v35.base.FINAL = os.path.join(OUT, f"BlockMaster_v36_stage_{STAGE_SLUG}_canary.apk")
v35.base.DEX_VERIFY = os.path.join(OUT, "tmp", f"v36_stage_{STAGE_SLUG}_verify_classes15")
VERSIONED_MERGED = os.path.join(OUT, f"stage2_v36_stage_{STAGE_SLUG}_1019_merged.apk")
VERSIONED_ALIGNED = os.path.join(OUT, f"stage2_v36_stage_{STAGE_SLUG}_1019_aligned.apk")
VERSIONED_FINAL = os.path.join(OUT, f"BlockMaster_v36_stage_{STAGE_SLUG}_1019_canary.apk")

# classes10 must be freshly rebuilt with the Stage-A HSData switch.
v35.DEX_MARKERS[3] = b"BM_V36_HSDATA_HTTP_POST_DISABLED"
v35.DEX_MARKERS[10] = b"BM_V36_HSDATA_DISABLED"
if STAGE_LABEL == "B":
    v35.DEX_MARKERS[13] = b"BM_V36_ORIGINAL_ADX_DISABLED"
v35.base.REPLACEMENTS["classes3.dex"] = v35.dex_path(3)
v35.base.REPLACEMENTS["assets/mediation.json"] = os.path.join(
    v35.STAGE, "assets", "mediation.json"
)


def build_versioned_apk() -> None:
    with zipfile.ZipFile(v35.base.FINAL, "r") as source:
        manifest = source.read("AndroidManifest.xml")
        old_name = "1.0.1.7".encode("utf-16le")
        new_name = "1.0.1.9".encode("utf-16le")
        old_code = struct.pack("<I", 1017)
        new_code = struct.pack("<I", 1019)
        if manifest.count(old_name) != 1 or manifest.count(old_code) != 1:
            raise RuntimeError("compiled manifest version anchors are not unique")
        manifest = manifest.replace(old_name, new_name, 1).replace(old_code, new_code, 1)

        signatures = (".RSA", ".DSA", ".EC", ".SF")
        with zipfile.ZipFile(VERSIONED_MERGED, "w") as target:
            for item in source.infolist():
                upper = item.filename.upper()
                if upper == "META-INF/MANIFEST.MF" or upper.endswith(signatures):
                    continue
                data = manifest if item.filename == "AndroidManifest.xml" else source.read(item.filename)
                compression = zipfile.ZIP_STORED if (
                    item.filename.endswith(".dex") or
                    (item.filename.startswith("lib/") and item.filename.endswith(".so"))
                ) else item.compress_type
                target.writestr(item, data, compress_type=compression)

    keystore, alias = v35.base.build_config.signing_environment()
    v35.base.run('"%s\\zipalign.exe" -f -p 4 "%s" "%s"' % (
        v35.base.BT, VERSIONED_MERGED, VERSIONED_ALIGNED), 300)
    v35.base.run(
        'cmd /c ""%s\\apksigner.bat" sign --ks "%s" --ks-key-alias %s '
        '--ks-pass env:BLOCKMASTER_KS_PASS --key-pass env:BLOCKMASTER_KEY_PASS '
        '--out "%s" "%s""' % (
            v35.base.BT, keystore, alias, VERSIONED_FINAL, VERSIONED_ALIGNED),
        300,
    )
    v35.base.run('"%s\\apksigner.bat" verify --verbose --print-certs "%s"' % (
        v35.base.BT, VERSIONED_FINAL), 300)
    dump = v35.base.run('"%s\\aapt2.exe" dump badging "%s"' % (
        v35.base.BT, VERSIONED_FINAL), 120)
    output = (dump.stdout or "") + (dump.stderr or "")
    if "versionCode='1019'" not in output or "versionName='1.0.1.9'" not in output:
        raise RuntimeError("versioned APK badging check failed")
    print("VERSIONED_FINAL", VERSIONED_FINAL)
    print("VERSIONED_SHA256", v35.base.sha256_file(VERSIONED_FINAL).upper())


def main() -> None:
    v35.base.run('"%s" "%s" --stage %s' % (
        sys.executable, os.path.join(W, "verify_v36_network_capture.py"), STAGE_LABEL), 120)
    v35.main()
    with zipfile.ZipFile(v35.base.FINAL, "r") as archive:
        classes10 = archive.read("classes10.dex")
    if b"BM_V36_HSDATA_REMOTE_CONFIG_DISABLED" not in classes10:
        raise RuntimeError("final APK is missing the HSData remote-config marker")
    if STAGE_LABEL == "B":
        with zipfile.ZipFile(v35.base.FINAL, "r") as archive:
            if b"BM_V36_ORIGINAL_ADX_DISABLED" not in archive.read("classes13.dex"):
                raise RuntimeError("final APK is missing the original ADX marker")
    build_versioned_apk()


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("BUILD FAILED:", error, file=sys.stderr)
        sys.exit(1)
