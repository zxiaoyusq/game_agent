#!/usr/bin/env python3
"""Final systematic XXTEA offset tests on the AFFA container."""
import gzip
import struct
import sys

KEY_B = b"65485d8a-8161-4c"
KEY_A = b"93274615-a57e-4d"
DELTA = 0x9E3779B9
MASK = 0xFFFFFFFF


def _mx(y, z, s, p, e, k):
    return (((z >> 5) ^ (y << 2)) + ((y >> 3) ^ (z << 4))) ^ ((s ^ y) + (k[(p & 3) ^ e] ^ z))


def xxtea(data: bytes, key: bytes) -> bytes:
    if len(data) < 8:
        return data
    n = len(data) // 4
    v = list(struct.unpack("<%dI" % n, data[: n * 4]))
    k = list(struct.unpack("<4I", key[:16].ljust(16, b"\x00")))
    y = v[0]
    q = 6 + 52 // n
    s = (q * DELTA) & MASK
    while s:
        e = (s >> 2) & 3
        for p in range(n - 1, 0, -1):
            z = v[p - 1]
            v[p] = (v[p] - _mx(y, z, s, p, e, k)) & MASK
            y = v[p]
        z = v[n - 1]
        v[0] = (v[0] - _mx(y, z, s, 0, e, k)) & MASK
        y = v[0]
        s = (s - DELTA) & MASK
    return struct.pack("<%dI" % n, *v)


def describe(r: bytes) -> str:
    if r[:2] == b"\x1f\x8b":
        return "GZIP " + r[:8].hex()
    if r[:2] == b"\xaf\xfa":
        return "AFFA " + r[:8].hex()
    if b"require" in r[:100] or r[:1] in (b"(", b"w", b"\"", b"'", b"S", b"c", b"/"):
        return "JS? " + repr(r[:60])
    pr = sum(1 for b in r[:128] if 32 <= b < 127) / min(len(r), 128)
    return "rand pr=%.2f %s" % (pr, r[:8].hex())


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else r"E:\codex_apk_work\blockblast_extracted\assets\main.js"
    raw = open(path, "rb").read()
    pt = xxtea(raw[8:], KEY_B)
    assert pt[:2] == b"\xaf\xfa"
    print("file:", path)
    print("pt head:", pt[:16].hex(" "))
    keys = {"B": KEY_B, "A": KEY_A, "meta8": pt[4:12]}
    for kn, key in keys.items():
        for off in (4, 8, 12):
            seg = pt[off:]
            if len(seg) % 4 != 0:
                seg = seg[: len(seg) // 4 * 4]
            try:
                r = xxtea(seg, key)
                print(f"off={off} key={kn}: {describe(r)}")
            except Exception as e:
                print(f"off={off} key={kn}: ERR {e}")


if __name__ == "__main__":
    main()
