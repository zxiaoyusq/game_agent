# -*- coding: utf-8 -*-
"""Static vendor-link verifier for Block Master stage2.

Scans stage2_sdk or a final APK for blocked original-vendor domains/keys.
- Executable references (main.js, patch main.js, main index JS, Manifest, normal configs) must not contain BLOCKED.
- cacheList.json URL keys are reported as INERT_CACHE_KEY and do not fail unless --strict-cache-keys.
- Missing REQUIRED Block Master Firebase/Athena values returns 2.
"""
import argparse
import os
import re
import sys
import zipfile

BLOCKED = (
    b"bband1.afafb.com",
    b"horizon.afafb.com",
    b"horizon-dev.afafb.com",
    b"inner-package1.youxi123.com",
    b"hungrystudio.com",
    b"ff75b8d00cdfb07d847d460774d19e94",
)
REQUIRED = (
    b"1:638272297170:android:ab8c495238a3d5b85fb50b",
    b"crushblock-b58ab",
    b"Drift_Sand",
)

# Files that are allowed to keep original URLs as local cache keys.
CACHE_KEY_FILES = {
    "assets/remote_seed/gamecaches/gamecaches/cacheList.json",
    "assets/remote_seed/patch/patch/baseM",
    "assets/remote_seed/patch/patch/project.manifest",
    "assets/src/settings.5731e.js",
    "assets/remote_seed/patch/patch/src/settings.85c88.js",
}

EXECUTABLE_PATTERNS = [
    "assets/main.js",
    "assets/remote_seed/patch/patch/main.js",
    "assets/assets/main/index.7d3cd.js",
    "assets/remote_seed/patch/patch/assets/main/index.146a7.js",
    "AndroidManifest.xml",
]


def scan_text(data):
    hits = {}
    for blocked in BLOCKED:
        if blocked in data:
            hits[blocked.decode("utf-8", "replace")] = data.count(blocked)
    return hits


def check_stage2(stage2):
    problems = []
    inert = []
    required_ok = {r.decode("utf-8", "replace"): False for r in REQUIRED}

    # Only scan the files that can actually execute or carry config in v28.
    scan_files = set(EXECUTABLE_PATTERNS)
    scan_files.update(CACHE_KEY_FILES)
    scan_files.add("res/values/strings.xml")
    scan_files.add("res/values/colors.xml")

    for rel in scan_files:
        p = os.path.join(stage2, rel.replace("/", os.sep))
        if not os.path.exists(p):
            continue
        try:
            data = open(p, "rb").read()
        except Exception:
            continue
        if rel in EXECUTABLE_PATTERNS or rel.endswith(".xml"):
            hits = scan_text(data)
            if hits:
                problems.append((rel, hits))
        if rel in CACHE_KEY_FILES:
            hits = scan_text(data)
            if hits:
                inert.append((rel, hits))
        for req in REQUIRED:
            if req in data:
                required_ok[req.decode("utf-8", "replace")] = True

    return problems, inert, required_ok


def check_apk(apk):
    problems = []
    inert = []
    required_ok = {r.decode("utf-8", "replace"): False for r in REQUIRED}
    z = zipfile.ZipFile(apk)
    for info in z.infolist():
        name = info.filename
        try:
            data = z.read(name)
        except Exception:
            continue
        if name in EXECUTABLE_PATTERNS or (name.endswith((".xml", ".json", ".js")) and name not in CACHE_KEY_FILES):
            hits = scan_text(data)
            if hits:
                problems.append((name, hits))
        if name in CACHE_KEY_FILES:
            hits = scan_text(data)
            if hits:
                inert.append((name, hits))
        for req in REQUIRED:
            if req in data:
                required_ok[req.decode("utf-8", "replace")] = True
    return problems, inert, required_ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage2")
    ap.add_argument("--apk")
    ap.add_argument("--strict-cache-keys", action="store_true")
    args = ap.parse_args()

    if args.stage2:
        problems, inert, required_ok = check_stage2(args.stage2)
        src = args.stage2
    elif args.apk:
        problems, inert, required_ok = check_apk(args.apk)
        src = args.apk
    else:
        print("need --stage2 or --apk")
        return 3

    print("=== vendor link check:", src, "===")
    failed = False
    if problems:
        failed = True
        print("FAIL executable references:")
        for rel, hits in problems:
            print(" ", rel, hits)
    else:
        print("PASS no executable blocked references")

    if inert:
        print("INERT_CACHE_KEY (allowed unless strict):")
        for rel, hits in inert:
            print(" ", rel, hits)
        if args.strict_cache_keys:
            failed = True

    missing = [k for k, v in required_ok.items() if not v]
    if missing:
        print("FAIL missing required:", missing)
        return 2
    print("PASS required values present:", list(required_ok.keys()))

    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
