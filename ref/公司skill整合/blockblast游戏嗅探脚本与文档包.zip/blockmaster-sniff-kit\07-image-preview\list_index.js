﻿const fs = require('fs');
const data = JSON.parse(fs.readFileSync('E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810/spine-preview/spine_index.json', 'utf8'));
for (let i = 0; i < data.length; i++) {
  const it = data[i];
  if (i < 30 || it.name.includes('clear') || it.name.includes('eliminate') || it.name.includes('combo')) {
    console.log(i, it.name, it.bundle, it.skin, 'anims=' + (it.anims||[]).length);
  }
}
