#!/usr/bin/env python3
"""Dump readable strings from the in-memory key table and inspect v01 payloads."""
import collections
import math
import re
import sys


def entropy(b):
    if not b:
        return 0.0
    c = collections.Counter(b)
    n = len(b)
    return -sum((v / n) * math.log2(v / n) for v in c.values())


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "keys"
    if mode == "keys":
        data = open(r"E:\codex_apk_work\memdump\key_table_full.bin", "rb").read()
        print("key_table len:", len(data))
        strs = re.findall(rb"[\x20-\x7e]{4,}", data)
        seen = set()
        for s in strs:
            if s not in seen:
                seen.add(s)
                print(repr(s))
        # hexdump around the two known key strings
        for key in (b"65485d8a-8161-4c", b"93274615-a57e-4d"):
            i = data.find(key)
            print(key, "at", hex(i) if i >= 0 else "NOT FOUND")
            if i >= 0:
                lo = max(0, i - 32)
                hi = min(len(data), i + 64)
                print(data[lo:hi].hex(" "))
    else:
        path = sys.argv[2] if len(sys.argv) > 2 else r"E:\codex_apk_work\blockblast_extracted\assets\main.js"
        data = open(path, "rb").read()
        body = data[8:]
        print("file:", path)
        print("body entropy:", round(entropy(body), 4), "len:", len(body))
        print("body[:12]:", body[:12].hex(" "))
        print("payload[12:64]:", body[12:64].hex(" "))


if __name__ == "__main__":
    main()
