# -*- coding: utf-8 -*-
"""B4: remove dead original-vendor update functions from main.js after B1-B3."""
import io, os

WORK = r'E:\codex_apk_work\blockmaster_pro_swap\work\stage2_sdk'
FILES = [
    os.path.join(WORK, 'assets', 'main.js'),
    os.path.join(WORK, 'assets', 'remote_seed', 'patch', 'patch', 'main.js'),
]

START = '//多链路兜底策略'
END = 'window.boot = function () {'

def patch(path):
    with io.open(path, encoding='utf-8') as f:
        s = f.read()
    if START not in s or END not in s:
        print('WARN markers not found', path)
        return
    i = s.find(START)
    j = s.find(END)
    if i >= j:
        print('WARN order wrong', path)
        return
    removed = s[i:j]
    s = s[:i] + s[j:]
    with io.open(path, 'w', encoding='utf-8', newline='') as f:
        f.write(s)
    print('patched', path, 'removed_len', len(removed))

def main():
    for p in FILES:
        patch(p)

if __name__ == '__main__':
    main()
