# -*- coding: utf-8 -*-
"""Remove MoreGames/MiniGame/JewelGame entries from baseM and project.manifest."""
import io
import json
import os

PATCH = r'E:\codex_apk_work\blockmaster_pro_swap\work\stage2_sdk\assets\remote_seed\patch\patch'
FILES = ['baseM', 'project.manifest']

KEYWORDS = [
    'GameLobbyAddMoreGame',
    'CommonGameEntrance',
    'CommonGameList',
    'GLHallMoreGames',
    'GameOverShowMiniGame',
    'ChangeMoreGamesDoubleCol',
    'MoreGamesUnlockByDays',
    'MoreGamesUnlockByBreakHighScore',
    'MiniGame',
    'JewelGame',
]

def main():
    for name in FILES:
        p = os.path.join(PATCH, name)
        with io.open(p, encoding='utf-8') as f:
            d = json.load(f)
        assets = d.get('assets', {})
        before = len(assets)
        filtered = {k: v for k, v in assets.items() if not any(kw in k for kw in KEYWORDS)}
        d['assets'] = filtered
        with io.open(p, 'w', encoding='utf-8', newline='\n') as f:
            json.dump(d, f, ensure_ascii=False, separators=(',', ':'))
        print(name, 'assets', before, '->', len(filtered), 'removed', before - len(filtered))

if __name__ == '__main__':
    main()
