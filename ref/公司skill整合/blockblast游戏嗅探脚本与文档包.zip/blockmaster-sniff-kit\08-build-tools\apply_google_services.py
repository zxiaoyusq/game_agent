#!/usr/bin/env python3
"""Apply/verify google-services.json values in the apktool resource project."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


WORK = Path(__file__).resolve().parents[1]
STAGE = WORK / "stage2_sdk"
DEFAULT_CONFIG = STAGE / "google-services.json"
DEFAULT_STRINGS = STAGE / "res" / "values" / "strings.xml"
PACKAGE = "com.driftsand.game.blockmaster"


def selected_values(config_path: Path) -> dict[str, str]:
    payload = json.loads(config_path.read_text(encoding="utf-8"))
    selected = None
    for client in payload.get("client", []):
        package = client.get("client_info", {}).get("android_client_info", {}).get("package_name")
        if package == PACKAGE:
            selected = client
            break
    if selected is None:
        raise RuntimeError("google-services client missing for %s" % PACKAGE)
    keys = selected.get("api_key", [])
    if not keys or not keys[0].get("current_key"):
        raise RuntimeError("google-services API key missing for %s" % PACKAGE)
    project = payload.get("project_info", {})
    api_key = keys[0]["current_key"]
    return {
        "google_app_id": selected["client_info"]["mobilesdk_app_id"],
        "gcm_defaultSenderId": project["project_number"],
        "google_api_key": api_key,
        "google_crash_reporting_api_key": api_key,
        "google_storage_bucket": project["storage_bucket"],
    }


def replace_value(text: str, name: str, value: str) -> tuple[str, bool]:
    pattern = re.compile(r'(<string\s+name="%s"[^>]*>)(.*?)(</string>)' % re.escape(name))
    match = pattern.search(text)
    if not match:
        raise RuntimeError("resource string missing: %s" % name)
    current = match.group(2)
    if current == value:
        return text, False
    return pattern.sub(lambda item: item.group(1) + value + item.group(3), text, count=1), True


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--strings", type=Path, default=DEFAULT_STRINGS)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()

    expected = selected_values(args.config)
    text = args.strings.read_text(encoding="utf-8")
    changed = []
    updated = text
    for name, value in expected.items():
        updated, did_change = replace_value(updated, name, value)
        if did_change:
            changed.append(name)

    if args.check and changed:
        raise RuntimeError("Firebase resources differ from google-services.json: %s" % changed)
    if changed:
        args.strings.write_text(updated, encoding="utf-8", newline="")
        print("UPDATED", ",".join(changed))
    print("GOOGLE_SERVICES: PASS package=%s app_id=%s" % (PACKAGE, expected["google_app_id"]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
