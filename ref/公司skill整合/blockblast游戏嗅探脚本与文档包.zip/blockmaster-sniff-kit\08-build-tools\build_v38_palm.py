# -*- coding: utf-8 -*-
"""Build/sign the V38 arm64 Firebase-adapter fix from the signed V37 baseline."""
from __future__ import annotations

import os
import shutil
import sys
import time
import zipfile

import build_v34_palm as base


W = base.W
STAGE = base.STAGE
OUT = os.path.abspath(os.environ.get("BLOCKMASTER_OUTPUT_DIR", W))
os.makedirs(OUT, exist_ok=True)

base.BASELINE = os.path.join(W, "BlockMaster_v37_palm_full_arm64.apk")
base.APKTOOL_ATTEMPT = os.path.join(OUT, "stage2_sdk_unsigned_v38_arm64.apk")
base.MERGED = os.path.join(OUT, "stage2_v38_arm64_merged.apk")
base.ALIGNED = os.path.join(OUT, "stage2_v38_arm64_aligned.apk")
base.FINAL = os.path.join(OUT, "BlockMaster_v38_palm_full_arm64.apk")
base.DEX_VERIFY = os.path.join(OUT, "tmp", "v38_verify_classes13")

DEX13 = os.path.join(STAGE, "build", "apk", "classes13.dex")
DEX14 = os.path.join(STAGE, "build", "apk", "classes14.dex")
DEX15 = os.path.join(STAGE, "build", "apk", "classes15.dex")
ADAPTER_MARKER = b"BMV38FirebaseAdapter"
ADAPTER_DESCRIPTOR = b"Lcom/block/juggle/datareport/firebase/SFireBaseDataAdapter;"

base.REPLACEMENTS = {
    "classes13.dex": DEX13,
    "classes14.dex": DEX14,
}


def compile_and_verify_classes13() -> None:
    for path in (DEX13, DEX14, DEX15, base.APKTOOL_ATTEMPT):
        if os.path.exists(path):
            os.remove(path)

    started = time.time()
    result = base.run(
        'java -jar "%s" b "%s" -o "%s"'
        % (base.APKTOOL, STAGE, base.APKTOOL_ATTEMPT),
        1800,
        check=False,
    )
    output = (result.stdout or "") + (result.stderr or "")
    if result.returncode != 0 and "failed assigning IDs" not in output:
        raise RuntimeError("apktool failed before the known resource-link boundary")

    for path in (DEX13, DEX14, DEX15):
        if not os.path.isfile(path) or os.path.getmtime(path) < started:
            raise RuntimeError(f"DEX was not freshly assembled: {path}")

    data = open(DEX13, "rb").read()
    for marker in (ADAPTER_MARKER, ADAPTER_DESCRIPTOR, b"BM_V36_ORIGINAL_ADX_DISABLED"):
        if marker not in data:
            raise RuntimeError(f"classes13.dex marker missing: {marker!r}")

    dex14 = open(DEX14, "rb").read()
    for marker in (
        b"BMAthenaBridge",
        b"FirebaseBridge",
        b"logEventWithParams",
        b"26042852QVdSm3",
    ):
        if marker not in dex14:
            raise RuntimeError(f"classes14.dex marker missing: {marker!r}")

    if os.path.isdir(base.DEX_VERIFY):
        shutil.rmtree(base.DEX_VERIFY)
    os.makedirs(base.DEX_VERIFY, exist_ok=True)
    mini_apk = os.path.join(base.DEX_VERIFY, "classes13.apk")
    with zipfile.ZipFile(mini_apk, "w") as archive:
        archive.write(DEX13, "classes.dex", compress_type=zipfile.ZIP_STORED)
    decoded = os.path.join(base.DEX_VERIFY, "decoded")
    base.run(
        'java -jar "%s" d -f -r "%s" -o "%s"'
        % (base.APKTOOL, mini_apk, decoded),
        600,
    )
    adapter = os.path.join(
        decoded,
        "smali",
        "com",
        "block",
        "juggle",
        "datareport",
        "firebase",
        "SFireBaseDataAdapter.smali",
    )
    text = open(adapter, "r", encoding="utf-8").read()
    for needle in (
        ".method public static getInstance()",
        "FirebaseAnalytics;->getInstance",
        "FirebaseAnalytics;->logEvent",
        "FirebaseAnalytics;->setConsent",
    ):
        if needle not in text:
            raise RuntimeError(f"rebuilt Firebase adapter missing: {needle}")
    print("VERIFIED classes13", base.sha256_file(DEX13), flush=True)


def verify_final() -> None:
    base.verify_final_entries()
    with zipfile.ZipFile(base.FINAL, "r") as archive:
        names = archive.namelist()
        abis = sorted({name.split("/")[1] for name in names if name.startswith("lib/")})
        if abis != ["arm64-v8a"]:
            raise RuntimeError(f"unexpected ABI set: {abis}")
        dex = archive.read("classes13.dex")
        for marker in (ADAPTER_MARKER, ADAPTER_DESCRIPTOR):
            if marker not in dex:
                raise RuntimeError(f"final Firebase adapter marker missing: {marker!r}")
        dex14 = archive.read("classes14.dex")
        for marker in (b"BMAthenaBridge", b"FirebaseBridge", b"logEventWithParams"):
            if marker not in dex14:
                raise RuntimeError(f"final Firebase dual-report marker missing: {marker!r}")

    dump = base.run(f'"{base.BT}\\aapt2.exe" dump badging "{base.FINAL}"', 120)
    badging = (dump.stdout or "") + (dump.stderr or "")
    if "versionCode='1019'" not in badging or "versionName='1.0.1.9'" not in badging:
        raise RuntimeError("final version mismatch")
    if "native-code: 'arm64-v8a'" not in badging:
        raise RuntimeError("final APK is not arm64-only")


def main() -> None:
    base.run(
        f'"{sys.executable}" "{os.path.join(W, "verify_v37_transsion_only.py")}"',
        120,
    )
    base.run(
        f'"{sys.executable}" "{os.path.join(W, "verify_v38_firebase_adapter.py")}"',
        120,
    )
    compile_and_verify_classes13()
    base.overlay_baseline()
    verify_final()


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("BUILD FAILED:", error, file=sys.stderr)
        sys.exit(1)
