#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Corrected write-back for the XCfive DragonBones assets.

The APK stores these import files as Cocos serialized wrappers:
    [1, 0, 0, [["dragonBones.DragonBonesAsset", [...], 1]], ...,
     [[0, "XCfive_ske", "<dragonbones json string>"]], ...]
So we keep the wrapper byte-structure intact and only swap the embedded
JSON string at arr[5][0][2].  Native PNGs are still plain PNG after XOR.
"""

import gzip
import io
import json
import os
import shutil

from PIL import Image

KEY = b"65485d8a-8161-4c"
HEADER = b"HEK:\x03\x00\x01\x02"

APK_ASSETS = r"E:\codex_apk_work\blockmaster_pro_swap\work\blockblast_apktool\assets\assets"
OUT = r"E:\codex_apk_work\blockmaster_pro_swap\work\blocklogo_db"
BACKUP = r"E:\codex_apk_work\blockmaster_pro_swap\work\blocklogo_swap_backup"

TITLE_SRC = r"C:\Users\nenghong.zhao\Desktop\block_logo\title.png"
TITLE_TARGET = APK_ASSETS + r"\resources\native\7e\7e6db96e-3ca8-4235-b1ca-4c8b67074c71.67667.png"

SKE_JSON = OUT + r"\blocklogo_ske.json"
ATLAS_JSON = OUT + r"\blocklogo_atlas.json"
ATLAS_PNG = OUT + r"\blocklogo_atlas.png"

SKE_TARGET = APK_ASSETS + r"\chapter\import\0c\0c1ad7d2-b3d8-4566-9104-230bcbf51808.e1dbe.json"
ATLAS_TARGET = APK_ASSETS + r"\chapter\import\a2\a27434c1-5de9-4992-987f-ed2b013add6f.90b6a.json"
ATLAS_PNG_TARGET = APK_ASSETS + r"\chapter\native\07\0789aa9f-5904-42c0-b259-202a2cbcf643.96302.png"


def keystream(n):
    return (KEY * (n // 16 + 1))[:n]


def decrypt(data):
    if not data.startswith(b"HEK:"):
        return data
    body = data[8:]
    return bytes(a ^ b for a, b in zip(body, keystream(len(body))))


def maybe_gunzip(data):
    if data[:2] == b"\x1f\x8b":
        try:
            return gzip.decompress(data)
        except Exception:
            return data
    return data


def encrypt_native(plaintext):
    body = bytes(a ^ b for a, b in zip(plaintext, keystream(len(plaintext))))
    return HEADER + body


def encrypt_import_json(obj):
    raw = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return encrypt_native(gzip.compress(raw))


def read_decrypted(p):
    with open(p, "rb") as f:
        return maybe_gunzip(decrypt(f.read()))


def parse_wrapper(p):
    return json.loads(read_decrypted(p).decode("utf-8"))


def main():
    ok = True

    # ---- 1) title.png (native, plain PNG after XOR) ----
    title = Image.open(TITLE_SRC).convert("RGBA")
    canvas = Image.new("RGBA", (631, 407), (0, 0, 0, 0))
    # paste WITHOUT alpha mask so semi-transparent edge pixels keep their
    # original straight-alpha RGBA (using the mask premultiplies edges and
    # leaves a dark fringe around the logo)
    canvas.paste(title, ((631 - title.width) // 2, (407 - title.height) // 2))
    buf = io.BytesIO()
    canvas.save(buf, format="PNG")
    title_plain = buf.getvalue()
    with open(TITLE_TARGET, "wb") as f:
        f.write(encrypt_native(title_plain))
    got = read_decrypted(TITLE_TARGET)
    print("title png verify:", got == title_plain, len(got))
    ok &= got == title_plain

    # ---- 2) skeleton wrapper ----
    ske_wrapper_orig = parse_wrapper(os.path.join(BACKUP, "chapter", "import", "0c", "0c1ad7d2-b3d8-4566-9104-230bcbf51808.e1dbe.json"))
    new_ske = json.load(open(SKE_JSON, encoding="utf-8"))
    new_ske_str = json.dumps(new_ske, ensure_ascii=False, separators=(",", ":"))
    ske_wrapper = json.loads(json.dumps(ske_wrapper_orig, ensure_ascii=False))
    assert ske_wrapper[5][0][1] == "XCfive_ske"
    ske_wrapper[5][0][2] = new_ske_str
    with open(SKE_TARGET, "wb") as f:
        f.write(encrypt_import_json(ske_wrapper))
    back = json.loads(read_decrypted(SKE_TARGET).decode("utf-8"))
    same = back == ske_wrapper and json.loads(back[5][0][2]) == new_ske
    print("skeleton wrapper verify:", same)
    ok &= same

    # ---- 3) atlas wrapper ----
    atlas_wrapper_orig = parse_wrapper(os.path.join(BACKUP, "chapter", "import", "a2", "a27434c1-5de9-4992-987f-ed2b013add6f.90b6a.json"))
    new_atlas = json.load(open(ATLAS_JSON, encoding="utf-8"))
    new_atlas_str = json.dumps(new_atlas, ensure_ascii=False, separators=(",", ":"))
    atlas_wrapper = json.loads(json.dumps(atlas_wrapper_orig, ensure_ascii=False))
    assert atlas_wrapper[5][0][1] == "XCfive_tex"
    atlas_wrapper[5][0][2] = new_atlas_str
    with open(ATLAS_TARGET, "wb") as f:
        f.write(encrypt_import_json(atlas_wrapper))
    back = json.loads(read_decrypted(ATLAS_TARGET).decode("utf-8"))
    same = back == atlas_wrapper and json.loads(back[5][0][2]) == new_atlas
    print("atlas wrapper verify:", same)
    ok &= same

    # ---- 4) atlas png (native) ----
    atlas_png = open(ATLAS_PNG, "rb").read()
    with open(ATLAS_PNG_TARGET, "wb") as f:
        f.write(encrypt_native(atlas_png))
    got = read_decrypted(ATLAS_PNG_TARGET)
    print("atlas png verify:", got == atlas_png, len(got))
    ok &= got == atlas_png

    print("ALL OK" if ok else "SOME VERIFY FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
