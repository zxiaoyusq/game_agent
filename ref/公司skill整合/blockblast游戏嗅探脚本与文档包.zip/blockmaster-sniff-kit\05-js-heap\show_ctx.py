import re
import sys

path = sys.argv[1] if len(sys.argv) > 1 else r"E:\codex_apk_work\memdump\ctx_0x303000_cocos2d-jsb_8930c6.bin"
raw = open(path, "rb").read()
txt = raw.decode("utf-16-le", errors="ignore")
print("len", len(raw), "chars", len(txt))
out = r"E:\codex_apk_work\memdump\ctx_text.txt"
with open(out, "w", encoding="utf-8", errors="replace") as f:
    f.write(txt)
print("wrote", out)
# find the anchor
for anchor in ["cocos2d-jsb", "window.__require", "cc.sys"]:
    i = txt.find(anchor)
    print(anchor, "at", i)
    if i >= 0:
        seg = txt[max(0, i - 200):i + 300].replace("\n", "\\n")
        print("...", seg[:500].encode("ascii", "replace").decode("ascii"))
        break
