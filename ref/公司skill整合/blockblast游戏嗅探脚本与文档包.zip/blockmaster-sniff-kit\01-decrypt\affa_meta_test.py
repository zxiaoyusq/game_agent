#!/usr/bin/env python3
"""Test whether the AFFA meta8 is itself XXTEA ciphertext."""
import struct

KEY_B = b"65485d8a-8161-4c"
KEY_A = b"93274615-a57e-4d"
DELTA = 0x9E3779B9
MASK = 0xFFFFFFFF

META_SAMPLES = [
    bytes.fromhex("07a21ba10700c4be"),
    bytes.fromhex("08241b230800c4de"),
    bytes.fromhex("6d845b836dc18c64"),
    bytes.fromhex("23ec9beb2318291d"),
    bytes.fromhex("3d479b463d1f291d"),
    bytes.fromhex("fdc19bc0fd27291d"),
    bytes.fromhex("0f52cbffff3f290d"),
    bytes.fromhex("28 21 1b 20 28 00 e4 ff".replace(" ", "")),
]


def _mx(y, z, s, p, e, k):
    return (((z >> 5) ^ (y << 2)) + ((y >> 3) ^ (z << 4))) ^ ((s ^ y) + (k[(p & 3) ^ e] ^ z))


def xxtea_n2(blk8: bytes, key: bytes) -> bytes:
    v = list(struct.unpack("<2I", blk8))
    k = list(struct.unpack("<4I", key[:16].ljust(16, b"\x00")))
    n = 2
    q = 6 + 52 // n
    s = (q * DELTA) & MASK
    y = v[0]
    while s:
        e = (s >> 2) & 3
        for p in range(n - 1, 0, -1):
            z = v[p - 1]
            v[p] = (v[p] - _mx(y, z, s, p, e, k)) & MASK
            y = v[p]
        z = v[n - 1]
        v[0] = (v[0] - _mx(y, z, s, 0, e, k)) & MASK
        y = v[0]
        s = (s - DELTA) & MASK
    return struct.pack("<2I", *v)


for m in META_SAMPLES:
    for kname, key in [("B", KEY_B), ("A", KEY_A)]:
        print(kname, m.hex(), "->", xxtea_n2(m, key).hex())
    print()
