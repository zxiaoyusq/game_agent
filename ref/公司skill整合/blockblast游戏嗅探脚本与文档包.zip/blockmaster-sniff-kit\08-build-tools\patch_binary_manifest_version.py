#!/usr/bin/env python3
"""Replace equal-length Android version fields in a compiled AXML manifest."""
from __future__ import annotations

import argparse
import pathlib
import struct


def replace_once(data: bytes, old: bytes, new: bytes, label: str) -> bytes:
    if len(old) != len(new):
        raise RuntimeError(f"{label} length differs: {len(old)} != {len(new)}")
    count = data.count(old)
    if count != 1:
        raise RuntimeError(f"{label} expected one binary match, found {count}")
    return data.replace(old, new, 1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=pathlib.Path)
    parser.add_argument("output", type=pathlib.Path)
    parser.add_argument("--old-code", type=int, required=True)
    parser.add_argument("--new-code", type=int, required=True)
    parser.add_argument("--old-name", required=True)
    parser.add_argument("--new-name", required=True)
    args = parser.parse_args()

    data = args.input.read_bytes()
    data = replace_once(
        data,
        args.old_name.encode("utf-16le"),
        args.new_name.encode("utf-16le"),
        "versionName",
    )
    data = replace_once(
        data,
        struct.pack("<I", args.old_code),
        struct.pack("<I", args.new_code),
        "versionCode",
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(data)
    print(
        f"PATCHED manifest versionName={args.new_name} "
        f"versionCode={args.new_code} bytes={len(data)}"
    )


if __name__ == "__main__":
    main()
