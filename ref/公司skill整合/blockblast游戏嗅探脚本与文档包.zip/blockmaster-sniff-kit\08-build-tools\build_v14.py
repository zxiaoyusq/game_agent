# -*- coding: utf-8 -*-
"""Build final v14 APKs (full/lite) with MoreSettings bridge dex merged as classes19."""
import os, zipfile, subprocess, sys

W = r'E:\codex_apk_work\blockmaster_pro_swap\work'
BT = r'E:\AndroidSdk\build-tools\34.0.0'
KS = r'E:\Gameprogram\water_game\native\engine\android\keystore\debug.keystore'

ADDS = [
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes2.dex'), 'classes15.dex'),
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes4.dex'), 'classes16.dex'),
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes.dex'), 'classes17.dex'),
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes3.dex'), 'classes18.dex'),
    (os.path.join(W, 'more_settings_bridge_dex', 'classes.dex'), 'classes19.dex'),
]

def run(c, t=900):
    print('>>', c)
    r = subprocess.run(c, shell=True, capture_output=True, text=True, timeout=t)
    if r.returncode != 0:
        print(r.stdout[-3000:])
        print(r.stderr[-3000:])
        sys.exit(1)
    return r.stdout

def build(tag, src_unsigned, final_apk):
    merged = os.path.join(W, f'stage2_{tag}_v14_merged.apk')
    stored = os.path.join(W, f'stage2_{tag}_v14_stored.apk')
    aligned = os.path.join(W, f'stage2_{tag}_v14_aligned.apk')
    for p in (merged, stored, aligned, final_apk):
        if os.path.exists(p):
            os.remove(p)

    zin = zipfile.ZipFile(src_unsigned)
    zout = zipfile.ZipFile(merged, 'w', zipfile.ZIP_DEFLATED)
    for item in zin.infolist():
        data = zin.read(item.filename)
        if item.filename.endswith('.dex') or (item.filename.startswith('lib/') and item.filename.endswith('.so')):
            zout.writestr(item, data, compress_type=zipfile.ZIP_STORED)
        else:
            zout.writestr(item, data)
    for path, name in ADDS:
        zout.writestr(name, open(path, 'rb').read(), compress_type=zipfile.ZIP_STORED)
    zout.writestr('META-INF/services/bmkx.coroutines.H', b'bmkx.coroutines.android.b\r\n')
    zout.writestr('META-INF/services/bmkx.coroutines.internal.n', b'bmkx.coroutines.android.a\r\n')
    zout.close()
    zin.close()
    print('merged:', os.path.getsize(merged))

    zin = zipfile.ZipFile(merged)
    zout = zipfile.ZipFile(stored, 'w', zipfile.ZIP_DEFLATED)
    for item in zin.infolist():
        data = zin.read(item.filename)
        if item.filename.startswith('lib/') and item.filename.endswith('.so'):
            zout.writestr(item, data, compress_type=zipfile.ZIP_STORED)
        else:
            zout.writestr(item, data)
    zout.close()
    zin.close()
    print('stored:', os.path.getsize(stored))

    run('"%s\\zipalign.exe" -f -p 4 "%s" "%s"' % (BT, stored, aligned))
    run('cmd /c ""%s\\apksigner.bat" sign --ks "%s" --ks-key-alias debug_keystore --ks-pass pass:123456 --out "%s" "%s""' % (BT, KS, final_apk, aligned))
    run('"%s\\apksigner.bat" verify --verbose "%s"' % (BT, final_apk), 300)
    print('signed:', os.path.getsize(final_apk))

if __name__ == '__main__':
    build('sdk', os.path.join(W, 'stage2_sdk_unsigned_v14.apk'), os.path.join(W, 'BlockMaster_v14_full.apk'))
    build('lite', os.path.join(W, 'stage2_lite_unsigned_v14.apk'), os.path.join(W, 'BlockMaster_v14_lite.apk'))
    print('V14 PIPELINE DONE')