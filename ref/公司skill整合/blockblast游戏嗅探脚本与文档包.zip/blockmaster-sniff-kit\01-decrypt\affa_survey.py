#!/usr/bin/env python3
"""Survey all HEK:v01 files: size, AFFA version byte, meta8, payload length."""
import os
import struct

KEY = b"65485d8a-8161-4c"
DELTA = 0x9E3779B9
MASK = 0xFFFFFFFF
SRC = r"E:\codex_apk_work\blockblast_extracted"


def _mx(y, z, s, p, e, k):
    return (((z >> 5) ^ (y << 2)) + ((y >> 3) ^ (z << 4))) ^ ((s ^ y) + (k[(p & 3) ^ e] ^ z))


def xxtea_decrypt(data: bytes, key: bytes) -> bytes:
    if len(data) < 8:
        return data
    n = len(data) // 4
    v = list(struct.unpack("<%dI" % n, data[: n * 4]))
    k = list(struct.unpack("<4I", key[:16].ljust(16, b"\x00")))
    y = v[0]
    q = 6 + 52 // n
    s = (q * DELTA) & MASK
    while s:
        e = (s >> 2) & 3
        for p in range(n - 1, 0, -1):
            z = v[p - 1]
            v[p] = (v[p] - _mx(y, z, s, p, e, k)) & MASK
            y = v[p]
        z = v[n - 1]
        v[0] = (v[0] - _mx(y, z, s, 0, e, k)) & MASK
        y = v[0]
        s = (s - DELTA) & MASK
    return struct.pack("<%dI" % n, *v)


def main():
    rows = []
    counts = {"affa": 0, "direct": 0, "other": 0}
    v01_seen = 0
    for root, dirs, files in os.walk(SRC):
        for fn in files:
            p = os.path.join(root, fn)
            try:
                raw = open(p, "rb").read()
            except OSError:
                continue
            if len(raw) <= 8 or raw[:4] != b"HEK:" or raw[4] != 1:
                continue
            v01_seen += 1
            body = raw[8:]
            pt = xxtea_decrypt(body, KEY)
            rel = os.path.relpath(p, SRC)
            if pt[:2] == b"\xaf\xfa":
                counts["affa"] += 1
                rows.append((len(raw), pt[4], pt[4:12].hex(), len(body) - 12, rel))
            elif rel.endswith("main.js"):
                print("main.js pt[:8]:", pt[:8].hex())
            elif pt[:2] == b"(f" or pt[:6] == b"window" or b"\n" in pt[:64]:
                counts["direct"] += 1
            else:
                counts["other"] += 1
    print("v01 seen:", v01_seen)
    print("counts:", counts)
    print("affa rows:", len(rows))
    # group by version byte
    from collections import Counter
    ver = Counter(r[1] for r in rows)
    print("version bytes:", ver)
    rows.sort(key=lambda x: -x[0])
    for r in rows[:30]:
        print(r[0], "ver", hex(r[1]), "meta", r[2], "payload", r[3], r[4])


if __name__ == "__main__":
    main()
