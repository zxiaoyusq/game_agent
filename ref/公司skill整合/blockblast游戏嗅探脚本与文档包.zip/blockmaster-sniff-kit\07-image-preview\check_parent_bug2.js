﻿'use strict';
const fs = require('fs');
const HTML = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810/spine-preview/preview.html';
const REF = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/blast-block-spine/preview.html';
function load(htmlPath){
  const html = fs.readFileSync(htmlPath, 'utf8');
  const m = html.match(/const DATA = (\[[\s\S]*?\]);\r?\n/);
  return JSON.parse(m[1]);
}
const data = load(HTML);
for (const i of [0, 5, 50, 300]) {
  const u = data[i].atlasUrl;
  const body = u.slice(u.indexOf(',') + 1);
  const slashCount = (body.match(/\//g) || []).length;
  console.log('our[' + i + ']', data[i].name, 'body len', body.length, 'slashes in body:', slashCount, 'lastIdx:', u.lastIndexOf('/'));
}
const rdata = load(REF);
for (const i of [0, 10]) {
  const u = rdata[i].atlasUrl;
  const body = u.slice(u.indexOf(',') + 1);
  console.log('ref[' + i + ']', rdata[i].name, 'body len', body.length, 'slashes in body:', (body.match(/\//g) || []).length, 'lastIdx:', u.lastIndexOf('/'), 'url head:', u.slice(0, 40));
}
