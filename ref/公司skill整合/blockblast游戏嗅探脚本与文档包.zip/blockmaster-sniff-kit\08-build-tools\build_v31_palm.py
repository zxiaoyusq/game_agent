# -*- coding: utf-8 -*-
"""Build BlockMaster_v31_palm_full.apk from stage2_sdk_unsigned_v31.apk."""
import os
import subprocess
import sys
import zipfile

W = r'E:\codex_apk_work\blockmaster_pro_swap\work'
BT = r'E:\AndroidSdk\build-tools\34.0.0'
KS = r'E:\blockh5\config\keystore'
KS_PASS = 'transsion20260424'
KEY_ALIAS = 'blockmaster'
KEY_PASS = '1234567890'

SRC = os.path.join(W, 'stage2_sdk_unsigned_v31.apk')
MERGED = os.path.join(W, 'stage2_v31_merged.apk')
STORED = os.path.join(W, 'stage2_v31_stored.apk')
ALIGNED = os.path.join(W, 'stage2_v31_aligned.apk')
FINAL = os.path.join(W, 'BlockMaster_v31_palm_full.apk')

ADDS = [
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes2.dex'), 'classes15.dex'),
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes4.dex'), 'classes16.dex'),
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes.dex'), 'classes17.dex'),
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes3.dex'), 'classes18.dex'),
    (os.path.join(W, 'more_settings_bridge_dex', 'classes.dex'), 'classes19.dex'),
]


def run(c, t=900):
    print('>>', c)
    r = subprocess.run(c, shell=True, capture_output=True, text=True, timeout=t)
    if r.returncode != 0:
        print(r.stdout[-3000:])
        print(r.stderr[-3000:])
        sys.exit(1)
    return r.stdout


def main():
    for p in (MERGED, STORED, ALIGNED, FINAL):
        if os.path.exists(p):
            os.remove(p)

    with zipfile.ZipFile(SRC, 'r') as zin, zipfile.ZipFile(MERGED, 'w', zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename.endswith('.dex') or (item.filename.startswith('lib/') and item.filename.endswith('.so')):
                zout.writestr(item, data, compress_type=zipfile.ZIP_STORED)
            else:
                zout.writestr(item, data)
        for path, name in ADDS:
            with open(path, 'rb') as f:
                zout.writestr(name, f.read(), compress_type=zipfile.ZIP_STORED)
        zout.writestr('META-INF/services/bmkx.coroutines.H', b'bmkx.coroutines.android.b\r\n')
        zout.writestr('META-INF/services/bmkx.coroutines.internal.n', b'bmkx.coroutines.android.a\r\n')
    print('merged:', os.path.getsize(MERGED))

    with zipfile.ZipFile(MERGED, 'r') as zin, zipfile.ZipFile(STORED, 'w', zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename.startswith('lib/') and item.filename.endswith('.so'):
                zout.writestr(item, data, compress_type=zipfile.ZIP_STORED)
            else:
                zout.writestr(item, data)
    print('stored:', os.path.getsize(STORED))

    run('"%s\\zipalign.exe" -f -p 4 "%s" "%s"' % (BT, STORED, ALIGNED))
    run('cmd /c ""%s\\apksigner.bat" sign --ks "%s" --ks-key-alias %s --ks-pass pass:%s --key-pass pass:%s --out "%s" "%s""'
        % (BT, KS, KEY_ALIAS, KS_PASS, KEY_PASS, FINAL, ALIGNED))
    run('"%s\\apksigner.bat" verify --verbose --print-certs "%s"' % (BT, FINAL), 300)
    print('signed:', os.path.getsize(FINAL))
    print('BUILD DONE', FINAL)


if __name__ == '__main__':
    main()
