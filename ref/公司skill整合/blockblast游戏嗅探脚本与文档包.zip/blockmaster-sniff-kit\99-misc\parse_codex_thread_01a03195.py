# -*- coding: utf-8 -*-
"""Parse a codex rollout JSONL: type stats + extract user/assistant dialogue to a compact MD."""
import json, sys, io, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

PATH = r"C:/Users/nenghong.zhao/.codex/sessions/2026/08/24/rollout-2026-08-24T10-24-58-01a03195-c489-7c21-ad13-2c7636fa0eb9.jsonl"
OUT   = r"E:/codex_apk_work/scripts/_codex_thread_01a03195_dialogue.md"
OUTL  = r"E:/codex_apk_work/scripts/_codex_thread_01a03195_outline.txt"

from collections import Counter
stats = Counter()
outline = []
dialogue = []

def text_from_content(content):
    out = []
    if isinstance(content, list):
        for cpart in content:
            if isinstance(cpart, dict):
                t = cpart.get('text') or cpart.get('input_text') or ''
                if cpart.get('type') in ('input_text','output_text','text') and cpart.get('text'):
                    out.append(cpart['text'])
                elif isinstance(t, str) and t:
                    out.append(t)
    elif isinstance(content, str):
        out.append(content)
    return "\n".join(out)

def clip(s, n):
    s = s or ''
    s = s.replace('\r','')
    if len(s) <= n: return s
    return s[:n] + f" …[+{len(s)-n} chars]"

with open(PATH, encoding='utf-8', errors='replace') as f:
    for i, line in enumerate(f):
        try:
            obj = json.loads(line)
        except Exception:
            stats['<parse_error>'] += 1
            continue
        t = obj.get('type','?')
        p = obj.get('payload') or {}
        pt = p.get('type','')
        ts = (obj.get('timestamp') or '')[:19]
        if t == 'response_item':
            stats[f'response_item/{pt}'] += 1
            if pt == 'message':
                role = p.get('role','?')
                txt = text_from_content(p.get('content'))
                if role == 'user':
                    # skip environment/system-injected context lines
                    if txt.startswith('<user_instructions>') or txt.startswith('<environment_context>'):
                        stats['resp_message/user_ctx'] += 1
                        outline.append(f"[{ts}] L{i} USER_CTX {clip(txt.replace(chr(10),' | '),120)}")
                        continue
                    stats['resp_message/user'] += 1
                    outline.append(f"[{ts}] L{i} USER {clip(txt.replace(chr(10),' | '),300)}")
                    dialogue.append(f"\n{'='*80}\n### USER @ {ts} (line {i})\n{clip(txt, 4000)}")
                elif role == 'assistant':
                    stats['resp_message/assistant'] += 1
                    outline.append(f"[{ts}] L{i} ASSISTANT {clip(txt.replace(chr(10),' | '),300)}")
                    dialogue.append(f"\n{'='*80}\n### ASSISTANT @ {ts} (line {i})\n{clip(txt, 12000)}")
            elif pt == 'function_call':
                name = p.get('name','?')
                args = p.get('arguments','')
                brief = clip(str(args).replace(chr(10),' '), 260)
                outline.append(f"[{ts}] L{i} CALL {name} {brief}")
            elif pt == 'function_call_output':
                out = p.get('output')
                if isinstance(out, dict):
                    out = out.get('content') or out.get('output') or ''
                outline.append(f"[{ts}] L{i} OUT {clip(str(out).replace(chr(10),' '), 200)}")
            elif pt == 'reasoning':
                pass  # skip reasoning blobs (can be huge)
            else:
                outline.append(f"[{ts}] L{i} {pt} {clip(str(p)[:150],150)}")
        elif t == 'event_msg':
            stats[f'event_msg/{pt}'] += 1
            if pt == 'user_message':
                txt = p.get('message','')
                if not txt.startswith('<user_instructions>') and not txt.startswith('<environment_context>'):
                    outline.append(f"[{ts}] L{i} EVT_USER {clip(txt.replace(chr(10),' | '),300)}")
                    dialogue.append(f"\n{'='*80}\n### USER(evt) @ {ts} (line {i})\n{clip(txt, 4000)}")
            elif pt == 'agent_message':
                txt = p.get('message','')
                outline.append(f"[{ts}] L{i} EVT_AGENT {clip(txt.replace(chr(10),' | '),300)}")
                dialogue.append(f"\n{'='*80}\n### ASSISTANT(evt) @ {ts} (line {i})\n{clip(txt, 12000)}")
        else:
            stats[t] += 1

with open(OUTL, 'w', encoding='utf-8') as f:
    f.write("\n".join(outline))
with open(OUT, 'w', encoding='utf-8') as f:
    f.write("\n".join(dialogue))

print("=== STATS ===")
for k,v in sorted(stats.items()):
    print(f"{k}: {v}")
print(f"outline lines: {len(outline)}  -> {OUTL}")
print(f"dialogue lines: {len(dialogue)} -> {OUT}")
