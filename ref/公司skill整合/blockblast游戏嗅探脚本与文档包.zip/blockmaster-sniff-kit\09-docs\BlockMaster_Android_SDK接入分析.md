# Block Master 原版 Android SDK 接入分析

> 来源工程：`E:\blockh5\build\android_ps\proj`
> 业务源码：`E:\blockh5\native\engine\android\app`
> 用途：作为 Block Master 换皮工程（V7）SDK 对齐的参考基线。

---

## 一、工程结构

- Cocos Creator 3.8.7 原生 Android 工程。
- Gradle 聚合模块：
  - `libcocos`：Cocos 引擎
  - `libservice`：Cocos 标准 `SDKWrapper` 生命周期壳
  - `app`：业务工程，位于 `E:\blockh5\native\engine\android\app`
- 包名：`com.driftsand.game.blockmaster`
- 版本：`VERSION_NAME=1.0.1.5`，`VERSION_CODE=1015`
- ABI：`arm64-v8a:armeabi-v7a`

---

## 二、渠道双包设计（PS / GP）

`app/build.gradle` 使用 Product Flavor 区分渠道：

| 渠道 | 说明 | 额外 sourceSet |
|---|---|---|
| `ps` | 传音 / Palm Store 内部渠道，含 PalmUpdate、ABTest、AhaLocalPush | `src-ps` |
| `gp` | Google Play 渠道，不包含私有 SDK | `src-gp` |

核心封装：

- 渠道差异收敛到同名类 `ChannelSdkBridge`：
  - `src-ps/.../ChannelSdkBridge.java`：真实现
  - `src-gp/.../ChannelSdkBridge.java`：空实现
- 调用方只静态调用，无 if / 无反射。
- 私有 SDK 使用 `psImplementation` 依赖，GP 包不会打入。

---

## 三、SDK 清单

| SDK | 依赖坐标 | 用途 | 渠道 |
|---|---|---|---|
| Firebase Analytics | `firebase-bom:34.12.0` + `firebase-analytics` | 统计 | 通用 |
| Firebase Crashlytics | `firebase-crashlytics` | 崩溃上报 | 通用 |
| Firebase Remote Config | `firebase-config` | 远程配置 | 通用 |
| Athena | `com.transsion.api:athena-ga:3.1.1.9` | 埋点 | 通用 |
| SnowBall | `com.transsion.api:athena-ga:1.3.0.0-snowball` | 归因/埋点 | 通用 |
| Athena Attribution | `com.transsion.api:athena-attribution:1.0.0.3` | 归因 | 通用 |
| Hisavana Mediation | `com.cloud.hisavana.sdk.mediation:mediation-lib:3.6.0.0` | 广告聚合 | 通用 |
| Admob Adapter | `admob-lib:3.6.0.0` | 广告 | 通用 |
| Pangle Adapter | `pangle-lib:3.6.0.0` + `com.google.ads.mediation:pangle:7.1.0.8.0` | 广告 | 通用 |
| Vungle Adapter | `com.google.ads.mediation:vungle:7.5.0.0` | 广告 | 通用 |
| PalmUpdateSDK | `com.transsion.attribution:upgrade:1.1.13` | 升级 | 仅 PS |
| AhaLocalPush | `net.bat.pushCore:push:3.0.0.1` | 本地推送 | 仅 PS |
| ABTest | `net.bat.store:abTest:0.0.9` + `com.transsion.galileo:galileojava:1.1.0` | A/B 实验 | 仅 PS |
| Google Play Billing | `com.android.billingclient:billing:7.1.1` | 支付 | 通用 |
| GAID | `com.google.android.gms:play-services-ads-identifier:18.0.1` | 广告 ID | 通用 |

---

## 四、应用初始化链路

### 1. `GameApplication.onCreate`

```text
DeviceInfoBridge.init(this)
ChannelSdkBridge.initApplication(this)   // AhaLocalPush + ABTest
AthenaSDK.initSDK(this)
FirebaseRemoteConfigBridge.init(this)
```

- DeviceInfo 先初始化，为 ABTest 提供 GAID。
- ABTest 等待 GAID 最多 2 秒，超时用 `"aaa"` 占位。

### 2. `AppActivity.onCreate`

```text
SDKWrapper.shared().init(this)
LoadingOverlay.show(this)
AthenaSDK.trackCommon("game_logo_ga", "{}")   // 冷启动
DStudioUtilsSDK.initSDK(this)
HisavanaSDK.initWebPath(this)
HisavanaSDK.setActivity(this)
DeviceInfoBridge.init(this)
FirebaseBridge.init(this)
ChannelSdkBridge.initActivity(this)          // PalmUpdateSDK
DeepLinkBridge.init(this)
DeepLinkBridge.handleIntent(getIntent())
```

### 3. `AppActivity` 生命周期

- `onResume`：`ChannelSdkBridge.onActivityResume()` + 延迟 1 秒 `checkUpdate`
- `onPause`：`ChannelSdkBridge.onActivityPause()`（AhaLocalPush 记录在线时长）

---

## 五、各 SDK 封装方式

### 1. Firebase

- `FirebaseBridge`：
  - `init()` → `FirebaseAnalytics.getInstance`
  - `logEvent` / `logEventWithParams` / `setUserId` / `setUserProperty`
- `FirebaseRemoteConfigBridge`：
  - `init()` 在 Application 调用
  - 默认值：`res/xml/remote_config_defaults.xml`
  - 复杂激活策略：上次会话待激活标记、登录完成时机、本次会话不切换分组
  - 提供 `getString/getBool/getNumber`

### 2. Athena

- `AthenaConfig`：
  - `DEBUG=false`
  - `TRACK_DEFAULT_TYPE=5943`
  - `EVENT_NAME=Drift_Sand`
- `AthenaSDK`：
  - `initSDK`：初始化 `AthenaAnalytics`
  - `track`：自定义事件，事件名固定 `Drift_Sand`
  - `trackCommon`：通用事件，事件名直接用传入 trackName
  - 自动附加 `host_pkg/host_vn/host_vc/vaid/customTrackName/param/ext`

### 3. Hisavana 广告

封装层级：

```text
CocosHisavanaBridge（TS 静态调用入口）
      ↓
HisavanaSDK（全局管理 + HashMap<slotId, Ad>）
      ↓
GameTRewardedAd / GameTInterstitialAd / GameTBannerAd
      ↓
IGameTAdListener（统一回调）
```

- `HisavanaSDK.InitSDK` → `TAdManager.init`
- Banner：代码动态创建 `FrameLayout`，`SIZE_320x50` 底部对齐
- 回调统一：
  ```js
  window.__onHisavanaCallback(type, event, data)
  ```
  - type：`init / reward / interstitial / banner`
  - event：`onLoad / onError / onShow / onShowError / onClicked / onClosed / onRewarded`

### 4. PalmUpdateSDK（PS）

- `PalmUpdateSDKConfig.APP_KEY = 2b9158986d6c9969374e93a2e7d3df78`
- `PalmUpdateSDKBridge`：
  - `initSDK(activity, isDebug)`
  - `checkUpdate(activity)`
  - `showUpgradeDialog()`
  - `isNewVersion()`

### 5. ABTest（PS）

- `ABTestConfig.APP_KEY = "blockGames"`
- `ABTestSDKBridge`：
  - `init(Application, gaid)`
  - `isInited()`
  - `getConfigString(key, defVal)`
  - `getConfigJson(key)`
- 初始化在 `ChannelSdkBridge.initApplication` 中异步完成。

### 6. AhaLocalPush（PS）

- `AhaPushSDK.initSDK(app)`：Application 初始化
- `AhaPushSDK.onActivityPause()`：记录活跃时间
- `AhaPersistentHandler.onActivityResume()`：停止常驻栏轮询
- 包含完整配置仓库与 Handler 体系。

### 7. DeviceInfoBridge

- 异步获取 GAID（必须子线程）
- 用户限制广告跟踪时返回空串
- 支持 adb 广播动态切换日志：
  ```bash
  adb shell am broadcast -a com.driftsand.game.SET_LOG_STATE --ez state true -p <pkg>
  ```

### 8. DStudioUtilsSDK

- 提供国家码、MCC、Toast 等工具。

### 9. DeepLinkBridge

- 冷启动：缓存 URL，TS 通过 `getPendingUrl()` 消费
- 热启动：`onNewIntent` 后回调 `window.__onDeepLink(url)`

---

## 六、JS ↔ 原生桥接规范

- JS → Java：
  ```js
  native.reflection.callStaticMethod('类名', '方法名', '签名', 参数...)
  ```
- Java → JS：
  - `CocosJavascriptJavaBridge.evalString(js)`
  - `JsbBridgeWrapper.dispatchEventToScript(eventName, data)`

---

## 七、对 V7 换皮工程的接入建议

1. V7 已通过注入 BM dex 包含上述 Bridge 类与底层 SDK 类。
2. 主要缺口不是“类不存在”，而是：
   - 当前 App 入口仍使用 BB 的 NIS Shell `MyApplication` 与 `org.cocos2dx.javascript.AppActivity`，原版 SDK 初始化链未启动。
   - Firebase 的 `google-services.json` 派生资源可能未完整写入。
   - PS 渠道私有 SDK（PalmUpdate/ABTest/AhaLocalPush）的 manifest 组件/权限可能缺失。
   - JS 侧尚未调用原版 `FirebaseRemoteConfigBridge` / `ABTestSDKBridge` / `DeepLinkBridge` / `PalmUpdateSDKBridge` 等。
3. 对齐方式：
   - 保留 NIS Shell 时：在 `MyApplication.onCreate` / 现有 Activity 中补调原版 Bridge。
   - 不保留 NIS Shell 时：直接把 Application/Activity 切到 `com.driftsand.game.GameApplication` / `com.driftsand.game.AppActivity`。

---

## 八、V8 接入实况（2026-08-22）

已在 V7 基础上按原版接入方式做了第一轮“激活”：

- 在 `BMInitProvider.onCreate` 增加：
  - `DeviceInfoBridge.init`
  - `FirebaseBridge.init`
  - `FirebaseRemoteConfigBridge.init`
  - `ChannelSdkBridge.initApplication`（AhaLocalPush + ABTest）
- 在 `BMInitProvider$1.onActivityCreated` 增加：
  - `DStudioUtilsSDK.initSDK`
  - `ChannelSdkBridge.initActivity`（PalmUpdateSDK）
  - `DeepLinkBridge.init` + `handleIntent`
- 在 `onActivityResumed` / `onActivityPaused` 增加：
  - `ChannelSdkBridge.onActivityResume` / `onActivityPause`
  - 首次 Resumed 时 `ChannelSdkBridge.checkUpdate`
- 补入 `res/xml/remote_config_defaults.xml`
- 将注入 dex 中 `R$xml.remote_config_defaults` 重映射到 V8 资源 ID `0x7f17000e`

真机验证结果：

- ✅ FirebaseAnalytics 初始化成功
- ✅ FirebaseRemoteConfig 开始拉取远程配置
- ✅ DeviceInfoBridge GAID 获取成功
- ✅ PalmUpdateSDK 检测到“未安装 Palm Store”（正常降级）
- ✅ DeepLinkBridge 初始化
- ✅ 进程稳定，无 FATAL EXCEPTION

已知遗留问题：

- ⚠️ AhaLocalPush 依赖的 MMKV 方法与 V7 基座内置 MMKV 版本不匹配：
  - `NoSuchMethodError: MMKV.s(String,I)Z`
  - `NoSuchMethodError: MMKV.v(String,String)Z`
  - 被 try/catch 捕获，不影响主流程；但 AhaPush 功能未真正可用。
- ⚠️ `hs_common_dimens_111dp` 等 BM 资源 ID 未全部重映射，IconLoader 有资源警告，不影响启动。
- ⚠️ `com.block.juggle.datareport.firebase.SFireBaseDataAdapter` 缺失为 BB 基座旧引用，非本次新增问题。
