# -*- coding: utf-8 -*-
"""C2: remove Bugsnag auto-init entries from AndroidManifest."""
import io

MANIFEST = r'E:\codex_apk_work\blockmaster_pro_swap\work\stage2_sdk\AndroidManifest.xml'

def main():
    with io.open(MANIFEST, encoding='utf-8') as f:
        s = f.read()

    targets = [
        '        <meta-data android:name="com.bugsnag.android.API_KEY" android:value="ff75b8d00cdfb07d847d460774d19e94"/>\n',
        '        <provider android:authorities="com.driftsand.game.blockmaster.bugsnag-startup" android:exported="false" android:initOrder="9000" android:name="com.bugsnag.android.internal.BugsnagContentProvider"/>\n',
        '        <meta-data android:name="com.bugsnag.android.BUILD_UUID" android:value="e7650a17-1754-4e92-afb2-1e242a08c396"/>\n',
    ]
    for t in targets:
        assert t in s, 'missing: ' + t
        s = s.replace(t, '')
    with io.open(MANIFEST, 'w', encoding='utf-8', newline='\r\n') as f:
        f.write(s)
    print('removed Bugsnag manifest entries')
    assert 'bugsnag' not in s.lower(), 'remaining bugsnag in manifest'

if __name__ == '__main__':
    main()
