﻿# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding="utf-8")
s = "椭圆 2"
alias = "".join(chr(0xFF00 + b) for b in s.encode("utf-8"))
print("alias:", alias, [hex(ord(c)) for c in alias])
print("length:", len(alias))
target = "￦ﾤﾭ￥ﾜﾆ 2"
print("target:", target, [hex(ord(c)) for c in target])
print("equal:", alias == target)
