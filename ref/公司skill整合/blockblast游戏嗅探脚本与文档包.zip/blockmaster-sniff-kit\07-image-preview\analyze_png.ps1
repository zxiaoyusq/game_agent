param(
  [Parameter(Mandatory=$true)][string]$Path
)
Add-Type -AssemblyName System.Drawing
$bmp = New-Object System.Drawing.Bitmap($Path)
$w = $bmp.Width
$h = $bmp.Height
$total = $w * $h
$dark = 0
$black = 0
$colored = 0
$bright = 0
$rSum = [long]0; $gSum = [long]0; $bSum = [long]0
$step = [Math]::Max(1, [int]($total / 200000))
for ($y = 0; $y -lt $h; $y += $step) {
  for ($x = 0; $x -lt $w; $x += $step) {
    $c = $bmp.GetPixel($x, $y)
    $lum = (0.299 * $c.R + 0.587 * $c.G + 0.114 * $c.B)
    $rSum += $c.R; $gSum += $c.G; $bSum += $c.B
    if ($lum -lt 30) { $dark++ }
    if ($lum -lt 12) { $black++ }
    $maxc = [Math]::Max($c.R, [Math]::Max($c.G, $c.B))
    $minc = [Math]::Min($c.R, [Math]::Min($c.G, $c.B))
    if (($maxc - $minc) -gt 40 -and $maxc -gt 60) { $colored++ }
    if ($lum -gt 160) { $bright++ }
  }
}
$n = [Math]::Ceiling($total / $step / $step)
$bmp.Dispose()
"size=$w x $h sampled=$n"
"darkPct=$([Math]::Round(100.0*$dark/$n,1)) blackPct=$([Math]::Round(100.0*$black/$n,1)) coloredPct=$([Math]::Round(100.0*$colored/$n,1)) brightPct=$([Math]::Round(100.0*$bright/$n,1))"
"avgRGB=$([Math]::Round($rSum/$n)) $([Math]::Round($gSum/$n)) $([Math]::Round($bSum/$n))"
