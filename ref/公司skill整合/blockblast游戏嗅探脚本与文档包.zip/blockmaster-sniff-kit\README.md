# blockmaster-sniff-kit · BlockMaster / Block Blast 嗅探脚本与文档包

> 打包时间：2026-08-20 ｜ 来源根目录：`E:\codex_apk_work`
> 内容：本次（及此前）嗅探路径中实际使用的**脚本 165 个 + 说明文档 12 份**，外加重跑必需的**映射表数据 16 个**，共 **177 个文件**（约 2.4 MB）。
> 配套方法论：`09-docs/BlockMaster_嗅探方法论与参数手册.md`（**先读这份**，它把本包的每个脚本串成了可重跑的路径）

---

## 一、目录索引

| 目录 | 文件数 | 内容 | 对应方法论章节 |
|---|---:|---|---|
| `01-decrypt` | 17 | HEK:XOR / HEK:XXTEA / AFFA 解密、密钥分析、gzip 多成员解析 | §1 |
| `02-resindex` | 7 | **资源索引工具（必用）**：build_index.py、resindex.py、ri.cmd、naming_map.json | §2 |
| `03-trait-algo` | 7 | Trait 提取/关联/验收、埋点表生成 | §3 |
| `04-remote-bundle` | 4 | 远程皮肤/Trait bundle 下载与整理 | §4 |
| `05-js-heap` | 16 | JS 明文提取、堆内存搜索、Frida 挂钩与 dump | §3、§7 |
| `06-static-analysis` | 9 | dex/so 分析、Manifest 过滤与校验 | §7 |
| `07-image-preview` | 31 | PKM→PNG、图集检查、Spine/DragonBones 预览生成、CDP 诊断 | §2、§4 |
| `08-build-tools` | 52 | v9~v40 各版本构建脚本、离线 seed、SDK patch/merge | §7 |
| `09-docs` | 12 | **本次要求的 12 份说明文档** | 全部 |
| `10-data-artifacts` | 16 | Trait/远程包**映射表 JSON**（重跑必需，非脚本） | §3、§4 |
| `99-misc` | 6 | 换 logo、设计文档 HTML 生成等一次性脚本 | — |

---

## 二、文档清单（`09-docs/`）

| 文件 | 内容 |
|---|---|
| **`BlockMaster_嗅探方法论与参数手册.md`** | **入口文档**：环境前置、三层加密参数、resindex、JS/Trait 取证、远程包、真机网络与埋点、复现 checklist、纪律红线 |
| `两层全量美术资源统计.md` | 本体/皮肤/Trait 三块 SHA1 去重后的美术资源总量 |
| `美术表现规则文档.md` | 皮肤/配色/特效/分发四套系统（美术视角） |
| `低端机适配6.5详解.md` | 6.5 低端机 checklist 五项逐条详解 |
| `BlockMaster_SDK与联网拉取盘点.md` | SDK 全量清单 + 启动联网拉取链路 |
| `BlockMaster_Android_SDK接入分析.md` | 原版 Android 工程结构与 PS/GP 双渠道 |
| `BlockMaster_V34_埋点事件与网络上报审计.md` | 114 个埋点事件、Athena 四级证据、原厂域名静态清单 |
| `BlockMaster_广告策略全解.md` | 广告机制与触发条件全表 |
| `BlockMaster_原版广告策略还原_展示时机与瀑布.md` | 展示时机、瀑布/竞价、频控与底价还原 |
| `BlockMaster_广告QA验证手册.md` | 广告"加载→展示→回调"逐步验证 |
| `BlockMaster_v7_满配置包资源缺口清单.md` | 内置 vs 全量对比与缺口 |
| `BlockMaster_v7_低端机专用包资源剔除清单.md` | 低端机包分层体积与剔除项 |

---

## 三、环境前置（**不满足则脚本全失败**）

```powershell
# 1) Python 必须用绝对路径 —— PATH 上的 python 是 Windows Store 占位程序，会报
#    "The file cannot be accessed by the system"
& 'C:\Program Files\Python312\python.exe' -X utf8 <脚本.py>

# 2) PowerShell 5 脚本（.ps1）含中文时必须存为 UTF-8 with BOM，否则 ParserError
# 3) 本机无 pwsh，请用： powershell -NoProfile -ExecutionPolicy Bypass -File xxx.ps1
```

把本包放到 `E:\codex_apk_work\` 下的任意位置即可；但**脚本内的路径常量写死了 `E:\codex_apk_work`
的来源路径**（如 `SRC`/`DST`/`REF`），迁移目录后需先改脚本头部的常量。

---

## 四、快速上手（5 分钟复现一条链路）

```powershell
cd E:\codex_apk_work

# A. 资源检索（最常用，先跑冒烟测试）
.\resindex\ri.cmd where                       # 看 rows 是否非零
.\resindex\ri.cmd find backgroundbg --ext .png
.\resindex\ri.cmd zh 结算背景
.\resindex\ri.cmd extract Remote_Skin_Material_2033/backgroundbg -o out

# B. 解密（改好脚本头部的 SRC/DST 再跑）
& 'C:\Program Files\Python312\python.exe' -X utf8 scripts\decrypt_resources.py   # 资源 HEK:XOR
& 'C:\Program Files\Python312\python.exe' -X utf8 scripts\decrypt_jsc.py         # JS  HEK:XXTEA
& 'C:\Program Files\Python312\python.exe' -X utf8 scripts\affa_survey.py         # AFFA 内层普查

# C. 索引重建
& 'C:\Program Files\Python312\python.exe' -X utf8 resindex\build_index.py
```

### 冒烟测试（下"资源不存在"结论前必做）

```powershell
.\resindex\ri.cmd where
(.\resindex\ri.cmd find backgroundbg --ext .png | Measure-Object -Line).Lines   # 应非零
```

> ⚠️ `where` 报的行数很大但 `find` 恒为 `0 条` ⇒ **索引库坏了**，重跑 `build_index.py`。
> 不先冒烟测试，就会把"索引故障"误判成"资源缺失"。

---

## 五、关键参数速查（🔑 可复现）

| 项 | 值 |
|---|---|
| XOR 密钥 | `65485d8a-8161-4c`（16 字节 ASCII 循环异或） |
| XXTEA 密钥 | 同上一把；`DELTA = 0x9E3779B9`，`MASK = 0xFFFFFFFF` |
| 分流依据 | `HEK:` + v**03** → XOR（`data[8:]` 起）｜`HEK:` + v**01** → XXTEA |
| AFFA 标记 | 解密后 `pt[:2] == b"\xaf\xfa"` |
| 压缩 | 明文可能是 gzip（`1F 8B`），且**可能多成员**，需循环解 |
| 作用范围 | `HEK:XOR` **同时作用于 `.json` 和 `.png`** |
| 运行时取明文 | `jsb.fileUtils.getStringFromFile()`（静态解密失败时的后门） |
| 热更路径 | `/data/user/0/<pkg>/files/patch/`，顺序 `main.jsc` → `main.js` → APK assets |

---

## 六、本包不含（需从工程内另行获取）

| 项 | 说明 |
|---|---|
| `resindex.db`（~49 MB） | 体积大且可由 `build_index.py` 重建；**本包含重建脚本** |
| APK / 解包素材 / 皮肤包 | 版权与体积原因不打包；路径见方法论 §2.4 |
| `apktool_2.9.3.jar`、`frida-server-*` | 第三方二进制，留在 `tools\` 目录 |
| `trait_decorator_registry.json` 等的**生成脚本** | 当时为临时脚本，未保留；**产物 JSON 已包含**（`10-data-artifacts/`），可直接当输入 |
| 设备日志 / 抓包 / 截图 | 含环境与个人信息，不打包 |

---

## 七、使用纪律（务必遵守）

1. **找图先查 `resindex`**，禁止用 grep/内容扫描找图片资源（APK 内是加密+哈希命名，必然失败）。
2. **先找真实执行路径**：文件存在 ≠ 运行时会用；桥接调用 ≠ 真正上报成功。
3. **分清 4 套同族工程**：`blockmaster_apk` / `bb_1047_base.apk`(10.4.7) / `com.block.juggle.base.apk`(9.5.0) / 全量解包。
   同名资源在不同工程里不是同一张图，下结论前先确认工程。
4. **证据分级**：静态结构 < 脚本测试 < 模拟器 < 真机画面/日志 < 网络抓包 < 平台后台。不得互相替代。
5. **不重新分发**无授权的原始游戏资产、密钥或用户数据；本包仅含脚本、文档与映射表。
