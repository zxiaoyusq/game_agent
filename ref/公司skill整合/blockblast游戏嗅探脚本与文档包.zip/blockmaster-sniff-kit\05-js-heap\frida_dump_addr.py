#!/usr/bin/env python3
"""Dump a list of addresses from the game process."""
import frida
import os
import sys

JS = r"""
'use strict';
function dump(addrHex, size) {
    return ptr(addrHex).readByteArray(size);
}
rpc.exports = { dump: dump };
"""

OUT = r"E:\codex_apk_work\memdump"
os.makedirs(OUT, exist_ok=True)

TARGETS = [
    ("require_ascii_1", 0x30300700436c - 0x800, 0x2000),
    ("require_utf16_1", 0x3030017c001c - 0x800, 0x2000),
    ("ccgame_utf16_1", 0x3030005ae9de - 0x800, 0x2000),
    ("usestrict_utf16_1", 0x3030002c0428 - 0x800, 0x4000),
    ("usestrict_utf16_2", 0x3030002c4334 - 0x800, 0x4000),
]

PID = int(sys.argv[1]) if len(sys.argv) > 1 else 5829

dev = frida.get_device_manager().add_remote_device('127.0.0.1:27042')
session = dev.attach(PID)
script = session.create_script(JS)
script.load()
for name, addr, size in TARGETS:
    try:
        data = script.exports_sync.dump(hex(addr), size)
        if data is None:
            print(name, "EMPTY")
            continue
        with open(os.path.join(OUT, name + ".bin"), "wb") as f:
            f.write(data)
        print(name, "dumped", len(data))
    except Exception as e:
        print(name, "ERROR", e)
session.detach()
