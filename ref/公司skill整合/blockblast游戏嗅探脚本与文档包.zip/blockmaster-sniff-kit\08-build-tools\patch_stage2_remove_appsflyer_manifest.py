# -*- coding: utf-8 -*-
"""C1: remove AppsFlyer auto-init entries from AndroidManifest."""
import io, os, re

MANIFEST = r'E:\codex_apk_work\blockmaster_pro_swap\work\stage2_sdk\AndroidManifest.xml'

def read():
    with io.open(MANIFEST, encoding='utf-8') as f:
        return f.read()

def write(s):
    with io.open(MANIFEST, 'w', encoding='utf-8', newline='\r\n') as f:
        f.write(s)

def main():
    s = read()
    # 1) remove fullBackupContent attribute
    old_attr = ' android:fullBackupContent="@xml/appsflyer_backup_rules"'
    assert old_attr in s, 'fullBackupContent attr missing'
    s = s.replace(old_attr, '')

    # 2) remove queries install provider intent
    old_query = '''        <intent>
            <action android:name="com.appsflyer.referrer.INSTALL_PROVIDER"/>
        </intent>
'''
    assert old_query in s, 'appsflyer install provider query missing'
    s = s.replace(old_query, '')

    # 3) remove SingleInstallBroadcastReceiver receiver block
    receiver_block = '''        <receiver android:exported="true" android:name="com.appsflyer.SingleInstallBroadcastReceiver">
            <intent-filter>
                <action android:name="com.android.vending.INSTALL_REFERRER"/>
            </intent-filter>
        </receiver>
'''
    assert receiver_block in s, 'SingleInstallBroadcastReceiver block missing'
    s = s.replace(receiver_block, '')

    # 4) remove FirebaseMessagingServiceListener service block
    service_block = '''        <service android:exported="false" android:name="com.appsflyer.FirebaseMessagingServiceListener">
            <intent-filter>
                <action android:name="com.google.firebase.MESSAGING_EVENT"/>
            </intent-filter>
        </service>
'''
    assert service_block in s, 'FirebaseMessagingServiceListener block missing'
    s = s.replace(service_block, '')

    write(s)
    print('removed AppsFlyer manifest entries')
    assert 'appsflyer' not in s.lower(), 'remaining appsflyer in manifest'

if __name__ == '__main__':
    main()
