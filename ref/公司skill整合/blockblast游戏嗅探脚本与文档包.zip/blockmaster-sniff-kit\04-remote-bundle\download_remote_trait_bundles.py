#!/usr/bin/env python3
"""Download Block Blast remote trait / feature bundles from the game CDN.

Phase 1: config.<ver>.json + index.<ver>.js for every bundle in the full
bundleVers manifest recovered from the heap dump (remote_manifest_full.json).

Files are encrypted with the "HEK:" XOR scheme (key recovered from the APK);
configs decrypt to plaintext Cocos bundle JSON.  index.js decrypts to the
second-layer encrypted script payload (kept raw for later analysis).
"""
import gzip
import json
import os
import sys
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

KEY = b"65485d8a-8161-4c"
BASE = "https://bband1.afafb.com/update/block_android_online/remoteRes/0/remote/"
OUT_ROOT = r"E:\codex_apk_work\remote_traits"
MANIFEST = r"E:\codex_apk_work\main_algo_extract\remote_manifest_full.json"
HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Linux; Android 14; Pixel 8) "
                   "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36"),
    "Accept": "*/*",
}


def decrypt(data):
    if not data.startswith(b"HEK:"):
        return data
    body = data[8:]
    ks = (KEY * (len(body) // 16 + 1))[:len(body)]
    pt = bytes(a ^ b for a, b in zip(body, ks))
    if pt[:2] == b"\x1f\x8b":
        try:
            pt = gzip.decompress(pt)
        except Exception:
            pass
    return pt


def http_get(url, timeout=30):
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def save(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(data)


def main():
    manifest = json.load(open(MANIFEST, encoding="utf-8"))
    bv = manifest["bundleVers"]
    # trait bundles + notable non-skin feature bundles
    selected = {}
    for name, ver in bv.items():
        if "Trait" in name or name.startswith("Remote_") and not name.startswith("Remote_Skin"):
            selected[name] = ver
    print("selected bundles:", len(selected))

    results = {"ok": 0, "fail": [], "config_plaintext": 0, "index_hek": 0}

    def work(item):
        name, ver = item
        out = {"name": name, "ver": ver, "config": None, "index": None}
        # config
        try:
            raw = http_get(BASE + f"{name}/config.{ver}.json")
            save(os.path.join(OUT_ROOT, "raw", name, f"config.{ver}.json"), raw)
            pt = decrypt(raw)
            save(os.path.join(OUT_ROOT, "dec", name, f"config.{ver}.json"), pt)
            out["config"] = len(pt)
            if pt[:1] == b"{":
                results["config_plaintext"] += 1
        except Exception as e:
            out["config"] = f"ERR {getattr(e, 'code', e)}"
        # index
        try:
            raw = http_get(BASE + f"{name}/index.{ver}.js")
            save(os.path.join(OUT_ROOT, "raw", name, f"index.{ver}.js"), raw)
            pt = decrypt(raw)
            save(os.path.join(OUT_ROOT, "dec", name, f"index.{ver}.js"), pt)
            out["index"] = len(pt)
            if raw[:4] == b"HEK:":
                results["index_hek"] += 1
        except Exception as e:
            out["index"] = f"ERR {getattr(e, 'code', e)}"
        return out

    with ThreadPoolExecutor(max_workers=12) as ex:
        futs = [ex.submit(work, item) for item in selected.items()]
        done = 0
        for f in as_completed(futs):
            r = f.result()
            done += 1
            if "ERR" in str(r["config"]) or "ERR" in str(r["index"]):
                results["fail"].append(r)
            else:
                results["ok"] += 1
            if done % 500 == 0:
                print(f"progress {done}/{len(futs)} ok={results['ok']}")

    print("OK bundles:", results["ok"])
    print("failures:", len(results["fail"]))
    for r in results["fail"][:40]:
        print("  ", r["name"], r["ver"], r["config"], r["index"])
    with open(os.path.join(OUT_ROOT, "download_report.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
