import gzip
import struct
import sys
import zlib

sys.path.insert(0, r"E:\codex_apk_work\scripts")
from decrypt_jsc import KEY, xxtea_decrypt

raw = open(r"E:\codex_apk_work\blockblast_extracted\assets\assets\gl_fruit\index.701f6.jsc", "rb").read()
r = xxtea_decrypt(raw, KEY)
print("decrypted len:", len(r), "head:", r[:4].hex())

# manual gzip member parse
data = r
member = 0
while True:
    if len(data) < 10 or data[:2] != b"\x1f\x8b":
        print("no more gzip at", len(data), "remaining head:", data[:16].hex())
        break
    member += 1
    print("member", member, "header:", data[:10].hex())
    method, flag = data[2], data[3]
    mtime = struct.unpack("<I", data[4:8])[0]
    pos = 10
    if flag & 0x04:  # FEXTRA
        xlen = struct.unpack("<H", data[pos:pos + 2])[0]
        pos += 2 + xlen
    if flag & 0x08:  # FNAME
        while data[pos] != 0:
            pos += 1
        pos += 1
    if flag & 0x10:  # FCOMMENT
        while data[pos] != 0:
            pos += 1
        pos += 1
    if flag & 0x02:  # FHCRC
        pos += 2
    d = zlib.decompressobj(wbits=-zlib.MAX_WBITS)
    out = d.decompress(data[pos:])
    used = len(data[pos:]) - len(d.unused_data)
    print("  decompressed:", len(out), "consumed:", used)
    crc, length = struct.unpack("<II", d.unused_data[:8])
    print("  crc ok:", crc == zlib.crc32(out), "length ok:", length == len(out) & 0xFFFFFFFF)
    print("  tail:", out[:120])
    print("  tail last:", out[-80:])
    data = d.unused_data[8:]
    if member >= 3:
        break

open(r"E:\codex_apk_work\memdump\jsc_first_member.bin", "wb").write(out)
