# -*- coding: utf-8 -*-
"""Associate the trait bundle directories with recovered trait classes.

Each Trait dir under the rebuilt project is a Cocos bundle named after the
trait class. We match it against the classId registry recovered from the heap
dump and compute per-directory asset-type statistics.
"""
import os
import re
import json
import collections

PROJECT = r"E:\codex_apk_work\blockblast_project\assets"
EXTRACT = r"E:\codex_apk_work\main_algo_extract"


def norm(name):
    return re.sub(r"[^A-Za-z0-9]", "", name).lower()


def main():
    trait_classes = json.load(open(os.path.join(EXTRACT, "trait_classes.json"), encoding="utf-8"))
    class_norm = {norm(k): k for k in trait_classes}

    dirs = []
    for root, dnames, fnames in os.walk(PROJECT):
        base = os.path.basename(root)
        if base.endswith("Trait"):
            rel = os.path.relpath(root, PROJECT)
            dirs.append((base, root, fnames))

    rows = []
    asset_kinds = collections.Counter()
    for name, path, fnames in dirs:
        n = norm(name)
        if n in class_norm:
            match = ("exact", class_norm[n])
        else:
            cand = [k for k in trait_classes if n in norm(k) or norm(k) in n]
            match = ("fuzzy", sorted(cand)[:3]) if cand else ("none", None)
        # config name field
        cfg_name = None
        cfg = os.path.join(path, "config.original.json")
        if os.path.exists(cfg):
            try:
                cfg_name = json.load(open(cfg, encoding="utf-8")).get("name")
            except Exception:
                pass
        kinds = collections.Counter()
        for f in fnames:
            if f == "config.original.json" or f.endswith(".meta"):
                continue
            ext = os.path.splitext(f)[1].lower()
            kinds[ext] += 1
        asset_kinds.update(kinds)
        rows.append(
            {
                "dir": name,
                "configName": cfg_name,
                "match": match[0],
                "matchTarget": match[1],
                "exts": dict(kinds),
            }
        )

    rows.sort(key=lambda r: r["dir"].lower())
    with open(os.path.join(EXTRACT, "trait_dir_association.json"), "w", encoding="utf-8") as fh:
        json.dump({"total": len(rows), "rows": rows}, fh, ensure_ascii=False, indent=1)

    by_match = collections.Counter(r["match"] for r in rows)
    print("total trait dirs (depth1):", len(rows))
    print("match:", dict(by_match))
    print("asset ext totals:", dict(asset_kinds))

    # summary of exact matches
    exact = [r for r in rows if r["match"] == "exact"]
    print("\nexact matches (%d):" % len(exact))
    for r in exact:
        print("  ", r["dir"])


if __name__ == "__main__":
    main()
