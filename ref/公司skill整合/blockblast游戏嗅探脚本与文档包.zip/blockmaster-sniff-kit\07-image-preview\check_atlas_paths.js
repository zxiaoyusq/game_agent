const fs = require('fs');

function loadData(fp) {
  const html = fs.readFileSync(fp, 'utf8');
  let m = html.match(/const DATA = (\[[\s\S]*?\]);\r?\nlet cur = -1;/);
  if (!m) m = html.match(/const DATA = (\[[\s\S]*?\]);/);
  if (!m) throw new Error('DATA not found: ' + fp);
  return JSON.parse(m[1]);
}

function atextOf(au) {
  const payload = au.split(',')[1];
  return Buffer.from(payload, 'base64').toString('utf8');
}

function firstImageLine(t) {
  for (const ln of t.split('\n')) if (ln.trim()) return ln.trim();
  return '';
}

const targets = [
  ['OURS', 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810/spine-preview/preview.html'],
  ['REF ', 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/blast-block-spine/preview.html'],
];

for (const [label, fp] of targets) {
  const data = loadData(fp);
  let slashCnt = 0, parentNon = 0, validImg = 0, noImg = 0;
  const examples = [];
  for (const it of data) {
    const au = it.atlasUrl || '';
    const payload = au.includes(',') ? au.split(',')[1] : '';
    slashCnt += payload.split('/').length - 1;
    const last = au.lastIndexOf('/');
    const parent = last >= 0 ? au.slice(0, last) : '';
    let atext = '';
    try { atext = atextOf(au); } catch (e) {}
    const imgline = firstImageLine(atext);
    const full = parent ? parent + '/' + imgline : imgline;
    if (parent) {
      parentNon++;
      if (examples.length < 3) {
        examples.push({
          name: it.name,
          parentLen: parent.length,
          imgPrefix: imgline.slice(0, 45),
          fullPrefix: full.slice(0, 90),
          fullIsDataUrl: full.startsWith('data:image/png;base64,'),
        });
      }
    } else if (imgline.startsWith('data:image/png;base64,')) {
      validImg++;
    } else {
      noImg++;
    }
  }
  console.log(label, 'entries=' + data.length, 'payloadSlashes=' + slashCnt,
    'parentNonEmpty=' + parentNon, 'validImg=' + validImg, 'noImg=' + noImg);
  for (const e of examples) console.log('   ', JSON.stringify(e));
}
