# -*- coding: utf-8 -*-
"""Build per-trait-dir evidence: where the name appears in the memory corpus."""
import os
import re
import json

ROOT = r"E:\codex_apk_work\memdump\js_strings"
EXTRACT = r"E:\codex_apk_work\main_algo_extract"


def main():
    assoc = json.load(open(os.path.join(EXTRACT, "trait_dir_association.json"), encoding="utf-8"))
    dir_names = sorted(set(r["dir"] for r in assoc["rows"]))
    class_ids = json.load(open(os.path.join(EXTRACT, "trait_classes.json"), encoding="utf-8"))

    evidence = {n: {"total": 0, "classId": False, "nameList": 0, "traitClassName": 0, "files": set()} for n in dir_names}
    re_classid = re.compile(r'classId\(\s*"([^"]+)"\s*\)')
    re_namelist = re.compile(r'\{\s*name:\s*"([^"]+)"')
    re_traitclass = re.compile(r'traitClassName:\s*"([^"]+)"')

    for fn in sorted(os.listdir(ROOT)):
        if not fn.endswith(".js"):
            continue
        txt = open(os.path.join(ROOT, fn), encoding="utf-8", errors="ignore").read()
        # build fast maps for this file
        cids = set(re_classid.findall(txt))
        nls = set(re_namelist.findall(txt))
        tcs = set(re_traitclass.findall(txt))
        for n in dir_names:
            c = txt.count(n)
            if c == 0:
                continue
            e = evidence[n]
            e["total"] += c
            e["files"].add(fn)
            if n in cids:
                e["classId"] = True
            if n in nls:
                e["nameList"] += 1
            if n in tcs:
                e["traitClassName"] += 1

    rows = []
    for n in dir_names:
        e = evidence[n]
        rows.append(
            {
                "dir": n,
                "occurrences": e["total"],
                "classIdRegistered": e["classId"] or n in class_ids,
                "inNameLists": e["nameList"],
                "inDecoratorConfigs": e["traitClassName"],
                "files": sorted(e["files"])[:6],
            }
        )
    rows.sort(key=lambda r: (-r["occurrences"], r["dir"].lower()))
    with open(os.path.join(EXTRACT, "trait_dir_evidence.json"), "w", encoding="utf-8") as fh:
        json.dump({"total": len(rows), "rows": rows}, fh, ensure_ascii=False, indent=1)

    n_classid = sum(1 for r in rows if r["classIdRegistered"])
    n_any = sum(1 for r in rows if r["occurrences"] > 0)
    print("trait dirs:", len(rows), "| with occurrences:", n_any, "| classId registered:", n_classid)
    for r in rows[:25]:
        print(f"  {r['occurrences']:4d}  classId={int(r['classIdRegistered'])}  nameList={r['inNameLists']:3d}  decor={r['inDecoratorConfigs']:3d}  {r['dir']}")


if __name__ == "__main__":
    main()
