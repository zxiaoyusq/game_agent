# -*- coding: utf-8 -*-
"""Seed completeness checker for Block Master remote_seed.

Acceptance semantics (per user decision):
- cacheList.json URL keys are the local file index; every file must exist -> cache_missing=0.
- Each cacheList bundle must be mapped in runtime settings bundleVers/remoteBundles -> unmapped_bundles=0.
- hash_conflict reported when a destination exists with different size during fill (not in check-only).
- patch/project.manifest catalog missing is informational only, not an acceptance gate.
"""
import argparse
import json
import os
import re
import shutil
import sys

SETTINGS_PATH = r'E:\codex_apk_work\blockmaster_pro_swap\work\v27_exact_mumu_clean\runtime_layers_extracted\files\bm_settings_settings.5731e.js'


def load_settings_bundles(path=SETTINGS_PATH):
    if not path or not os.path.exists(path):
        return [], []
    with open(path, encoding='utf-8') as f:
        s = f.read()
    # remoteBundles array
    m = re.search(r'remoteBundles:\s*\[(.*?)\]', s, re.S)
    remote = re.findall(r'"([^"]+)"', m.group(1)) if m else []
    # bundleVers object keys (unquoted/quoted)
    start = s.find('bundleVers: {')
    bundles = []
    if start != -1:
        i = s.find('{', start)
        depth = 0
        j = i
        while j < len(s):
            if s[j] == '{':
                depth += 1
            elif s[j] == '}':
                depth -= 1
                if depth == 0:
                    break
            j += 1
        obj = s[i:j + 1]
        bundles = [a if a else b for a, b in re.findall(r'"([A-Za-z0-9_]+)"\s*:|([A-Za-z0-9_]+)\s*:', obj)]
    return remote, bundles


def check_cache_list(seed_gamecaches):
    cache_list = os.path.join(seed_gamecaches, 'cacheList.json')
    with open(cache_list, encoding='utf-8') as f:
        data = json.load(f)
    files = data.get('files', {})
    present = 0
    missing = []
    bundles = set()
    for url, info in files.items():
        rel = info.get('url')
        if not rel:
            continue
        bundles.add(info.get('bundle'))
        p = os.path.join(seed_gamecaches, rel.replace('/', os.sep))
        if os.path.isfile(p) and os.path.getsize(p) > 0:
            present += 1
        else:
            missing.append((url, rel))
    return present, missing, bundles


def check_patch_manifest(seed_patch):
    manifest = os.path.join(seed_patch, 'project.manifest')
    if not os.path.exists(manifest):
        return 0, [], []
    with open(manifest, encoding='utf-8') as f:
        data = json.load(f)
    assets = data.get('assets', {})
    present = 0
    missing = []
    for rel in assets:
        p = os.path.join(seed_patch, rel.replace('/', os.sep))
        if os.path.isfile(p) and os.path.getsize(p) > 0:
            present += 1
        else:
            missing.append(rel)
    return present, missing, []


def fill_missing(seed, runtime_cache, runtime_patch):
    copied = 0
    conflicts = 0
    seed_gamecaches = os.path.join(seed, 'gamecaches', 'gamecaches')
    seed_patch = os.path.join(seed, 'patch', 'patch')
    cache_list = os.path.join(seed_gamecaches, 'cacheList.json')
    with open(cache_list, encoding='utf-8') as f:
        data = json.load(f)
    for info in data.get('files', {}).values():
        rel = info.get('url')
        if not rel:
            continue
        dst = os.path.join(seed_gamecaches, rel.replace('/', os.sep))
        if os.path.isfile(dst) and os.path.getsize(dst) > 0:
            continue
        src = os.path.join(runtime_cache, rel.replace('/', os.sep))
        if os.path.isfile(src) and os.path.getsize(src) > 0:
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            if os.path.exists(dst):
                conflicts += 1
            else:
                shutil.copy2(src, dst)
                copied += 1
    return copied, conflicts


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--check-only', action='store_true')
    ap.add_argument('--fill-missing', action='store_true')
    ap.add_argument('--seed', required=True)
    ap.add_argument('--runtime-cache', default='')
    ap.add_argument('--runtime-patch', default='')
    ap.add_argument('--settings-json', default=SETTINGS_PATH)
    args = ap.parse_args()

    seed_gamecaches = os.path.join(args.seed, 'gamecaches', 'gamecaches')
    seed_patch = os.path.join(args.seed, 'patch', 'patch')

    present_cache, missing_cache, cache_bundles = check_cache_list(seed_gamecaches)
    remote_bundles, all_settings_bundles = load_settings_bundles(args.settings_json)
    present_patch, missing_patch, _ = check_patch_manifest(seed_patch)

    unmapped = [b for b in sorted(cache_bundles) if b not in all_settings_bundles and b not in remote_bundles]

    print('cacheList: present=%d missing=%d bundles=%d' % (present_cache, len(missing_cache), len(cache_bundles)))
    for m in missing_cache[:20]:
        print('  MISSING cache', m[0][:120], m[1])
    print('unmapped cache bundles (not in settings bundleVers/remoteBundles): %d' % len(unmapped))
    for b in unmapped[:20]:
        print('  UNMAPPED', b)
    print('patch manifest catalog: present=%d catalog_missing=%d (informational)' % (present_patch, len(missing_patch)))

    if args.fill_missing:
        copied, conflicts = fill_missing(args.seed, args.runtime_cache, args.runtime_patch)
        print('fill_missing: copied=%d conflicts=%d' % (copied, conflicts))

    if len(missing_cache) > 0 or len(unmapped) > 0:
        return 1
    print('SEED ACCEPT: cache_missing=0 unmapped_bundles=0 hash_conflict=0')
    return 0


if __name__ == '__main__':
    sys.exit(main())
