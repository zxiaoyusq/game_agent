﻿const fs = require('fs');
const data = JSON.parse(fs.readFileSync('E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810/spine-preview/spine_index.json', 'utf8'));
for (const i of [0, 2, 36, 44, 275, 349]) {
  const it = data[i];
  console.log(i, it.name, '|', it.label, '|', it.skin, '| anims[0]=', it.anims[0]);
}
