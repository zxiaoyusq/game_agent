﻿'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810';
const NAMED = path.join(ROOT, 'named');
const SPINE_LIB = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/blast-block-spine/lib/spine-player.js';
const spineSrc = fs.readFileSync(SPINE_LIB, 'utf8');
const sandbox = {
  console, setTimeout, clearTimeout, setInterval, clearInterval,
  window: {}, document: {}, navigator: { userAgent: 'node' },
  atob: (b64) => Buffer.from(b64, 'base64').toString('latin1'),
  btoa: (s) => Buffer.from(s, 'latin1').toString('base64'),
  TextEncoder, TextDecoder,
  ArrayBuffer, DataView, Uint8Array, Uint16Array, Uint32Array,
  Int8Array, Int16Array, Int32Array, Float32Array, Float64Array,
  Math, JSON, Object, Array, Date, String, Number, Boolean,
  Error, TypeError, RangeError, Map, Set, parseFloat, parseInt, isNaN, isFinite,
};
vm.createContext(sandbox);
vm.runInContext(spineSrc, sandbox, { filename: 'spine-player.js' });

let binPath = null;
(function walk(d) {
  for (const de of fs.readdirSync(d, { withFileTypes: true })) {
    const p = path.join(d, de.name);
    if (de.isDirectory()) walk(p);
    else if (de.name === 'gameplay_word_011.bin') binPath = p;
  }
})(path.join(NAMED, 'Remote_Skin_Material_3011'));
sandbox.binB64 = fs.readFileSync(binPath).toString('base64');

const sim = `
(function(){
  function b64ToU8(b64){ var bin=atob(b64); var u=new Uint8Array(bin.length);
    for(var i=0;i<bin.length;i++) u[i]=bin.charCodeAt(i); return u; }
  function dummyRegion(){ return { u:0, v:0, u2:1, v2:1, originalWidth:1, originalHeight:1, offsetX:0, offsetY:0, width:1, height:1, rotate:false }; }
  var loader = {
    newRegionAttachment: function(skin,name,p){ var a=new spine.RegionAttachment(p||name); a.region=dummyRegion(); return a; },
    newMeshAttachment: function(skin,name,p){ var a=new spine.MeshAttachment(p||name); a.region=dummyRegion(); return a; },
    newBoundingBoxAttachment: function(skin,name){ return new spine.BoundingBoxAttachment(name); },
    newClippingAttachment: function(skin,name){ return new spine.ClippingAttachment(name); },
    newPathAttachment: function(skin,name){ return new spine.PathAttachment(name); },
    newPointAttachment: function(skin,name){ return new spine.PointAttachment(name); }
  };
  var out = {};
  var sd = new spine.SkeletonBinary(loader).readSkeletonData(b64ToU8(binB64));
  out.anims = sd.animations.map(function(a){ return a.name; });
  out.skinNames = sd.skins.map(function(s){ return s.name; });
  var sk = new spine.Skeleton(sd);
  if (out.skinNames.length) sk.setSkinByName(out.skinNames[0]);
  sk.setToSetupPose();
  sk.updateWorldTransform();
  var off = new spine.Vector2(0,0), sz = new spine.Vector2(0,0);
  sk.getBounds(off, sz);
  out.setup = [off.x, off.y, sz.width, sz.height];
  // per-slot attachment info at setup
  out.slots = sk.slots.map(function(s){
    var a = s.getAttachment();
    return { name: s.data.name, att: a ? a.constructor.name : null };
  });
  // apply first animation mid
  var sd2 = new spine.AnimationStateData(sd);
  var st = new spine.AnimationState(sd2);
  st.setAnimation(0, sd.animations[0].name, false);
  st.update(sd.animations[0].duration / 2);
  st.apply(sk);
  sk.updateWorldTransform();
  var off2 = new spine.Vector2(0,0), sz2 = new spine.Vector2(0,0);
  sk.getBounds(off2, sz2);
  out.animMid = [off2.x, off2.y, sz2.width, sz2.height];
  out.slotsAfter = sk.slots.map(function(s){
    var a = s.getAttachment();
    return { name: s.data.name, att: a ? a.constructor.name : null };
  });
  // raw world vertices of first region attachment
  out.region = null;
  for (var i=0;i<sk.slots.length;i++){
    var a = sk.slots[i].getAttachment();
    if (a instanceof spine.RegionAttachment){
      var verts = new Float32Array(8);
      a.computeWorldVertices(sk.slots[i], 0, 8, verts, 0, 2);
      out.region = { slot: sk.slots[i].data.name, offset: Array.prototype.slice.call(a.offset), verts: Array.prototype.slice.call(verts) };
      break;
    }
  }
  return out;
})();
`;
const out = vm.runInContext(sim, sandbox);
console.log('anims:', out.anims.length, 'skins:', JSON.stringify(out.skinNames));
console.log('setup bounds:', JSON.stringify(out.setup));
console.log('anim mid bounds:', JSON.stringify(out.animMid));
console.log('slots at setup:', JSON.stringify(out.slots));
console.log('slots after anim:', JSON.stringify(out.slotsAfter));
console.log('first region:', JSON.stringify(out.region));
