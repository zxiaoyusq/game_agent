# Block Master / Block Blast 广告策略还原

> 生成日期：2026-08-20  
> 目标：还原客户端可见的展示时机、瀑布/竞价候选、超时、预加载、频控和竞价底价，作为迁移到传音自有账号的参考。

## 1. 先说结论

1. **原版的“游戏内展示时机”已基本还原**：包括回到前台、无操作、结算/死亡、复活、大厅、Banner 及新用户保护。
2. **V27 现场数据库中保存了原厂实际下发的实验参数**，比 APK 中“存在但未启用”的 Trait 更有参考价值。
3. **V35 的 Hisavana 候选策略已完整提取**：4 个广告位，每个广告位均包含 Hisavana 与 AdMob 候选。
4. V35 真机日志证明：底部 Banner 的实际胜出者是 **AdMob Network**，返回 `_ecpm=1000` 与 `_bidding_price=1000`。因此 V35 看到更高价值素材并非完全是错觉。
5. **无法从客户端还原原厂广告服务器的私有算法、历史账号学习和最终结算规则**。本文还原的是“客户端可见策略 + 当时已缓存云控”。
6. 本次**没有重新打开 Hungry/AF-AFB 联网**，使用的是已保存在本机的历史现场和 APK 快照。

## 2. 证据来源

| 证据 | 用途 |
|---|---|
| `E:\codex_apk_work\blockmaster_pro_swap\work\v27_exact_mumu_clean\runtime_layers_extracted\databases\jsb.sqlite` | 原厂服务器当时下发的用户实验配置；SHA256 `EB98E4ADD08985DBD533D7A64DF045E53438A26912ACC83B7C28C554718D7630` |
| `block-blast-server_experiment_config` | `jsb.sqlite` 中的主配置键；实验日期 `2026/07/29 15:51:07`，原包名 `com.block.juggle` |
| `E:\codex_apk_work\blockmaster_pro_swap\work\BlockMaster_v35_palm_full.apk!/assets/mediation.json` | V35 内置的 Hisavana 云控快照，`cloudControlVersion=50`；内容 SHA256 `554936CC202EBAB633B7AC3EE30DB3BAA7B09295E515997EF88C4757E44E2315` |
| `E:\codex_apk_work\blockmaster_pro_swap\work\evidence_v35\phone_online_cold1_full_logcat.txt` | V35 真机实际请求、胜出广告源、eCPM 和展示证据 |
| `E:\codex_apk_work\blockmaster_pro_swap\work\js_dumps\remote_seed_patch_assets_main_index.7b71a.js` | 原版展示链路、场景与预加载调用 |
| `E:\codex_apk_work\blockmaster_pro_swap\work\js_dumps\remote_seed_patch_assets_mainTraits_index.6eb04.js` | 广告间隔、概率屏蔽、大厅广告等 Trait 逻辑 |
| `E:\codex_apk_work\blockmaster_pro_swap\work\js_dumps\remote_seed_patch_assets_chapter_index.3d73a.js` | `AdLevelTrait` 的精确早期局数频控逻辑 |
| `E:\codex_apk_work\blockmaster_pro_swap\work\stage2_sdk\assets\mediation.json` | V39 当前快照对照；SHA256 `52812C1A34BFEE3CF4D365CAA5852F6AF623F26547745B43D5A3891D0BE2161D` |

## 3. 原版展示时机

### 3.1 客户端明确存在的展示入口

| 时机 | 广告类型 | 客户端行为 |
|---|---|---|
| 应用回到前台 `onAppShow` | 插屏 | 触发 `back_to_foreground` 场景，但仍经过频控和 Trait 屏蔽 |
| 玩家长时间无操作 | 插屏 | 触发 `inactivity` 场景 |
| 一局结束/死亡/结算 | 插屏 | 根据模式和 `ADLOCK_TYPE` 选择 400–409 系列广告类型 |
| 复活、道具、皮肤奖励 | 激励视频 | 主要是 500/501–504/701/705 系列；某些 Trait 可把激励替换为插屏 |
| 游戏大厅 | 插屏/激励 | `game_lobby` 场景，另有按游戏时长和次数触发的 Trait |
| 主页、大厅、局中 | Banner | 按页面显示/隐藏，叠加新用户天数和进度策略 |
| 冷启动 | 品牌广告 | APK 中有 Display/Frequency/Jump/Retention/Skip 全套 Trait，但本次历史用户分组中未取得“实际展示”证据 |

通用放行条件：

- 剩余内存小于 300 MB：不播广告。
- VIP/去广告用户：不播广告。
- 激励/插屏发出后，JS 层等待原生回调；5 秒内没有回调时，业务层自动继续，避免卡死。
- 展示完成后会再触发对应广告类型的补载。

### 3.2 V27 现场中真正分配到的广告实验

以下是 `block-blast-server_experiment_config` 当时实际存储的配置，不是单纯的静态代码存在性。

#### 经过代码证明的准确逻辑

`adLevel={noAd:1,end:10}` 的实际逻辑：

- 第 1 个章节阶段：插屏被屏蔽。
- 第 2–10 个章节阶段：对局计数为奇数时屏蔽插屏，相当于早期阶段最多隔局放行。
- 超过 `end=10` 后，这个 Trait 本身不再限制，但仍可被其他频控、概率和 eCPM 策略屏蔽。

#### 已确认下发，但部分精确分支仍在加密动态 Trait 中

| 配置 | 当时值 | 可确认的含义 |
|---|---|---|
| `EarlySessionInterstitial` | 已启用 | 存在早期 Session 插屏策略；该项无数值参数，不应自行猜测具体是第几局 |
| `NoBannerAdNewUserByDays` | `days=[1,3]` | 新用户第 1–3 天的 Banner 保护窗口 |
| `GLShowAdsByGameTime` | `firing=1, showAdsTime=2` | 大厅小游戏的按游时长广告逻辑已启用；`2` 的单位未在客户端配置中声明 |
| `GLGameAdStrategyOptimize` | `mode=2, totalGameTime=60` | 大厅小游戏使用第 2 种广告优化模式，总游戏时长阈值原始值为 60 |
| `HighProgressShowBanner` | 已启用 | 高进度玩家可进入 Banner 展示分支 |
| `isClassADReviveNoIneresting` | `noAdDelay=30` | 复活/无兴趣保护的延迟原始值为 30；单位未在配置中声明 |
| `reviveCount` | `count=3` | 经典复活可用次数参数为 3 |
| `reviveLimit` | `score=3000, per=0.8` | 复活显示与分数/比例有关，原始阈值为 3000 和 0.8 |
| `levelReviveCondi` | `per=0.5` | 关卡复活条件比例为 0.5 |
| `levelReviveCount` | `count=1` | 关卡复活次数为 1 |

### 3.3 `AdPlusMinusStrategy` 现场参数

现场值：`strategyEnable=111111`。它很可能表示 6 个加/减子策略全开，但这一点只能作为高可信推断，不应当作服务端官方定义。

| 子策略 | 原始参数 |
|---|---|
| `addition1` | `game2Enable=0`, `game2ScoreRatio=60`, `game3ScoreRatio=40` |
| `addition2` | `startGame=14` |
| `banner` | `firstNGames=100` |
| `interstitial` | `coldStartN=0`, `coldStartExemptRatio=10`, `coldStartFirstRatio=60`, `coldStartSecondRatio=40`, `coldStartThirdRatio=20`, `game4ScoreRatio=60`, `game5ScoreRatio=40`, `exemptGame6Ratio=20`, `exemptGame78Ratio=10` |
| `subtraction1` | `consecutiveBreakCount=1`, `maxReviveWhenNoUse=2`, `maxReviveWhenUsed=1`, `nextGameScoreRatio=0.8` |
| `subtraction2` | `n1=0`, `n2=4`, `n3=8` |

注意：`firstNGames=100` 是 Banner 子策略的原始参数，但仅凭字段名不能宣称“前 100 局一定不放 Banner”。真正开/关行为仍与加密 Trait 的分支实现有关。

## 4. V35 Hisavana 瀑布/竞价候选

### 4.1 全局配置

| 字段 | V35 值 | 解读 |
|---|---:|---|
| `applicationId` | `26042852QVdSm3` | Hisavana 主 App ID |
| `cloudControlVersion` | `50` | 当时的云控版本 |
| `defaultAdEnable` | `true` | 默认允许广告 |
| `defaultAdRequestTimeInterval` | `1440` | SDK 原始值；客户端 JSON 未声明单位 |
| `cloudControlCacheInterval` | `72` | 云控缓存原始值；客户端 JSON 未声明单位 |
| `showTrackingNewPowerEnable` | `false` | 新展示跟踪开关关闭 |

### 4.2 四个广告位

| Hisavana 广告位 | 类型 | 预加载 | 并发数 | 竞价等待 | 候选源与配置价 |
|---|---|---:|---:|---:|---|
| `260428mX7wkxmr` | Rewarded | `false` | 3 | `10000` | AdMob `.../5605283108` = 1000；Hisavana 直营 = 10 |
| `260428LY5BXBxm` | PageBottom/Banner | `false` | 3 | `10000` | AdMob `.../3525038969` = 100；Hisavana 直营 = 10 |
| `260428HB3UWwCs` | PageBottom/Banner | `false` | 3 | `10000` | AdMob `.../8039874758` = 100；Hisavana 直营 = 10 |
| `26042893qlR57i` | Interstitial | `true` | 5 | `10000` | AdMob `.../9898875626` = 1000；Hisavana 直营 = 30 |

AdMob Application ID：`ca-app-pub-3665476663852390~1435958481`。

### 4.3 “瀑布排序”应如何理解

- V35 四个广告位中，Hisavana 和 AdMob 的 `biddingType` 都为 `2`。
- JSON 数组的先后不能直接等同于实际展示顺序；SDK 会结合实时返价、缓存有效性和过滤规则重排。
- 从“配置价”看，AdMob 候选的优先级显著高于 Hisavana 直营：
  - Rewarded：1000 vs 10。
  - Banner：100 vs 10。
  - Interstitial：1000 vs 30。
- 因此可复制的排序思路是：**优先让高价竞价源参与，再用自有直营/低价源托底**。
- 不能复制的是 AdMob 原账号的历史学习、人群和出价能力。

## 5. 超时、预加载、频控和底价

### 5.1 V35 四个广告位的共同值

| 项目 | 值 | 说明 |
|---|---:|---|
| `adRequestCount` | 1 | 每轮请求数原始值 |
| `adRequestTimeInterval` | 1000 | 请求间隔原始值；按 SDK 常见用法很可能为毫秒，但 JSON 未声明单位 |
| `adRequestTimeout` | 60 | 广告请求超时原始值 |
| `biddingWaitTime` | 10000 | 竞价等待窗口；真机日志同步记录 `_bidding_duration=10000` |
| `cacheTimeout` | 55 | 广告缓存过期原始值 |
| `preloadLogic` | 2 | 第 2 种预加载逻辑 |
| `fillCallbackMode` | 1 | 填充回调模式 1 |
| `requestIntervalMode` | 1 | 请求间隔模式 1 |
| `showPriceCoefficient` | 1 | 展示价系数不放大/缩小 |

### 5.2 预加载

- V35：只有插屏位 `26042893qlR57i` 为 `preload=true`。
- V35：Rewarded 和两个 Banner 位均为 `preload=false`。
- 游戏 JS 层另有事件驱动补载：展示回调后、进入大厅后、AtomEngine 初始化和就绪查询时都可触发。
- 所以 `preload=false` 不等于“永远不预请求”，它只表示 Hisavana 云控广告位本身没开启自动预加载。

### 5.3 频控

Hisavana 层：

- `adShowCountLimitDay=-1`：不设每日正数上限。
- `adShowCountLimitHour=-1`：不设每小时正数上限。
- `adShowTimeInterval=-1000`：未设置正的展示间隔。
- `adxShowRate=100`, `ewShowRate=100`：V35 中两条扩展广告分支均是满比例原始值。

游戏层：

- `AdLevelTrait` 控制早期章节的隔局展示。
- `AdIntervalTrait` 会将上次成功插屏时间持久化到 `adInterstitialLastPlayTime`，未满 `time` 不放行。
- `NoShowInterAdRateTrait` 使用 `Math.random() <= Rate` 按概率不展示插屏。
- `SessionProbNoInterAdTrait` 使用 `prob` 进行 Session 级的插屏豁免，并对第二个新对局有特殊分支。
- 但在本次 V27 用户现场的 `features` 中，没有找到 `AdInterval`/`NoShowInterAdRate`/`SessionProbNoInterAd` 的实际下发数值，因此只能复制机制，不能伪造具体频控值。

### 5.4 竞价底价

- V35 全部 8 个 network 候选的 `minPrice` 均为 **0**。
- 因此 V35 快照中**没有客户端正数竞价底价**。
- `price` 是候选源的配置价/优先级参考，不等于最终结算价。
- 最终实时价可以与配置价不同。V35 真机 Banner 配置价为 100，但实际胜出日志为 `_bidding_price=1000` 和 `_ecpm=1000`。

## 6. V35 真机实际胜出证据

V35 真机日志中，底部 Banner 位 `260428LY5BXBxm` 实际展示：

| 字段 | 实测值 |
|---|---|
| `mediator_source` | `AdMob Network` |
| `scene_id` | `bottom` |
| `code_seat_id` | `ca-app-pub-3665476663852390/3525038969` |
| `biddingType` | 2 |
| `bidding_price` | 1000 |
| `ecpm` | 1000 |
| `ecpm_precision` | `estimated` |
| `show_status` | 1 |
| `show_price.ad_value` | 164 |
| `advalue_currency_code` | `USD` |

`ad_value=164` 的金额单位没有在该日志中声明，不应直接解读为 164 美元。

这组证据说明：

- Hisavana 聚合链已实际选中 AdMob。
- V35 的高价值广告观感至少有一部分来自 AdMob 竞价候选胜出。
- 要复制这种效果，应在传音 Hisavana 中配置归属于传音/己方账号的 AdMob、Pangle、Meta、AppLovin 等高价候选，而不是恢复 Hungry 服务器。

## 7. V39 对照

V39 当前内置的真机快照共 8 个广告位：3 Rewarded、2 Banner、3 Interstitial。

与 V35 相比的主要变化：

- V35：4 个广告位，`adxShowRate=100`, `ewShowRate=100`。
- V39：8 个广告位，`adxShowRate=0`, `ewShowRate=0`。
- V35：只有插屏自动预加载。
- V39：多个 Rewarded/Interstitial 位改为自动预加载。
- V39 新增的部分广告位仅有 Hisavana 直营候选，这会增加低价图片广告的观感占比。
- V39 仍保留了若干 AdMob 候选，因此并非“只能播图片广告”；最终素材类型仍受地区、设备、库存、出价和广告位类型影响。

## 8. 可直接复制的策略

### 可复制

- 回前台、无操作、结算、复活、大厅和 Banner 的业务触发点。
- 新用户早期保护、隔局插屏、Session 概率豁免、最小展示间隔。
- 插屏与激励预加载、展示后补载、就绪查询和 5 秒业务回调保护。
- 高价竞价候选优先、自有直营托底的结构。
- 超时、并发数、缓存时间、每轮请求数和价格系数。

### 不能直接复制

- 原厂 AdMob/Pangle/Meta/AppLovin 账号、Application ID 和广告位 ID。
- Hungry/AF-AFB 服务器的动态人群分层、模型、实时底价和账号历史学习。
- 原厂账号的结算关系。即使客户端复制出完全相同的瀑布，如果使用原厂广告位，收益仍会归原广告账号。

## 9. 迁移到传音账号的建议模板

1. 保留原版游戏层触发点和早期用户保护。
2. 在 Hisavana 后台为 Rewarded、Interstitial、Banner 分别配置：
   - 第一层：传音/己方账号的高价竞价源。
   - 第二层：传音/己方账号的常规瀑布源。
   - 第三层：Hisavana 自有直营托底。
3. 不建议直接复制 V35 的原 AdMob ID；应换成后台能证明归属传音/己方的 ID。
4. 底价不建议一开始就设得很高。V35 客户端底价为 0，主要靠竞价结果选优；可先以 0 底价收集 3–7 天数据，再按国家和广告位调整。
5. QA 必须同时查看 `ad_request`/`ad_return`/`ad_show`/`show_price`，不能只看“广告播出了”。
6. 收益归属的最终证据必须来自 Hisavana 后台的广告位归属、展示量和收益记录，不能只靠 APK 静态扫描。

## 10. 仍需后台补齐的信息

要把这份策略真正复制成“高价值但收益归传音”，还需要：

- Hisavana 后台中 8 个广告位的当前策略导出或截图。
- 每个下游广告源的账号归属、Application ID 和广告位 ID。
- 同国家、同设备、同广告位的 fill rate、show rate、eCPM 和 revenue 对比。
- 后台是否支持按国家/用户层级设置竞价底价和频控。

---

最终判定：**原版游戏侧展示策略可以复制，V35 的 Hisavana 候选结构也可以复制；但所有账号、广告位和收益结算关系必须换成传音/己方资产。**
