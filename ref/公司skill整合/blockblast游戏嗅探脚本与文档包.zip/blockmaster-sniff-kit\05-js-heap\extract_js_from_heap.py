#!/usr/bin/env python3
"""Extract long printable UTF-16LE runs (V8 source strings) from heap dumps."""
import glob
import os
import re
import sys

SRC = r"E:\codex_apk_work\memdump\heap"
DST = r"E:\codex_apk_work\memdump\js_strings"
MIN_RUN = int(sys.argv[1]) if len(sys.argv) > 1 else 80
os.makedirs(DST, exist_ok=True)

# printable ASCII + common whitespace/punct
GOOD = set(range(0x20, 0x7F)) | {0x09, 0x0A, 0x0D, 0x00A0, 0x2028, 0x2029}


def extract_runs(raw: bytes):
    """Return list of (offset, text) for runs of printable utf-16le chars."""
    runs = []
    n = len(raw) // 2
    cur_start = None
    buf = []
    for i in range(n):
        u = raw[i * 2] | (raw[i * 2 + 1] << 8)
        if u in GOOD:
            if cur_start is None:
                cur_start = i * 2
            buf.append(chr(u))
        else:
            if cur_start is not None and len(buf) >= MIN_RUN:
                runs.append((cur_start, "".join(buf)))
            cur_start = None
            buf = []
    if cur_start is not None and len(buf) >= MIN_RUN:
        runs.append((cur_start, "".join(buf)))
    return runs


def main():
    all_runs = []
    for path in sorted(glob.glob(os.path.join(SRC, "*.bin"))):
        raw = open(path, "rb").read()
        runs = extract_runs(raw)
        print(os.path.basename(path), "runs:", len(runs))
        all_runs.extend((os.path.basename(path), off, txt) for off, txt in runs)
    all_runs.sort(key=lambda x: -len(x[2]))
    print("total runs:", len(all_runs))

    meta = []
    for idx, (fn, off, txt) in enumerate(all_runs):
        out_name = f"run_{idx:05d}_{len(txt):d}.js"
        with open(os.path.join(DST, out_name), "w", encoding="utf-8", errors="replace") as f:
            f.write(txt)
        meta.append({"file": out_name, "src": fn, "offset": off, "len": len(txt)})

    import json
    with open(os.path.join(DST, "_runs.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=1)

    # summary by length
    from collections import Counter
    buckets = Counter()
    for _, _, txt in all_runs:
        l = len(txt)
        if l >= 100000:
            buckets["100k+"] += 1
        elif l >= 50000:
            buckets["50k+"] += 1
        elif l >= 10000:
            buckets["10k+"] += 1
        elif l >= 1000:
            buckets["1k+"] += 1
        else:
            buckets["small"] += 1
    print(buckets)


if __name__ == "__main__":
    main()
