data = open(r"E:\codex_apk_work\libs_x86_64\lib\x86_64\libcocos2djs.so", "rb").read()
print("so len:", len(data))
for pat in [b"65485d8a-8161-4c", b"93274615-a57e-4d", b"HEK:", b"\xaf\xfa\x00", b"xxtea", b"AFFA", b"block.juggle", b"main.js", b"atomengine"]:
    idx = []
    start = 0
    while True:
        i = data.find(pat, start)
        if i < 0:
            break
        idx.append(i)
        start = i + 1
        if len(idx) > 8:
            break
    print(pat, "->", len(idx), [hex(i) for i in idx])
