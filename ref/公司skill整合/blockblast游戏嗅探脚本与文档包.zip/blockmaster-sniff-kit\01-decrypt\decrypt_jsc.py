#!/usr/bin/env python3
"""Decrypt Block Blast .jsc files: XXTEA(keyB) -> gzip -> JS."""
import os
import struct
import sys
import zlib

KEY = b"65485d8a-8161-4c"
DELTA = 0x9E3779B9
MASK = 0xFFFFFFFF


def _mx(y, z, s, p, e, k):
    return (((z >> 5) ^ (y << 2)) + ((y >> 3) ^ (z << 4))) ^ ((s ^ y) + (k[(p & 3) ^ e] ^ z))


def xxtea_decrypt(data: bytes, key: bytes) -> bytes:
    if len(data) < 8:
        return data
    n = len(data) // 4
    v = list(struct.unpack("<%dI" % n, data[: n * 4]))
    k = list(struct.unpack("<4I", key[:16].ljust(16, b"\x00")))
    y = v[0]
    q = 6 + 52 // n
    s = (q * DELTA) & MASK
    while s:
        e = (s >> 2) & 3
        for p in range(n - 1, 0, -1):
            z = v[p - 1]
            v[p] = (v[p] - _mx(y, z, s, p, e, k)) & MASK
            y = v[p]
        z = v[n - 1]
        v[0] = (v[0] - _mx(y, z, s, 0, e, k)) & MASK
        y = v[0]
        s = (s - DELTA) & MASK
    return struct.pack("<%dI" % n, *v)


def gunzip_all(data: bytes) -> bytes:
    """Decompress a (possibly multi-member) gzip stream, returning all members' payloads."""
    out_all = b""
    while True:
        if len(data) < 10 or data[:2] != b"\x1f\x8b":
            break
        flag = data[3]
        pos = 10
        if flag & 0x04:  # FEXTRA
            xlen = struct.unpack("<H", data[pos:pos + 2])[0]
            pos += 2 + xlen
        if flag & 0x08:  # FNAME
            while data[pos] != 0:
                pos += 1
            pos += 1
        if flag & 0x10:  # FCOMMENT
            while data[pos] != 0:
                pos += 1
            pos += 1
        if flag & 0x02:  # FHCRC
            pos += 2
        d = zlib.decompressobj(wbits=-zlib.MAX_WBITS)
        out = d.decompress(data[pos:])
        out_all += out
        unused = d.unused_data
        if len(unused) >= 8:
            data = unused[8:]  # skip CRC32 + ISIZE trailer
        else:
            break
    return out_all


def main():
    src = r"E:\codex_apk_work\blockblast_extracted\assets\assets"
    dst = r"E:\codex_apk_work\jsc_decrypted"
    os.makedirs(dst, exist_ok=True)
    total = 0
    for root, dirs, files in os.walk(src):
        for fn in files:
            if not fn.endswith(".jsc"):
                continue
            p = os.path.join(root, fn)
            raw = open(p, "rb").read()
            pt = xxtea_decrypt(raw, KEY)
            if pt[:2] == b"\x1f\x8b":
                try:
                    js = gunzip_all(pt)
                except Exception as e:
                    print("gzip fail", p, e)
                    continue
            else:
                js = pt
            rel = os.path.relpath(p, src).replace(".jsc", ".js")
            out = os.path.join(dst, rel)
            os.makedirs(os.path.dirname(out), exist_ok=True)
            with open(out, "w", encoding="utf-8", errors="replace") as f:
                f.write(js.decode("utf-8", errors="replace"))
            total += 1
            print(out, len(js))
    print("total jsc:", total)


if __name__ == "__main__":
    main()
