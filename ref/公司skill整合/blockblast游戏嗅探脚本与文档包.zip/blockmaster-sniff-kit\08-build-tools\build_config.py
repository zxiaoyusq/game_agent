# -*- coding: utf-8 -*-
"""Portable build inputs for the current Block Master V35 pipeline."""
from __future__ import annotations

import os
from pathlib import Path


WORK = Path(__file__).resolve().parent
REPO = WORK.parent
STAGE = WORK / "stage2_sdk"
BUILD_TOOLS_VERSION = os.environ.get("BLOCKMASTER_BUILD_TOOLS_VERSION", "34.0.0")
APKTOOL = Path(os.environ.get(
    "BLOCKMASTER_APKTOOL",
    str(WORK / "tools" / "bin" / "apktool_2.9.3.jar"),
)).expanduser()
BASELINE_V34 = WORK / "baselines" / "BlockMaster_v34_palm_full.apk"
GOOGLE_SERVICES = STAGE / "google-services.json"


def resolve_build_tools() -> Path:
    explicit = os.environ.get("BLOCKMASTER_ANDROID_BUILD_TOOLS")
    if explicit:
        candidates = [Path(explicit).expanduser()]
    else:
        candidates = []
        for variable in ("ANDROID_SDK_ROOT", "ANDROID_HOME"):
            sdk = os.environ.get(variable)
            if sdk:
                candidates.append(Path(sdk).expanduser() / "build-tools" / BUILD_TOOLS_VERSION)
        local = os.environ.get("LOCALAPPDATA")
        if local:
            candidates.append(
                Path(local) / "Android" / "Sdk" / "build-tools" / BUILD_TOOLS_VERSION
            )

    for candidate in candidates:
        if (candidate / "apksigner.bat").is_file() and (candidate / "zipalign.exe").is_file():
            return candidate.resolve()
    rendered = ", ".join(str(item) for item in candidates) or "<no candidates>"
    raise RuntimeError(
        "Android Build Tools %s not found. Set BLOCKMASTER_ANDROID_BUILD_TOOLS "
        "or ANDROID_SDK_ROOT. Checked: %s" % (BUILD_TOOLS_VERSION, rendered)
    )


def resolve_apktool() -> Path:
    if not APKTOOL.is_file():
        raise RuntimeError(
            "apktool missing: %s. Run 'git lfs pull' after cloning." % APKTOOL
        )
    return APKTOOL.resolve()


def resolve_baseline_v34() -> Path:
    if not BASELINE_V34.is_file():
        raise RuntimeError(
            "V34 baseline missing: %s. Run 'git lfs pull' after cloning." % BASELINE_V34
        )
    return BASELINE_V34.resolve()


def signing_environment() -> tuple[Path, str]:
    value = os.environ.get("BLOCKMASTER_KEYSTORE")
    if not value:
        raise RuntimeError(
            "BLOCKMASTER_KEYSTORE is not set. The formal keystore is distributed "
            "through a secure channel and is intentionally not stored in Git."
        )
    keystore = Path(value).expanduser()
    if not keystore.is_file():
        raise RuntimeError("keystore does not exist: %s" % keystore)
    missing = [name for name in ("BLOCKMASTER_KS_PASS", "BLOCKMASTER_KEY_PASS")
               if not os.environ.get(name)]
    if missing:
        raise RuntimeError("missing signing environment variable(s): %s" % ", ".join(missing))
    return keystore.resolve(), os.environ.get("BLOCKMASTER_KEY_ALIAS", "blockmaster")


def doctor(require_signing: bool = False) -> None:
    print("WORK", WORK)
    print("STAGE", STAGE)
    print("APKTOOL", resolve_apktool())
    print("BASELINE_V34", resolve_baseline_v34())
    print("ANDROID_BUILD_TOOLS", resolve_build_tools())
    print("GOOGLE_SERVICES", GOOGLE_SERVICES)
    if require_signing:
        keystore, alias = signing_environment()
        print("KEYSTORE", keystore)
        print("KEY_ALIAS", alias)
    print("PORTABLE_BUILD_ENV: PASS")


if __name__ == "__main__":
    doctor(require_signing="--require-signing" in os.sys.argv)
