@echo off
rem resindex entry:  ri find xxx ^| ri zh jiesuan ^| ri extract xxx -o out
setlocal
set "PY=C:\Program Files\Python312\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" -X utf8 "%~dp0resindex.py" %*
