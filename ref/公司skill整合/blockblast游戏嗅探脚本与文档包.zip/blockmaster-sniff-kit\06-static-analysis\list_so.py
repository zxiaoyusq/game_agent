import glob
import os
import zipfile

for p in glob.glob(r"E:\codex_apk_work\apks\com.block.juggle\*.apk"):
    try:
        z = zipfile.ZipFile(p)
        sos = [n for n in z.namelist() if n.endswith(".so")]
        if sos:
            print(os.path.basename(p), "->", len(sos), "so files")
            for s in sos[:10]:
                print("   ", s)
    except Exception as e:
        print(os.path.basename(p), "ERR", e)
