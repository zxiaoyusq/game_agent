import sys
sys.path.insert(0, r"E:\codex_apk_work\scripts")
from affa_survey import xxtea_decrypt, KEY

raw = open(r"E:\codex_apk_work\blockblast_extracted\assets\main.js", "rb").read()
print("raw[:8]", raw[:8].hex(), "raw[4]", raw[4])
body = raw[8:]
pt = xxtea_decrypt(body, KEY)
print("pt[:8]", pt[:8].hex())
print("pt[:4] bytes:", pt[:4])
print("target bytes:", b"\xaf\xfa")
print("equal:", pt[:4] == b"\xaf\xfa")
