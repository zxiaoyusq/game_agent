# -*- coding: utf-8 -*-
"""C2: no-op NativeBug JS calls."""
import io, os

FILES = [
    r'E:\codex_apk_work\blockmaster_pro_swap\work\stage2_sdk\assets\assets\main\index.7d3cd.js',
    r'E:\codex_apk_work\blockmaster_pro_swap\work\stage2_sdk\assets\remote_seed\patch\patch\assets\main\index.146a7.js',
]
OLD = '''e.setBugsangContext = function(e) {
return r.NativeBridge.send("setBugsangContext", e, "(Ljava/lang/String;)V");
};'''
NEW = '''e.setBugsangContext = function(e) {
return;
};'''

def main():
    for p in FILES:
        with io.open(p, encoding='utf-8') as f:
            s = f.read()
        c = s.count(OLD)
        assert c == 1, (p, c)
        s = s.replace(OLD, NEW)
        with io.open(p, 'w', encoding='utf-8', newline='') as f:
            f.write(s)
        print('patched', p)

if __name__ == '__main__':
    main()
