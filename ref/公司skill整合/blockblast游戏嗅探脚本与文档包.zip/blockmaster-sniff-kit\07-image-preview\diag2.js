﻿'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810';
const NAMED = path.join(ROOT, 'named');
const SPINE_LIB = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/blast-block-spine/lib/spine-player.js';
const spineSrc = fs.readFileSync(SPINE_LIB, 'utf8');
const sandbox = {
  console, setTimeout, clearTimeout, setInterval, clearInterval,
  window: {}, document: {}, navigator: { userAgent: 'node' },
  atob: (b64) => Buffer.from(b64, 'base64').toString('latin1'),
  btoa: (s) => Buffer.from(s, 'latin1').toString('base64'),
  ArrayBuffer, DataView, Uint8Array, Uint16Array, Uint32Array,
  Int8Array, Int16Array, Int32Array, Float32Array, Float64Array,
  Math, JSON, Object, Array, Date, String, Number, Boolean,
  Error, TypeError, RangeError, Map, Set, parseFloat, parseInt, isNaN, isFinite,
};
vm.createContext(sandbox);
vm.runInContext(spineSrc, sandbox, { filename: 'spine-player.js' });

function findFiles(bundle, stem) {
  const dir = path.join(NAMED, bundle);
  let binPath = null, atlasPath = null;
  (function walk(d) {
    for (const de of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, de.name);
      if (de.isDirectory()) walk(p);
      else if (de.name === stem + '.bin') binPath = p;
      else if (de.name === stem + '.atlas') atlasPath = p;
    }
  })(dir);
  return { binPath, atlasPath };
}

const cases = [
  ['Remote_Skin_Material_3017', 'revive_countdown_017'],
  ['Remote_Skin_Material_4007', 'gameplay_comboTips_4007'],
  ['Remote_Skin_Material_4082', 'revive_num_xin'],
];

for (const [bundle, stem] of cases) {
  const { binPath, atlasPath } = findFiles(bundle, stem);
  if (!binPath || !atlasPath) { console.log('MISSING', bundle, stem); continue; }
  const atlasText = fs.readFileSync(atlasPath, 'utf8');
  sandbox.atlasText = atlasText;
  sandbox.binB64 = fs.readFileSync(binPath).toString('base64');
  const res = vm.runInContext(`
    (function(){
      function b64ToU8(b64){ var bin=atob(b64); var u=new Uint8Array(bin.length);
        for(var i=0;i<bin.length;i++) u[i]=bin.charCodeAt(i); return u; }
      function cp(s){ var a=[]; for(var i=0;i<s.length;i++) a.push(s.charCodeAt(i).toString(16)); return a.join(','); }
      var out = { cp: {} };
      var atlas = new spine.TextureAtlas(atlasText, function(p){ return { setFilters:function(){}, setWraps:function(){}, getImage:function(){ return {width:2048,height:2048}; }, dispose:function(){} }; });
      var regions = atlas.regions.map(function(r){ return r.name; });
      var requested = [];
      var loader = {
        newRegionAttachment: function(skin,name,p){ requested.push(p); var a=new spine.RegionAttachment(p||name); a.region={u:0,v:0,u2:1,v2:1,originalWidth:1,originalHeight:1,offsetX:0,offsetY:0,width:1,height:1,rotate:false}; return a; },
        newMeshAttachment: function(skin,name,p){ requested.push(p); var a=new spine.MeshAttachment(p||name); a.region={u:0,v:0,u2:1,v2:1,originalWidth:1,originalHeight:1,offsetX:0,offsetY:0,width:1,height:1,rotate:false}; return a; },
        newBoundingBoxAttachment: function(skin,name){ return new spine.BoundingBoxAttachment(name); },
        newClippingAttachment: function(skin,name){ return new spine.ClippingAttachment(name); },
        newPathAttachment: function(skin,name){ return new spine.PathAttachment(name); },
        newPointAttachment: function(skin,name){ return new spine.PointAttachment(name); }
      };
      new spine.SkeletonBinary(loader).readSkeletonData(b64ToU8(binB64));
      out.regionSet = regions;
      out.requested = requested;
      var missing = [];
      for (var i=0;i<requested.length;i++){ if (regions.indexOf(requested[i]) < 0 && missing.indexOf(requested[i]) < 0) missing.push(requested[i]); }
      out.missing = missing;
      out.cp.chineseRegion = regions.filter(function(r){ return /[^\\x00-\\x7f]/.test(r); }).slice(0,3).map(function(r){ return r + ' [' + cp(r) + ']'; });
      out.cp.chineseReq = missing.filter(function(r){ return /[^\\x00-\\x7f]/.test(r); }).slice(0,3).map(function(r){ return r + ' [' + cp(r) + ']'; });
      out.cp.xlReq = missing.filter(function(r){ return r.indexOf('xl/') === 0; }).slice(0,5);
      out.xlInRegions = regions.filter(function(r){ return r.indexOf('xl/') === 0; }).slice(0,8);
      return out;
    })();
  `, sandbox);
  console.log('=== ' + bundle + '/' + stem + ' ===');
  console.log('region count:', res.regionSet.length, 'requested count:', res.requested.length, 'missing:', res.missing.length);
  console.log('missing (all):', JSON.stringify(res.missing));
  console.log('chinese region cps:', JSON.stringify(res.cp.chineseRegion));
  console.log('chinese req cps:', JSON.stringify(res.cp.chineseReq));
  console.log('xl missing sample:', JSON.stringify(res.cp.xlReq));
  console.log('xl in regions sample:', JSON.stringify(res.xlInRegions));
}
