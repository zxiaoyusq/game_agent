import re

raw = open(r"E:\codex_apk_work\memdump\ctx_0x303000_cocos2d-jsb_8930c6.bin", "rb").read()
txt = raw.decode("utf-16-le", errors="ignore")

GOOD = set(chr(c) for c in range(0x20, 0x7F)) | set("\t\n\r")
runs = []
cur = []
start = 0
for i, ch in enumerate(txt):
    if ch in GOOD:
        if not cur:
            start = i
        cur.append(ch)
    else:
        if len(cur) >= 100:
            runs.append((start, "".join(cur)))
        cur = []
if len(cur) >= 100:
    runs.append((start, "".join(cur)))

print("runs:", len(runs))
for idx, (off, s) in enumerate(runs):
    if "window.boot" in s or "CC_PHYSICS" in s:
        print("run", idx, "off", off, "len", len(s))
        out = r"E:\codex_apk_work\memdump\mainjs_recovered.js"
        with open(out, "w", encoding="utf-8") as f:
            f.write(s)
        print("wrote", out)
        print(s[:500])
        print("...TAIL...")
        print(s[-300:])
        break
