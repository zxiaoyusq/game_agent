import frida
import os

JS = r"""
'use strict';
function dump(addrHex, size) {
    return ptr(addrHex).readByteArray(size);
}
rpc.exports = { dump: dump };
"""

OUT = r"E:\codex_apk_work\memdump"
os.makedirs(OUT, exist_ok=True)

# (name, address, size)
TARGETS = [
    ("keystream_table_1", "0x763806253200", 0x2000),
    ("keystream_table_2", "0x763802e51500", 0x2000),
    ("keystream_table_3", "0x76380510e800", 0x4000),
    ("main_js_region_1", "0x7637fdfa8000", 0x122000),
    ("main_js_region_2", "0x76387461e000", 0x122000),
    ("window_cc_hit", "0x76387bcf8000", 0x40000),
    ("hek_data_24k", "0x7637f4a7f000", 0x6000),
    ("low_anon_14f", "0x14f00000", 0x200000),
    ("low_anon_15c", "0x15c00000", 0x180000),
    ("big_region_119MB_probe", "0x7637ff800000", 0x800000),
]

import sys
PID = int(sys.argv[1]) if len(sys.argv) > 1 else 5829

dev = frida.get_device_manager().add_remote_device('127.0.0.1:27042')
session = dev.attach(PID)
script = session.create_script(JS)
script.load()
for name, addr, size in TARGETS:
    try:
        data = script.exports_sync.dump(addr, size)
        if data is None:
            print(name, "EMPTY")
            continue
        with open(os.path.join(OUT, name + ".bin"), "wb") as f:
            f.write(data)
        print(name, "dumped", len(data))
    except Exception as e:
        print(name, "ERROR", e)
session.detach()
