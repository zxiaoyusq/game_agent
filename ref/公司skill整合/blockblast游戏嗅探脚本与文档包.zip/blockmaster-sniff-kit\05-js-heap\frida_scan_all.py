#!/usr/bin/env python3
"""Scan all process memory (r-- and rw-) for JS markers, ASCII and UTF-16."""
import frida

JS = r"""
'use strict';
function scanPat(pat) {
    var results = [];
    var ranges = Process.enumerateRanges('r--').concat(Process.enumerateRanges('rw-'));
    var done = 0;
    ranges.forEach(function (range) {
        try {
            var matches = Memory.scanSync(range.base, range.size, pat);
            matches.forEach(function (m) {
                results.push({addr: m.address.toString(), base: range.base.toString(), len: range.size});
            });
        } catch (e) { }
        done++;
    });
    return {total: done, hits: results};
}
rpc.exports = { scan: scanPat };
"""

PATTERNS = {
    "sysreg_ascii": "53 79 73 74 65 6d 2e 72 65 67 69 73 74 65 72",
    "sysreg_utf16": "53 00 79 00 73 00 74 00 65 00 6d 00 2e 00 72 00 65 00 67 00 69 00 73 00 74 00 65 00 72 00",
    "require_ascii": "77 69 6e 64 6f 77 2e 5f 5f 72 65 71 75 69 72 65",
    "require_utf16": "77 00 69 00 6e 00 64 00 6f 00 77 00 2e 00 5f 00 5f 00 72 00 65 00 71 00 75 00 69 00 72 00 65 00",
    "ccgame_ascii": "63 63 2e 67 61 6d 65",
    "ccgame_utf16": "63 00 63 00 2e 00 67 00 61 00 6d 00 65 00",
    "usestrict_utf16": "22 00 75 00 73 00 65 00 20 00 73 00 74 00 72 00 69 00 63 00 74 00 22 00",
    "cocos2djsb_ascii": "63 6f 63 6f 73 32 64 2d 6a 73 62",
    "atomengine_ascii": "61 74 6f 6d 65 6e 67 69 6e 65",
}

import sys
PID = int(sys.argv[1]) if len(sys.argv) > 1 else 5829

dev = frida.get_device_manager().add_remote_device('127.0.0.1:27042')
session = dev.attach(PID)
script = session.create_script(JS)
script.load()
for name, pat in PATTERNS.items():
    out = script.exports_sync.scan(pat)
    hits = out.get('hits', [])
    print(name, "->", len(hits), "ranges:", out.get('total'))
    for h in hits[:20]:
        print("   ", h['addr'], "range", h['base'], "len", hex(h['len']))
session.detach()
