# -*- coding: utf-8 -*-
"""Fix duplicate public resource IDs in stage2_sdk and update id_map."""
import io
import json
import os
import re
from collections import defaultdict

WORK = r'E:\codex_apk_work\blockmaster_pro_swap\work'
PUB = os.path.join(WORK, 'stage2_sdk', 'res', 'values', 'public.xml')
ID_MAP = os.path.join(WORK, 'hisavana_id_map.json')


def main():
    with io.open(PUB, encoding='utf-8') as f:
        txt = f.read()
    entries = []  # (typ, name, rid, line)
    for m in re.finditer(r'<public type="([^"]+)" name="([^"]+)" id="(0x[0-9a-fA-F]+)"', txt):
        entries.append((m.group(1), m.group(2), int(m.group(3), 16), m.start(), m.end()))

    # group by id
    by_id = defaultdict(list)
    for e in entries:
        by_id[e[2]].append(e)

    # compute max per type
    max_by_type = defaultdict(int)
    for e in entries:
        if e[2] > max_by_type[e[0]]:
            max_by_type[e[0]] = e[2]

    replacements = []  # (old_rid, new_rid, typ, name)
    changed = False
    for rid, group in sorted(by_id.items()):
        if len(group) <= 1:
            continue
        # keep first (by position)
        keep = group[0]
        for dup in group[1:]:
            typ = dup[0]
            max_by_type[typ] += 1
            new_rid = max_by_type[typ]
            replacements.append((dup[2], new_rid, typ, dup[1]))
            changed = True

    # apply replacements to public.xml by replacing id strings in place
    # We'll rebuild lines using positions? Simpler: process from end to start
    for old_rid, new_rid, typ, name in replacements:
        # find exact public line for this name/type
        pat = re.compile(r'(<public type="%s" name="%s" id=")0x[0-9a-fA-F]+(" />)' % (re.escape(typ), re.escape(name)))
        txt, n = pat.subn(lambda m: m.group(1) + '0x%08x' % new_rid + m.group(2), txt, count=1)
        if n != 1:
            raise RuntimeError('Could not replace %s/%s' % (typ, name))
    if changed:
        with io.open(PUB, 'w', encoding='utf-8') as f:
            f.write(txt)
        print('Fixed', len(replacements), 'duplicates')
    else:
        print('No duplicates')

    # Update id_map
    with io.open(ID_MAP, encoding='utf-8') as f:
        id_map = json.load(f)
    for old_rid, new_rid, typ, name in replacements:
        for r in id_map:
            if r['type'] == typ and r['name'] == name:
                r['new_id'] = new_rid
    with io.open(ID_MAP, 'w', encoding='utf-8') as f:
        json.dump(id_map, f, ensure_ascii=False, indent=2)
    print('id_map updated')


if __name__ == '__main__':
    main()
