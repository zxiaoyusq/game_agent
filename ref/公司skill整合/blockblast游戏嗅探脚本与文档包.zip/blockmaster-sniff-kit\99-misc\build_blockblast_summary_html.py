# -*- coding: utf-8 -*-
"""Build a single self-contained HTML report from all Block Blast reverse-engineering MD docs."""
from pathlib import Path
import re, json, urllib.parse, html as html_mod
import markdown

ROOT = Path(r'E:/codex_apk_work')
ART_ROOT = Path(r'E:/参考图/block录屏/解包素材')
OUT = ROOT / 'BlockBlast汇总总览.html'

# Collect docs: root + relevant subproject docs, de-duplicated by filename (root wins)
candidates = []
for pattern in ['*.md']:
    candidates.extend(ROOT.glob(pattern))
for sub in [
    ROOT / 'blockmaster_pro_swap' / 'README.md',
    ROOT / 'blockmaster_pro_swap' / 'work' / '*.md',
    ROOT / 'blockmaster_v41_worktree' / '*.md',
    ROOT / 'blockmaster_v41_worktree' / 'docs' / '*.md',
    ROOT / 'main_algo_extract' / '*.md',
]:
    if sub.parent.exists():
        candidates.extend(sub.parent.glob(sub.name))

seen = set()
docs = []
for p in candidates:
    if p.name in seen:
        continue
    seen.add(p.name)
    try:
        text = p.read_text(encoding='utf-8', errors='replace')
    except Exception as e:
        text = f'<p>读取失败: {e}</p>'
    docs.append({
        'path': p,
        'name': p.name,
        'text': text,
        'chars': len(text),
        'tables': text.count('|'),
        'h1': next((l.strip('#').strip() for l in text.splitlines() if l.startswith('# ')), p.name),
    })

# Group by keywords
def group_name(name, h1):
    s = name + h1
    if any(k in s for k in ['接手索引', '项目索引', '项目现状', '交接总结', '项目状态', 'PROJECT_HANDOFF', 'QA_ACCEPTANCE', '验收']):
        return '项目总览与交接'
    if any(k in s for k in ['SDK', '广告', '埋点', '联网', 'V34', 'V35', '瀑布', '启动链路', '四SDK']):
        return 'SDK / 广告 / 网络'
    if any(k in s for k in ['主算法', 'Trait', '核心算法', '策划翻译']):
        return '玩法 / 算法 / Trait'
    if any(k in s for k in ['美术', 'Spine', 'spine', '资源', 'DragonBones']):
        return '美术 / 动画 / 资源'
    if any(k in s for k in ['低端机', 'v7', '6.5', 'v29', 'v30', 'Loading', 'load', '诊断', '卡']):
        return '工程 / 低端机 / 修复'
    if any(k in s for k in ['GitHub', '工具']):
        return '工具与环境'
    return '其他'

for d in docs:
    d['group'] = group_name(d['name'], d['h1'])

docs.sort(key=lambda d: (d['group'], d['name']))
groups = {}
for d in docs:
    groups.setdefault(d['group'], []).append(d)

# Art preview links (existing HTML previews in art path)
art_links = []
for pattern in [
    'blast-block-spine/blast-block-spine/preview.html',
    'BlastBlock-美术资源全量-20260810/blast-block-dragonbones/preview.html',
    'BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810/spine-preview/preview.html',
]:
    p = ART_ROOT / pattern
    if p.exists():
        art_links.append({'label': pattern.split('/')[0] + ' / ' + pattern.split('/')[-2], 'path': p})
# Per-animation previews under blast-block-dragonbones-spine
spine_dir = ART_ROOT / 'BlastBlock-美术资源全量-20260810' / 'blast-block-dragonbones-spine'
if spine_dir.exists():
    for p in sorted(spine_dir.rglob('preview.html')):
        rel = p.relative_to(ART_ROOT)
        art_links.append({'label': 'Spine / ' + p.parent.name, 'path': p})

def file_uri(path: Path) -> str:
    return path.resolve().as_uri()

def render_md(text: str) -> str:
    return markdown.markdown(text, extensions=['tables', 'fenced_code', 'sane_lists'])

# Build doc articles
rendered_docs = [render_md(d['text']) for d in docs]
doc_articles = []
for gname, items in groups.items():
    cards = ''.join(
        f'<div class="doc-card"><h4><a href="#doc-{i}">{html_mod.escape(d["h1"])}</a></h4>'
        f'<div class="doc-meta">{html_mod.escape(d["name"])} · {d["chars"]} 字 · {rendered_docs[i].count("<table>")} 表格</div></div>'
        for i, d in enumerate(docs) if d['group'] == gname
    )
    doc_articles.append(f'<div class="group"><h3>{html_mod.escape(gname)}</h3><div class="doc-grid">{cards}</div></div>')

full_articles = []
for i, d in enumerate(docs):
    full_articles.append(f'''
<section class="doc-full" id="doc-{i}">
<div class="doc-head">
  <span class="doc-index">#{i+1}</span>
  <h3>{html_mod.escape(d['h1'])}</h3>
  <span class="doc-file">{html_mod.escape(d['name'])}</span>
</div>
{rendered_docs[i]}
</section>
''')

total_tables = sum(r.count('<table>') for r in rendered_docs)
total_chars = sum(d['chars'] for d in docs)

# Art links HTML
art_rows = ''.join(
    f'<tr><td>{html_mod.escape(a["label"])}</td><td><a href="{file_uri(a["path"])}" target="_blank">打开 preview.html</a></td>'
    f'<td><a href="{file_uri(a["path"].parent)}" target="_blank">打开目录</a></td></tr>'
    for a in art_links
)
art_rows = f'<tr><td>📁 美术素材根目录</td><td colspan="2"><a href="{file_uri(ART_ROOT)}" target="_blank">打开目录</a></td></tr>' + art_rows

page = f'''<!doctype html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Block Blast 逆向拆解全量汇总</title>
<style>
:root {{ --bg:#0f1115; --panel:#1a1d24; --panel2:#232733; --line:#333845; --txt:#e8eaf0; --dim:#9aa1b0; --acc:#4cc2ff; --ok:#4cd97b; --warn:#ffb454; --err:#ff6b6b; }}
* {{ box-sizing:border-box; margin:0; padding:0; }}
body {{ background:var(--bg); color:var(--txt); font-family:"Microsoft YaHei","PingFang SC",system-ui,sans-serif; }}
header {{ padding:22px 28px; background:linear-gradient(135deg,#141824,#1d2330); border-bottom:1px solid var(--line); }}
h1 {{ font-size:24px; margin-bottom:6px; }}
.sub {{ color:var(--dim); font-size:13px; }}
.wrap {{ display:flex; min-height:calc(100vh - 90px); }}
nav {{ width:260px; flex:0 0 260px; background:var(--panel); border-right:1px solid var(--line); padding:14px 10px; position:sticky; top:0; height:100vh; overflow:auto; }}
nav a {{ display:block; padding:8px 12px; color:var(--dim); text-decoration:none; border-radius:6px; margin-bottom:4px; font-size:13px; }}
nav a:hover, nav a.active {{ background:var(--panel2); color:#fff; }}
main {{ flex:1; min-width:0; padding:24px 28px; }}
.section {{ display:none; }}
.section.active {{ display:block; }}
h2 {{ font-size:20px; margin:8px 0 14px; }}
h3 {{ font-size:16px; margin:18px 0 8px; }}
.grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:12px; margin-bottom:18px; }}
.stat {{ background:var(--panel); border:1px solid var(--line); border-radius:10px; padding:14px 16px; }}
.stat b {{ font-size:22px; color:var(--acc); display:block; }}
.hl-row {{ display:flex; gap:10px; flex-wrap:wrap; margin:14px 0; }}
.hl {{ background:var(--panel2); border:1px solid var(--line); border-radius:8px; padding:8px 12px; font-size:13px; color:var(--dim); }}
.doc-grid {{ display:grid; grid-template-columns:repeat(auto-fill,minmax(300px,1fr)); gap:10px; }}
.doc-card {{ background:var(--panel); border:1px solid var(--line); border-radius:8px; padding:10px 12px; }}
.doc-card a {{ color:var(--acc); text-decoration:none; }}
.doc-meta {{ color:var(--dim); font-size:12px; margin-top:4px; }}
.doc-full {{ background:var(--panel); border:1px solid var(--line); border-radius:12px; padding:18px 22px; margin-bottom:22px; }}
.doc-head {{ border-bottom:1px solid var(--line); padding-bottom:8px; margin-bottom:12px; }}
.doc-index {{ color:var(--acc); font-weight:bold; margin-right:6px; }}
.doc-file {{ color:var(--dim); font-size:12px; margin-left:8px; }}
table {{ border-collapse:collapse; width:100%; margin:10px 0; }}
th,td {{ border:1px solid var(--line); padding:6px 8px; font-size:13px; vertical-align:top; }}
th {{ background:var(--panel2); color:var(--acc); }}
pre {{ background:#0b0d12; border:1px solid var(--line); border-radius:6px; padding:10px; overflow:auto; font-size:12px; }}
code {{ background:#0b0d12; padding:1px 4px; border-radius:4px; font-size:12px; }}
a {{ color:var(--acc); }}
.search-box {{ width:100%; max-width:560px; padding:10px 12px; border-radius:8px; border:1px solid var(--line); background:var(--panel2); color:var(--txt); font-size:14px; margin-bottom:12px; }}
.art-table {{ width:100%; }}
</style>
</head>
<body>
<header>
  <h1>🧱 Block Blast 逆向拆解全量汇总</h1>
  <div class="sub">来源：E:\\codex_apk_work（Block Blast / BlockMaster 逆向文档） · 美术素材：E:\\参考图\\block录屏\\解包素材</div>
</header>
<div class="wrap">
<nav>
  <a href="#dashboard" onclick="show('dashboard')">📊 数据总览</a>
  <a href="#art" onclick="show('art')">🎨 美术素材</a>
  <a href="#docs" onclick="show('docs')">📚 全量文档</a>
  <a href="#analysis" onclick="show('analysis')">🧠 分析说明</a>
</nav>
<main>
  <section id="dashboard" class="section active">
    <h2>📊 数据总览</h2>
    <div class="grid">
      <div class="stat"><b>{len(docs)}</b>份 MD 文档</div>
      <div class="stat"><b>{total_chars:,}</b>字</div>
      <div class="stat"><b>{total_tables}</b>张表格</div>
      <div class="stat"><b>{len(art_links)}</b>个美术预览入口</div>
    </div>
    <div class="hl-row">
      <span class="hl">所有 MD 已完整内嵌到本 HTML</span>
      <span class="hl">美术预览使用 file:// 链接，建议直接双击打开本文件</span>
      <span class="hl">BlockMaster 案例值禁止直接复制到其他项目</span>
    </div>
    <h3>文档分组</h3>
    {''.join(f'<div class="hl">{html_mod.escape(g)}：{len(items)} 份</div>' for g, items in groups.items())}
    <h3>快速跳转</h3>
    {''.join(f'<a class="hl" href="#doc-{i}" onclick="show(\'docs\')">{i+1}. {html_mod.escape(d["h1"])}</a> ' for i,d in enumerate(docs))}
  </section>

  <section id="art" class="section">
    <h2>🎨 美术素材路径</h2>
    <p>根目录：<code>E:\\参考图\\block录屏\\解包素材</code></p>
    <table class="art-table">
      <thead><tr><th>入口</th><th>预览</th><th>目录</th></tr></thead>
      <tbody>{art_rows}</tbody>
    </table>
    <div class="hl-row">
      <span class="hl">💡 如果点击打不开，请在浏览器中直接粘贴文件路径，或确认使用 file:// 方式打开本 HTML</span>
    </div>
  </section>

  <section id="docs" class="section">
    <h2>📚 全量文档（所有 MD 已完整内嵌）</h2>
    <div class="hl-row">
      <span class="hl">✅ 本页不是索引页：以下为全部 {len(docs)} 份 MD 的完整内容</span>
      <span class="hl">共 {total_tables} 张表格、{total_chars:,} 字</span>
      <span class="hl">搜索框可实时过滤全部正文</span>
    </div>
    <input class="search-box" id="docSearch" placeholder="🔍 搜索全部文档标题/内容…" oninput="filterDocs()">
    <h2>全量细则正文（完整输出）</h2>
    {''.join(full_articles)}
    <hr style="margin:28px 0;border-color:var(--line)">
    <h2>📑 文档目录</h2>
    {''.join(doc_articles)}
  </section>

  <section id="analysis" class="section">
    <h2>🧠 分析说明</h2>
    <h3>范围</h3>
    <ul>
      <li>本页整合 <code>E:\\codex_apk_work</code> 下 Block Blast / BlockMaster 逆向拆解产生的全部 MD 文档。</li>
      <li>包含根目录 23 份文档 + 子项目交接/算法/工作区文档，按文件名去重，根目录版本优先。</li>
      <li>美术素材目录仅提供交互入口，不复制原始资源。</li>
    </ul>
    <h3>证据边界</h3>
    <ul>
      <li>所有 BlockMaster 包名、版本、路径、事件名、数量、key 均为案例值，迁移到其他项目时必须重新取证。</li>
      <li>静态结论与真机验证结论在原始文档中已区分，本页不额外改写证据等级。</li>
    </ul>
    <h3>生成方式</h3>
    <pre>python E:/codex_apk_work/scripts/build_blockblast_summary_html.py</pre>
  </section>
</main>
</div>
<script>
function show(id) {{
  document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  document.querySelectorAll('nav a').forEach(a=>a.classList.toggle('active', a.getAttribute('href')==='#'+id));
}}
function filterDocs() {{
  const q = document.getElementById('docSearch').value.toLowerCase();
  document.querySelectorAll('.doc-full').forEach((el, i) => {{
    const t = (el.textContent || '').toLowerCase();
    el.style.display = t.includes(q) ? '' : 'none';
  }});
}}
show('docs');
</script>
</body>
</html>
'''
OUT.write_text(page, encoding='utf-8')
print('wrote', OUT, 'size', len(page))
print('docs', len(docs), 'chars', total_chars, 'tables', total_tables, 'art_links', len(art_links))
