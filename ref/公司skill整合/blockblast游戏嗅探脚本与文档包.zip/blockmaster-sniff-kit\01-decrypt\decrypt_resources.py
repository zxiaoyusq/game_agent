#!/usr/bin/env python3
"""Decrypt Block Blast "HEK:" resources (v03 variant).

Format observed:
    header  : b"HEK:" + 4 bytes (version marker)
    body    : plaintext XOR keystream, keystream = b"65485d8a-8161-4c" repeated
    plaintext may be gzip-compressed (magic 1F 8B) -> decompress transparently.
"""
import collections
import gzip
import hashlib
import json
import os
import shutil
import sys

KEY = b"65485d8a-8161-4c"
SRC = r"E:\codex_apk_work\blockblast_extracted"
DST = r"E:\codex_apk_work\blockblast_decrypted"


def keystream(n):
    return (KEY * (n // 16 + 1))[:n]


def decrypt(data):
    """Return (plaintext, was_hek)."""
    if not data.startswith(b"HEK:"):
        return data, False
    body = data[8:]
    ks = keystream(len(body))
    pt = bytes(a ^ b for a, b in zip(body, ks))
    return pt, True


def maybe_gunzip(data):
    if data[:2] == b"\x1f\x8b":
        try:
            return gzip.decompress(data), True
        except Exception:
            return data, False
    return data, False


def main():
    stats = collections.Counter()          # ext -> count
    gz_stats = collections.Counter()       # ext -> gzip count
    hek_stats = collections.Counter()      # ext -> HEK count
    manifest = []
    errors = []
    total_in = total_out = 0

    os.makedirs(DST, exist_ok=True)
    for root, dirs, files in os.walk(SRC):
        for fn in files:
            src_path = os.path.join(root, fn)
            rel = os.path.relpath(src_path, SRC)
            dst_path = os.path.join(DST, rel)
            ext = os.path.splitext(fn)[1].lower()
            try:
                with open(src_path, "rb") as f:
                    raw = f.read()
            except OSError as e:
                errors.append((rel, "read", str(e)))
                continue

            total_in += len(raw)
            pt, was_hek = decrypt(raw)
            pt, was_gz = maybe_gunzip(pt)
            total_out += len(pt)

            stats[ext] += 1
            if was_hek:
                hek_stats[ext] += 1
            if was_gz:
                gz_stats[ext] += 1

            os.makedirs(os.path.dirname(dst_path), exist_ok=True)
            with open(dst_path, "wb") as f:
                f.write(pt)

            manifest.append({
                "path": rel.replace("\\", "/"),
                "size_in": len(raw),
                "size_out": len(pt),
                "hek": was_hek,
                "gzip": was_gz,
                "sha1": hashlib.sha1(pt).hexdigest(),
            })

    report = {
        "src": SRC,
        "dst": DST,
        "key": KEY.decode("ascii"),
        "total_files": sum(stats.values()),
        "total_in_bytes": total_in,
        "total_out_bytes": total_out,
        "by_ext": dict(stats),
        "hek_by_ext": dict(hek_stats),
        "gzip_by_ext": dict(gz_stats),
        "errors": errors[:200],
    }
    with open(os.path.join(DST, "_manifest.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=1)

    print(json.dumps(report, ensure_ascii=False, indent=1))
    print("errors:", len(errors))
    for e in errors[:30]:
        print("  ", e)


if __name__ == "__main__":
    sys.exit(main())
