#!/usr/bin/env python3
"""Freeze a verified Hisavana CloudControl.db snapshot into mediation.json."""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import sqlite3


RUNTIME_FIELDS = {
    "mCurrentHourShowTimes",
    "mCurrentHourZeroClock",
    "mLastShowTime",
    "mTodayShowTimes",
    "mTodayZeroClock",
}


def sha256(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cloud_db", type=pathlib.Path)
    parser.add_argument("mediation_json", type=pathlib.Path)
    parser.add_argument("--meta", type=pathlib.Path, required=True)
    args = parser.parse_args()

    payload = json.loads(args.mediation_json.read_text(encoding="utf-8"))
    with sqlite3.connect(f"file:{args.cloud_db}?mode=ro", uri=True) as db:
        rows = list(db.execute(
            "select _id, codeSeatId, json from cloudList order by _id"
        ))
    if not rows:
        raise RuntimeError("CloudControl snapshot has no code seats")

    seats: list[dict] = []
    for _row_id, code_seat_id, raw in rows:
        seat = json.loads(raw)
        if seat.get("codeSeatId") != code_seat_id:
            raise RuntimeError(f"codeSeatId mismatch: {code_seat_id}")
        for key in RUNTIME_FIELDS:
            seat.pop(key, None)
        seats.append(seat)

    payload["data"]["codeSeats"] = seats
    payload["data"]["cloudControlVersion"] = "phone-snapshot-20260820"
    args.mediation_json.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )

    meta = {
        "source": "TECNO KL4 real-device CloudControl.db",
        "captured_at": "2026-08-20",
        "package": "com.driftsand.game.blockmaster",
        "version_name": "1.0.1.9",
        "version_code": 1019,
        "source_sha256": sha256(args.cloud_db),
        "seat_count": len(seats),
        "code_seat_ids": [item["codeSeatId"] for item in seats],
        "runtime_fields_removed": sorted(RUNTIME_FIELDS),
        "mediation_json_sha256": sha256(args.mediation_json),
    }
    args.meta.write_text(
        json.dumps(meta, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(
        f"FROZEN Hisavana strategy seats={len(seats)} "
        f"sha256={meta['mediation_json_sha256']}"
    )


if __name__ == "__main__":
    main()
