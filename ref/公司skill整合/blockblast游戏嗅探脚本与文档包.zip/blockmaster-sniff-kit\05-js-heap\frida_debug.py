import frida

JS = r"""
'use strict';
function main() {
    var ranges = Process.enumerateRanges('r--');
    var target = null;
    ranges.forEach(function (r) {
        if (r.file && r.file.path && r.file.path.indexOf('libcocos2djs.so') !== -1) {
            target = r;
        }
    });
    if (!target) {
        return "NO RANGE FOUND";
    }
    var bytes = target.base.readByteArray(32);
    var hex = Array.prototype.map.call(new Uint8Array(bytes), function (b) {
        return ('0' + b.toString(16)).slice(-2);
    }).join(' ');
    var hits = Memory.scanSync(target.base, Math.min(target.size, 16 * 1024 * 1024), "6c 69 62 63 6f 63 6f 73 32 64 6a 73");
    return JSON.stringify({
        path: target.file.path,
        base: target.base.toString(),
        size: target.size,
        firstBytes: hex,
        scanHits: hits.length,
        rangesTotal: ranges.length
    });
}
rpc.exports = { main: main };
"""

dev = frida.get_device_manager().add_remote_device('127.0.0.1:27042')
session = dev.attach(3781)
script = session.create_script(JS)
script.load()
print(script.exports_sync.main())
session.detach()
