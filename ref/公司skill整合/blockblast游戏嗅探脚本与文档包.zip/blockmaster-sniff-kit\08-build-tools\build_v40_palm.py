# -*- coding: utf-8 -*-
"""Build/sign V40 arm64 with offline per-install experiment suites."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
import zipfile

import build_config
import build_v34_palm as base


W = base.W
STAGE = base.STAGE
BASELINE = os.path.join(W, "BlockMaster_v39_palm_full_arm64.apk")
MERGED = os.path.join(W, "stage2_v40_arm64_merged.apk")
ALIGNED = os.path.join(W, "stage2_v40_arm64_aligned.apk")
FINAL = os.path.join(W, "BlockMaster_v40_palm_full_arm64.apk")
SEED_ROOT = os.path.join(STAGE, "assets", "remote_seed", "gamecaches")
SEED_ARCHIVE = os.path.join(W, "baselines", "BlockMaster_v40_offline_seed.zip")
SEED_PREFIX = "assets/remote_seed/gamecaches/"
REPLACEMENTS = {
    "assets/main.js": os.path.join(STAGE, "assets", "main.js"),
    "assets/assets/main/index.7d3cd.js": os.path.join(
        STAGE, "assets", "assets", "main", "index.7d3cd.js"
    ),
    "assets/remote_seed/patch/patch/assets/main/index.146a7.js": os.path.join(
        STAGE,
        "assets",
        "remote_seed",
        "patch",
        "patch",
        "assets",
        "main",
        "index.146a7.js",
    ),
}


def sha256_file(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def seed_entry_count(root: str) -> int:
    cache_path = os.path.join(root, "cacheList.json")
    if not os.path.isfile(cache_path):
        return -1
    with open(cache_path, "r", encoding="utf-8") as stream:
        return len(json.load(stream).get("files", {}))


def materialize_seed() -> None:
    if seed_entry_count(SEED_ROOT) == 9706:
        return
    if not os.path.isfile(SEED_ARCHIVE):
        raise RuntimeError(f"V40 offline Seed archive missing: {SEED_ARCHIVE}")
    if os.path.isdir(SEED_ROOT):
        shutil.rmtree(SEED_ROOT)
    os.makedirs(SEED_ROOT, exist_ok=True)
    root_real = os.path.realpath(SEED_ROOT)
    with zipfile.ZipFile(SEED_ARCHIVE, "r") as archive:
        for name in archive.namelist():
            target = os.path.realpath(os.path.join(SEED_ROOT, name))
            if target != root_real and not target.startswith(root_real + os.sep):
                raise RuntimeError(f"unsafe Seed archive member: {name}")
        archive.extractall(SEED_ROOT)
    if seed_entry_count(SEED_ROOT) != 9706:
        raise RuntimeError("V40 offline Seed archive has an invalid cacheList")


def overlay_and_sign() -> None:
    keystore, key_alias = build_config.signing_environment()
    for path in (MERGED, ALIGNED, FINAL):
        if os.path.exists(path):
            os.remove(path)
    for path in (BASELINE, *REPLACEMENTS.values()):
        if not os.path.isfile(path):
            raise RuntimeError(f"required build input missing: {path}")

    signature_suffixes = (".RSA", ".DSA", ".EC", ".SF")
    with zipfile.ZipFile(BASELINE, "r") as source, zipfile.ZipFile(
        MERGED, "w", allowZip64=True
    ) as target:
        names = [item.filename for item in source.infolist()]
        if len(names) != len(set(names)):
            raise RuntimeError("V39 baseline contains duplicate ZIP entries")
        missing_replacements = set(REPLACEMENTS) - set(names)
        if missing_replacements:
            raise RuntimeError(f"baseline entries missing: {missing_replacements}")
        for item in source.infolist():
            upper = item.filename.upper()
            if upper == "META-INF/MANIFEST.MF" or upper.endswith(signature_suffixes):
                continue
            if item.filename.startswith(SEED_PREFIX):
                continue
            replacement = REPLACEMENTS.get(item.filename)
            data = open(replacement, "rb").read() if replacement else source.read(item.filename)
            compression = zipfile.ZIP_STORED if (
                item.filename.endswith(".dex")
                or (item.filename.startswith("lib/") and item.filename.endswith(".so"))
            ) else item.compress_type
            target.writestr(item, data, compress_type=compression)

        for root, _, files in os.walk(SEED_ROOT):
            for filename in sorted(files):
                path = os.path.join(root, filename)
                relative = os.path.relpath(path, SEED_ROOT).replace(os.sep, "/")
                target.write(
                    path,
                    SEED_PREFIX + relative,
                    compress_type=zipfile.ZIP_DEFLATED,
                )

    base.run(f'"{base.BT}\\zipalign.exe" -f -p 4 "{MERGED}" "{ALIGNED}"', 600)
    base.run(
        'cmd /c ""%s\\apksigner.bat" sign --ks "%s" --ks-key-alias %s '
        '--ks-pass env:BLOCKMASTER_KS_PASS --key-pass env:BLOCKMASTER_KEY_PASS '
        '--out "%s" "%s""'
        % (base.BT, keystore, key_alias, FINAL, ALIGNED),
        600,
    )
    base.run(f'"{base.BT}\\apksigner.bat" verify --verbose --print-certs "{FINAL}"', 600)
    base.run(f'"{base.BT}\\zipalign.exe" -c -p 4 "{FINAL}"', 600)


def verify_final() -> None:
    with zipfile.ZipFile(FINAL, "r") as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise RuntimeError("V40 contains duplicate ZIP entries")
        for name, path in REPLACEMENTS.items():
            if hashlib.sha256(archive.read(name)).hexdigest() != sha256_file(path):
                raise RuntimeError(f"replacement mismatch: {name}")
            if "/main/index." in name and b"BM_V40_OFFLINE_TRAIT_SUITES" not in archive.read(name):
                raise RuntimeError(f"V40 suite marker missing: {name}")
        cache_name = SEED_PREFIX + "cacheList.json"
        cache = json.loads(archive.read(cache_name).decode("utf-8"))
        entries = cache.get("files", {})
        if len(entries) != 9706:
            raise RuntimeError(f"unexpected cache entry count: {len(entries)}")
        missing = [
            record.get("url")
            for record in entries.values()
            if SEED_PREFIX + str(record.get("url", "")) not in names
        ]
        if missing:
            raise RuntimeError(f"V40 Seed missing {len(missing)} files")
        abis = sorted({name.split("/")[1] for name in names if name.startswith("lib/")})
        if abis != ["arm64-v8a"]:
            raise RuntimeError(f"unexpected ABI set: {abis}")

    dump = base.run(f'"{base.BT}\\aapt2.exe" dump badging "{FINAL}"', 120)
    badging = (dump.stdout or "") + (dump.stderr or "")
    if "versionCode='1019'" not in badging or "versionName='1.0.1.9'" not in badging:
        raise RuntimeError("V40 version mismatch")
    if "native-code: 'arm64-v8a'" not in badging:
        raise RuntimeError("V40 is not arm64-only")
    print("FINAL", FINAL)
    print("SIZE", os.path.getsize(FINAL))
    print("SHA256", sha256_file(FINAL).upper())


def main() -> None:
    materialize_seed()
    base.run(f'"{sys.executable}" "{os.path.join(W, "verify_v40_offline_suites.py")}"', 180)
    base.run(f'"{sys.executable}" "{os.path.join(W, "verify_v37_transsion_only.py")}"', 180)
    base.run(f'"{sys.executable}" "{os.path.join(W, "verify_v38_firebase_adapter.py")}"', 180)
    overlay_and_sign()
    verify_final()


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("BUILD FAILED:", error, file=sys.stderr)
        sys.exit(1)
