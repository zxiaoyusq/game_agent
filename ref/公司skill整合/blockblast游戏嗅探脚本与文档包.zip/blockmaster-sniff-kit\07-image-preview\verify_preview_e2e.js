﻿'use strict';
const fs = require('fs');
const vm = require('vm');

function arg(name, def) {
  const i = process.argv.indexOf('--' + name);
  return i >= 0 && i + 1 < process.argv.length ? process.argv[i + 1] : def;
}

const HTML = arg('html', 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810/spine-preview/preview.html');
const SPINE_LIB = arg('spine-lib', 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/blast-block-spine/lib/spine-player.js');

const html = fs.readFileSync(HTML, 'utf8');
const m = html.match(/const DATA = (\[[\s\S]*?\]);\r?\nlet cur = -1;/);
if (!m) { console.error('DATA not found in html'); process.exit(1); }
const DATA = JSON.parse(m[1]);
console.log('DATA entries:', DATA.length);

const spineSrc = fs.readFileSync(SPINE_LIB, 'utf8');
const sandbox = {
  console, setTimeout, clearTimeout, setInterval, clearInterval,
  window: {}, document: {}, navigator: { userAgent: 'node' },
  atob: (b64) => Buffer.from(b64, 'base64').toString('latin1'),
  btoa: (s) => Buffer.from(s, 'latin1').toString('base64'),
  TextEncoder, TextDecoder,
  ArrayBuffer, DataView, Uint8Array, Uint16Array, Uint32Array,
  Int8Array, Int16Array, Int32Array, Float32Array, Float64Array,
  Math, JSON, Object, Array, Date, String, Number, Boolean,
  Error, TypeError, RangeError, Map, Set, parseFloat, parseInt, isNaN, isFinite,
};
vm.createContext(sandbox);
vm.runInContext(spineSrc, sandbox, { filename: 'spine-player.js' });
sandbox.DATA = DATA;

vm.runInContext(`
  var __skipped = 0;
  function byteMojibakeToUtf8(s){
    var bytes = [];
    for (var i=0;i<s.length;i++){
      var c = s.charCodeAt(i);
      if (c >= 0xFF00 && c <= 0xFFFF){ bytes.push(c - 0xFF00); }
      else if (c < 0x80){ bytes.push(c); }
      else return null;
    }
    try { return new TextDecoder('utf-8').decode(new Uint8Array(bytes)); } catch(e){ return null; }
  }
  function utf8ToByteMojibake(s){
    var bytes = new TextEncoder().encode(s);
    var out = '';
    for (var i=0;i<bytes.length;i++){ var b = bytes[i]; out += b < 0x80 ? String.fromCharCode(b) : String.fromCharCode(0xFF00 + b); }
    return out;
  }
  (function(){
    var proto = spine.AtlasAttachmentLoader.prototype;
    function wrap(orig){
      return function(skin, name, path){
        try { return orig.call(this, skin, name, path); }
        catch(e){
          if (path != null){
            var alt = byteMojibakeToUtf8(path);
            if (alt !== null && alt !== path){
              try { return orig.call(this, skin, name, alt); } catch(e2){}
            }
            var alt2 = utf8ToByteMojibake(path);
            if (alt2 !== path){
              try { return orig.call(this, skin, name, alt2); } catch(e3){}
            }
          }
          __skipped++;
          return null;
        }
      };
    }
    proto.newRegionAttachment = wrap(proto.newRegionAttachment);
    proto.newMeshAttachment = wrap(proto.newMeshAttachment);
  })();
`, sandbox);

const sim = `
(function(){
  function b64ToU8(b64){ var bin = atob(b64); var u = new Uint8Array(bin.length);
    for (var i=0;i<bin.length;i++) u[i]=bin.charCodeAt(i); return u; }
  function utf8Decode(b64){
    try { return new TextDecoder('utf-8').decode(b64ToU8(b64)); } catch(e){ return ''; }
  }
  function fakeTexture(){ return { setFilters:function(){}, setWraps:function(){},
    getImage:function(){ return { width: 1024, height: 1024 }; }, dispose:function(){} }; }
  var out = [];
  for (var i = 0; i < DATA.length; i++) {
    var it = DATA[i];
    var res = { name: it.name, ok: false };
    try {
      var atlasText = utf8Decode(it.atlasUrl.split(',')[1]);
      var atlas = new spine.TextureAtlas(atlasText, function(path){ return fakeTexture(); });
      var loader = new spine.AtlasAttachmentLoader(atlas);
      var sd;
      if (it.fmt === 'json') {
        var jsonText = utf8Decode(it.skelUrl.split(',')[1]);
        sd = new spine.SkeletonJson(loader).readSkeletonData(JSON.parse(jsonText));
      } else {
        var bin = b64ToU8(it.skelUrl.split(',')[1]);
        sd = new spine.SkeletonBinary(loader).readSkeletonData(bin);
      }
      var skeleton = new spine.Skeleton(sd);
      var skins = sd.skins.map(function (s) { return s.name; });
      if (skins.length) skeleton.setSkinByName(skins[0]);
      skeleton.setToSetupPose();
      var anims = sd.animations.map(function (a) { return a.name; });
      var state = new spine.AnimationState(new spine.AnimationStateData(sd));
      if (anims.length) state.setAnimation(0, anims[0], true);
      state.update(0.5);
      state.apply(skeleton);
      skeleton.updateWorldTransform();
      var offset = new spine.Vector2(0, 0), size = new spine.Vector2(0, 0);
      skeleton.getBounds(offset, size);
      res.ok = true;
      res.anims = anims.length; res.skins = skins.length;
      res.size = Math.round(size.width) + 'x' + Math.round(size.height);
    } catch (e) {
      res.err = (e && e.message) || String(e);
    }
    out.push(res);
  }
  return out;
})();
`;
const results = vm.runInContext(sim, sandbox);
let ok = 0;
const errs = [];
for (const r of results) {
  if (r.ok) ok++; else errs.push(r);
}
console.log('e2e ok:', ok, '/', results.length);
console.log('attachments skipped (missing regions):', sandbox.__skipped);
if (errs.length) {
  console.log('failures:');
  for (const e of errs.slice(0, 20)) console.log(' ', e.name, '->', e.err);
} else {
  const samples = [0, 1, 2, 40, 200, results.length - 1];
  for (const i of samples) {
    const r = results[i];
    console.log(' sample', i, DATA[i].bundle + '/' + DATA[i].name,
      'anims=' + r.anims, 'skins=' + r.skins, 'size=' + r.size);
  }
}
