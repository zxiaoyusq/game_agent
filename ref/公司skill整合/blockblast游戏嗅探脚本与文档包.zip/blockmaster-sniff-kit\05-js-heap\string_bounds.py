raw = open(r"E:\codex_apk_work\memdump\heap\0x3030001c0000_7200000.bin", "rb").read()
anchor = 0x890832

GOOD = set(range(0x20, 0x7F)) | {0x09, 0x0A, 0x0D}


def is_good_u16(off):
    if off < 0 or off + 1 >= len(raw):
        return False
    u = raw[off] | (raw[off + 1] << 8)
    return u in GOOD


# scan back
b = anchor
while b >= 2 and is_good_u16(b - 2):
    b -= 2
# scan forward
e = anchor + 2
while e + 1 < len(raw) and is_good_u16(e):
    e += 2
print("string start:", hex(b), "end:", hex(e), "chars:", (e - b) // 2)

for label, off in [("before start", b - 32), ("start", b), ("end", e), ("after end", e)]:
    pass

# dump before start
lo = max(0, b - 32)
hi = e + 32
chunk = raw[lo:hi]
for i in range(0, len(chunk), 16):
    row = chunk[i:i + 16]
    asc = "".join(chr(x) if 32 <= x < 127 else "." for x in row)
    print(hex(lo + i), row.hex(" "), asc)

# save the exact string
with open(r"E:\codex_apk_work\memdump\mainjs_exact.js", "wb") as f:
    f.write(raw[b:e].decode("utf-16-le").encode("utf-8"))
print("saved mainjs_exact.js", (e - b) // 2, "chars")
