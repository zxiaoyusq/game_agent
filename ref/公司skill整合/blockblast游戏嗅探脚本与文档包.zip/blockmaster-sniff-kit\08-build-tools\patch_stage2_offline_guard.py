# -*- coding: utf-8 -*-
"""Add downloader cache-miss guard to main.js (both copies) after cc.assetManager.init."""
import io, os

WORK = r'E:\codex_apk_work\blockmaster_pro_swap\work\stage2_sdk'
FILES = [
    os.path.join(WORK, 'assets', 'main.js'),
    os.path.join(WORK, 'assets', 'remote_seed', 'patch', 'patch', 'main.js'),
]

GUARD_FUNCS = r'''
function bmBlockedRemoteUrl(value) {
    var s = String(value || '').toLowerCase();
    var blocked = [
        ['afa', 'fb.com'].join(''),
        ['youxi', '123.com'].join(''),
        ['hungry', 'studio.com'].join(''),
    ];
    return blocked.some(function (host) { return s.indexOf(host) >= 0; });
}

function bmInstallDownloadGuard() {
    var am = cc.assetManager;
    if (!am || am.__bmGuardInstalled) return;
    am.__bmGuardInstalled = true;
    var downloader = am.downloader;
    if (downloader && typeof downloader.download === 'function') {
        var originalDownload = downloader.download;
        downloader.download = function () {
            var args = Array.prototype.slice.call(arguments);
            var url = args.find(function (arg) {
                return typeof arg === 'string' && (arg.indexOf('://') >= 0 || arg.indexOf('//') === 0);
            }) || '';
            if (bmBlockedRemoteUrl(url)) {
                var cb = null;
                for (var i = args.length - 1; i >= 0; i--) {
                    if (typeof args[i] === 'function') { cb = args[i]; break; }
                }
                var err = new Error('[BMNetworkGuard] cache miss blocked: ' + url);
                bmWriteMark('bm_blocked_download.txt', err.message);
                if (cb) cb(err, null);
                return null;
            }
            return originalDownload.apply(this, arguments);
        };
    }
}

'''

def patch(path):
    with io.open(path, encoding='utf-8') as f:
        s = f.read()
    if 'bmInstallDownloadGuard' in s:
        print('already patched', path)
        return
    # insert functions before window.boot
    s = s.replace('window.boot = function () {', GUARD_FUNCS + 'window.boot = function () {', 1)
    # insert call after cc.assetManager.init block: find the closing '});' after 'server: settings.server'
    marker = 'server: settings.server'
    idx = s.find(marker)
    if idx == -1:
        print('WARN init marker not found', path)
        return
    end = s.find('});', idx)
    if end == -1:
        print('WARN init end not found', path)
        return
    insert_at = end + 3
    s = s[:insert_at] + '\n    bmInstallDownloadGuard();' + s[insert_at:]
    with io.open(path, 'w', encoding='utf-8', newline='') as f:
        f.write(s)
    print('patched', path)

def main():
    for p in FILES:
        patch(p)

if __name__ == '__main__':
    main()
