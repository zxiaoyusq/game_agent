const fs = require('fs');
const data = JSON.parse(fs.readFileSync('E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810/spine-preview/spine_index.json', 'utf8'));
const want = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 36, 44, 59, 99, 106, 114, 129, 145, 153, 161, 169, 177, 193, 201, 214, 229, 243, 259, 267, 275, 283, 290, 297, 305, 313, 340, 343, 349];
for (const i of want) {
  const it = data[i];
  console.log(i, it.name, '|', it.bundle, '| anims:', JSON.stringify(it.anims), '| skins:', JSON.stringify(it.skins));
}
