# -*- coding: utf-8 -*-
"""Portable build/sign entry for BlockMaster V35 using the LFS V34 baseline."""
import hashlib
import json
import os
import sys

import build_v34_palm as base
import build_config


W = base.W
STAGE = base.STAGE
OUTPUT_DIR = os.path.abspath(os.environ.get('BLOCKMASTER_OUTPUT_DIR', W))
os.makedirs(OUTPUT_DIR, exist_ok=True)
base.BASELINE = str(build_config.resolve_baseline_v34())
base.APKTOOL_ATTEMPT = os.path.join(OUTPUT_DIR, 'stage2_sdk_unsigned_v35.apk')
base.MERGED = os.path.join(OUTPUT_DIR, 'stage2_v35_merged.apk')
base.ALIGNED = os.path.join(OUTPUT_DIR, 'stage2_v35_aligned.apk')
base.FINAL = os.path.join(OUTPUT_DIR, 'BlockMaster_v35_palm_full.apk')
base.DEX_VERIFY = os.path.join(OUTPUT_DIR, 'tmp', 'v35_verify_classes15')


DEX_MARKERS = {
    2: b'BM_V35_SAFEDK_START_DISABLED',
    4: b'BM_V35_AUDIENCE_PROVIDER_DISABLED',
    8: b'BM_V35_ORIGINAL_APM_UPLOAD_DISABLED',
    10: b'BM_V35_APPLOVIN_PROVIDER_DISABLED',
    13: b'BM_V35_BUGSNAG_DELIVERY_DISABLED',
    14: b'BMInitProvider',
    15: b'BM_V35_FIREBASEBRIDGE_DISABLED',
}


def dex_path(number):
    name = 'classes.dex' if number == 1 else 'classes%d.dex' % number
    return os.path.join(STAGE, 'build', 'apk', name)


base.REPLACEMENTS = {
    'classes2.dex': dex_path(2),
    'classes4.dex': dex_path(4),
    'classes8.dex': dex_path(8),
    'classes10.dex': dex_path(10),
    'classes13.dex': dex_path(13),
    'classes14.dex': dex_path(14),
    'classes15.dex': dex_path(15),
    'assets/main.js': os.path.join(STAGE, 'assets', 'main.js'),
    'assets/assets/main/index.7d3cd.js': os.path.join(
        STAGE, 'assets', 'assets', 'main', 'index.7d3cd.js'),
    'assets/remote_seed/patch/patch/assets/main/index.146a7.js': os.path.join(
        STAGE, 'assets', 'remote_seed', 'patch', 'patch', 'assets', 'main', 'index.146a7.js'),
}


def verify_fresh_dex_markers():
    for number, marker in DEX_MARKERS.items():
        path = dex_path(number)
        if not os.path.isfile(path):
            raise RuntimeError('rebuilt DEX missing: %s' % path)
        with open(path, 'rb') as stream:
            data = stream.read()
        if marker not in data:
            raise RuntimeError('rebuilt DEX marker missing: classes%d %r' % (number, marker))
        print('VERIFIED classes%d marker=%s sha256=%s' % (
            number, marker.decode('ascii'), base.sha256_file(path)))


def expected_google_app_id():
    with open(build_config.GOOGLE_SERVICES, 'r', encoding='utf-8') as stream:
        payload = json.load(stream)
    for client in payload.get('client', []):
        info = client.get('client_info', {})
        package = info.get('android_client_info', {}).get('package_name')
        if package == 'com.driftsand.game.blockmaster':
            return info['mobilesdk_app_id']
    raise RuntimeError('Block Master client missing from google-services.json')


def verify_apk_firebase(apk_path):
    result = base.run('"%s\\aapt2.exe" dump resources "%s"' % (
        base.BT, apk_path), 300)
    app_id = expected_google_app_id()
    output = (result.stdout or '') + (result.stderr or '')
    if app_id not in output:
        raise RuntimeError('APK Firebase app id does not match google-services.json')
    print('VERIFIED Firebase app_id=%s apk=%s' % (app_id, apk_path))


def main():
    base.run('"%s" "%s"' % (
        sys.executable, os.path.join(W, 'tools', 'apply_google_services.py')), 120)
    base.run('"%s" "%s"' % (
        sys.executable, os.path.join(W, 'verify_v35_vendor_isolation.py')), 120)
    base.run('"%s" "%s"' % (
        sys.executable, os.path.join(W, 'verify_v32_regressions.py')), 120)
    verify_apk_firebase(base.BASELINE)
    base.compile_and_verify_classes15()
    verify_fresh_dex_markers()
    base.overlay_baseline()
    base.verify_final_entries()
    verify_apk_firebase(base.FINAL)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('BUILD FAILED:', error, file=sys.stderr)
        sys.exit(1)
