# -*- coding: utf-8 -*-
"""Build and formally sign BlockMaster_v32_palm_full.apk from stage2_sdk."""
import os
import subprocess
import sys
import zipfile

W = r'E:\codex_apk_work\blockmaster_pro_swap\work'
BT = r'E:\AndroidSdk\build-tools\34.0.0'
APKTOOL = r'E:\codex_apk_work\tools\apktool_2.9.3.jar'
KS = r'E:\blockh5\config\keystore'
KS_PASS = 'transsion20260424'
KEY_ALIAS = 'blockmaster'
KEY_PASS = '1234567890'

STAGE = os.path.join(W, 'stage2_sdk')
SRC = os.path.join(W, 'stage2_sdk_unsigned_v32.apk')
MERGED = os.path.join(W, 'stage2_v32_merged.apk')
STORED = os.path.join(W, 'stage2_v32_stored.apk')
ALIGNED = os.path.join(W, 'stage2_v32_aligned.apk')
FINAL = os.path.join(W, 'BlockMaster_v32_palm_full.apk')

ADDS = [
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes2.dex'), 'classes15.dex'),
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes4.dex'), 'classes16.dex'),
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes.dex'), 'classes17.dex'),
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes3.dex'), 'classes18.dex'),
    (os.path.join(W, 'more_settings_bridge_dex', 'classes.dex'), 'classes19.dex'),
]


def run(command, timeout=900):
    print('>>', command)
    result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=timeout)
    if result.returncode != 0:
        print(result.stdout[-4000:])
        print(result.stderr[-4000:])
        sys.exit(1)
    if result.stdout:
        print(result.stdout[-4000:])
    return result.stdout


def main():
    run('py -3 "%s"' % os.path.join(W, 'verify_v32_regressions.py'), 120)
    for path in (SRC, MERGED, STORED, ALIGNED, FINAL):
        if os.path.exists(path):
            os.remove(path)

    run('java -jar "%s" b "%s" -o "%s"' % (APKTOOL, STAGE, SRC), 1800)

    with zipfile.ZipFile(SRC, 'r') as zin, zipfile.ZipFile(MERGED, 'w', zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename.endswith('.dex') or (item.filename.startswith('lib/') and item.filename.endswith('.so')):
                zout.writestr(item, data, compress_type=zipfile.ZIP_STORED)
            else:
                zout.writestr(item, data)
        for path, name in ADDS:
            with open(path, 'rb') as dex_file:
                zout.writestr(name, dex_file.read(), compress_type=zipfile.ZIP_STORED)
        zout.writestr('META-INF/services/bmkx.coroutines.H', b'bmkx.coroutines.android.b\r\n')
        zout.writestr('META-INF/services/bmkx.coroutines.internal.n', b'bmkx.coroutines.android.a\r\n')

    with zipfile.ZipFile(MERGED, 'r') as zin, zipfile.ZipFile(STORED, 'w', zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename.startswith('lib/') and item.filename.endswith('.so'):
                zout.writestr(item, data, compress_type=zipfile.ZIP_STORED)
            else:
                zout.writestr(item, data)

    run('"%s\\zipalign.exe" -f -p 4 "%s" "%s"' % (BT, STORED, ALIGNED))
    run('cmd /c ""%s\\apksigner.bat" sign --ks "%s" --ks-key-alias %s --ks-pass pass:%s --key-pass pass:%s --out "%s" "%s""'
        % (BT, KS, KEY_ALIAS, KS_PASS, KEY_PASS, FINAL, ALIGNED))
    run('"%s\\apksigner.bat" verify --verbose --print-certs "%s"' % (BT, FINAL), 300)
    print('BUILD DONE', FINAL, os.path.getsize(FINAL))


if __name__ == '__main__':
    main()
