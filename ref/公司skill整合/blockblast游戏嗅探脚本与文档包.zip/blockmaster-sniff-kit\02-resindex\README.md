# resindex · 本项目美术资源索引（**先看这里，别再用 grep 扫文件找资源**）

## 为什么会有这个目录

`E:\codex_apk_work` 里同时躺着 **4 套同族工程**，资源名字空间互相不同：

| 工程 | 资源根 | 索引形式 |
|---|---|---|
| Block Master（`res-game`/`res-lobby` 那套，Transsion 壳） | `blockmaster_apk\apk\assets\assets\<bundle>\` | 每个 bundle 一份 `cc.config.json` |
| Block Blast 10.4.7 原版 | `bb_1047_base.apk` → `assets/assets/<bundle>/` | APK 内 `config.<hash>.json`（加密） |
| Block Blast 9.5.0 原版 | `com.block.juggle.base.apk` | 同上 |
| 参考素材全量解包 | `E:\参考图\block录屏\解包素材\BlastBlock-美术资源全量-20260810\` | `ui_manifest.json` + `skins_report.json` |

图像本体在 APK 里是 **`HEK:` 加密 + uuid/哈希命名**，所以"用文件名 grep 图片"必然失败；
必须走 **cc.config(索引) → uuid → import/native 文件 → 解密** 这条链。

## 用法

```powershell
cd E:\codex_apk_work
python -X utf8 resindex\build_index.py          # 首次/资源变动后重建（约 1 分钟）
python -X utf8 resindex\resindex.py find backgroundbg --ext .png
python -X utf8 resindex\resindex.py zh 结算背景
python -X utf8 resindex\resindex.py get 12345
python -X utf8 resindex\resindex.py extract Remote_Skin_Material_3012/backgroundbg -o out
python -X utf8 resindex\resindex.py cheat
```

## 标准三步（AI 照着做）

1. **`find` / `zh`** 拿到候选资源名（不要先猜文件路径，也不要 grep 内容）。
2. **`get <id>`** 看 `src/bundle/kind/uuid/file/native/enc`，确定资源属于哪套工程。
3. **`extract`** 导出真图（自动 HEK 解密 / APK 解包），再用 Read 看图核对。

## 已知易踩的坑（血泪教训）

- **中文词得先映射成英文资源名**：用 `zh`（对照表见 `naming_map.json`），例如
  "结算背景" ≠ 叫 `settlement_bg`，实际是 `backgroundbg` / `backgroundbg_material_<皮肤ID>`。
- **全屏背景不是纯色也不是 shader**，是整张竖向渐变 PNG（`backgroundbg*`，全屏比例 960×1707 / 656×1456）。
  `res-game` 里的 `images/ui/common/BG_01` 是 **87×87 纯色 #7B4DCF**，别和渐变背景混为一谈。
- **同一资源名在不同工程里指向不同图**（`resources` vs `res-game`），先确认工程的 `cc.config.json` 再下结论。
- **截图/录像里的文字可能是贴图**：字符串在 JS/prefab/配置里搜不到时，不要继续搜文本，直接按视觉特征在
  图集子图里找（`ui_manifest.json` 的 `sprite_atlases.subimages` 有 rect）。
- **皮肤资源不在 APK 里**：`Remote_Skin_Material_<id>` 是运行时从 CDN 下载的远程 bundle，
  已解密落在 `E:\参考图\...\材质皮肤-远程bundle-20260810\{raw,dec,named}\`。
- 判断"截图属于哪套工程"时，先比 **专属图标**（如皇冠 `images/ui/common/crown`、按钮 `try_again`），
  再比背景，能少走一半弯路。

## 索引来源（build_index.py 会扫）

`cocos-bundle`（cc.config + native）· `ui-manifest`（图集子图/prefab/scene/纹理/字体/音频）·
`skins`（skins_report + named 目录树）· `apk`（zip 条目）· `files`（全局 manifest.csv）· `docs`（结论文档）

`index_meta.json` 记录建库时间与行数；`where` 可随时查看新鲜度，资源变了就重建。
