#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Apply the BlockMaster Pro logo swap into the block blast apktool project:
  1) login/home logo PNG  -> resources/native/7e/7e6db96e-... .png (padded 631x407)
  2) XCfive skeleton      -> chapter/import/0c/0c1ad7d2-... .e1dbe.json (gzip+HEK)
  3) XCfive atlas json    -> chapter/import/a2/a27434c1-... .90b6a.json (gzip+HEK)
  4) XCfive atlas texture -> chapter/native/07/0789aa9f-... .96302.png (HEK)
Everything is backed up first, then verified by decrypting the written files.
"""

import gzip
import hashlib
import io
import json
import os
import shutil

from PIL import Image

KEY = b"65485d8a-8161-4c"
HEADER = b"HEK:\x03\x00\x01\x02"

APK_ASSETS = r"E:\codex_apk_work\blockmaster_pro_swap\work\blockblast_apktool\assets\assets"
OUT = r"E:\codex_apk_work\blockmaster_pro_swap\work\blocklogo_db"
BACKUP = r"E:\codex_apk_work\blockmaster_pro_swap\work\blocklogo_swap_backup"

TITLE_SRC = r"C:\Users\nenghong.zhao\Desktop\block_logo\title.png"
TITLE_TARGET = APK_ASSETS + r"\resources\native\7e\7e6db96e-3ca8-4235-b1ca-4c8b67074c71.67667.png"

SKE_JSON = OUT + r"\blocklogo_ske.json"
ATLAS_JSON = OUT + r"\blocklogo_atlas.json"
ATLAS_PNG = OUT + r"\blocklogo_atlas.png"

SKE_TARGET = APK_ASSETS + r"\chapter\import\0c\0c1ad7d2-b3d8-4566-9104-230bcbf51808.e1dbe.json"
ATLAS_TARGET = APK_ASSETS + r"\chapter\import\a2\a27434c1-5de9-4992-987f-ed2b013add6f.90b6a.json"
ATLAS_PNG_TARGET = APK_ASSETS + r"\chapter\native\07\0789aa9f-5904-42c0-b259-202a2cbcf643.96302.png"


def keystream(n):
    return (KEY * (n // 16 + 1))[:n]


def decrypt(data):
    if not data.startswith(b"HEK:"):
        return data
    body = data[8:]
    ks = keystream(len(body))
    return bytes(a ^ b for a, b in zip(body, ks))


def maybe_gunzip(data):
    if data[:2] == b"\x1f\x8b":
        try:
            return gzip.decompress(data)
        except Exception:
            return data
    return data


def encrypt_native(plaintext):
    body = bytes(a ^ b for a, b in zip(plaintext, keystream(len(plaintext))))
    return HEADER + body


def encrypt_import_json(obj):
    raw = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    compressed = gzip.compress(raw)
    return encrypt_native(compressed)


def read_json(p):
    with open(p, "rb") as f:
        return json.loads(maybe_gunzip(decrypt(f.read())).decode("utf-8"))


def read_bytes(p):
    with open(p, "rb") as f:
        return maybe_gunzip(decrypt(f.read()))


def write_target(target, payload):
    os.makedirs(os.path.dirname(target), exist_ok=True)
    with open(target, "wb") as f:
        f.write(payload)


def backup_file(p):
    rel = os.path.relpath(p, APK_ASSETS)
    dst = os.path.join(BACKUP, rel)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(p, dst)
    print("backup:", dst)


def verify_bytes(label, actual, expected):
    ok = actual == expected
    print("VERIFY", label, "OK" if ok else "FAIL", "len", len(actual))
    return ok


def verify_json(label, actual, expected_obj):
    try:
        got = json.loads(actual.decode("utf-8"))
        ok = got == expected_obj
        print("VERIFY", label, "OK" if ok else "FAIL")
        return ok
    except Exception as e:
        print("VERIFY", label, "FAIL", e)
        return False


def main():
    os.makedirs(BACKUP, exist_ok=True)
    ok = True

    # ---- 1) title.png -> logo texture ----
    title = Image.open(TITLE_SRC).convert("RGBA")
    print("title size:", title.size)
    canvas = Image.new("RGBA", (631, 407), (0, 0, 0, 0))
    canvas.paste(title, ((631 - title.width) // 2, (407 - title.height) // 2), title)
    buf = io.BytesIO()
    canvas.save(buf, format="PNG")
    title_plain = buf.getvalue()
    print("padded title bytes:", len(title_plain))

    backup_file(TITLE_TARGET)
    write_target(TITLE_TARGET, encrypt_native(title_plain))
    ok &= verify_bytes("title png", read_bytes(TITLE_TARGET), title_plain)

    # ---- 2) skeleton json ----
    ske_obj = read_json(SKE_JSON)
    backup_file(SKE_TARGET)
    write_target(SKE_TARGET, encrypt_import_json(ske_obj))
    ok &= verify_json("skeleton json", maybe_gunzip(decrypt(open(SKE_TARGET, "rb").read())), ske_obj)

    # ---- 3) atlas json ----
    atlas_obj = read_json(ATLAS_JSON)
    backup_file(ATLAS_TARGET)
    write_target(ATLAS_TARGET, encrypt_import_json(atlas_obj))
    ok &= verify_json("atlas json", maybe_gunzip(decrypt(open(ATLAS_TARGET, "rb").read())), atlas_obj)

    # ---- 4) atlas png ----
    atlas_png = open(ATLAS_PNG, "rb").read()
    backup_file(ATLAS_PNG_TARGET)
    write_target(ATLAS_PNG_TARGET, encrypt_native(atlas_png))
    ok &= verify_bytes("atlas png", read_bytes(ATLAS_PNG_TARGET), atlas_png)

    print("ALL OK" if ok else "SOME VERIFY FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
