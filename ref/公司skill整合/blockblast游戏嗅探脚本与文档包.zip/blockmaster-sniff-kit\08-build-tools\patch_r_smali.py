# -*- coding: utf-8 -*-
"""Patch disassembled Hisavana R smali files with new resource IDs."""
import io
import json
import os
import re

WORK = r'E:\codex_apk_work\blockmaster_pro_swap\work'
ID_MAP = os.path.join(WORK, 'hisavana_id_map.json')
SRC_DIR = os.path.join(WORK, '_bm_sel_test')
OUT_DIR = os.path.join(WORK, '_bm_r_patched')

R_CLASSES = [
    'com/cloud/hisavana/sdk/j0.smali',
    'com/cloud/hisavana/sdk/k0.smali',
    'com/cloud/hisavana/sdk/l0.smali',
    'com/cloud/hisavana/sdk/m0.smali',
    'com/cloud/hisavana/sdk/n0.smali',
    'com/cloud/hisavana/sdk/o0.smali',
    'com/cloud/hisavana/sdk/q0.smali',
    'com/cloud/hisavana/sdk/r0.smali',
    'com/cloud/hisavana/sdk/s0.smali',
]


def main():
    with io.open(ID_MAP, encoding='utf-8') as f:
        id_map = json.load(f)
    # old_id -> new_id
    old_to_new = {int(r['old_id']): int(r['new_id']) for r in id_map}
    # name+type -> new_id (for field replacement by name)
    key_to_new = {}
    for r in id_map:
        key_to_new[(r['type'], r['name'])] = int(r['new_id'])

    # Type per class for field lookup
    class_type = {
        'com/cloud/hisavana/sdk/j0.smali': 'color',
        'com/cloud/hisavana/sdk/k0.smali': 'dimen',
        'com/cloud/hisavana/sdk/l0.smali': 'drawable',
        'com/cloud/hisavana/sdk/m0.smali': 'id',
        'com/cloud/hisavana/sdk/n0.smali': 'layout',
        'com/cloud/hisavana/sdk/o0.smali': 'mipmap',
        'com/cloud/hisavana/sdk/q0.smali': 'string',
        'com/cloud/hisavana/sdk/r0.smali': 'style',
        'com/cloud/hisavana/sdk/s0.smali': 'attr',
    }

    os.makedirs(OUT_DIR, exist_ok=True)
    for rel in R_CLASSES:
        src = os.path.join(SRC_DIR, rel)
        dst = os.path.join(OUT_DIR, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with io.open(src, encoding='utf-8') as f:
            lines = f.readlines()
        typ = class_type[rel]
        out_lines = []
        for line in lines:
            # Replace .field ... = 0x...
            m = re.match(r'^(\.field public static (\w+):I = )0x[0-9a-fA-F]+', line)
            if m:
                name = m.group(2)
                key = (typ, name)
                if key in key_to_new:
                    line = '%s0x%08x\n' % (m.group(1), key_to_new[key])
            # Replace constants in s0 clinit / array-data using old ID map
            if rel.endswith('s0.smali'):
                def repl(match):
                    val = int(match.group(0), 16)
                    if val in old_to_new:
                        return '0x%08x' % old_to_new[val]
                    return match.group(0)
                line = re.sub(r'0x[0-9a-fA-F]{8}', repl, line)
            out_lines.append(line)
        with io.open(dst, 'w', encoding='utf-8') as f:
            f.writelines(out_lines)
        print('patched', rel)

    print('done')


if __name__ == '__main__':
    main()
