# -*- coding: utf-8 -*-
"""Parameterized v28 build/sign helper.

Usage:
  python build_v28_palm.py --tag v28a_seed_audit
  input : work/stage2_sdk_unsigned_<tag>.apk
  output: work/BlockMaster_<tag>.apk
"""
import argparse
import os
import subprocess
import sys
import zipfile

W = r'E:\codex_apk_work\blockmaster_pro_swap\work'
BT = r'E:\AndroidSdk\build-tools\34.0.0'
KS = r'E:\blockh5\config\keystore'
KS_PASS = 'transsion20260424'
KEY_ALIAS = 'blockmaster'
KEY_PASS = '1234567890'

ADDS = [
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes2.dex'), 'classes15.dex'),
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes4.dex'), 'classes16.dex'),
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes.dex'), 'classes17.dex'),
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes3.dex'), 'classes18.dex'),
    (os.path.join(W, 'more_settings_bridge_dex', 'classes.dex'), 'classes19.dex'),
]


def run(c, t=900):
    print('>>', c)
    r = subprocess.run(c, shell=True, capture_output=True, text=True, timeout=t)
    if r.returncode != 0:
        print(r.stdout[-3000:])
        print(r.stderr[-3000:])
        sys.exit(1)
    return r.stdout


def build(tag):
    src_unsigned = os.path.join(W, f'stage2_sdk_unsigned_{tag}.apk')
    final_apk = os.path.join(W, f'BlockMaster_{tag}.apk')
    merged = os.path.join(W, f'stage2_{tag}_merged.apk')
    stored = os.path.join(W, f'stage2_{tag}_stored.apk')
    aligned = os.path.join(W, f'stage2_{tag}_aligned.apk')
    for p in (merged, stored, aligned, final_apk):
        if os.path.exists(p):
            os.remove(p)

    zin = zipfile.ZipFile(src_unsigned)
    zout = zipfile.ZipFile(merged, 'w', zipfile.ZIP_DEFLATED)
    for item in zin.infolist():
        data = zin.read(item.filename)
        if item.filename.endswith('.dex') or (item.filename.startswith('lib/') and item.filename.endswith('.so')):
            zout.writestr(item, data, compress_type=zipfile.ZIP_STORED)
        else:
            zout.writestr(item, data)
    for path, name in ADDS:
        zout.writestr(name, open(path, 'rb').read(), compress_type=zipfile.ZIP_STORED)
    zout.writestr('META-INF/services/bmkx.coroutines.H', b'bmkx.coroutines.android.b\r\n')
    zout.writestr('META-INF/services/bmkx.coroutines.internal.n', b'bmkx.coroutines.android.a\r\n')
    zout.close()
    zin.close()
    print('merged:', os.path.getsize(merged))

    zin = zipfile.ZipFile(merged)
    zout = zipfile.ZipFile(stored, 'w', zipfile.ZIP_DEFLATED)
    for item in zin.infolist():
        data = zin.read(item.filename)
        if item.filename.startswith('lib/') and item.filename.endswith('.so'):
            zout.writestr(item, data, compress_type=zipfile.ZIP_STORED)
        else:
            zout.writestr(item, data)
    zout.close()
    zin.close()
    print('stored:', os.path.getsize(stored))

    run('"%s\\zipalign.exe" -f -p 4 "%s" "%s"' % (BT, stored, aligned))
    run('cmd /c ""%s\\apksigner.bat" sign --ks "%s" --ks-key-alias %s --ks-pass pass:%s --key-pass pass:%s --out "%s" "%s""'
        % (BT, KS, KEY_ALIAS, KS_PASS, KEY_PASS, final_apk, aligned))
    run('"%s\\apksigner.bat" verify --verbose --print-certs "%s"' % (BT, final_apk), 300)
    print('signed:', os.path.getsize(final_apk))


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--tag', required=True)
    args = ap.parse_args()
    build(args.tag)
    print('BUILD DONE', args.tag)
