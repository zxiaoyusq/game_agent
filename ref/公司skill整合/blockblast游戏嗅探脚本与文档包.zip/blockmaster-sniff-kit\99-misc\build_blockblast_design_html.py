# -*- coding: utf-8 -*-
"""Build the comprehensive Block Blast design-intent HTML with chapters, charts, mind maps, flow diagrams and full appendices."""
from pathlib import Path
import html as html_mod
import markdown

ROOT = Path(r'E:/codex_apk_work')
DOC_DIR = ROOT / 'blockblast_规范文档'
ART_ROOT = Path(r'E:/参考图/block录屏/解包素材')
OUT = ROOT / 'BlockBlast汇总总览.html'

# ---------- Normalized design docs ----------
doc_files = [
    '00_总览与证据边界.md',
    '01_线上内容与联网拉取.md',
    '02_美术资源与动画预览.md',
    '03_局内玩法与算法规则.md',
    '04_局外系统与运营规则.md',
    '05_商业化与广告规则.md',
    '06_美术动效加载与性能优化规则.md',
    '07_AB测试与远程配置规则.md',
    '08_加密与工程安全说明.md',
    '09_美术设计与实现规则.md',
    '10_遗漏与后续补充.md',
    'QA_预览验证结果.md',
]
docs = []
for name in doc_files:
    p = DOC_DIR / name
    text = p.read_text(encoding='utf-8', errors='replace')
    h1 = next((l.strip('#').strip() for l in text.splitlines() if l.startswith('# ')), name)
    docs.append({'name': name, 'path': p, 'text': text, 'h1': h1, 'chars': len(text)})
import re
for d in docs:
    d['html'] = markdown.markdown(d['text'], extensions=['tables', 'fenced_code', 'sane_lists'])
    d['tables'] = d['html'].count('<table>')

def add_heading_ids(html, idx):
    counter = [0]
    def repl(m):
        tag = m.group(1)
        hid = f'doc-{idx}-h{counter[0]}'
        counter[0] += 1
        return f'<h{tag} id="{hid}">'
    return re.sub(r'<h([23])>', repl, html)

for idx, d in enumerate(docs):
    d['html'] = add_heading_ids(d['html'], idx)

total_chars = sum(d['chars'] for d in docs)
total_tables = sum(d['tables'] for d in docs)

# ---------- Original raw docs (full appendix) ----------
raw_candidates = []
for pattern in ['*.md']:
    raw_candidates.extend(ROOT.glob(pattern))
for sub in [
    ROOT / 'blockmaster_pro_swap' / 'README.md',
    ROOT / 'blockmaster_pro_swap' / 'work' / '*.md',
    ROOT / 'blockmaster_v41_worktree' / '*.md',
    ROOT / 'blockmaster_v41_worktree' / 'docs' / '*.md',
    ROOT / 'main_algo_extract' / '*.md',
]:
    if sub.parent.exists():
        raw_candidates.extend(sub.parent.glob(sub.name))
seen = set()
raw_docs = []
for p in raw_candidates:
    if p.name in seen:
        continue
    seen.add(p.name)
    try:
        text = p.read_text(encoding='utf-8', errors='replace')
    except Exception:
        text = '<p>读取失败</p>'
    raw_docs.append({'name': p.name, 'path': p, 'text': text})
raw_docs.sort(key=lambda d: d['name'])
for d in raw_docs:
    d['html'] = markdown.markdown(d['text'], extensions=['tables', 'fenced_code', 'sane_lists'])

# ---------- Art links ----------
art_links = []
def add_art(label, rel):
    p = ART_ROOT / rel
    if p.exists():
        art_links.append({'label': label, 'path': p})

add_art('Spine 全量预览（旧包）', 'blast-block-spine/blast-block-spine/preview.html')
add_art('DragonBones 全量预览', 'BlastBlock-美术资源全量-20260810/blast-block-dragonbones/preview.html')
add_art('材质皮肤远程 bundle Spine 预览', 'BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810/spine-preview/preview.html')
spine_dir = ART_ROOT / 'BlastBlock-美术资源全量-20260810' / 'blast-block-dragonbones-spine'
if spine_dir.exists():
    for p in sorted(spine_dir.rglob('preview.html')):
        art_links.append({'label': 'Spine / ' + p.parent.name, 'path': p})

def file_uri(path: Path) -> str:
    return path.resolve().as_uri()

def flow_svg(title, steps, color, uid):
    n = len(steps)
    box_w = 130 if n <= 5 else 112
    gap = 24
    total = n * box_w + (n - 1) * gap
    x0 = max(10, (900 - total) // 2)
    y, h = 78, 64
    parts = []
    for i, step in enumerate(steps):
        x = x0 + i * (box_w + gap)
        parts.append(f'<rect x="{x}" y="{y}" width="{box_w}" height="{h}" rx="10" fill="#232733" stroke="{color}" stroke-width="1.2"/>')
        # split step into two lines if long
        words = step
        if len(words) <= 10:
            parts.append(f'<text x="{x+box_w/2}" y="{y+36}" text-anchor="middle" fill="#e8eaf0" font-size="12">{html_mod.escape(words)}</text>')
        else:
            mid = len(words)//2
            # break at space near middle
            space = words.rfind(' ', 0, mid)
            if space > len(words)//3:
                parts.append(f'<text x="{x+box_w/2}" y="{y+28}" text-anchor="middle" fill="#e8eaf0" font-size="12">{html_mod.escape(words[:space])}</text>')
                parts.append(f'<text x="{x+box_w/2}" y="{y+48}" text-anchor="middle" fill="#e8eaf0" font-size="12">{html_mod.escape(words[space+1:])}</text>')
            else:
                parts.append(f'<text x="{x+box_w/2}" y="{y+36}" text-anchor="middle" fill="#e8eaf0" font-size="12">{html_mod.escape(words[:10])}…</text>')
        if i < n - 1:
            ax = x + box_w
            ay = y + h / 2
            bx = ax + gap
            parts.append(f'<line x1="{ax}" y1="{ay}" x2="{bx}" y2="{ay}" stroke="{color}" stroke-width="1.5" marker-end="url(#arr_{uid})"/>')
    return f'''<svg viewBox="0 0 900 200" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:auto;background:#0d0f14;border-radius:12px">
<defs><marker id="arr_{uid}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="{color}"/></marker></defs>
<text x="450" y="34" text-anchor="middle" fill="{color}" font-size="14" font-weight="bold">{html_mod.escape(title)}</text>
{''.join(parts)}
</svg>'''

art_rows = ''.join(
    f'<tr><td>{html_mod.escape(a["label"])}</td><td><a href="{file_uri(a["path"])}" target="_blank">打开 preview.html</a></td>'
    f'<td><a href="{file_uri(a["path"].parent)}" target="_blank">打开目录</a></td></tr>'
    for a in art_links
)
art_rows = f'<tr><td>📁 美术素材根目录</td><td colspan="2"><a href="{file_uri(ART_ROOT)}" target="_blank">打开目录</a></td></tr>' + art_rows

# ---------- Chapter list ----------
chapters = [{'title': '总览 / 设计总纲', 'sub': '数据图表 + 脑图 + 流程图'}]
for d in docs:
    chapters.append({'title': d['h1'], 'sub': d['name']})
chapters.append({'title': '原始 MD 附录', 'sub': f'{len(raw_docs)} 份原始逆向文档全量'})

# ---------- Chapter content ----------
# Chapter 0: dashboard + design overview
max_chars = max(d['chars'] for d in docs) or 1
bars = ''.join(
    f'<div class="bar-row"><span class="bar-label">{i+1}. {html_mod.escape(d["name"][:24])}</span>'
    f'<div class="bar-track"><div class="bar-fill" style="width:{d["chars"]/max_chars*100:.1f}%"></div></div>'
    f'<span class="bar-val">{d["chars"]:,}</span></div>'
    for i, d in enumerate(docs)
)

# Donut chart: distribution by major group (using doc index)
donut_segments = [
    (len(docs[0:1]), '#4cc2ff', '总览'),
    (len(docs[1:2]), '#7a5cff', '线上'),
    (len(docs[2:3]), '#4cd97b', '美术'),
    (len(docs[3:5]), '#ffb454', '玩法/局外'),
    (len(docs[5:6]), '#ff6b6b', '商业化'),
    (len(docs[6:9]), '#f472b6', '性能/AB/安全'),
    (len(docs[9:10]), '#22d3ee', '美术规则'),
    (len(docs[10:12]), '#a3e635', '遗漏/QA'),
]
total_docs = len(docs)
donut_css = []
start = 0
for count, color, label in donut_segments:
    pct = count / total_docs * 100
    donut_css.append(f'{color} {start:.1f}% {start+pct:.1f}%')
    start += pct
donut_style = 'conic-gradient(' + ','.join(donut_css) + ')'

mind_svg = '''
<svg viewBox="0 0 900 560" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:auto;background:#0d0f14;border-radius:12px">
  <style>
    .mm-root{fill:#4cc2ff;font-weight:bold;font-size:18px}
    .mm-node{fill:#232733;stroke:#333845;stroke-width:1}
    .mm-text{fill:#e8eaf0;font-size:12px}
    .mm-line{stroke:#4cc2ff;stroke-width:1.5;fill:none}
  </style>
  <text x="450" y="36" text-anchor="middle" class="mm-root">Block Blast 设计体系</text>
  <line x1="450" y1="48" x2="450" y2="70" class="mm-line"/>
  <g transform="translate(150,80)"><rect width="190" height="76" rx="10" class="mm-node"/><text x="95" y="28" text-anchor="middle" class="mm-text" fill="#4cc2ff">玩法算法</text><text x="95" y="48" text-anchor="middle" class="mm-text">出题/消除/连击/Trait</text><text x="95" y="64" text-anchor="middle" class="mm-text">→ 03/07</text></g>
  <g transform="translate(365,80)"><rect width="190" height="76" rx="10" class="mm-node"/><text x="95" y="28" text-anchor="middle" class="mm-text" fill="#4cc2ff">美术表现</text><text x="95" y="48" text-anchor="middle" class="mm-text">Spine/DragonBones/皮肤分层</text><text x="95" y="64" text-anchor="middle" class="mm-text">→ 02/06/09</text></g>
  <g transform="translate(580,80)"><rect width="190" height="76" rx="10" class="mm-node"/><text x="95" y="28" text-anchor="middle" class="mm-text" fill="#4cc2ff">商业化广告</text><text x="95" y="48" text-anchor="middle" class="mm-text">激励/插屏/Banner/瀑布</text><text x="95" y="64" text-anchor="middle" class="mm-text">→ 05</text></g>
  <g transform="translate(150,210)"><rect width="190" height="76" rx="10" class="mm-node"/><text x="95" y="28" text-anchor="middle" class="mm-text" fill="#4cc2ff">线上配置</text><text x="95" y="48" text-anchor="middle" class="mm-text">联网拉取/AB/远程Trait</text><text x="95" y="64" text-anchor="middle" class="mm-text">→ 01/07</text></g>
  <g transform="translate(365,210)"><rect width="190" height="76" rx="10" class="mm-node"/><text x="95" y="28" text-anchor="middle" class="mm-text" fill="#4cc2ff">局外运营</text><text x="95" y="48" text-anchor="middle" class="mm-text">签到/竞赛/推送/皮肤</text><text x="95" y="64" text-anchor="middle" class="mm-text">→ 04</text></g>
  <g transform="translate(580,210)"><rect width="190" height="76" rx="10" class="mm-node"/><text x="95" y="28" text-anchor="middle" class="mm-text" fill="#4cc2ff">工程安全</text><text x="95" y="48" text-anchor="middle" class="mm-text">加密/桥接/防篡改/离线</text><text x="95" y="64" text-anchor="middle" class="mm-text">→ 08</text></g>
  <g transform="translate(365,340)"><rect width="190" height="76" rx="10" class="mm-node"/><text x="95" y="28" text-anchor="middle" class="mm-text" fill="#4cc2ff">遗漏与QA</text><text x="95" y="48" text-anchor="middle" class="mm-text">缺口盘点/验证清单</text><text x="95" y="64" text-anchor="middle" class="mm-text">→ 10/QA</text></g>
  <line x1="245" y1="120" x2="245" y2="200" class="mm-line"/>
  <line x1="460" y1="120" x2="460" y2="200" class="mm-line"/>
  <line x1="675" y1="120" x2="675" y2="200" class="mm-line"/>
  <line x1="460" y1="250" x2="460" y2="330" class="mm-line"/>
</svg>
'''

flow_gameplay = '''
<svg viewBox="0 0 900 220" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:auto;background:#0d0f14;border-radius:12px">
  <defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="#4cc2ff"/></marker></defs>
  <style>.fbox{fill:#232733;stroke:#4cc2ff;stroke-width:1.2;rx:10}.ft{fill:#e8eaf0;font-size:12px;text-anchor:middle}</style>
  <g><rect x="10" y="70" width="130" height="60" class="fbox"/><text x="75" y="95" class="ft">生成方块</text><text x="75" y="112" class="ft" fill="#9aa1b0">算法族出题</text></g>
  <g><rect x="180" y="70" width="130" height="60" class="fbox"/><text x="245" y="95" class="ft">拖拽落子</text><text x="245" y="112" class="ft" fill="#9aa1b0">棋盘判定</text></g>
  <g><rect x="350" y="70" width="130" height="60" class="fbox"/><text x="415" y="95" class="ft">消除/连击</text><text x="415" y="112" class="ft" fill="#9aa1b0">清屏/特效</text></g>
  <g><rect x="520" y="70" width="130" height="60" class="fbox"/><text x="585" y="95" class="ft">计分/奖励</text><text x="585" y="112" class="ft" fill="#9aa1b0">连击/金币</text></g>
  <g><rect x="690" y="70" width="130" height="60" class="fbox"/><text x="755" y="95" class="ft">新方块</text><text x="755" y="112" class="ft" fill="#9aa1b0">循环 / 失败</text></g>
  <line x1="140" y1="100" x2="175" y2="100" stroke="#4cc2ff" marker-end="url(#arrow)"/>
  <line x1="310" y1="100" x2="345" y2="100" stroke="#4cc2ff" marker-end="url(#arrow)"/>
  <line x1="480" y1="100" x2="515" y2="100" stroke="#4cc2ff" marker-end="url(#arrow)"/>
  <line x1="650" y1="100" x2="685" y2="100" stroke="#4cc2ff" marker-end="url(#arrow)"/>
  <path d="M755 135 C755 190, 245 190, 245 135" stroke="#ffb454" stroke-width="1.5" fill="none" marker-end="url(#arrow)" stroke-dasharray="5 3"/>
  <text x="470" y="205" text-anchor="middle" fill="#ffb454" font-size="12">复活 / 新局回环</text>
</svg>
'''

flow_ad = '''
<svg viewBox="0 0 900 220" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:auto;background:#0d0f14;border-radius:12px">
  <defs><marker id="arrow2" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="#ff6b6b"/></marker></defs>
  <style>.fbox2{fill:#232733;stroke:#ff6b6b;stroke-width:1.2;rx:10}.ft2{fill:#e8eaf0;font-size:12px;text-anchor:middle}</style>
  <g><rect x="10" y="70" width="130" height="60" class="fbox2"/><text x="75" y="95" class="ft2">事件触发</text><text x="75" y="112" class="ft2" fill="#9aa1b0">失败/复活/关卡</text></g>
  <g><rect x="180" y="70" width="130" height="60" class="fbox2"/><text x="245" y="95" class="ft2">预加载检查</text><text x="245" y="112" class="ft2" fill="#9aa1b0">插屏/激励</text></g>
  <g><rect x="350" y="70" width="130" height="60" class="fbox2"/><text x="415" y="95" class="ft2">门控链</text><text x="415" y="112" class="ft2" fill="#9aa1b0">VIP/时间/频控</text></g>
  <g><rect x="520" y="70" width="130" height="60" class="fbox2"/><text x="585" y="95" class="ft2">瀑布/竞价</text><text x="585" y="112" class="ft2" fill="#9aa1b0">高价优先</text></g>
  <g><rect x="690" y="70" width="130" height="60" class="fbox2"/><text x="755" y="95" class="ft2">回调/奖励</text><text x="755" y="112" class="ft2" fill="#9aa1b0">一次结算</text></g>
  <line x1="140" y1="100" x2="175" y2="100" stroke="#ff6b6b" marker-end="url(#arrow2)"/>
  <line x1="310" y1="100" x2="345" y2="100" stroke="#ff6b6b" marker-end="url(#arrow2)"/>
  <line x1="480" y1="100" x2="515" y2="100" stroke="#ff6b6b" marker-end="url(#arrow2)"/>
  <line x1="650" y1="100" x2="685" y2="100" stroke="#ff6b6b" marker-end="url(#arrow2)"/>
  <path d="M415 135 C415 195, 75 195, 75 135" stroke="#ffb454" stroke-width="1.5" fill="none" marker-end="url(#arrow2)" stroke-dasharray="5 3"/>
  <text x="245" y="210" text-anchor="middle" fill="#ffb454" font-size="12">门控失败 → 放弃展示，不打断体验</text>
</svg>
'''

flow_art = '''
<svg viewBox="0 0 900 220" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:auto;background:#0d0f14;border-radius:12px">
  <defs><marker id="arrow3" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="#4cd97b"/></marker></defs>
  <style>.fbox3{fill:#232733;stroke:#4cd97b;stroke-width:1.2;rx:10}.ft3{fill:#e8eaf0;font-size:12px;text-anchor:middle}</style>
  <g><rect x="10" y="70" width="120" height="60" class="fbox3"/><text x="70" y="92" class="ft3">UI 层</text><text x="70" y="110" class="ft3" fill="#9aa1b0">界面/按钮/弹窗</text></g>
  <g><rect x="150" y="70" width="120" height="60" class="fbox3"/><text x="210" y="92" class="ft3">棋盘层</text><text x="210" y="110" class="ft3" fill="#9aa1b0">底板/格子/高亮</text></g>
  <g><rect x="290" y="70" width="120" height="60" class="fbox3"/><text x="350" y="92" class="ft3">方块层</text><text x="350" y="110" class="ft3" fill="#9aa1b0">方块/拖拽/皮肤</text></g>
  <g><rect x="430" y="70" width="120" height="60" class="fbox3"/><text x="490" y="92" class="ft3">特效层</text><text x="490" y="110" class="ft3" fill="#9aa1b0">消除/连击/清屏</text></g>
  <g><rect x="570" y="70" width="120" height="60" class="fbox3"/><text x="630" y="92" class="ft3">动效层</text><text x="630" y="110" class="ft3" fill="#9aa1b0">Spine/DragonBones</text></g>
  <g><rect x="710" y="70" width="150" height="60" class="fbox3"/><text x="785" y="92" class="ft3">远程 bundle 层</text><text x="785" y="110" class="ft3" fill="#9aa1b0">皮肤包/活动资源</text></g>
  <line x1="130" y1="100" x2="145" y2="100" stroke="#4cd97b" marker-end="url(#arrow3)"/>
  <line x1="270" y1="100" x2="285" y2="100" stroke="#4cd97b" marker-end="url(#arrow3)"/>
  <line x1="410" y1="100" x2="425" y2="100" stroke="#4cd97b" marker-end="url(#arrow3)"/>
  <line x1="550" y1="100" x2="565" y2="100" stroke="#4cd97b" marker-end="url(#arrow3)"/>
  <line x1="690" y1="100" x2="705" y2="100" stroke="#4cd97b" marker-end="url(#arrow3)"/>
</svg>
'''

flow_ab = '''
<svg viewBox="0 0 900 220" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:auto;background:#0d0f14;border-radius:12px">
  <defs><marker id="arrow4" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="#f472b6"/></marker></defs>
  <style>.fbox4{fill:#232733;stroke:#f472b6;stroke-width:1.2;rx:10}.ft4{fill:#e8eaf0;font-size:12px;text-anchor:middle}</style>
  <g><rect x="10" y="70" width="140" height="60" class="fbox4"/><text x="80" y="95" class="ft4">定义实验</text><text x="80" y="112" class="ft4" fill="#9aa1b0">参数/开关/分组</text></g>
  <g><rect x="190" y="70" width="140" height="60" class="fbox4"/><text x="260" y="95" class="ft4">人群分层</text><text x="260" y="112" class="ft4" fill="#9aa1b0">国家/LTV/设备</text></g>
  <g><rect x="370" y="70" width="140" height="60" class="fbox4"/><text x="440" y="95" class="ft4">Trait 开关</text><text x="440" y="112" class="ft4" fill="#9aa1b0">远程/本地快照</text></g>
  <g><rect x="550" y="70" width="140" height="60" class="fbox4"/><text x="620" y="95" class="ft4">运行/收集</text><text x="620" y="112" class="ft4" fill="#9aa1b0">埋点/上报</text></g>
  <g><rect x="730" y="70" width="140" height="60" class="fbox4"/><text x="800" y="95" class="ft4">决策/回滚</text><text x="800" y="112" class="ft4" fill="#9aa1b0">放量/一键回退</text></g>
  <line x1="150" y1="100" x2="185" y2="100" stroke="#f472b6" marker-end="url(#arrow4)"/>
  <line x1="330" y1="100" x2="365" y2="100" stroke="#f472b6" marker-end="url(#arrow4)"/>
  <line x1="510" y1="100" x2="545" y2="100" stroke="#f472b6" marker-end="url(#arrow4)"/>
  <line x1="690" y1="100" x2="725" y2="100" stroke="#f472b6" marker-end="url(#arrow4)"/>
</svg>
'''

chapter_figs = [
    flow_svg('证据边界分层', ['已确认证据', '静态结构证据', '脚本/日志推断', '真机待验证', '未知/缺口'], '#4cc2ff', 1),
    flow_svg('联网拉取链路', ['游戏启动', '读本地配置', '请求远程内容', '成功→应用', '失败→离线兜底'], '#7a5cff', 2),
    flow_svg('美术资源构成', ['贴图/图集', 'Spine动画', 'DragonBones', 'Lottie/序列帧', '音频/字体', '远程Bundle'], '#4cd97b', 3),
    flow_svg('局内玩法循环', ['生成方块', '拖拽落子', '消除判定', '连击/特效', '计分/新方块'], '#ffb454', 4),
    flow_svg('局外系统模块', ['主界面', '章节地图', '签到/任务', '竞赛/排行', '推送/召回', '皮肤/广告/离线'], '#22d3ee', 5),
    flow_svg('广告展示时机', ['冷启动保护', '失败/复活', '结算/关卡', '激励/插屏', '回调/奖励'], '#ff6b6b', 6),
    flow_svg('加载与性能降级', ['资源清单', '机型分级', '按需加载', '低端降级', '展示/回退'], '#f472b6', 7),
    flow_svg('AB/远程配置流程', ['定义实验', '人群分层', 'Trait开关', '运行/收集', '决策/回滚'], '#a3e635', 8),
    flow_svg('安全防护层次', ['JS加密', 'SDK桥接', '资源防篡改', '网络隔离', '热更回退'], '#fb923c', 9),
    flow_svg('美术制作流程', ['策划需求', '原画/UI', '骨骼/特效', '资源打包', '远程分发', 'QA验收'], '#4cd97b', 10),
    flow_svg('缺口优先级', ['高价值易补', '高价值难补', '低价值易补', '低价值难补', '暂不处理'], '#e879f9', 11),
    flow_svg('预览QA流程', ['资源提取', '生成预览', '浏览器自检', '截图/日志', '结论/门禁'], '#60a5fa', 12),
]

chapter0 = f'''
<div class="grid">
  <div class="stat"><b>{len(docs)}</b> 份规范文档</div>
  <div class="stat"><b>{total_chars:,}</b> 字</div>
  <div class="stat"><b>{total_tables}</b> 张表格</div>
  <div class="stat"><b>{len(raw_docs)}</b> 份原始 MD 附录</div>
</div>
<div class="grid">
  <div class="stat"><b>{len(art_links)}</b> 个美术预览入口</div>
  <div class="stat"><b>12</b> 章节目录</div>
  <div class="stat"><b>4</b> 张核心流程图</div>
  <div class="stat"><b>1</b> 张设计脑图</div>
</div>
<div class="hl-row">
  <span class="hl">✅ 本页不是索引页：每一章都是完整正文</span>
  <span class="hl">左侧可按章节翻页，底部有上一章/下一章</span>
  <span class="hl">原始 MD 附录保留全部证据链</span>
</div>
<h3>文档篇幅分布</h3>
<div style="margin-bottom:18px">{bars}</div>
<h3>文档类型分布</h3>
<div class="grid">
  <div style="background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px">
    <div style="width:140px;height:140px;border-radius:50%;background:{donut_style};margin:0 auto"></div>
    <div style="margin-top:12px;font-size:12px;color:var(--dim)">
      {''.join(f'<div><span style="display:inline-block;width:10px;height:10px;background:{c};border-radius:2px;margin-right:4px"></span>{label} × {cnt}</div>' for cnt,c,label in donut_segments)}
    </div>
  </div>
  <div style="background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px">
    <h3 style="margin-top:0">设计意图总纲</h3>
    <table><thead><tr><th>设计意图</th><th>当前实现/效果</th><th>可调点</th></tr></thead><tbody>
      <tr><td>不死局与持续爽感</td><td>算法族出题 + 质检 + 棋盘兜底</td><td>生成参数/质检阈值</td></tr>
      <tr><td>广告核心变现</td><td>激励/插屏/Banner/瀑布/频控</td><td>广告位/时机/豁免</td></tr>
      <tr><td>线上可运营</td><td>远程配置/AB/Trait 开关</td><td>分组/参数/开关</td></tr>
      <tr><td>美术皮肤化</td><td>皮肤 = 贴图+UI+特效+字体+音效</td><td>皮肤定价/命名/分层</td></tr>
      <tr><td>低端机可降级</td><td>按机型裁剪特效与资源</td><td>降级档位/保留项</td></tr>
    </tbody></table>
  </div>
</div>
<h3>设计脑图</h3>
{mind_svg}
<h3>核心流程图</h3>
<h4>玩法循环</h4>
{flow_gameplay}
<h4>广告展示流程</h4>
{flow_ad}
<h4>美术分层</h4>
{flow_art}
<h4>AB / 远程配置流程</h4>
{flow_ab}
'''

def extract_headings(text, limit=12):
    heads = []
    for line in text.splitlines():
        s = line.strip()
        if s.startswith('## '):
            heads.append(s.lstrip('#').strip())
        elif s.startswith('### '):
            heads.append('· ' + s.lstrip('#').strip())
        if len(heads) >= limit:
            break
    return heads

chapter_parts = [chapter0]
for idx, d in enumerate(docs):
    heads = extract_headings(d['text'])
    chips = ''.join(
        f'<button class="chip-btn" onclick="jumpTo({idx}, {n})">🔗 {html_mod.escape(h)}</button>'
        for n, h in enumerate(heads)
    )
    md_uri = d['path'].resolve().as_uri() if 'path' in d else ''
    chapter_parts.append(f'''
<div class="doc-head"><span class="doc-index">📄</span><h3>{html_mod.escape(d['h1'])}</h3><span class="doc-file">{html_mod.escape(d['name'])}</span></div>
<div class="fig-box"><h4>本章配图</h4>{chapter_figs[idx]}</div>
<div class="quick-grid">
  <div class="stat mini"><b>{d['chars']:,}</b><span>字</span></div>
  <div class="stat mini"><b>{d['tables']}</b><span>表格</span></div>
  <div class="stat mini"><b>{len(heads)}</b><span>主题</span></div>
  <div class="stat mini"><a href="{md_uri}" target="_blank"><b>MD</b><span>打开原文</span></a></div>
</div>
<div class="key-chips"><span class="chip-label">本章要点（点击跳转）</span>{chips}</div>
<details class="full-text" id="full-{idx}">
  <summary>📖 展开阅读完整分析（{d['chars']:,} 字 · {d['tables']} 表）</summary>
  <div class="doc-body">{d['html']}</div>
</details>
''')

# Appendix chapter with all raw docs in details
raw_appendix = '<h2>原始逆向 MD 附录</h2><p>以下为 Block Blast / BlockMaster 逆向项目产生的原始 MD 文档，保留完整证据链，方便对照设计意图版。</p>'
for i, d in enumerate(raw_docs):
    raw_appendix += f'''
<details class="raw-doc">
  <summary><b>#{i+1}</b> {html_mod.escape(d['name'])} <span style="color:var(--dim)">（{d['html'].count("<table>")} 张表）</span></summary>
  <div class="raw-body">{d['html']}</div>
</details>
'''
chapter_parts.append(raw_appendix)

# Nav sidebar
nav_items = ''.join(
    f'<a href="#chapter-{i}" onclick="showChapter({i})">{i+1}. {html_mod.escape(c["title"])}</a>'
    for i, c in enumerate(chapters)
)

# Chapter sections
chapter_sections = ''.join(
    f'<section class="chapter" id="chapter-{i}"><div class="chapter-title"><h2>{html_mod.escape(c["title"])}</h2><div class="chapter-sub">{html_mod.escape(c["sub"])}</div></div>{content}</section>'
    for i, (c, content) in enumerate(zip(chapters, chapter_parts))
)

# Prev/next navigation
prev_next = '''
<div class="pager">
  <button id="prevBtn" onclick="step(-1)">← 上一章</button>
  <span id="pageInfo"></span>
  <button id="nextBtn" onclick="step(1)">下一章 →</button>
</div>
'''

page = f'''<!doctype html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Block Blast 逆向拆解 · 设计意图全量总览</title>
<style>
:root {{ --bg:#0f1115; --panel:#1a1d24; --panel2:#232733; --line:#333845; --txt:#e8eaf0; --dim:#9aa1b0; --acc:#4cc2ff; --ok:#4cd97b; --warn:#ffb454; --err:#ff6b6b; }}
* {{ box-sizing:border-box; margin:0; padding:0; }}
html, body {{ height:100%; }}
body {{ background:var(--bg); color:var(--txt); font-family:"Microsoft YaHei","PingFang SC",system-ui,sans-serif; line-height:1.8; overflow:hidden; }}
p {{ line-height:1.8; margin:0.6em 0; }}
li {{ line-height:1.7; margin:0.28em 0; }}
h2, h3, h4 {{ line-height:1.5; }}
table th, table td {{ line-height:1.6; padding:8px 10px; }}
header {{ padding:20px 28px; background:linear-gradient(135deg,#141824,#1d2330); border-bottom:1px solid var(--line); height:76px; flex:0 0 auto; }}
h1 {{ font-size:22px; margin-bottom:4px; }}
.sub {{ color:var(--dim); font-size:12px; }}
.wrap {{ display:flex; height:calc(100vh - 76px); overflow:hidden; }}
nav {{ width:260px; flex:0 0 260px; background:var(--panel); border-right:1px solid var(--line); padding:14px 10px; height:100%; overflow-y:auto; }}
nav a {{ display:block; padding:8px 10px; color:var(--dim); text-decoration:none; border-radius:6px; margin-bottom:3px; font-size:12px; line-height:1.3; }}
nav a:hover, nav a.active {{ background:var(--panel2); color:#fff; }}
main {{ flex:1; min-width:0; min-height:0; padding:24px 28px 80px; height:100%; overflow-y:auto; }}
.chapter {{ display:none; }}
.chapter.active {{ display:block; }}
.chapter-title {{ margin-bottom:18px; border-bottom:1px solid var(--line); padding-bottom:10px; }}
.chapter-title h2 {{ font-size:22px; }}
.chapter-sub {{ color:var(--dim); font-size:13px; margin-top:4px; }}
.grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:12px; margin-bottom:18px; }}
.stat {{ background:var(--panel); border:1px solid var(--line); border-radius:10px; padding:14px 16px; }}
.stat b {{ font-size:22px; color:var(--acc); display:block; }}
.hl-row {{ display:flex; gap:10px; flex-wrap:wrap; margin:14px 0; }}
.hl {{ background:var(--panel2); border:1px solid var(--line); border-radius:8px; padding:8px 12px; font-size:13px; color:var(--dim); text-decoration:none; }}
a.hl {{ color:var(--acc); }}
.doc-head {{ border-bottom:1px solid var(--line); padding-bottom:8px; margin-bottom:12px; display:flex; align-items:center; gap:8px; }}
.doc-index {{ color:var(--acc); font-weight:bold; }}
.doc-file {{ color:var(--dim); font-size:12px; }}
table {{ border-collapse:collapse; width:100%; margin:10px 0; }}
th,td {{ border:1px solid var(--line); padding:6px 8px; font-size:13px; vertical-align:top; }}
th {{ background:var(--panel2); color:var(--acc); }}
pre {{ background:#0b0d12; border:1px solid var(--line); border-radius:6px; padding:10px; overflow:auto; font-size:12px; }}
code {{ background:#0b0d12; padding:1px 4px; border-radius:4px; font-size:12px; }}
a {{ color:var(--acc); }}
.search-box {{ width:100%; max-width:560px; padding:10px 12px; border-radius:8px; border:1px solid var(--line); background:var(--panel2); color:var(--txt); font-size:14px; margin-bottom:12px; }}
.fig-box {{ background:var(--panel); border:1px solid var(--line); border-radius:10px; padding:12px 14px; margin:12px 0; }}
.fig-box h4 {{ margin:0 0 8px; color:var(--acc); font-size:14px; }}
.quick-grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:10px; margin:10px 0; }}
.stat.mini {{ padding:10px 12px; }}
.stat.mini b {{ font-size:18px; }}
.stat.mini span {{ display:block; color:var(--dim); font-size:11px; }}
.key-chips {{ display:flex; flex-wrap:wrap; gap:8px; align-items:center; margin:12px 0 16px; }}
.chip-label {{ color:var(--dim); font-size:13px; margin-right:4px; }}
.chip-btn {{ background:var(--panel2); border:1px solid var(--line); border-radius:20px; padding:7px 14px; font-size:13px; color:var(--acc); cursor:pointer; transition:all .15s ease; }}
.chip-btn:hover {{ background:var(--acc); color:#0b0d12; border-color:var(--acc); transform:translateY(-1px); }}
.chip {{ background:var(--panel2); border:1px solid var(--line); border-radius:20px; padding:4px 10px; font-size:12px; color:var(--acc); }}
.full-text {{ background:var(--panel2); border:1px solid var(--line); border-radius:10px; padding:14px 18px; margin-top:10px; }}
.full-text summary {{ cursor:pointer; font-size:16px; color:var(--acc); font-weight:600; padding:4px 0; }}
.full-text[open] summary {{ margin-bottom:12px; }}
.doc-body {{ border-top:1px solid var(--line); padding-top:16px; }}
.doc-body p {{ font-size:15px; line-height:2; margin:0.9em 0; }}
.doc-body h2 {{ font-size:22px; color:var(--acc); margin:1.6em 0 0.6em; scroll-margin-top:90px; }}
.doc-body h3 {{ font-size:18px; color:#fff; margin:1.4em 0 0.5em; scroll-margin-top:90px; }}
.doc-body li {{ font-size:14.5px; line-height:1.9; margin:0.45em 0; }}
.doc-body table {{ font-size:14px; }}
.doc-body td, .doc-body th {{ padding:9px 12px; }}
.stat b {{ font-size:26px; }}
.doc-head h3 {{ font-size:20px; }}
.bar-row {{ display:flex; align-items:center; gap:10px; margin:4px 0; }}
.bar-label {{ width:220px; font-size:12px; color:var(--dim); text-overflow:ellipsis; overflow:hidden; white-space:nowrap; }}
.bar-track {{ flex:1; background:var(--panel2); border-radius:5px; height:14px; overflow:hidden; }}
.bar-fill {{ background:linear-gradient(90deg,#4cc2ff,#7a5cff); height:100%; border-radius:5px; }}
.bar-val {{ width:70px; text-align:right; font-size:12px; color:var(--dim); }}
.art-table {{ width:100%; }}
.pager {{ position:fixed; bottom:0; left:260px; right:0; background:rgba(20,24,32,.96); border-top:1px solid var(--line); padding:12px 28px; display:flex; align-items:center; justify-content:space-between; gap:12px; z-index:20; }}
.pager button {{ padding:8px 18px; border-radius:8px; border:1px solid var(--acc); background:transparent; color:var(--acc); cursor:pointer; font-size:14px; }}
.pager button:hover {{ background:var(--panel2); }}
.raw-doc {{ background:var(--panel2); border:1px solid var(--line); border-radius:8px; margin:8px 0; padding:8px 12px; }}
.raw-doc summary {{ cursor:pointer; font-size:14px; padding:4px 0; }}
.raw-body {{ border-top:1px solid var(--line); margin-top:8px; padding-top:10px; }}
h4 {{ margin:14px 0 6px; color:var(--acc); }}
</style>
</head>
<body>
<header>
  <h1>🧱 Block Blast 逆向拆解 · 设计意图全量总览</h1>
  <div class="sub">共 {len(chapters)} 章 · {len(docs)} 份规范文档 · {len(raw_docs)} 份原始 MD 附录 · 美术素材：E:\\参考图\\block录屏\\解包素材</div>
</header>
<div class="wrap">
<nav>{nav_items}</nav>
<main>
{chapter_sections}
{prev_next}
</main>
</div>
<script>
let current = 0;
const total = {len(chapters)};
function showChapter(i) {{
  if (i < 0 || i >= total) return;
  current = i;
  document.querySelectorAll('.chapter').forEach(s => s.classList.remove('active'));
  document.getElementById('chapter-' + i).classList.add('active');
  document.querySelectorAll('nav a').forEach((a, idx) => a.classList.toggle('active', idx === i));
  document.getElementById('pageInfo').textContent = '第 ' + (i+1) + ' / ' + total + ' 章';
  document.getElementById('prevBtn').disabled = i === 0;
  document.getElementById('nextBtn').disabled = i === total - 1;
  const main = document.querySelector('main');
  if (main) main.scrollTop = 0;
}}
function step(d) {{ showChapter(current + d); }}
function jumpTo(docIdx, hIdx) {{
  const det = document.getElementById('full-' + docIdx);
  const el = document.getElementById('doc-' + docIdx + '-h' + hIdx);
  if (!el) return;
  const wasClosed = det && !det.open;
  if (wasClosed) det.open = true;
  const go = () => {{
    const main = document.querySelector('main');
    try {{ el.scrollIntoView({{behavior:'auto', block:'start'}}); }}
    catch(_) {{ el.scrollIntoView(); }}
    if (main) {{
      const top = el.getBoundingClientRect().top + main.scrollTop - 80;
      if (top > 0) main.scrollTop = top;
    }}
  }};
  if (wasClosed) requestAnimationFrame(() => setTimeout(go, 120));
  else go();
}}
function filterDocs() {{
  const q = document.getElementById('docSearch').value.toLowerCase();
  document.querySelectorAll('.doc-full').forEach((el) => {{
    const t = (el.textContent || '').toLowerCase();
    el.style.display = t.includes(q) ? '' : 'none';
  }});
}}
showChapter(0);
</script>
</body>
</html>
'''
OUT.write_text(page, encoding='utf-8')
print('wrote', OUT, 'size', len(page))
print('chapters', len(chapters), 'docs', len(docs), 'raw', len(raw_docs), 'tables', total_tables, 'art', len(art_links))
