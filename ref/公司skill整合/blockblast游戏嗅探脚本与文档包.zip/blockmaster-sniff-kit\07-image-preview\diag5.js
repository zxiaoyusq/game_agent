﻿'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810';
const NAMED = path.join(ROOT, 'named');
const SPINE_LIB = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/blast-block-spine/lib/spine-player.js';
const spineSrc = fs.readFileSync(SPINE_LIB, 'utf8');
const sandbox = {
  console, setTimeout, clearTimeout, setInterval, clearInterval,
  window: {}, document: {}, navigator: { userAgent: 'node' },
  atob: (b64) => Buffer.from(b64, 'base64').toString('latin1'),
  btoa: (s) => Buffer.from(s, 'latin1').toString('base64'),
  TextEncoder, TextDecoder,
  ArrayBuffer, DataView, Uint8Array, Uint16Array, Uint32Array,
  Int8Array, Int16Array, Int32Array, Float32Array, Float64Array,
  Math, JSON, Object, Array, Date, String, Number, Boolean,
  Error, TypeError, RangeError, Map, Set, parseFloat, parseInt, isNaN, isFinite,
};
vm.createContext(sandbox);
vm.runInContext(spineSrc, sandbox, { filename: 'spine-player.js' });

// find the atlas/bin for revive_countdown_017 in bundle 3017
let binPath = null, atlasPath = null;
(function walk(d) {
  for (const de of fs.readdirSync(d, { withFileTypes: true })) {
    const p = path.join(d, de.name);
    if (de.isDirectory()) walk(p);
    else if (de.name === 'revive_countdown_017.bin') binPath = p;
    else if (de.name === 'revive_countdown_017.atlas') atlasPath = p;
  }
})(path.join(NAMED, 'Remote_Skin_Material_3017'));
sandbox.atlasText = fs.readFileSync(atlasPath, 'utf8');
sandbox.binB64 = fs.readFileSync(binPath).toString('base64');

const sim = `
(function(){
  function b64ToU8(b64){ var bin=atob(b64); var u=new Uint8Array(bin.length);
    for(var i=0;i<bin.length;i++) u[i]=bin.charCodeAt(i); return u; }
  function byteMap(s){
    var bytes = new TextEncoder().encode(s);
    var out = '';
    for (var i=0;i<bytes.length;i++) { var b = bytes[i]; out += b < 0x80 ? String.fromCharCode(b) : String.fromCharCode(0xFF00 + b); }
    return out;
  }
  function cp(s){ var a=[]; for (var i=0;i<s.length;i++) a.push(s.charCodeAt(i).toString(16)); return a.join(','); }
  var out = {};
  var atlas = new spine.TextureAtlas(atlasText, function(p){ return { setFilters:function(){}, setWraps:function(){}, getImage:function(){ return {width:2048,height:2048}; }, dispose:function(){} }; });
  out.regions = atlas.regions.map(function(r){ return r.name; });
  var aliasNames = [];
  var originals = atlas.regions.slice();
  for (var i=0;i<originals.length;i++){
    var r = originals[i];
    var alt = byteMap(r.name);
    if (alt !== r.name && !atlas.findRegion(alt)){
      var a = new spine.TextureAtlasRegion();
      a.name = alt; a.page = r.page; a.degrees = r.degrees; a.rotate = r.rotate;
      a.u = r.u; a.v = r.v; a.u2 = r.u2; a.v2 = r.v2;
      a.x = r.x; a.y = r.y; a.width = r.width; a.height = r.height;
      a.originalWidth = r.originalWidth; a.originalHeight = r.originalHeight;
      a.offsetX = r.offsetX; a.offsetY = r.offsetY; a.index = r.index; a.texture = r.texture;
      atlas.regions.push(a);
      aliasNames.push(alt);
    }
  }
  out.aliasNames = aliasNames;
  // request the region name that the skeleton uses
  var requested = [];
  var loader = {
    newRegionAttachment: function(skin,name,p){ requested.push(p); var a=new spine.RegionAttachment(p||name); a.region={u:0,v:0,u2:1,v2:1,originalWidth:1,originalHeight:1,offsetX:0,offsetY:0,width:1,height:1,rotate:false}; return a; },
    newMeshAttachment: function(skin,name,p){ requested.push(p); var a=new spine.MeshAttachment(p||name); a.region={u:0,v:0,u2:1,v2:1,originalWidth:1,originalHeight:1,offsetX:0,offsetY:0,width:1,height:1,rotate:false}; return a; },
    newBoundingBoxAttachment: function(skin,name){ return new spine.BoundingBoxAttachment(name); },
    newClippingAttachment: function(skin,name){ return new spine.ClippingAttachment(name); },
    newPathAttachment: function(skin,name){ return new spine.PathAttachment(name); },
    newPointAttachment: function(skin,name){ return new spine.PointAttachment(name); }
  };
  new spine.SkeletonBinary(loader).readSkeletonData(b64ToU8(binB64));
  out.requested = requested;
  out.cpRequested = requested.map(cp);
  out.cpAliases = aliasNames.map(cp);
  out.findResults = requested.map(function(n){ return atlas.findRegion(n) != null; });
  return out;
})();
`;
const out = vm.runInContext(sim, sandbox);
console.log('regions:', JSON.stringify(out.regions));
console.log('aliases:', JSON.stringify(out.aliasNames));
console.log('cp aliases:', JSON.stringify(out.cpAliases));
console.log('requested:', JSON.stringify(out.requested));
console.log('cp requested:', JSON.stringify(out.cpRequested));
console.log('findResults:', JSON.stringify(out.findResults));
