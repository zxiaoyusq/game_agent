# -*- coding: utf-8 -*-
"""Generate self-contained spine preview page + raw group exports + comparison md."""
import base64
import io
import json
import os
import re
import shutil
import sys

REF_DIR = os.environ['REF_DIR']          # their blast-block-spine folder
PROJECT = r'E:\codex_apk_work\blockblast_project'
WORK = r'E:\codex_apk_work'
OUT = os.path.join(WORK, 'spine_preview')

usage = json.load(open(os.path.join(WORK, 'spine_usage_index.json'), encoding='utf-8'))
verify = json.load(open(os.path.join(WORK, 'spine_verify_report.json'), encoding='utf-8'))
theirs = json.load(open(os.path.join(REF_DIR, 'index.json'), encoding='utf-8'))['items']

dead = {}
for atlas, names in verify.get('dead_attachments', []):
    dead[atlas.replace('\\', '/')] = names
cross = {}
for atlas, names in verify.get('multi_atlas', []):
    cross[atlas.replace('\\', '/')] = names


def stem_of(rel):
    return rel.replace('\\', '/').split('/')[-1].replace('.atlas', '')


def bundle_of(rel):
    rel = rel.replace('\\', '/')
    parts = rel.split('/')
    if parts[0] == 'assets':
        parts = parts[1:]
    return parts[0]


def png_of(rel):
    return rel.replace('\\', '/')[:-6] + '.png'


os.makedirs(os.path.join(OUT, 'lib'), exist_ok=True)
for f in ('spine-player.js', 'spine-canvas.js'):
    shutil.copy2(os.path.join(REF_DIR, 'lib', f), os.path.join(OUT, 'lib', f))

DATA = []
total_anims = 0
total_missing = 0

for u in usage:
    rel = u['rel'].replace('\\', '/')
    stem = stem_of(rel)
    bundle = bundle_of(rel)
    gdir = '{0}_{1}'.format(bundle, stem)
    group_out = os.path.join(OUT, gdir)
    os.makedirs(group_out, exist_ok=True)

    skel_path = os.path.join(PROJECT, rel[:-6] + '.json')
    png_path = os.path.join(PROJECT, png_of(rel))
    doc = json.load(open(skel_path, encoding='utf-8'))
    item = doc[0]
    raw_skel = item['_skeletonJson']
    atlas_text = item['_atlasText'].strip()

    # write raw three-piece export
    raw_json_str = json.dumps(raw_skel, ensure_ascii=False, separators=(',', ':'))
    with open(os.path.join(group_out, stem + '.json'), 'w', encoding='utf-8') as f:
        f.write(raw_json_str)
    with open(os.path.join(group_out, stem + '.atlas'), 'w', encoding='utf-8') as f:
        f.write(atlas_text)
    png_bytes = open(png_path, 'rb').read()
    with open(os.path.join(group_out, stem + '.png'), 'wb') as f:
        f.write(png_bytes)

    # embedded data URLs (single-page atlases confirmed for all 56)
    png_b64 = base64.b64encode(png_bytes).decode('ascii')
    lines = atlas_text.split('\n')
    lines[0] = 'data:image/png;base64,' + png_b64
    atlas_embedded = '\n'.join(lines)

    # Spine 4.x player only understands array-format skins; Cocos 3.6 exports
    # skins as a dict. Convert for the embedded preview JSON so skins and
    # attachments actually render. The raw export above stays untouched.
    preview_skel = dict(raw_skel)
    sk = raw_skel.get('skins')
    if isinstance(sk, dict):
        arr = []
        for name, body in sk.items():
            entry = {'name': name}
            if isinstance(body, dict):
                atts, bones, cons = {}, None, None
                for k, v in body.items():
                    if k == 'bones' and isinstance(v, list):
                        bones = v
                    elif k == 'constraints' and isinstance(v, list):
                        cons = v
                    else:
                        atts[k] = v
                entry['attachments'] = atts
                if bones:
                    entry['bones'] = bones
                if cons:
                    entry['constraints'] = cons
            else:
                entry['attachments'] = {}
            arr.append(entry)
        preview_skel['skins'] = arr
    preview_json_str = json.dumps(preview_skel, ensure_ascii=False,
                                  separators=(',', ':'))

    jsonUrl = 'data:application/json;base64,' + base64.b64encode(
        preview_json_str.encode('utf-8')).decode('ascii')
    atlasUrl = 'data:text/plain;base64,' + base64.b64encode(
        atlas_embedded.encode('utf-8')).decode('ascii')

    anims = list(u['anims'])
    skel_anims = list((raw_skel.get('animations') or {}).keys())
    if set(anims) != set(skel_anims):
        print('ANIM MISMATCH', gdir, set(anims) ^ set(skel_anims))
        anims = skel_anims
    raw_skins = raw_skel.get('skins') or []
    if isinstance(raw_skins, dict):
        skins = list(raw_skins.keys())
    else:
        skins = [s['name'] for s in raw_skins]
    missing = dead.get(os.path.join(PROJECT, rel).replace('\\', '/'), [])
    cross_list = cross.get(os.path.join(PROJECT, rel).replace('\\', '/'), [])

    total_anims += len(anims)
    total_missing += len(missing)

    DATA.append({
        'name': stem,
        'bundle': bundle,
        'dir': gdir,
        'skeleton': stem + '.json',
        'atlas': stem + '.atlas',
        'png': stem + '.png',
        'jsonUrl': jsonUrl,
        'atlasUrl': atlasUrl,
        'anims': anims,
        'skins': skins,
        'bounds': None,
        'missing': missing,
        'missing_n': len(missing),
        'cross': cross_list,
        'atlas_err': None,
    })

print('groups:', len(DATA), 'total anims:', total_anims, 'missing:', total_missing)

# ---------------------------------------------------------------------------
# preview.html
# ---------------------------------------------------------------------------
HTML_TEMPLATE = r'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Blast Block! · Spine 动效预览器（56 组 · 本机拆包）</title>
<style>
  :root{--bg:#15171c;--panel:#1e2128;--panel2:#262a33;--line:#333845;
    --txt:#e8eaf0;--dim:#9aa1b0;--acc:#4cc2ff;--warn:#ffb454;--err:#ff6b6b;}
  *{box-sizing:border-box;margin:0;padding:0}
  html,body{height:100%}
  body{background:var(--bg);color:var(--txt);font-family:"Microsoft YaHei","PingFang SC",system-ui,sans-serif;
    display:flex;flex-direction:column;overflow:hidden}
  header{height:48px;display:flex;align-items:center;gap:14px;padding:0 16px;background:var(--panel);
    border-bottom:1px solid var(--line);flex:0 0 auto}
  header h1{font-size:15px;font-weight:600}
  header .sub{color:var(--dim);font-size:12px}
  main{flex:1;display:flex;min-height:0}
  aside{width:340px;flex:0 0 auto;background:var(--panel);border-right:1px solid var(--line);
    display:flex;flex-direction:column;min-height:0}
  #search{margin:10px;padding:8px 10px;border:1px solid var(--line);border-radius:6px;
    background:var(--panel2);color:var(--txt);font-size:13px;outline:none}
  #search:focus{border-color:var(--acc)}
  #listWrap{flex:1;overflow:auto;padding:0 6px 12px}
  .row{display:flex;align-items:center;gap:8px;padding:7px 8px;border-radius:6px;cursor:pointer;
    font-size:13px;border:1px solid transparent}
  .row:hover{background:var(--panel2)}
  .row.active{background:#2c3648;border-color:var(--acc)}
  .row .nm{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .row .cnt{color:var(--dim);font-size:11px;background:#2a2e38;border-radius:9px;padding:1px 7px;flex:0 0 auto}
  .row.warn .nm::after{content:"缺"attr(data-miss);color:var(--warn);font-weight:700;margin-left:6px;font-size:11px}
  section{flex:1;display:flex;flex-direction:column;min-width:0;min-height:0}
  #toolbar{flex:0 0 auto;display:flex;flex-wrap:wrap;align-items:center;gap:10px;padding:10px 14px;
    background:var(--panel);border-bottom:1px solid var(--line);font-size:13px}
  #toolbar .sp{width:1px;height:22px;background:var(--line)}
  #toolbar select,#toolbar button{background:var(--panel2);color:var(--txt);border:1px solid var(--line);
    border-radius:6px;padding:5px 10px;font-size:12px;cursor:pointer}
  #toolbar button:hover{border-color:var(--acc)}
  #toolbar label{display:flex;align-items:center;gap:5px;color:var(--dim);font-size:12px;cursor:pointer}
  #curInfo{color:var(--dim);font-size:12px;min-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  #stage{flex:1;position:relative;min-height:0;overflow:hidden;background:#17191f}
  #stage .spine-player{position:absolute;inset:0}
  #stage .spine-player canvas{width:100%;height:100%}
  #status{flex:0 0 auto;height:26px;display:flex;align-items:center;gap:14px;padding:0 14px;
    background:var(--panel);border-top:1px solid var(--line);color:var(--dim);font-size:12px}
  #status b{color:var(--txt);font-weight:600}
  @media (max-width:900px){ aside{width:260px} }
</style>
</head>
<body>
<header>
  <h1>Blast Block! · Spine 动效预览器</h1>
  <span class="sub" id="hdStats"></span>
</header>
<main>
  <aside>
    <input id="search" placeholder="搜索骨架名称…">
    <div id="listWrap"></div>
  </aside>
  <section>
    <div id="toolbar">
      <span id="curInfo">请选择左侧骨架</span>
      <span class="sp"></span>
      <button id="prev">‹ 上一个</button>
      <button id="next">下一个 ›</button>
      <span class="sp"></span>
      <label><input type="checkbox" id="loop" checked> 循环</label>
      <label><input type="checkbox" id="bgGrid"> 棋盘格背景</label>
      <label><input type="checkbox" id="showBones"> 骨骼线</label>
    </div>
    <div id="stage"></div>
    <div id="status"><span>组 <b id="pos">0/0</b></span><span>动画 <b id="animInfo">-</b></span>
      <span>缺帧 <b id="missInfo">-</b></span><span id="errInfo"></span></div>
  </section>
</main>
<script src="lib/spine-player.js"></script>
<script>
const DATA = __DATA_JSON__;
let cur = -1;
let player = null;

function el(tag, cls, txt){const e=document.createElement(tag);if(cls)e.className=cls;if(txt!=null)e.textContent=txt;return e;}

function renderList(){
  const q=document.getElementById('search').value.trim().toLowerCase();
  const wrap=document.getElementById('listWrap');
  wrap.innerHTML='';
  DATA.forEach((it,i)=>{
    const nm=(it.name+'  ['+it.bundle+']').toLowerCase();
    if(q && !nm.includes(q)) return;
    const row=el('div','row'+(i===cur?' active':'')+(it.missing_n?' warn':''));
    row.dataset.miss=it.missing_n;
    const nmEl=el('span','nm',it.name);
    nmEl.title=(it.missing_n?('缺帧: '+it.missing.join('、')):'');
    row.appendChild(nmEl);
    const cnt=el('span','cnt',it.anims.length+'动');
    row.appendChild(cnt);
    row.onclick=()=>load(i);
    wrap.appendChild(row);
  });
}

function fit(it){
  const stage=document.getElementById('stage');
  stage.innerHTML='';
  const cfg={
    jsonUrl: it.jsonUrl,
    atlasUrl: it.atlasUrl,
    animation: new URLSearchParams(location.search).get('anim') || it.anims[0] || null,
    skin: new URLSearchParams(location.search).get('skin') || it.skins[0] || null,
    alpha: true,
    premultipliedAlpha: false,
    backgroundColor: '#00000000',
    viewport: { transitionTime: 0.2 },
    showControls: true,
    success: function(widget){
      widget.animationState.timeScale=1;
      if(document.getElementById('loop').checked){
        const a=widget.animationState.getCurrent(0);
        if(a) a.loop=true;
      }
    },
    error: function(widget,msg){
      document.getElementById('errInfo').textContent='加载失败: '+msg;
    }
  };
  try{
    player=new spine.SpinePlayer(stage, cfg);
    document.getElementById('errInfo').textContent='';
  }catch(e){
    document.getElementById('errInfo').textContent='初始化失败: '+e;
  }
}

function load(i){
  if(i<0||i>=DATA.length) return;
  cur=i;
  const it=DATA[i];
  document.getElementById('curInfo').textContent=it.name+'  ['+it.bundle+']';
  document.getElementById('pos').textContent=(i+1)+'/'+DATA.length;
  document.getElementById('animInfo').textContent=(it.anims.length?it.anims.length+' 个':'无')+
    (it.skins.length?' · '+it.skins.length+' 皮肤':'');
  document.getElementById('missInfo').textContent=it.missing_n?it.missing_n+' 个引用缺失':'0';
  fit(it);
  renderList();
}

document.getElementById('search').addEventListener('input', renderList);
document.getElementById('prev').onclick=()=>load((cur-1+DATA.length)%DATA.length);
document.getElementById('next').onclick=()=>load((cur+1)%DATA.length);
document.getElementById('bgGrid').addEventListener('change',e=>{
  document.getElementById('stage').style.background=
    e.target.checked?'conic-gradient(#2a2e38 25%,#22252d 0 50%,#2a2e38 0 75%,#22252d 0)':'#17191f';
  document.getElementById('stage').style.backgroundSize=e.target.checked?'20px 20px':'';
});
document.getElementById('showBones').addEventListener('change',e=>{
  if(player&&player.config) player.config.debug.bones=e.target.checked;
});
document.addEventListener('keydown',e=>{
  if(e.key==='ArrowRight') load((cur+1)%DATA.length);
  if(e.key==='ArrowLeft') load((cur-1+DATA.length)%DATA.length);
});

document.getElementById('hdStats').textContent=DATA.length+' 组 Spine · '+
  DATA.reduce((s,it)=>s+it.anims.length,0)+' 个动画 · '+
  DATA.reduce((s,it)=>s+it.missing_n,0)+' 个缺失帧引用';
renderList();
const gParam=new URLSearchParams(location.search).get('g');
load(gParam!==null&&gParam!==''?parseInt(gParam,10):0);
</script>
</body>
</html>
'''

html = HTML_TEMPLATE.replace('__DATA_JSON__', json.dumps(DATA, ensure_ascii=False, separators=(',', ':')))
with open(os.path.join(OUT, 'preview.html'), 'w', encoding='utf-8') as f:
    f.write(html)
print('preview.html written:', os.path.getsize(os.path.join(OUT, 'preview.html')))

# ---------------------------------------------------------------------------
# comparison md
# ---------------------------------------------------------------------------
m_pairs = {}
for u in usage:
    key = (bundle_of(u['rel']), stem_of(u['rel']))
    m_pairs.setdefault(key, []).append(set(u['anims']))
t_pairs = {}
for it in theirs:
    key = (it['bundle'], it['name'])
    t_pairs.setdefault(key, []).append(set(it['anims']))

m_keys = set(m_pairs)
t_keys = set(t_pairs)
matched = sorted(m_keys & t_keys)
only_t = sorted(t_keys - m_keys)

lines = []
lines.append('# Block Blast Spine 拆包结果对比（本机 56 组 vs 另一台电脑 92 组）')
lines.append('')
lines.append('## 结论')
lines.append('')
lines.append('- 本机拆出的 **56 组**（bundle+名称维度）**全部**能在对方 92 组中找到同名同 bundle 对应，且**动画列表完全一致**（0 组差异）。')
lines.append('- 对方独有 **36 组**（31 个唯一名称，其中 `lizi` 在两个 bundle 各一份）。')
lines.append('- 本机独有：**0 组**。')
lines.append('- 说明：两边的重复是“同名资源”，无法跨机器做 uuid 级比对；结合动画列表完全一致，可判定为同一批 Spine 骨架的不同版本 APK（或同一版本）导出。对方来源为雷电 14 模拟器，本机为雷电 9。')
lines.append('')
lines.append('## 一、两边重复的 56 组（本机全部，动画一致）')
lines.append('')
lines.append('| # | 骨架名 | 本机 bundle | 对方 bundle | 动画数 | 备注 |')
lines.append('| --- | --- | --- | --- | --- | --- |')
name_counter = {}
for i, key in enumerate(matched, 1):
    mb, mn = key
    name_counter.setdefault(mn, 0)
    name_counter[mn] += 1
    ta = t_pairs[key][0]
    note = ''
    if name_counter[mn] > 1:
        note = '同名第 {0} 份'.format(name_counter[mn])
    lines.append('| {0} | `{1}` | {2} | {3} | {4} | {5} |'.format(
        i, mn, mb, mb if key in t_keys else '-', len(ta), note))
lines.append('')
lines.append('## 二、对方独有、本机没有的 36 组')
lines.append('')
lines.append('| # | 骨架名 | 对方 bundle | 动画数 | 动画列表 |')
lines.append('| --- | --- | --- | --- | --- |')
for i, key in enumerate(only_t, 1):
    tb, tn = key
    ta = sorted(t_pairs[key][0])
    shown = '、'.join(ta[:10]) + (' …' if len(ta) > 10 else '')
    lines.append('| {0} | `{1}` | {2} | {3} | {4} |'.format(i, tn, tb, len(ta), shown))
lines.append('')
lines.append('## 三、同名多份注意（两边同名但 bundle 不同）')
lines.append('')
lines.append('| 名称 | 本机（bundle） | 对方（bundle） |')
lines.append('| --- | --- | --- |')
lines.append('| `gameplay_xinshou` | NewUserEarlyRoundsBoardTrait、ReplaceGuideSchemeTrait、UEExploreBeginnerDragTargetHighlightTrait（3 份） | 上述 3 份 + NewUserBoardDiffTrait（4 份） |')
lines.append('| `lihua` | gl_hall、gl_onet（2 份） | gl_hall、gl_onet（2 份） |')
lines.append('| `skeleton` | gl_watersort（1 份） | gl_onet、gl_sudoku、gl_watersort（3 份） |')
lines.append('| `finger` | gl_watersort（1 份） | gl_oneline、gl_watersort（2 份） |')
lines.append('| `lizi` | 无 | gl_oneline、gl_watersort（2 份） |')
lines.append('| `Fruit_0x` | 02/04/06/07/08（5 份） | 01~12（12 份） |')
lines.append('| `main_mosaic(_eff)` | main_mosaic_eff（1 份） | main_mosaic、main_mosaic_eff（2 份） |')
lines.append('| `minimalist_sandCrush_gameplay_progressBar_efx` | 无 | sand_mini（1 份） |')
lines.append('')
lines.append('## 四、可进一步核对的差异点')
lines.append('')
lines.append('- 对方多了水果全套皮肤 `Fruit_01/03/05/09~12` 与 `WatermelonPanel`、`shouzhi`、`miaozhun`、`HsFruitMerge_Click_fx_01_B`、`MergeNew_fx_B`、`hcdxg_gameplat_yld`，说明对方 APK 版本的水果合成皮肤/特效更全，或本机提取范围未覆盖 `resources`/部分远程 bundle。')
lines.append('- 对方多出 `resources` bundle 的 `gameplay_spine_blocklight_plan1`、`sandCrush_main_btn_light`，本机工程中对应资源位于 `assets/resources/dragonbones/` 等目录，可能被归类为 DragonBones/普通图集而未计入 56 组 Spine。')
lines.append('- 对方多出 `gl_onet_skeleton`（17 动画）、`gl_sudoku_skeleton`（10 动画）等以 `skeleton` 为名的整包骨架，本机未列入 56 组（本机对应 bundle 中只有 `gl_watersort/skeleton`）。')
lines.append('- 需要时可以从本机 APK 解包目录再按对方 92 组清单补导出缺失 36 组。')
lines.append('')

with open(os.path.join(WORK, 'spine对比清单.md'), 'w', encoding='utf-8') as f:
    f.write('\n'.join(lines))
print('comparison md written')
