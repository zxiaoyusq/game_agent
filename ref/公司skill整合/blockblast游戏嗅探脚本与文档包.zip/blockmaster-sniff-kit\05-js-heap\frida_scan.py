import frida

JS = r"""
'use strict';
function scanPattern(pat) {
    var results = [];
    var ranges = Process.enumerateRanges('r--');
    var done = 0;
    ranges.forEach(function (range) {
        try {
            var matches = Memory.scanSync(range.base, range.size, pat);
            matches.forEach(function (m) {
                results.push({addr: m.address.toString(), size: m.size, base: range.base.toString(), len: range.size});
            });
        } catch (e) { }
        done++;
    });
    return {kind: 'done', total: done, hits: results};
}
rpc.exports = { scan: scanPattern };
"""

PATTERNS = {
    "cocos2d-jsb.04bc6": "63 6f 63 6f 73 32 64 2d 6a 73 62 2e 30 34 62 63 36",
    "4c2ce": "34 63 32 63 65",
    "System.register": "53 79 73 74 65 6d 2e 72 65 67 69 73 74 65 72",
    "65485d8a": "36 35 34 38 35 64 38 61",
    "window.cc": "77 69 6e 64 6f 77 2e 63 63",
    "HEK": "48 45 4b",
    "libcocos2djs": "6c 69 62 63 6f 63 6f 73 32 64 6a 73",
    "com.block.juggle": "63 6f 6d 2e 62 6c 6f 63 6b 2e 6a 75 67 67 6c 65",
}

import sys
PID = int(sys.argv[1]) if len(sys.argv) > 1 else 3781

dev = frida.get_device_manager().add_remote_device('127.0.0.1:27042')
session = dev.attach(PID)
script = session.create_script(JS)
script.load()
for name, pat in PATTERNS.items():
    out = script.exports_sync.scan(pat)
    hits = out.get('hits', [])
    print(name, "->", len(hits), "ranges:", out.get('total'))
    for h in hits[:15]:
        print("   ", h['addr'], "range", h['base'], "len", h['len'])
session.detach()
