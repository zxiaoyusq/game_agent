# -*- coding: utf-8 -*-
"""Generate a self-contained Spine preview page for remote skin bundles.

Scans <root>/named for Spine skeletons (*.bin = Spine binary 3.8.x, and
sp.SkeletonData JSON wrappers), pairs each with its .atlas + .png, embeds
everything as base64 data URLs, and writes preview.html in the same style as
blast-block-spine/preview.html.

Usage:
  python gen_remote_skin_spine_preview.py [--root <素材根>] [--out <输出目录>]
                                          [--spine-lib <含 spine-player.js 的目录>]
"""
import argparse
import base64
import json
import os
import re
import shutil

ROOT = r'E:\参考图\block录屏\解包素材\BlastBlock-美术资源全量-20260810\材质皮肤-远程bundle-20260810'
NAMED = os.path.join(ROOT, 'named')
SKINS_MD = os.path.join(ROOT, 'skins清单.md')
SPINE_LIB = r'E:\参考图\block录屏\解包素材\BlastBlock-美术资源全量-20260810\blast-block-spine\lib'
OUT = os.path.join(ROOT, 'spine-preview')

LABELS = {
    'gameplay_clear': '清屏',
    'gameplay_clear_unbelievable': '清屏·不可思议',
    'gameplay_eliminate': '消除',
    'gameplay_eliminate_green': '消除·绿',
    'gameplay_eliminate_gold': '消除·金',
    'gameplay_ready_eliminate': '就绪消除',
    'gameplay_eliminateprompt': '预消除提示',
    'gameplay_eliminatePrompt': '预消除提示',
    'gameplay_combo': '连消',
    'gameplay_combo_tips': '连消提示',
    'gameplay_comboTips': '连消提示',
    'gameplay_light_startBlock': '落块闪光',
    'gameplay_spine_blocklight_plan1': '方块灯光',
    'revive_countdown': '复活倒计时',
    'gameplay_word': '文字动效',
}
ORDER = {
    'gameplay_clear': 0, 'gameplay_clear_unbelievable': 0,
    'gameplay_eliminate': 1, 'gameplay_eliminate_green': 1,
    'gameplay_eliminate_gold': 1, 'gameplay_ready_eliminate': 1,
    'gameplay_eliminateprompt': 2, 'gameplay_eliminatePrompt': 2,
    'gameplay_combo': 3, 'gameplay_combo_tips': 3, 'gameplay_comboTips': 3,
    'gameplay_light_startBlock': 4, 'gameplay_spine_blocklight_plan1': 4,
    'revive_countdown': 5,
    'gameplay_word': 6,
}


def load_skin_names(path):
    names = {}
    if not os.path.exists(path):
        return names
    with open(path, encoding='utf-8') as f:
        for line in f:
            m = re.match(r'\|\s*(\d+)\s*\|\s*([A-Za-z0-9_-]*)\s*\|', line)
            if m and m.group(2):
                names[m.group(1)] = m.group(2)
    return names


def read_varint(data, pos):
    b = data[pos]
    pos += 1
    result = b & 0x7F
    if b & 0x80:
        b = data[pos]
        pos += 1
        result |= (b & 0x7F) << 7
        if b & 0x80:
            b = data[pos]
            pos += 1
            result |= (b & 0x7F) << 14
            if b & 0x80:
                b = data[pos]
                pos += 1
                result |= (b & 0x7F) << 21
                if b & 0x80:
                    b = data[pos]
                    pos += 1
                    result |= (b & 0x7F) << 28
    return result, pos


def read_spine_string(data, pos):
    byte_count, pos = read_varint(data, pos)
    if byte_count == 0:
        return None, pos
    if byte_count == 1:
        return '', pos
    n = byte_count - 1
    return data[pos:pos + n].decode('latin1'), pos + n


def is_spine_binary(data):
    try:
        _hash, pos = read_spine_string(data, 0)
        ver, _ = read_spine_string(data, pos)
        return bool(ver and ver.startswith('3.'))
    except Exception:
        return False


def first_image_line(atlas_text):
    for ln in atlas_text.split('\n'):
        if ln.strip():
            return ln.strip()
    return None


def embed_atlas(atlas_text, png_dir, fallback_png=None):
    """Replace every atlas page image line with a data URL of the matching PNG.

    Also normalizes mipmap filters to Linear,Linear: spine-player (3.8) never
    generates mipmap levels for these textures, so a 'MipMap,...' min filter
    leaves the texture incomplete and the GPU samples pure black. Linear is
    safe for every page (NPOT or POT) and renders correctly in WebGL1/2.
    """
    lines = atlas_text.split('\n')
    n = len(lines)
    cache = {}

    def b64_for(name):
        if name in cache:
            return cache[name]
        fp = os.path.join(png_dir, name)
        if not os.path.exists(fp) and fallback_png and \
                name == os.path.basename(fallback_png):
            fp = fallback_png
        if not os.path.exists(fp):
            print('WARN: atlas page image not found:', fp)
            cache[name] = None
            return None
        cache[name] = base64.b64encode(open(fp, 'rb').read()).decode('ascii')
        return cache[name]

    for i in range(n):
        if lines[i].strip().lower().startswith('filter:'):
            parts = lines[i].split(':', 1)
            val = parts[1].strip() if len(parts) > 1 else ''
            if val.lower().startswith('mipmap'):
                lines[i] = parts[0] + ': Linear,Linear'

    i = 0
    while i < n:
        if lines[i].strip():
            start = i
            while i < n and lines[i].strip():
                i += 1
            block = [lines[k] for k in range(start, i)]
            if len(block) >= 2 and block[1].strip().startswith('size:'):
                b64 = b64_for(block[0].strip())
                if b64:
                    lines[start] = 'data:image/png;base64,' + b64
        else:
            i += 1
    return '\n'.join(lines)


def parse_sp_wrapper(doc):
    """Extract dict item from a Cocos sp.SkeletonData deserialized list."""
    if isinstance(doc, list) and doc:
        head = doc[0]
        if isinstance(head, dict):
            return head
        if len(doc) > 3 and isinstance(doc[3], list) and doc[3] and \
                isinstance(doc[3][0], list) and len(doc[3][0]) > 1:
            props = doc[3][0][1]
            if isinstance(props, list) and len(doc) > 5 and doc[5] and \
                    isinstance(doc[5][0], list):
                vals = doc[5][0]
                if len(vals) - 1 >= len(props):
                    return dict(zip(props, vals[1:1 + len(props)]))
    return None


def friendly(stem):
    base = re.sub(r'_\d+$', '', stem)
    return LABELS.get(base, base)


def order_of(stem):
    base = re.sub(r'_\d+$', '', stem)
    return ORDER.get(base, 99)


def skin_id_of(bundle):
    m = re.search(r'_(\d+)$', bundle)
    return int(m.group(1)) if m else 10 ** 9


def collect():
    skin_names = load_skin_names(SKINS_MD)
    entries = []
    seen = set()

    for bundle in sorted(os.listdir(NAMED)):
        bpath = os.path.join(NAMED, bundle)
        if not os.path.isdir(bpath):
            continue
        for root, dirs, files in os.walk(bpath):
            rel = os.path.relpath(root, bpath).replace('\\', '/')
            if rel.split('/')[0] == 'misc':
                continue
            for f in sorted(files):
                stem = os.path.splitext(f)[0]
                key = (bundle, stem)
                if key in seen:
                    continue
                if f.endswith('.bin'):
                    fp = os.path.join(root, f)
                    data = open(fp, 'rb').read()
                    if not is_spine_binary(data):
                        continue
                    atlas_fp = os.path.join(root, stem + '.atlas')
                    png_fp = os.path.join(root, stem + '.png')
                    if not (os.path.exists(atlas_fp) and os.path.exists(png_fp)):
                        continue
                    seen.add(key)
                    entries.append({
                        'bundle': bundle, 'stem': stem,
                        'fmt': 'bin',
                        'skel_b64': base64.b64encode(data).decode('ascii'),
                        'atlas_text': open(atlas_fp, encoding='utf-8').read(),
                        'png_bytes': open(png_fp, 'rb').read(),
                        'png_dir': root,
                        'anims': None, 'skins': None, 'bounds': None,
                    })
                elif f.endswith('.json'):
                    try:
                        doc = json.load(open(os.path.join(root, f), encoding='utf-8'))
                    except Exception:
                        continue
                    item = parse_sp_wrapper(doc)
                    if not item or '_skeletonJson' not in item:
                        continue
                    seen.add(key)
                    skel = item['_skeletonJson']
                    if isinstance(skel, str):
                        skel = json.loads(skel)
                    atlas_text = item.get('_atlasText') or ''
                    if not atlas_text.strip():
                        afp = os.path.join(root, stem + '.atlas')
                        if os.path.exists(afp):
                            atlas_text = open(afp, encoding='utf-8').read()
                    img = first_image_line(atlas_text)
                    png_fp = None
                    for cand in (img, (item.get('textures') or [None])[0],
                                 stem + '.png'):
                        if cand and os.path.exists(os.path.join(root, cand)):
                            png_fp = os.path.join(root, cand)
                            break
                    if not png_fp:
                        continue
                    ske = skel.get('skeleton') or {}
                    skins_raw = skel.get('skins') or {}
                    if isinstance(skins_raw, list):
                        skn_names = sorted(
                            s.get('name') for s in skins_raw
                            if isinstance(s, dict) and s.get('name'))
                    else:
                        skn_names = sorted(skins_raw.keys())
                    entries.append({
                        'bundle': bundle, 'stem': stem,
                        'fmt': 'json',
                        'skel_json': json.dumps(skel, ensure_ascii=False,
                                                separators=(',', ':')),
                        'atlas_text': atlas_text,
                        'png_bytes': open(png_fp, 'rb').read(),
                        'png_dir': root,
                        'anims': sorted((skel.get('animations') or {}).keys()),
                        'skins': skn_names,
                        'bounds': [ske.get('x', 0), ske.get('y', 0),
                                   ske.get('width', 0), ske.get('height', 0)],
                    })

    for e in entries:
        sid = skin_id_of(e['bundle'])
        e['skin_id'] = sid
        e['material'] = skin_names.get(str(sid), '')
    entries.sort(key=lambda e: (e['skin_id'], order_of(e['stem']), e['stem']))
    return entries


def build_data(entries):
    meta = {}
    meta_fp = os.path.join(OUT, 'spine_meta.json')
    if os.path.exists(meta_fp):
        with open(meta_fp, encoding='utf-8') as f:
            meta = json.load(f)
    data = []
    for e in entries:
        atlas_url = embed_atlas(e['atlas_text'], e['png_dir'])
        anims = e['anims']
        skins = e['skins']
        bounds = e['bounds']
        parse_err = None
        if e['fmt'] == 'bin':
            skel_url = 'data:application/octet-stream;base64,' + e['skel_b64']
            m = meta.get(e['bundle'] + '/' + e['stem'])
            if m:
                if 'err' in m:
                    parse_err = m['err']
                    anims, skins, bounds = [], [], None
                else:
                    anims, skins, bounds = m['anims'], m['skins'], m['bounds']
        else:
            skel_url = ('data:application/json;base64,' +
                        base64.b64encode(e['skel_json'].encode('utf-8'))
                        .decode('ascii'))
        mat = ' · ' + e['material'] if e['material'] else ''
        item = {
            'name': e['stem'],
            'label': friendly(e['stem']),
            'bundle': e['bundle'],
            'skin': '皮肤 %s%s' % (e['skin_id'], mat),
            'fmt': e['fmt'],
            'skelUrl': skel_url,
            'atlasUrl': 'data:text/plain;base64,' +
                        base64.b64encode(atlas_url.encode('utf-8'))
                        .decode('ascii'),
            'anims': anims,
            'skins': skins,
            'bounds': bounds,
        }
        if parse_err:
            item['parseErr'] = parse_err
        data.append(item)
    return data


HTML_TEMPLATE = r'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Block Blast! · 材质皮肤 Spine 动效预览器（远程 bundle）</title>
<style>
  :root{--bg:#15171c;--panel:#1e2128;--panel2:#262a33;--line:#333845;
    --txt:#e8eaf0;--dim:#9aa1b0;--acc:#4cc2ff;--warn:#ffb454;--err:#ff6b6b;}
  *{box-sizing:border-box;margin:0;padding:0}
  html,body{height:100%}
  body{background:var(--bg);color:var(--txt);font-family:"Microsoft YaHei","PingFang SC",system-ui,sans-serif;
    display:flex;flex-direction:column;overflow:hidden}
  header{height:48px;display:flex;align-items:center;gap:14px;padding:0 16px;background:var(--panel);
    border-bottom:1px solid var(--line);flex:0 0 auto}
  header h1{font-size:15px;font-weight:600}
  header .sub{color:var(--dim);font-size:12px}
  main{flex:1;display:flex;min-height:0}
  aside{width:340px;flex:0 0 auto;background:var(--panel);border-right:1px solid var(--line);
    display:flex;flex-direction:column;min-height:0}
  #search{margin:10px;padding:8px 10px;border:1px solid var(--line);border-radius:6px;
    background:var(--panel2);color:var(--txt);font-size:13px;outline:none}
  #search:focus{border-color:var(--acc)}
  #listWrap{flex:1;overflow:auto;padding:0 6px 12px}
  .group{margin-top:8px}
  .group h3{font-size:12px;color:var(--dim);padding:4px 8px;font-weight:600}
  .row{display:flex;align-items:center;gap:8px;padding:7px 8px;border-radius:6px;cursor:pointer;
    font-size:13px;border:1px solid transparent}
  .row:hover{background:var(--panel2)}
  .row.active{background:#2c3648;border-color:var(--acc)}
  .row .nm{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .row .cnt{color:var(--dim);font-size:11px;background:#2a2e38;border-radius:9px;padding:1px 7px;flex:0 0 auto}
  .row.warn .nm::after{content:"缺"attr(data-miss);color:var(--warn);font-weight:700;margin-left:6px;font-size:11px}
  section{flex:1;display:flex;flex-direction:column;min-width:0;min-height:0}
  #toolbar{flex:0 0 auto;display:flex;flex-wrap:wrap;align-items:center;gap:10px;padding:10px 14px;
    background:var(--panel);border-bottom:1px solid var(--line);font-size:13px}
  #toolbar .sp{width:1px;height:22px;background:var(--line)}
  #toolbar select,#toolbar button{background:var(--panel2);color:var(--txt);border:1px solid var(--line);
    border-radius:6px;padding:5px 10px;font-size:12px;cursor:pointer}
  #toolbar button:hover{border-color:var(--acc)}
  #toolbar label{display:flex;align-items:center;gap:5px;color:var(--dim);font-size:12px;cursor:pointer}
  #curInfo{color:var(--dim);font-size:12px;min-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  #stage{flex:1;position:relative;min-height:0;overflow:hidden;background:#17191f}
  #stage .spine-player{position:absolute;inset:0}
  #stage .spine-player canvas{width:100%;height:100%}
  #status{flex:0 0 auto;height:26px;display:flex;align-items:center;gap:14px;padding:0 14px;
    background:var(--panel);border-top:1px solid var(--line);color:var(--dim);font-size:12px}
  #status b{color:var(--txt);font-weight:600}
  @media (max-width:900px){ aside{width:260px} }
</style>
</head>
<body>
<header>
  <h1>Block Blast! · 材质皮肤 Spine 动效预览器</h1>
  <span class="sub" id="hdStats"></span>
</header>
<main>
  <aside>
    <input id="search" placeholder="搜索皮肤/动效…">
    <div id="listWrap"></div>
  </aside>
  <section>
    <div id="toolbar">
      <span id="curInfo">请选择左侧动效</span>
      <span class="sp"></span>
      <button id="prev">‹ 上一个</button>
      <button id="next">下一个 ›</button>
      <span class="sp"></span>
      <label>动作
        <select id="animSel" disabled></select>
      </label>
      <span class="sp"></span>
      <label><input type="checkbox" id="loop" checked> 循环</label>
      <label><input type="checkbox" id="bgGrid"> 棋盘格背景</label>
      <label><input type="checkbox" id="showBones"> 骨骼线</label>
    </div>
    <div id="stage"></div>
    <div id="status"><span>组 <b id="pos">0/0</b></span><span>动画 <b id="animInfo">-</b></span>
      <span>缺帧 <b id="missInfo">-</b></span><span id="errInfo"></span></div>
  </section>
</main>
<script src="lib/spine-player.js"></script>
<script>
/* 兼容补丁：部分远程皮肤骨架中的中文图集名被导出工具写成
   "UTF-8 字节 + 0xFF00" 的变体，这里让图集查找同时支持两种写法；
   若某附件在图集中确实不存在，则跳过该附件而不是让整组加载失败。 */
(function(){
  if (!window.spine || !spine.AtlasAttachmentLoader) return;
  function byteMojibakeToUtf8(s){
    var bytes=[];
    for(var i=0;i<s.length;i++){
      var c=s.charCodeAt(i);
      if(c>=0xFF00&&c<=0xFFFF){bytes.push(c-0xFF00);}
      else if(c<0x80){bytes.push(c);}
      else return null;
    }
    try{return new TextDecoder('utf-8').decode(new Uint8Array(bytes));}catch(e){return null;}
  }
  function utf8ToByteMojibake(s){
    var bytes=new TextEncoder().encode(s);
    var out='';
    for(var i=0;i<bytes.length;i++){var b=bytes[i];out+=b<0x80?String.fromCharCode(b):String.fromCharCode(0xFF00+b);}
    return out;
  }
  var proto=spine.AtlasAttachmentLoader.prototype;
  function wrap(orig){
    return function(skin,name,path){
      try{return orig.call(this,skin,name,path);}
      catch(e){
        if(path!=null){
          var alt=byteMojibakeToUtf8(path);
          if(alt!==null&&alt!==path){
            try{return orig.call(this,skin,name,alt);}catch(e2){}
          }
          var alt2=utf8ToByteMojibake(path);
          if(alt2!==path){
            try{return orig.call(this,skin,name,alt2);}catch(e3){}
          }
        }
        return null;
      }
    };
  }
  proto.newRegionAttachment=wrap(proto.newRegionAttachment);
  proto.newMeshAttachment=wrap(proto.newMeshAttachment);
})();
</script>
<script>
const DATA = __DATA_JSON__;
let cur = -1;
let player = null;

function el(tag, cls, txt){const e=document.createElement(tag);if(cls)e.className=cls;if(txt!=null)e.textContent=txt;return e;}

function renderList(){
  const q=document.getElementById('search').value.trim().toLowerCase();
  const wrap=document.getElementById('listWrap');
  wrap.innerHTML='';
  const groups={};
  DATA.forEach((it,i)=>{
    (groups[it.skin]=groups[it.skin]||[]).push([it,i]);
  });
  Object.keys(groups).forEach(skin=>{
    const g=el('div','group');
    const h=el('h3',null,skin+'（'+groups[skin].length+'）');
    g.appendChild(h);
    groups[skin].forEach(([it,i])=>{
      const hay=(it.name+' '+it.label+' '+it.bundle+' '+it.skin).toLowerCase();
      if(q && !hay.includes(q)) return;
      const row=el('div','row'+(i===cur?' active':'')+(it.parseErr?' warn':''));
      if(it.parseErr) row.dataset.miss='!';
      const nm=el('span','nm',it.label+' · '+it.name);
      nm.title=it.bundle+' / '+it.name;
      row.appendChild(nm);
      const cnt=el('span','cnt',(it.anims?it.anims.length:0)+'动');
      row.appendChild(cnt);
      row.onclick=()=>load(i);
      g.appendChild(row);
    });
    wrap.appendChild(g);
  });
}

function fit(it){
  const stage=document.getElementById('stage');
  stage.innerHTML='';
  let b=it.bounds;
  if(!b || !(b[2]>0 && b[3]>0)) b=[-300,-300,600,600];
  const [x,y,w,h]=b;
  const pad=Math.max(w,h)*0.12;
  const vp={x:x-pad, y:y-pad, width:w+pad*2, height:h+pad*2};
  const cfg={
    jsonUrl: it.fmt==='json' ? it.skelUrl : null,
    skelUrl: it.fmt==='bin' ? it.skelUrl : null,
    atlasUrl: it.atlasUrl,
    animation: it.anims && it.anims.length ? it.anims[0] : null,
    skin: it.skins && it.skins.length ? it.skins[0] : null,
    alpha: true,
    premultipliedAlpha: false,
    backgroundColor: '#00000000',
    viewport: vp,
    showControls: true,
    success: function(widget){
      widget.animationState.timeScale=1;
      if(document.getElementById('loop').checked){
        const a=widget.animationState.getCurrent(0);
        if(a) a.loop=true;
      }
    },
    error: function(widget,msg){
      document.getElementById('errInfo').textContent='加载失败: '+msg;
    }
  };
  try{
    player=new spine.SpinePlayer(stage, cfg);
    document.getElementById('errInfo').textContent='';
  }catch(e){
    document.getElementById('errInfo').textContent='初始化失败: '+e;
  }
}

function load(i){
  if(i<0||i>=DATA.length) return;
  cur=i;
  const it=DATA[i];
  document.getElementById('curInfo').textContent=it.label+' · '+it.name+'  ['+it.bundle+']';
  document.getElementById('pos').textContent=(i+1)+'/'+DATA.length;
  document.getElementById('animInfo').textContent=(it.anims?it.anims.length:0)+' 个';
  document.getElementById('missInfo').textContent=it.parseErr?'解析失败':'0';
  const sel=document.getElementById('animSel');
  sel.innerHTML='';
  const anims=it.anims||[];
  if(anims.length){
    anims.forEach(a=>{
      const o=document.createElement('option');
      o.value=a;
      o.textContent=a;
      sel.appendChild(o);
    });
    sel.disabled=false;
    sel.value=anims[0];
  }else{
    sel.disabled=true;
    const o=document.createElement('option');
    o.textContent='无动作';
    sel.appendChild(o);
  }
  fit(it);
  renderList();
}

document.getElementById('search').addEventListener('input', renderList);
document.getElementById('prev').onclick=()=>load((cur-1+DATA.length)%DATA.length);
document.getElementById('next').onclick=()=>load((cur+1)%DATA.length);
document.getElementById('animSel').addEventListener('change',e=>{
  if(!player||!player.animationState) return;
  const name=e.target.value;
  if(!name) return;
  try{
    const loop=document.getElementById('loop').checked;
    const t=player.animationState.setAnimation(0,name,loop);
    if(t) t.loop=loop;
  }catch(err){
    document.getElementById('errInfo').textContent='切换动作失败: '+err;
  }
});
document.getElementById('loop').addEventListener('change',e=>{
  if(player&&player.animationState){
    const t=player.animationState.getCurrent(0);
    if(t) t.loop=e.target.checked;
  }
});
document.getElementById('bgGrid').addEventListener('change',e=>{
  document.getElementById('stage').style.background=
    e.target.checked?'conic-gradient(#2a2e38 25%,#22252d 0 50%,#2a2e38 0 75%,#22252d 0)':'#17191f';
  document.getElementById('stage').style.backgroundSize=e.target.checked?'20px 20px':'';
});
document.getElementById('showBones').addEventListener('change',e=>{
  if(player&&player.config) player.config.debug.bones=e.target.checked;
});
document.addEventListener('keydown',e=>{
  if(e.key==='ArrowRight') load((cur+1)%DATA.length);
  if(e.key==='ArrowLeft') load((cur-1+DATA.length)%DATA.length);
});

document.getElementById('hdStats').textContent=DATA.length+' 组 Spine · '+
  DATA.reduce((s,it)=>s+(it.anims?it.anims.length:0),0)+' 个动画 · '+
  new Set(DATA.map(it=>it.skin)).size+' 个皮肤';
renderList();
const gParam=new URLSearchParams(location.search).get('g');
load(gParam!==null&&gParam!==''?parseInt(gParam,10):0);
</script>
</body>
</html>
'''


def main():
    global ROOT, NAMED, SKINS_MD, SPINE_LIB, OUT
    ap = argparse.ArgumentParser(description='生成远程皮肤 Spine 自包含预览页')
    ap.add_argument('--root', default=ROOT,
                    help='素材根目录（需包含 named/ 与 skins清单.md）')
    ap.add_argument('--out', default=None,
                    help='输出目录，默认 <root>/spine-preview')
    ap.add_argument('--spine-lib', default=SPINE_LIB,
                    help='含 spine-player.js 的 lib 目录')
    args = ap.parse_args()
    ROOT = args.root
    NAMED = os.path.join(ROOT, 'named')
    SKINS_MD = os.path.join(ROOT, 'skins清单.md')
    SPINE_LIB = args.spine_lib
    OUT = args.out or os.path.join(ROOT, 'spine-preview')
    os.makedirs(OUT, exist_ok=True)
    os.makedirs(os.path.join(OUT, 'lib'), exist_ok=True)
    shutil.copy2(os.path.join(SPINE_LIB, 'spine-player.js'),
                 os.path.join(OUT, 'lib', 'spine-player.js'))
    entries = collect()
    data = build_data(entries)
    html = HTML_TEMPLATE.replace('__DATA_JSON__',
                                 json.dumps(data, ensure_ascii=False,
                                            separators=(',', ':')))
    with open(os.path.join(OUT, 'preview.html'), 'w', encoding='utf-8') as f:
        f.write(html)
    with open(os.path.join(OUT, 'spine_index.json'), 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    skins = sorted({it['skin'] for it in data})
    n_anim = sum(len(it['anims'] or []) for it in data)
    print('entries:', len(data), 'skins:', len(skins),
          'anims:', n_anim,
          'html MB:', round(os.path.getsize(os.path.join(OUT, 'preview.html'))
                            / 1024 / 1024, 1))
    for s in skins:
        print(' ', s, sum(1 for it in data if it['skin'] == s))


if __name__ == '__main__':
    main()
