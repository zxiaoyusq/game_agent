# -*- coding: utf-8 -*-
import os, zipfile, subprocess, sys
W = r'E:\codex_apk_work\blockmaster_pro_swap\work'
BT = r'E:\AndroidSdk\build-tools\34.0.0'
KS = r'E:\Gameprogram\water_game\native\engine\android\keystore\debug.keystore'
def run(c, t=600):
    print('>>', c)
    r = subprocess.run(c, shell=True, capture_output=True, text=True, timeout=t)
    if r.returncode != 0:
        print(r.stdout[-3000:]); print(r.stderr[-3000:])
        sys.exit(1)
    return r.stdout
SRC = os.path.join(W, 'stage2_lite_unsigned.apk')
MERGED = os.path.join(W, 'stage2_lite_merged.apk')
ADDS = [
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes2.dex'), 'classes15.dex'),
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes4.dex'), 'classes16.dex'),
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes.dex'), 'classes17.dex'),
    (os.path.join(W, 'bm_rebuilt_dex_clean', 'classes3.dex'), 'classes18.dex'),
]
if os.path.exists(MERGED): os.remove(MERGED)
zin = zipfile.ZipFile(SRC)
zout = zipfile.ZipFile(MERGED, 'w', zipfile.ZIP_DEFLATED)
for item in zin.infolist():
    data = zin.read(item.filename)
    if item.filename.endswith('.dex') or (item.filename.startswith('lib/') and item.filename.endswith('.so')):
        zout.writestr(item, data, compress_type=zipfile.ZIP_STORED)
    else:
        zout.writestr(item, data)
for path, name in ADDS:
    zout.writestr(name, open(path, 'rb').read(), compress_type=zipfile.ZIP_STORED)
zout.writestr('META-INF/services/bmkx.coroutines.H', b'bmkx.coroutines.android.b\r\n')
zout.writestr('META-INF/services/bmkx.coroutines.internal.n', b'bmkx.coroutines.android.a\r\n')
zout.close(); zin.close()
print('merged:', os.path.getsize(MERGED))
STORED = os.path.join(W, 'stage2_lite_stored.apk')
if os.path.exists(STORED): os.remove(STORED)
zin = zipfile.ZipFile(MERGED)
zout = zipfile.ZipFile(STORED, 'w', zipfile.ZIP_DEFLATED)
for item in zin.infolist():
    data = zin.read(item.filename)
    if item.filename.startswith('lib/') and item.filename.endswith('.so'):
        zout.writestr(item, data, compress_type=zipfile.ZIP_STORED)
    else:
        zout.writestr(item, data)
zout.close(); zin.close()
print('stored:', os.path.getsize(STORED))
ALIGNED = os.path.join(W, 'stage2_lite_aligned.apk')
run('"%s\\zipalign.exe" -f -p 4 "%s" "%s"' % (BT, STORED, ALIGNED))
SIGNED = os.path.join(W, 'blockmaster_lite_signed.apk')
if os.path.exists(SIGNED): os.remove(SIGNED)
run('cmd /c ""%s\\apksigner.bat" sign --ks "%s" --ks-key-alias debug_keystore --ks-pass pass:123456 --out "%s" "%s""' % (BT, KS, SIGNED, ALIGNED))
print('signed:', os.path.getsize(SIGNED))
run('"%s\\apksigner.bat" verify --verbose "%s"' % (BT, SIGNED), 300)
print('LITE PIPELINE DONE')
