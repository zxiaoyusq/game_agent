#!/usr/bin/env python3
"""Generate the final Markdown acceptance report for the algorithm system
and the 262 trait directories."""
import json
import os

ROOT = r"E:\codex_apk_work"


def load(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return json.load(f)


def main():
    acc = load(r"main_algo_extract\trait_dir_acceptance.json")
    manifest = load(r"main_algo_extract\remote_manifest_full.json")
    summary = acc["summary"]
    uniq = acc["unique_dirs"]

    lines = []
    A = lines.append
    A("# Block Blast 主算法体系与 262 个 Trait 目录 — 验收报告")
    A("")
    A("> 数据源：APK 提取 + HEK/XXTEA 解密 + 运行时堆转储（163MB）+ 官方 CDN 远程资源包。")
    A("> 结论分级：[已确认] = 明文/源码/清单原文；[推断] = 依据引用的合理推断；[未解决] = 未获原文。")
    A("")
    A("## 1. 验收结论摘要")
    A("")
    A(f"- **262 个 Trait 目录口径**：清单 262 行 → 唯一目录 **{summary['unique_dirs']} 个**（差额 8 = 同名目录在 class/chapter 下重复出现）；**全部 254 个唯一目录在本地工程中都有实际资产文件**，**253 个在堆转储中可找到出现证据**。")
    A(f"- **远程 Trait 包**：官方清单共 **{summary['full_trait_bundles_remote_manifest']} 个 Trait bundle**（含 262 目录之外的完整线上机制开关库）；本次已下载解密 **{summary['remote_bundle_total']} 个清单包中的 {summary['remote_bundles_downloaded']} 个**（config+index）。")
    A(f"- **262 目录对应的远程包**：{summary['remote_bundle_exists']} 个存在远程对应；{summary['remote_config_downloaded']} 个 config 已下载解密；{summary['remote_403']} 个 CDN 403（多为 CTRefactor 新重构系/已被下架）；{summary['remote_with_assets']} 个已下载资产。")
    A(f"- **主算法体系**：OFFER_TYPE 注册表 **1,024 个算法 ID 在堆转储中 100% 出现**；堆中发现 **591 个 `algo_*` C++ 算法类名**（OFFER_TYPE→C++ 类映射）；远程清单中 **{summary['algo_related_remote_bundles']} 个算法相关 Trait 包**（LightGBM/UCB/Entropy/Puzzle/Strategy 等）。")
    A("- **加密状态**：HEK 外层已完全破解（v01=XXTEA(KEY_B)，v03=XOR）；v01 文件内部还有一层 AFFA 自定义容器**未解**（3,653 个代码包）；109 个资产型包已直接解出明文 JS。")
    A("")
    A("## 2. 口径核对（262 / 254 / 241 / 214 / 27 / 13）")
    A("")
    A("| 口径 | 数量 | 含义 |")
    A("|---|---|---|")
    A("| 用户口径 | 262 | 目录清单总行数（含同名重复） |")
    A("| 唯一目录 | 254 | 去重后的 Trait 名 |")
    A("| 有本地资产 | 254 | 唯一目录全部在 `blockblast_project/assets` 下找到文件 |")
    A("| 有远程对应包 | 241 | 官方 bundleVers 清单中存在同名/Remote_ 前缀包 |")
    A("| 远程 config 已下载 | 214 | 实际从 CDN 下载并解密成功 |")
    A("| 远程 403 | 27 | 清单有版本号但 CDN 拒绝访问（下架/白名单） |")
    A("| 无远程包 | 13 | 纯本地内容型 Trait（dragonbones/prefab/audio/font 资产在本地） |")
    A("")
    A("## 3. 主算法体系覆盖")
    A("")
    A("### 3.1 OFFER_TYPE 注册表（已确认）")
    A("")
    A("- 完整枚举：`OFFER_TYPE_enum.txt`（1,024 个算法 ID，值域 -1,805,200 ~ 5,575,600,001）。")
    A("- 堆转储命中率：**1,024 / 1,024（100%）**。")
    A("- 分类：经典（<1000，442 个）、正式策略（1000-29999，400 个）、实验/A-B（≥30000，182 个）。")
    A("")
    A("### 3.2 OFFER_TYPE → C++ 算法类映射（已确认）")
    A("")
    A(f"- 堆中发现 **591 个 `algo_*` C++ 类名**，覆盖随机/免死、清屏、困难题、上增、消除快感、精确覆盖铺砖（`algo_exact_cover_tiling`）、对称熵（`algo_symmetry_blocks_entropy`）、3x8 清屏搜索（`algo_3x8_clear_board_search`）等。")
    A("- 样例映射（此前报告已列 60+ 条）：`ALGO_LOW_PRESSURE_PUNISHMENT_HARD → algo_punish_hard`、`ALGO_HOLE_PUZZLE_FILL → algo_exact_cover_tiling`、`ALGO_ISLAND_FILL → algo_island_fill` 等。")
    A("")
    A("### 3.3 策略管线与核心实现（已确认，详见主报告）")
    A("")
    A("- 19 级 `AlgorthmStrategyLevelType` 管线 + 4 种玩法的 `AlgorithmSourceType`。")
    A("- `applyReplaceAlgorithmV3`（概率轮盘赌替换）、`BinaryBoard`（8 行 bitmask 消行/消列）、`findPileUpPos`（堆叠检测）、`getBoardWeight`（启发式）、`Trait` 基类与 `traitConfigInfo` 配置管线均已恢复原文。")
    A("")
    A("### 3.4 远程算法 Trait 包（本次新增）")
    A("")
    A(f"- 远程清单共 **{summary['algo_related_remote_bundles']} 个算法相关 Trait 包**，含 `LightGBMAlgorithmStrategyTrait`、`CTRefactorUCBBlockPoolStrategyTrait`、`AlgoFillSortEdgeNoUseTrait`、`EntropyIncreaseBeforeFillWithRoundTrait`、`RandomNoDeath*` 系列等。")
    A("- 每个包都有 `config.<ver>.json`（参数/资产清单）+ `index.<ver>.js`（类代码，AFFA 内层未解）。")
    A("")
    A("## 4. 262 个 Trait 目录逐项验收")
    A("")
    A("| 目录 | 本地文件数 | 远程包 | 远程 config | 远程资产 | 堆证据 | 状态 |")
    A("|---|---|---|---|---|---|---|")
    for r in sorted(uniq, key=lambda x: x["dir"]):
        status = r["status"].replace(";", " / ")
        if not status:
            status = "empty"
        remote = r["remote_bundle"] or "-"
        A(f"| {r['dir']} | {r['local_file_count']} | {remote} | {'是' if r['remote_config'] else ('403' if r['remote_403'] else '-')} | {r['remote_asset_count']} | {r['heap_occurrences']} | {status} |")
    A("")
    A("## 5. 本次新增的关键成果")
    A("")
    A("### 5.1 HEK 外层解密修正（重要）")
    A("")
    A("- 此前结论为“HEK:XOR v03 + 自定义第二层加密”；**本次确认：HEK 版本字节 1（v01）的文件第一层应为 XXTEA(KEY_B=65485d8a-8161-4c)，而非纯 XOR**。")
    A("- v01（index.js）：HEK → XXTEA → AFFA 容器（内层未解）或直接明文 JS（109 个资产型包）。")
    A("- v03（config.json）：HEK → 纯 XOR → 明文 JSON。")
    A("")
    A("### 5.2 官方远程资源全量清单（已确认）")
    A("")
    A("- 从堆转储 `settings` 恢复完整 `bundleVers`：**4,882 个远程包**，其中 **3,823 个 Trait 包**、125 个皮肤包、语言包、主题包等。")
    A("- 恢复 `jsList`：11 个远程脚本，含 `assets/libs/algorithmStrategy.1918b.js`（算法策略模块，CDN 403，未能直接下载）。")
    A("")
    A("### 5.3 远程 Trait 包下载与解密")
    A("")
    A(f"- 下载 **{summary['remote_bundles_downloaded']} 个包**的 config+index（原始+解密，`remote_traits/raw` + `remote_traits/dec`）。")
    A("- 解析 config：1,240 个包含资产路径，共 26,823 条资产路径。")
    A("- 对 781 个关键包（本地 262 目录对应 + 算法相关）下载资产 **4,023 个文件**（import JSON / PNG / MP3 / DragonBones bin），全部 HEK 解密成功，JSON 可正常解析。")
    A("")
    A("## 6. 未解决与下一步")
    A("")
    A("1. **AFFA 内层**：3,653 个 v01 代码包的 index.js 在 XXTEA 后仍是 AFFA 自定义容器（hdr4+meta8+载荷）。已排除标准 XXTEA/AES/RC4/ChaCha20/简单 XOR 的常见密钥派生；`libcocos2djs.so` 内含 XXTEA 常量与自研代码，需原生逆向或动态抓取解密结果。")
    A("2. **algorithmStrategy.1918b.js**：CDN 403；堆转储中未捕获完整模块源码（JIT 编译态），仅确认接口与引用。")
    A("3. **27 个 403 包**：清单有版本号但 CDN 拒绝，可能是被下架或需客户端签名/白名单。")
    A("4. **196 个远程包下载失败**（含 195 个 403 + mainTraits）：与清单版本差异需二次核对。")
    A("")
    A("## 7. 产出文件清单")
    A("")
    A("| 文件 | 说明 |")
    A("|---|---|")
    A("| `main_algo_extract/remote_manifest_full.json` | 官方 4,882 包全量清单（server/jsList/bundleVers） |")
    A("| `main_algo_extract/remote_trait_bundle_manifest.json` | 堆中 URL 提取的 187 包清单 |")
    A("| `main_algo_extract/local_dir_to_remote_bundle.json` | 262 目录→远程包名映射 |")
    A("| `main_algo_extract/trait_dir_acceptance.json` | 逐目录验收数据（含状态） |")
    A("| `remote_traits/dec/<bundle>/config.<ver>.json` | 3,790 个包的解密 config（明文 Cocos JSON） |")
    A("| `remote_traits/dec/<bundle>/index.<ver>.js` | 解密 index（AFFA 容器或明文 JS） |")
    A("| `remote_traits/raw/<bundle>/` | CDN 原始加密文件 |")
    A("| `remote_traits/assets/<bundle>/` | 4,023 个解密资产文件 |")
    A("| `scripts/download_remote_trait_bundles.py` / `download_trait_assets.py` | 下载脚本 |")
    A("| `scripts/build_trait_acceptance.py` / `gen_acceptance_report.py` | 验收脚本 |")
    A("| `main_algo_extract/主算法体系与Trait系统解密报告.md` | 主报告（上一轮） |")
    A("")

    out_path = os.path.join(ROOT, "main_algo_extract", "主算法体系与Trait目录验收报告.md")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print("written:", out_path, "lines:", len(lines))


if __name__ == "__main__":
    main()
