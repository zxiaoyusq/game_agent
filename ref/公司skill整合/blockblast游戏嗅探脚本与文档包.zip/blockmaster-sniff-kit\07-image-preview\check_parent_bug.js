﻿'use strict';
const fs = require('fs');
const HTML = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810/spine-preview/preview.html';
const REF = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/blast-block-spine/preview.html';
function load(htmlPath){
  const html = fs.readFileSync(htmlPath, 'utf8');
  const m = html.match(/const DATA = (\[[\s\S]*?\]);\r?\n/);
  return JSON.parse(m[1]);
}
const data = load(HTML);
let slash0 = 0, slashN = 0;
const examples = [];
for (const d of data) {
  const p = d.atlasUrl;
  const last = p.lastIndexOf('/');
  const parent = last >= 0 ? p.substring(0, last) : '';
  if (parent) { slashN++; if (examples.length < 3) examples.push([d.bundle + '/' + d.name, parent.length]); }
  else slash0++;
}
console.log('our entries:', data.length, 'atlasUrl parent=="" :', slash0, ' parent!="" :', slashN);
console.log('examples (bundle/name, parentLen):', JSON.stringify(examples));
// same for reference
const rdata = load(REF);
let r0 = 0, rN = 0;
for (const d of rdata) {
  const p = d.atlasUrl;
  const parent = p.lastIndexOf('/') >= 0 ? p.substring(0, p.lastIndexOf('/')) : '';
  if (parent) rN++; else r0++;
}
console.log('ref entries:', rdata.length, 'parent=="" :', r0, ' parent!="" :', rN);
