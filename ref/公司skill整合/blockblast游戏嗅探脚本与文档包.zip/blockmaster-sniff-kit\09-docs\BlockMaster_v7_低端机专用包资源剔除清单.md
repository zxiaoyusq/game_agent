# BlockMaster v7 低端机专用包 · 资源剔除清单

> 目标：在 `work\BlockMaster_v7.apk`（304.4 MB，Block Blast 1047 内容 + BlockMaster 壳 + 内置远程内容）基础上，打一个**低端机专用包**：只含低端机需要的资源，本地与远端内容全部内置，不再依赖 CDN 下载。
> 依据：`美术表现规则文档.md`（低端机判定机制、资源分级、_Atlas 高清包、特效简化档）、`两层全量美术资源统计.md`、v7.apk 实包逐项分析（2026-08-17 版）。
> 原则：**低端机 = 帧率跑不满 + 硬件弱 → 特效简化、不下高清、少贴图内存、零远程依赖**。

---

## 一、v7 内容构成总览（实测）

| 区域 | 内容 | 文件数 | 体积 | 性质 |
|---|---|---|---|---|
| `assets/assets/` | Block Blast 本体（429 个 bundle 目录：trait/章节/**小游戏(整删，见 H 类)**/UI/贴图/Spine/DB/音频） | 8,592 | 61.96 MB | **保留主体**（小游戏除外） |
| └ 其中 .png | 本体贴图 | 1,531 | 27.91 MB | 按需剔除大图 |
| `assets/remote_seed/gamecaches/` | 内置远程内容：18 个皮肤包（2004~2037）+ Remote_SkinThree_24Colors_18Mat + Common + 104 个 trait 目录 | 2,558 | 25.38 MB | **大部分可剔** |
| └ 其中皮肤 Remote_Skin* | 皮肤贴图/动效/字体/音效 | 1,922 | 20.19 MB | **全剔** |
| `assets/remote_seed/patch/` | 远程 patch bundle（193 个：AddUploadPicBlockV2Trait 等） | 193 | 20.77 MB | 部分可剔 |
| `assets/lottie/` | Lottie 动画（458 条目 / 456 文件，约 47 组） | 456 | 1.06 MB | **全剔** |
| `res/` | Android 壳资源（广告 SDK 图标/布局，AppLovin 等 mediation 网络） | 1,783 | 9.97 MB | 剔未用 SDK |
| `assets/**/*.webp` | res 图标等 | 403 | 0.37 MB | 随 res 处理 |
| `lib/` `kotlin/` `com/` `google/` `src/` `META-INF/` | 原生库/壳代码 | ~70 | — | 保留 |
| **合计** | | 13,804 | **304.4 MB** | |

> 注：v7 内置皮肤只有 **2004~2037 纯色系**（该设备当时只下载过这些）；29 个 4000+ 材质皮肤（羊毛/饼干等）**未内置**，运行时靠 CDN 下载——低端机包必须**禁掉这个下载通道**。

---

## 二、剔除清单总表（按优先级）

### A 类 · 远程皮肤系统（剔 20.19 MB）—— 最大单项，必剔

| 剔除内容 | 位置 | 体积 | 原因 |
|---|---|---|---|
| 18 个纯色皮肤包 | `assets/remote_seed/gamecaches/gamecaches/Remote_Skin_Material_2004~2037/` | ~18 MB | 低端机用内置 40 套纯色（FivePartColorControl，零贴图）即可；皮肤 = 贴图+动效+字体，全是显存/内存负担 |
| 24 色 18 材质包 | `.../Remote_SkinThree_24Colors_18Mat/` | 含上 | 同上 |
| 皮肤公共素材 | `.../Remote_SkinThree_Material_Common/` | 含上 | 皮肤失效后不需要 |
| 皮肤高清图集包 | 任何 `*_Atlas` bundle（当前未内置，禁止下载即可） | — | **低端机不下高清包**（美术规则 5.5） |

**必须同步做（只删资源不关开关 = 加载报错）：**
1. 27 个皮肤/外观类 trait 全部 `firing=0`：`BoardClearChangeSkin`、`ClassModeAutoSkinAfterThree`、`ChapterSeasonSkin`、`ComebackLaunchChangeSkin`、`ChapterHardSequenceSkin`、`HighestScoretriggersSkinReplacement`、`MultipleGamesWithoutSkinChangeThenChangeSkin`、`DualColorSkinByClearBoard/ByRound/WithClearSwap/Selector/MoreColorPriority/MoreWithBigBlock`、`PresetUgcSkin`、`SkinChangeSettlementEffect`、`ShowSSSWhenSkinChange`、`SkinChangeAblePush`、`PushBackChangeSkin`、`HelpChangeSkin`、`ClassReloadSkin`、`TwiceDefaultSkinNoClearChange`、`UGCDefultUseRandomSkin`、`DeleteContinuePercentLowSkins`、`OriginSkinShowGreyDefultSetBtn`、`CleanSceneUseSkinPerformanceSequence`、`IsOpenChangeSkinNotChangeBlock`、`IsOpenChangeSkinByColorPool`、`IsOpenChangeSkinFix`、`CTSkinBonesFixRevert` 等
2. 配置层：`SkinThreeConfig_<id>` 皮肤清单置空/仅保留纯色；皮肤 bundle 下载入口关闭（否则低端机仍会请求 CDN）

### B 类 · Lottie 动画（剔 1.06 MB）—— 必剔

| 剔除内容 | 位置 | 原因 |
|---|---|---|
| 全部 Lottie | `assets/lottie/`（456 文件，47 组） | Lottie 是 CPU 逐帧渲染，低端机卡顿源；Block Blast 本体玩法不用 Lottie（版本/渠道差异功能）；同步关 lottie 入口 |

### C 类 · 高配特效 Trait 美术（remote_seed + assets/assets，估 5~8 MB）—— 必剔

按 `美术表现规则文档` 4.4 节：低端机用**简化特效档**。以下"高配爽感特效"的 trait bundle（含 Spine/DB/贴图）整目录剔除 + `firing=0`：

| 特效类 trait（剔） | 说明 |
|---|---|
| `ClearBoardRainbowEffectTrait` / `ClearBoardRainbowFlowTrait` / `ClearBoardRainToSurgeTrait` / `ClearBoardHeartRippleAniTrait` / `ClearBoardUnbelievableAdd/ReduceTrait` | 清盘彩虹/雨涌/爱心波纹/难以置信——高配爽感 |
| `ComboBorderEffectTrait` / `ComboButterflyBorderEffectTrait` / `ContinuousComboEffectTrait` | 连击边框/蝴蝶/连续特效 |
| `IsOpenRainbowPutBlocksEffectTrait` / `DynamicPreClearEffectTrait` / `GameOverButtonShineEffectTrait` / `ClickStarEffectFeedbackTrait` / `IsOpenResultClickEffectTrait` / `ShowEffectWhenInitEmptyBoardTrait` / `ChapterWinShowRainbowTrait` / `GameWinShowTarotWordTrait` / `UnbelievableClearScreenCarouse` / `ChapterCollectPreClearEffectTrait` / `SkinColorRelatedToClearScreenBlockTrait` / `HighScoreShowRainbowColorTrait` / `CleanComboChangeColorTrait` | 彩虹放块/预消除/按钮闪光/点击反馈/空盘特效/胜利塔罗等 |
| `IsOpenEliminateSpecialEffectTrait` | 保留还是剔除：**保留**（基础消除特效属玩法反馈），但可考虑简化档 |

**保留（低端机包的核心机制，不能剔）：**
- 7 个 `LowDevice*` Trait（`LowDeviceBlockFullEffectTouch`、`LowDevice_TimeOutToRandomNoDie`、`LowDevice_ReplaceSomeAlgoToRandomNoDie`、`LowDevice_RepaceSomeFillInToMultFillin`、`LowDeviceControllBannerLoad`、`LowDeviceClearProtect`、`LowDeviceBoardWeight`）及其简化特效档资源
- 基础玩法特效：消除、连击基础、复活倒计时（`revive_number`）、新手引导 8 组 Spine（`gameplay_xinshou`/`WellDone`/`tanchuan`/箭头等）——**均为 main bundle 主玩法特效**
- 主玩法胜负反馈（main bundle 内的胜负/结算动效）
- ❌ **小游戏特效不保留**：`dianzan`/`juzhongdianzan`（gl_fruit）、`shibaijiemian`/`pingju`/`lihua`（gl_hall）等随小游戏整体删除（见 H 类）

### D 类 · remote_seed/patch（20.77 MB）—— 按需剔

| 剔除内容 | 原因 |
|---|---|
| patch 中纯美术/活动类 bundle（如 AddUploadPic*、活动皮肤相关） | 低端机不需要活动美术 |
| patch 中机制类 bundle（算法修复/广告逻辑） | **保留**（玩法完整性） |

> ⚠️ patch 内容需逐个核对 config 的资产类型后再删；机制类 bundle 删了会破坏玩法。

### E 类 · 大尺寸贴图（assets/assets 内，估 3~6 MB）—— 必剔/降采样

| 剔除内容 | 原因 |
|---|---|
| 尺寸 >2048×2048 的贴图（如 4096 级 encourage 类） | 低端机 GPU 显存有限，大图是加载卡顿/闪退主因；降采样到 1024/2048 或剔除次要大图 |
| 高清位图字体大图（>1024） | 保留必需字体，剔多余变体 |

### F 类 · 广告 SDK res 资源（9.97 MB）—— 剔未用网络

| 剔除内容 | 原因 |
|---|---|
| 未启用广告网络的图标/布局（AppLovin mediation 的 47 个网络图标、PubMatic/POB 等非在用 SDK 资源） | 只保留实际初始化的广告 SDK（Hisavana/AdMob 等，以 dex 初始化清单为准） |
| 壳用不到的 drawable/webp | 同上 |

### G 类 · 音频（可选，不剔或小剔）

| 内容 | 体积 | 建议 |
|---|---|---|
| 183 个 ogg（BGM/音效） | 3.9 MB | **保留**（声音不大）；如极端省内存可剔 BGM 只留音效 |
| 97 个 mp3（语音/音效） | ~1.5 MB | **保留** |

### H 类 · 小游戏（more games）整体删除 —— ❌ 全部删除，不保留

> **决策：小游戏（more games）模块整体从包中移除**——入口、bundle、远程补丁、相关 trait 全部删除，不做任何保留。

#### H-1 删除：小游戏 bundle（13 个，本体 assets/assets/ 下）

| 删除内容 | 位置 | 含美术 |
|---|---|---|
| gl_fruit（水果合成） | `assets/assets/gl_fruit/` | 水果 12 组 Spine（Fruit_02/04/06/07/08、dianzan、juzhongdianzan、watermelon_combo、GoldWatermelonPanel、hcdxg_Prompteff、lose_hint_fx、BoardFullPanel 等）+ DB + 贴图 + 音频 |
| gl_hall（小游戏大厅） | `assets/assets/gl_hall/` | 结果页 3 组 Spine（lihua、pingju、shibaijiemian）+ 大厅 UI/贴图/音频 |
| gl_mahjong（麻将） | `assets/assets/gl_mahjong/` | 麻将 7 组 Spine（Selected_V2、Collosion_normal/combo、Prophint、AllComboEffect、UIGroundEff、mahjong_gameplay_tips）+ 贴图/音频 |
| gl_tictactoe（井字棋） | `assets/assets/gl_tictactoe/` | 井字棋 3 组 Spine（Jingziqi_qizi/v2、gameplay_word）+ 贴图/音频 |
| gl_watersort（水排序） | `assets/assets/gl_watersort/` | 水排序 4 组 Spine（skeleton/spineNew 62 动画、finger、nopixel_thumb）+ 贴图/音频 |
| gl_sudoku（数独） | `assets/assets/gl_sudoku/` | 数独 2 组 Spine（aixin_01、gameplay_fzjl）+ 贴图/音频 |
| gl_onet（连连看） | `assets/assets/gl_onet/` | 连连看 2 组 Spine（PowerUP、lihua）+ 贴图/音频 |
| gl_oneline（连线） | `assets/assets/gl_oneline/` | 连线 2 组 Spine（crownTips、Oneline_gameplay_king）+ 贴图/音频 |
| sandcrush / sand_mini / sand_prefab / sand_audio（沙块） | `assets/assets/sandcrush/` 等 4 个 | 沙块 4 组 Spine（progressBar_efx/goal_efx、arrow、teaching_arrow）+ 贴图/音频 |
| hsgame（大厅壳） | `assets/assets/hsgame/` | 大厅相关代码/资源 |

#### H-2 删除：小游戏远程补丁（28 个，remote_manifest_full 中 `Remote_gl_*`）

| 删除内容 | 说明 |
|---|---|
| `Remote_gl_fruit_*`（7 个：NotDropLittleFruitWhenXiGuaOnShow、addBombAudio、cixi、faceNotRotate、qiehuan、showShakeResultEncourage、wanneng） | 水果合成远程补丁 |
| `Remote_gl_oneline_*`（10 个：GLBFDeadRoadSound、GLBFDieReplace、GLBFDieReplay、GLBFProgressSound、GLBFWhiteWrap、crown、halfDone、hintBtnTip、new_tip、wrongLine） | 连线远程补丁 |
| `Remote_gl_hall_*`（2 个：CampaignGuideMiniGame、MiniGameDeliveryUndertake） | 大厅/小游戏入口补丁 |
| `Remote_gl_mahjong_*`（2 个：autoReSort、longPressChangeOpacity）、`Remote_gl_onet_*`（2 个：blockItemsSplash、changeElementSprite）、`Remote_gl_sudoku_*`（3 个：errorAlert、numassist、unitCompleteEffect）、`Remote_gl_tictactoe_*`（2 个：firstWinEncourage、lastStepWinEncourage） | 各小游戏远程补丁 |

#### H-3 删除：小游戏入口/控制类 trait（关闭 `firing=0` 或直接剔除 bundle）

| 类别 | trait 清单 |
|---|---|
| MiniGame 系列 | `MiniGameEnterChangeColorTrait`、`MiniGameMainEnterChangeColorTrait`、`MiniGameSetEnterChangeColorTrait`、`MiniGameSetShowLockTrait`、`MiniGameSetShowProgressTrait`、`MiniGameShowOnlineCountTrait`、`MiniGameSpeedUpTrait`、`MiniGameUnlockByDaysTrait`、`MiniGameUnlockNotificationTrait`、`MiniGameUnlockTrait`、`MiniGameUseColorfulBtnTrait`、`MiniIconAddEffectTrait`、`MiniIconAddEffect_mainTrait` |
| MoreGames 系列 | `MoreGameBtnFixBugTrait`、`MoreGameContinueLastMiniGameTrait`、`MoreGameRandomEnterTrait`、`MoreGamesAdventureExchangeTrait`、`MoreGamesToMiniGamesTrait`、`MoreGamesUnlockByBreakHighScoreTrait`、`MoreGamesUnlockByDaysTrait`、`RecentMiniGamesTrait` |
| 小游戏入口/网络相关 | `CampaignAcceptFirstLaunchToMiniGameTrait`、`GameOverShowMiniGameIconTrait`、`NoNetMiniGameBlockTrait`、`NoNetworkNoMiniGameTrait` |

#### H-4 删除：入口与界面

| 删除内容 | 说明 |
|---|---|
| 大厅小游戏入口按钮/图标（MiniGame 入口、MoreGames 入口） | 入口相关预制体/贴图/文案随 gl_hall 与上述 trait 一并移除 |
| 小游戏场景（`gl_*.fire` 共 11 个）与结果页 | 随 bundle 删除 |
| 小游戏相关 Spine/DB/贴图/音频（约 39 组 Spine + 对应 DB/贴图/音频） | 随各 bundle 删除；**注意：`dianzan`/`juzhongdianzan`（gl_fruit）、`shibaijiemian`/`pingju`/`lihua`（gl_hall）等小游戏特效不保留** |

#### H-5 必须同步做

1. 大厅入口代码路径/按钮隐藏：`hsgame` 与 gl_hall 的入口跳转全部失效处理（否则点了无反应/报错）
2. 小游戏相关 trait 全部 `firing=0`（H-3 清单）
3. `Remote_gl_*` 补丁不内置、不下载（满配置包也删除，见满配置清单）

---

## 三、保留清单（低端机必需，不能动）

| 类别 | 内容 | 理由 |
|---|---|---|
| 核心玩法 | main / chapter / class / baseV / 全部机制类 trait bundle（js+config+算法） | 玩法完整性 |
| 方块与棋盘 | 白色基础方块、纯色 40 套配置（FivePartColorControl）、棋盘/背景/UI 图集、方块阴影 | 玩法必需表现 |
| 核心 Spine | 新手引导 8 组 + 复活倒计时 + 基础消除/连击（均为主玩法 main bundle） | 玩法反馈必需；体积小（本体 82 atlas 仅 0.1MB + 贴图）；⚠️ 小游戏 Spine（水果/麻将/井字棋/水排序/数独/连连看/大厅/沙块约 39 组）**不保留** |
| 核心 DragonBones | 本体 114 组（消除/预消除/combo/清屏/鼓励） | 玩法反馈必需；⚠️ 若需极致精简可只保留消除/预消除/combo，清屏/鼓励降级 |
| 音频 | 全部音效（ogg/mp3） | 操作反馈必需 |
| 字体 | 18 个 ttf + 必需 fnt | UI 必需 |
| 低端机机制 | 7 个 LowDevice* Trait + 简化特效档 + `AdjustEffectVolumeBasedOnEffectFrequency` + `LikeEffectOptimization` + `IsSpeedUpReviveAnim` + `OptimizeBlockDownAnim*` | **低端机包的核心卖点** |
| 场景/预制体 | 12 个 .fire、全部 .prefab、.anim、.effect | 界面必需 |

---

## 四、体积预估

| 项 | 体积 |
|---|---|
| v7 原包 | 304.4 MB |
| 剔 A 皮肤（20.19）+ B Lottie（1.06）+ C 高配特效（估 6）+ D patch 美术（估 8）+ E 大图（估 4）+ F res 未用 SDK（估 6） | 可剔 ~45 MB |
| **+ H 小游戏整体删除（13 个 gl_*/sand_*/hsgame bundle + 小游戏 Spine/DB/贴图/音频，估 8~15 MB）** | **再剔 ~10 MB** |
| **预估低端机包** | **~248-252 MB**（zip 压缩后差异更大，皮肤/lottie 压缩率高，实际安装包可再省 15-25 MB） |

---

## 五、操作步骤（脚本化建议）

```
1. apktool d BlockMaster_v7.apk -o v7_low  （或直接 zip 层级操作后重签）
2. 执行剔除脚本（按本文清单删目录）：
   - rm -rf v7_low/assets/remote_seed/gamecaches/gamecaches/Remote_Skin_*
   - rm -rf v7_low/assets/lottie
   - rm -rf 特效 trait 目录（C 类清单逐个）
   - rm -rf 皮肤 trait 目录（A 类清单逐个）
   - rm -rf 未用广告 SDK 的 res 图标（F 类，以 dex 初始化清单为准）
   - 大图降采样：Pillow 批量把 >2048px 贴图缩到 2048
   - ❌ 小游戏整删（H 类）：rm -rf v7_low/assets/assets/gl_fruit gl_hall gl_mahjong gl_oneline gl_onet gl_sudoku gl_tictactoe gl_watersort hsgame sandcrush sand_mini sand_prefab sand_audio
3. 修改配置（关键，否则报错/回退 CDN）：
   - traitConfigInfo / mergedConfig：A/C/D 类 trait 全部 firing=0 或 active=false
   - ❌ 小游戏相关 trait 全部 firing=0（H-3 清单：MiniGame*/MoreGames*/MiniIcon*/入口类 25 个）
   - ❌ 大厅小游戏/MoreGames 入口隐藏（H-4：入口按钮/跳转代码路径失效处理）
   - SkinThreeConfig_<id>：皮肤列表置空，只留纯色
   - 远程下载入口：皮肤 bundle / trait bundle 下载地址置空或指向本地 seed
   - settings 中 lottie 入口关闭
4. apktool b v7_low → zipalign → apksigner 签名（沿用 v7 签名流程，见 work/ 下 stage2 脚本）
5. QA 验证（见下）
```

---

## 六、QA 验证清单（低端机专项）

- [ ] **启动**：低端机（如 2GB 内存模拟器/旧机型）冷启动不闪退、loading 正常
- [ ] **无网络**：飞行模式启动 → 无任何皮肤/trait 下载请求（抓包确认 0 请求 CDN）
- [ ] **特效降级**：满盘时触发 `LowDeviceBlockFullEffectTouch` 简化特效（无满屏粒子）
- [ ] **对局**：连续 50 回合无卡顿（帧率 > 45fps on 低端机）、清盘/连击特效正常
- [ ] **皮肤**：设置页无皮肤入口或仅纯色选择；不出现"皮肤加载失败"报错
- [ ] **内存**：运行 30 分钟内存占用 < 阈值（无大图泄漏）
- [ ] **回归**：引导、复活、胜负结算正常；**小游戏（more games）入口不存在、无残留按钮/报错**（大厅无小游戏图标）
- [ ] **广告**：在用广告位正常出广告；未用 SDK 无初始化报错

---

## 七、风险与注意（不能踩的坑）

1. **只删资源不关 Trait = 加载报错**：所有被删 bundle 对应的 trait 必须同步 `firing=0`（A/C/D 类清单已列）
2. **机制类 trait bundle 不能删**：算法/广告/复活/难度类 trait 虽无美术，但删了会破坏玩法——只删"美术增强类"
3. **❌ 小游戏（more games）整体删除（H 类）**：13 个 gl_*/sand_*/hsgame bundle + 28 个 Remote_gl_* 补丁 + 25 个 MiniGame*/MoreGames* 入口 trait + 大厅入口全部删除；删除后入口代码路径必须同步失效处理，否则点击报错
4. **大图降采样会改变 uuid 资产尺寸**：需保证 config/import 引用一致（改图不改引用）
5. **res/ 广告 SDK 剔除前先核对 dex**：以 dex 中实际 `SDKWrapper`/初始化类清单为准，别误删在用 SDK
6. **40 套纯色是"无贴图"实现**：确认 `FivePartColorControl` 配置随本体保留，否则方块无色
7. **签名**：重新打包后签名不一致会导致升级失败（沿用 v7 的签名流程）
8. **Spine/DB 精简是灰度决策**：极端精简前建议先在 2GB 设备实测内存，别凭感觉删

---

## 附：参考文档

- `E:\codex_apk_work\美术表现规则文档.md`（5.3 设备分级 / 5.5 资源分级）
- `E:\codex_apk_work\两层全量美术资源统计.md`
- `E:\codex_apk_work\blockmaster_pro_swap\work\`（v7 构建脚本 stage2_*、v7_dedupe.py）
- 本清单实测数据来源：`BlockMaster_v7.apk` zip 条目逐项统计
