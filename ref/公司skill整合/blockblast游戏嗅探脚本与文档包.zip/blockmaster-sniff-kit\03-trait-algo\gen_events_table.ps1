﻿# 生成埋点事件 Excel（手写 xlsx）
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$work = 'E:\codex_apk_work\blockmaster_pro_swap\work'
$events = Import-Csv "$work\_events_list.csv" -Encoding UTF8

# 规则：事件名匹配模式 → [类别, 触发条件, 触发原理]
$rules = @(
  @('^gameLaunchProcess|^game_launch', '启动', '游戏启动流程各阶段', '记录启动链路阶段完成/失败（JS 引擎引导分步埋点）'),
  @('^usr_data_startup_time', '启动', '启动完成时', '记录启动耗时'),
  @('^usr_data_enter_first|^usr_data_enter_game', '启动/进入', '首次进入/进入游戏', '记录玩家进入游戏动作'),
  @('^usr_data_enter_bg', '生命周期', '游戏切后台时', '记录退到后台事件'),
  @('^usr_data_install', '启动/安装', '首次启动（trait 配置初始化完成）', '记录安装激活（onInstallDot）'),
  @('^usr_data_type', '启动/设备', 'trait 配置初始化完成时', '上报玩家分组(wayType)、皮肤数、可用内存'),
  @('^usr_data_restart', '对局', '重开一局时', '记录 restart（点击重开）'),
  @('^usr_data_game_start', '对局', '每局开始', '记录对局开始（含局数/模式）'),
  @('^usr_data_game_end', '对局', '每局结束/结算', '记录对局结束（得分/消除数据，usrDataGameEndDot）'),
  @('^usr_data_game_revive', '对局', '复活时', '记录玩家复活行为'),
  @('^usr_data_replay_click|^usr_data_replay_exp', '回放', '点击回放/回放实验', '记录回放入口点击与实验分流'),
  @('^usr_data_replay_progress_(click|drag)', '回放', '回放进度条点击/拖动', '记录回放进度操作'),
  @('^usr_data_replay_interface_return_click', '回放', '回放界面返回', '记录回放返回'),
  @('^usr_data_topscore', '对局/得分', '分数超过门槛或金/银/铜牌更新', '上报最高分与奖牌档位'),
  @('^usr_data_guide_3_end', '新手引导', '新手引导第3步完成', '记录引导进度（UI create ChapterGame 时）'),
  @('^usr_data_achieve|^usr_data_medals_(click|detail_click|detail_show|entrance_click)', '成就/勋章', '勋章入口/详情/领取点击', '记录勋章系统交互'),
  @('^usr_data_show_comment|^usr_data_send_comment|^usr_data_comment_state', '评论', '显示评论框/发送评论/状态', '记录评分评论（starNum 星级）'),
  @('^usr_data_ad_show', '广告', '广告成功展示时', '上报广告展示（processingAdInterface）'),
  @('^usr_data_ad_preload', '广告', '广告预加载请求时', '上报广告预加载（loadFullScreenAd）'),
  @('^ad_lowecpm_sub', '广告', '广告 ecpm 低于阈值时', '上报低 ecpm 广告位替换（inter/reward 次数与 ecpm）'),
  @('^banner_request', '广告', 'banner 请求时', '上报 banner 请求（局数/回合/开局前时间）'),
  @('^g_game_show_action_requestresult', '广告', '广告展示请求结果回调', '上报展示请求结果（-1内存/-2VIP/成功）'),
  @('^ui_setting_show|^ui_setting_button_close', 'UI-设置', '打开/关闭设置面板', '记录设置面板展示与关闭'),
  @('^ui_setting_(sound|vibration|bgm|replay|home|feedback|randomskin)_button_click|^ui_setting_(sound|vibration|bgm|feedback|randomskin|replay|home)_click', 'UI-设置', '点击设置项', '记录设置面板各开关/按钮点击（音效/震动/音乐/反馈/随机皮肤等）'),
  @('^ui_setting_moresetting_contactus', 'UI-设置', '点击联系我们', '记录联系客服'),
  @('^ui_theme_show', 'UI-主题', '主界面展示', '记录主界面显示'),
  @('^ui_theme_classic_click', 'UI-主题', '点击经典模式入口', '记录进入经典模式'),
  @('^ui_theme_travel_click_board|^ui_theme_travel_battle_show', 'UI-旅行', '点击开始旅行对局/对战界面显示', '记录旅行模式交互'),
  @('^ui_theme_moregame_click|^ui_theme_moregame_icon_show|^ui_theme_moregame_button_click', 'UI-小游戏', '点击/显示 moregame 图标入口', '记录小游戏（更多游戏）入口展示与点击（含是否已安装）'),
  @('^ui_theme_achievement_click', 'UI-成就', '点击成就入口', '记录成就入口点击（红点/统计/奖励）'),
  @('^ui_marketing_activity_(button_click|png_click)', 'UI-活动', '点击营销活动按钮/图片', '记录营销活动入口点击'),
  @('^ui_achievement_award_click', 'UI-成就', '领取成就奖励', '记录奖励领取'),
  @('^moregame_hall_download_success', '小游戏', 'moregame 下载成功', '记录小游戏大厅资源下载成功'),
  @('^g_game_attribution_(gad_native_request|gad_native_requestresult|gad_native_initiative_requestresult|abtest_request|experiment_request|experiment_requestresult|all_requestresult|preinstalledsources_requestresult|requestresult)', '归因', '归因（AppsFlyer/GAD）请求发出与结果回调', '记录买量归因 campaign/media_source/gad_campaign_id（启动/实验/预装渠道）'),
  @('^g_game_reinstall_success', '归因', '重装归因成功', '记录重装识别'),
  @('^g_game_abtest_flow_result_(request_success|response_success|settings_end)', 'AB测试', 'AB 流程请求/响应/配置落地各阶段', '记录 AB 实验流程（request_reason: launch/hot_update/timeout_retry；process_result）'),
  @('^usr_data_AB(_server|_quit|_quit_server)?$', 'AB测试', 'AB 分组变化/退出', '记录 AB 分组（server 为服务端分组）'),
  @('^abtest_wudiban_change_success', 'AB测试', '无底板 AB 替换成功', '记录 AB 变体应用成功（res_version 等）'),
  @('^gameServerTraitActiveList', 'Trait', 'trait 服务端列表到达', '记录服务端激活 trait 列表'),
  @('^g_game_apply_trait_ids_arrive', 'Trait', 'trait id 列表应用到达', '上报压缩 trait id 列表（Huffman 编码，每日限次）'),
  @('^g_login_trait_ids_arrive', 'Trait', '登录后 trait 列表到达', '记录登录时 trait 列表'),
  @('^g_game_solution_apply_success', 'Trait', '方案应用成功', '记录解决方案（远程配置）应用'),
  @('^g_game_cold_start_skin_start', '皮肤', '冷启动皮肤流程开始', '记录冷启动皮肤'),
  @('^g_game_skin_change_success', '皮肤', '皮肤切换成功', '记录换皮成功'),
  @('^g_game_language_download|^g_game_language_replace_success', '语言', '语言包下载/替换', '记录多语言资源下载'),
  @('^game_popup_start|^game_popup_done', '弹窗', '游戏内弹窗开始/完成', '记录弹窗生命周期'),
  @('^cocos_log_reporter|^cocos_lose_reporter|^cocos_res_reporter|^jsb_err_report', '错误上报', 'JS 错误/请求失败/资源问题发生时', '上报错误信息（版本前缀、去重）'),
  @('^usr_data_server_[0-9]+(new)?$|^usr_data_login_server_(hot_result|apply_fail_old|ratio_info)', '服务器', '服务器流程各阶段/登录结果', '记录服务器请求分步与登录结果'),
  @('^usr_data_tech_algo_sdk_errmsg', '算法', '算法 SDK 报错时', '上报算法错误（algoType/board/分数）'),
  @('^s_tech_request_init_success', '技术', '技术请求初始化成功', '记录技术链初始化'),
  @('^usr_data_catch_addloading', '加载', '捕获额外加载', '记录资源加载异常'),
  @('^updateflow', '更新', '更新流程', '记录热更流程'),
  @('^lightgbm_zxh_user_churn_pred|^game_get_model_result|^block_model_evaluate', 'AI模型', 'AI 模型推理/评估', '记录模型请求与结果（流失预测/评分）'),
  @('^trait_server_outer_boundary_fallback', 'Trait', 'trait 服务端边界回退', '记录回退'),
  @('^usr_data_migration_achieve_info|^usr_data_non_new_architecture_exp_success', '迁移', '数据迁移', '记录数据迁移'),
  @('^usr_data_gamefinish_cjpushcf_success|^usr_data_high_score_decay_fix|^usr_data_end_ui_show', '其他', '专项修复/结算UI', '记录专项事件'),
  @('^finishTravel', '旅行', '旅行阶段≥48完成', '记录旅行完成（travelId）'),
  @('^g_game_background_close', '生命周期', '游戏切后台', '记录后台关闭'),
  @('^g_game_backstop_fail', '兜底', '服务端兜底失败', '记录回退失败'),
  @('^g_game_attribution_gad_abtest_request', '归因', 'GAD AB 请求发出（启动/非启动）', '记录 AB 归因请求（gad_campaign_id）'),
  @('^g_game_native_push_attribution_before_ab_request_arrive', '归因', 'AB 请求到达前的原生推送归因', '记录推送归因 campaign/media_source'),
  @('^g_game_next_round_click', '对局', '章节结算点下一轮', '记录下一轮点击（skin_id/game_type）'),
  @('^g_game_revive_skin_click', '对局', '复活换肤点击', '记录复活皮肤点击（300ms 节流）'),
  @('^g_game_topscore_success', '对局', '最高分达成（MergeBlocks）', '记录高分达成（game_id/round）'),
  @('^game_ad_beforeAdShow', '广告', '广告展示前一刻', '上报广告展示前状态（adType/GameType/可用内存/总内存）'),
  @('^game_apply_model_result', 'AI模型', '模型结果应用', '记录模型结果应用（HttpDot）'),
  @('^game_classic_interest_success', '对局', '经典模式兴趣成功', '记录经典模式兴趣触发（interest 标记）'),
  @('^game_popop_lost_click', '复活', '失败弹窗点击（放弃复活）', '记录放弃复活（game_type/id/round）'),
  @('^game_popup_revive_click', '复活', '点击复活', '记录点击复活（withProp/game_type）'),
  @('^game_tech_(send|receive|effect)ServerRequest', '服务器', '服务器请求发送/接收/生效', '记录技术请求三阶段（serverType/param/result/耗时）'),
  @('^push_lower_ad', '广告', '广告下沉策略触发', '记录广告下沉（aDSubCurrentGame 次数）'),
  @('^s_ad_business_relative_requestresult', '广告', '广告业务请求结果', '记录广告业务请求结果'),
  @('^ui_achievement_show', 'UI-成就', '成就界面展示', '记录成就面板展示'),
  @('^ui_battle_show', 'UI-对战', '对战界面展示', '记录对战展示'),
  @('^ui_main_guide_(first|during)', '新手引导', '主界面引导首次/进行中', '记录主界面引导（num/entertype）'),
  @('^ui_marketing_activity_exp', 'UI-活动', '营销活动曝光', '记录活动曝光（location）'),
  @('^ui_setting_button_click', 'UI-设置', '设置面板按钮点击', '记录设置按钮（含 Bugsnag 上下文设置）'),
  @('^ui_setting_defaultskin_click', 'UI-设置', '点击默认皮肤', '记录默认皮肤选择'),
  @('^ui_setting_feedback_show', 'UI-设置', '反馈界面展示', '记录反馈面板'),
  @('^ui_setting_moregame_button_click|^ui_setting_moresetting_button_click_copy', 'UI-设置', '设置内更多游戏/更多设置按钮', '记录设置面板更多入口'),
  @('^ui_theme_travel_click_button', 'UI-旅行', '旅行入口按钮', '记录旅行入口'),
  @('^usr_act_clear', '对局/消除', '消除结算', '记录一次/多次/全清消除数（oneclean~allclean）'),
  @('^usr_data_adventure_magnifying_glass_click', '旅行', '冒险放大镜点击', '记录预览全部（TravelId）'),
  @('^usr_data_back_again', '对局', '再次回退', '记录回退行为'),
  @('^usr_data_block_deadId', '对局', '方块死局检测', '记录死局块 id 数组'),
  @('^usr_data_csr_request|^usr_data_csr_success', '服务器', 'CSR 服务请求/成功', '记录 CSR（ecpm/adnum/gameNum）'),
  @('^usr_data_end_next_click', '对局', '结算界面下一关', '记录结算下一步')
)

function Get-Rule($name){
  foreach($r in $rules){ if($name -match $r[0]){ return $r } }
  return $null
}

# 生成 Excel 行数据
$rows = foreach($e in $events){
  $r = Get-Rule $e.Name
  if($r){
    [PSCustomObject]@{ 事件名称=$e.Name; 出现次数=$e.Count; 类别=$r[1]; 触发条件=$r[2]; 触发原理=$r[3] }
  } else {
    [PSCustomObject]@{ 事件名称=$e.Name; 出现次数=$e.Count; 类别='其他'; 触发条件='(待补充)'; 触发原理='(待补充)' }
  }
}
$rows | Export-Csv "$work\_events_table.csv" -NoTypeInformation -Encoding UTF8
"规则覆盖: $(($rows | Where-Object { $_.触发条件 -notmatch '待补充' }).Count)/$($rows.Count)"
$uncovered = $rows | Where-Object { $_.触发条件 -match '待补充' } | Select-Object -ExpandProperty 事件名称
"未覆盖: $($uncovered -join ', ')"

# ========== 生成 xlsx（手写 Excel XML + zip） ==========
$outXlsx = 'E:\codex_apk_work\埋点事件清单.xlsx'
$all = @(
  [PSCustomObject]@{ 事件名称='事件名称'; 出现次数='出现次数'; 类别='类别'; 触发条件='触发条件'; 触发原理='触发原理' }
) + @($rows | Sort-Object 类别, 事件名称 | ForEach-Object {
  [PSCustomObject]@{ 事件名称=$_.事件名称; 出现次数=[string]$_.出现次数; 类别=$_.类别; 触发条件=$_.触发条件; 触发原理=$_.触发原理 }
})

function Xml-Escape($s){ return ([string]$s).Replace('&','&amp;').Replace('<','&lt;').Replace('>','&gt;').Replace('"','&quot;') }

# sheet XML
$sb = New-Object System.Text.StringBuilder
[void]$sb.Append('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>')
$r = 1
foreach($row in $all){
  [void]$sb.Append("<row r=`"$r`">")
  $c = 1
  foreach($prop in $row.PSObject.Properties){
    [void]$sb.Append("<c r=`"$([char](64+$c))$r`" t=`"inlineStr`"><is><t xml:space=`"preserve`">$(Xml-Escape $prop.Value)</t></is></c>")
    $c++
  }
  [void]$sb.Append('</row>')
  $r++
}
[void]$sb.Append('</sheetData></worksheet>')
$sheetXml = $sb.ToString()

# workbook.xml
$wbXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="埋点事件" sheetId="1" r:id="rId1"/></sheets></workbook>'
$wbRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>'
$ct = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>'
$rootRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'

if(Test-Path $outXlsx){ Remove-Item $outXlsx -Force }
$ms = New-Object System.IO.MemoryStream
$zip = New-Object System.IO.Compression.ZipArchive($ms, [System.IO.Compression.ZipArchiveMode]::Create, $true)
function Add-ZipEntry($zip, $name, $content){
  $e = $zip.CreateEntry($name)
  $s = $e.Open()
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($content)
  $s.Write($bytes, 0, $bytes.Length)
  $s.Dispose()
}
Add-ZipEntry $zip '[Content_Types].xml' $ct
Add-ZipEntry $zip '_rels/.rels' $rootRels
Add-ZipEntry $zip 'xl/workbook.xml' $wbXml
Add-ZipEntry $zip 'xl/_rels/workbook.xml.rels' $wbRels
Add-ZipEntry $zip 'xl/worksheets/sheet1.xml' $sheetXml
$zip.Dispose()
[System.IO.File]::WriteAllBytes($outXlsx, $ms.ToArray())
$ms.Dispose()
"✅ Excel 已生成: $outXlsx ($( [math]::Round((Get-Item $outXlsx).Length/1KB,1) )KB, $($rows.Count) 事件 + 表头)"