﻿# -*- coding: utf-8 -*-
import json, sys
sys.stdout.reconfigure(encoding="utf-8")
p = r"E:\参考图\block录屏\解包素材\BlastBlock-美术资源全量-20260810\材质皮肤-远程bundle-20260810\spine-preview\spine_index.json"
data = json.load(open(p, encoding="utf-8"))
print("entries:", len(data))
print("skins:", len({d["skin"] for d in data}))
print("anims total:", sum(len(d["anims"] or []) for d in data))
print("with parseErr:", sum(1 for d in data if d.get("parseErr")))
print("with null anims:", sum(1 for d in data if d["anims"] is None))
print("with null bounds:", sum(1 for d in data if not d.get("bounds")))
print("sample skin:", data[0]["skin"])
for d in data:
    if d["name"].startswith("gameplay_clear_unbelievable") and d["bundle"].endswith("_3011"):
        print("clear_unbelievable_3011 anims:", d["anims"])
        print("bounds:", d["bounds"])
        break
for d in data:
    if d["name"].startswith("gameplay_word") and d["bundle"].endswith("_3011"):
        print("word_3011 anim count:", len(d["anims"]), "first:", d["anims"][:12])
        break
for d in data:
    if d["name"].startswith("gameplay_eliminate") and d["bundle"].endswith("_4041"):
        print("eliminate_4041 anims:", d["anims"])
        break
