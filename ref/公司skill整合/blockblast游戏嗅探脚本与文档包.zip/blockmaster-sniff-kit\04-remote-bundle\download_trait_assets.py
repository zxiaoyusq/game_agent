#!/usr/bin/env python3
"""Download import/native assets for selected remote trait bundles.

Selection: bundles mapped from the local trait directories plus every bundle
whose name matches algorithm keywords (Algo*, LightGBM*, UCB*, Entropy*,
RandomNoDeath*, Binary*, Puzzle*, FillSort*, ClearBoard*, *Strategy*).

Asset URLs are computed from each bundle's decrypted config:
  import/<uuid2>/<uuid>.<importHash>.json
  native/<uuid2>/<uuid>.<nativeHash>.<ext>
"""
import base64
import gzip
import glob
import json
import os
import re
import sys
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

KEY = b"65485d8a-8161-4c"
BASE = "https://bband1.afafb.com/update/block_android_online/remoteRes/0/remote/"
OUT_ROOT = r"E:\codex_apk_work\remote_traits"
HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Linux; Android 14; Pixel 8) "
                   "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36"),
    "Accept": "*/*",
}

EXT_BY_TYPE = {
    "cc.Texture2D": ["png", "jpg", "webp"],
    "cc.SpriteFrame": ["png", "jpg", "webp"],
    "sp.SkeletonData": ["bin", "json", "skel"],
    "cc.BitmapFont": ["fnt"],
    "cc.AudioClip": ["mp3", "ogg", "wav"],
    "cc.JsonAsset": ["json"],
    "cc.Prefab": ["prefab", "json"],
    "dragonBones.DragonBonesAsset": ["json", "bin"],
    "dragonBones.DragonBonesAtlasAsset": ["atlas"],
    "cc.Asset": ["json", "atlas", "bin", "plist", "txt", "xml", "png", "mp3", "ogg"],
}

ALGO_KEYWORDS = [
    "Algo", "Algorithm", "LightGBM", "UCB", "Entropy", "RandomNoDeath",
    "BinaryBoard", "BinarySupport", "Puzzle", "FillSort", "ClearBoard",
    "Strategy", "GBM", "Tkxc", "TKXC", "puzzle", "algo",
]


def decrypt(data):
    if not data.startswith(b"HEK:"):
        return data
    body = data[8:]
    ks = (KEY * (len(body) // 16 + 1))[:len(body)]
    pt = bytes(a ^ b for a, b in zip(body, ks))
    if pt[:2] == b"\x1f\x8b":
        try:
            pt = gzip.decompress(pt)
        except Exception:
            pass
    return pt


def decode_uuid(compressed):
    if len(compressed) != 22:
        return compressed
    rest = base64.b64decode(compressed[2:] + "==")
    hexs = compressed[0:2] + rest.hex()
    return "%s-%s-%s-%s-%s" % (
        hexs[0:8], hexs[8:12], hexs[12:16], hexs[16:20], hexs[20:32])


def http_get(url, timeout=30):
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def asset_urls(config_path):
    d = json.load(open(config_path, encoding="utf-8"))
    uuids = d.get("uuids") or []
    types = d.get("types") or []
    paths = d.get("paths") or {}
    versions = d.get("versions") or {}
    import_v = versions.get("import") or []
    native_v = versions.get("native") or []
    # type by uuid idx
    type_by_uuid = {}
    for idx, info in paths.items():
        uuid = uuids[int(idx)]
        t = info[1] if len(info) > 1 and info[1] < len(types) else 0
        type_by_uuid[uuid] = types[t] if t < len(types) else "cc.Asset"
    urls = []
    for i in range(0, len(import_v), 2):
        uuid = uuids[import_v[i]]
        h = import_v[i + 1]
        u = decode_uuid(uuid)
        urls.append(("import", f"import/{u[:2]}/{u}.{h}.json"))
    for i in range(0, len(native_v), 2):
        uuid = uuids[native_v[i]]
        h = native_v[i + 1]
        u = decode_uuid(uuid)
        t = type_by_uuid.get(uuid, "cc.Asset")
        exts = EXT_BY_TYPE.get(t, ["bin", "json", "png", "atlas"])
        urls.append(("native", f"native/{u[:2]}/{u}.{h}.{exts[0]}"))
    return urls


def main():
    mapping = json.load(open(
        r"E:\codex_apk_work\main_algo_extract\local_dir_to_remote_bundle.json",
        encoding="utf-8"))
    selected = set(v for v in mapping.values() if v)
    # add all algo-related downloaded bundles
    for cfg in glob.glob(os.path.join(OUT_ROOT, "dec", "*", "config.*.json")):
        name = os.path.basename(os.path.dirname(cfg))
        if any(k in name for k in ALGO_KEYWORDS):
            selected.add(name)
    print("selected bundles:", len(selected))

    jobs = []
    for name in sorted(selected):
        cfgs = glob.glob(os.path.join(OUT_ROOT, "dec", name, "config.*.json"))
        if not cfgs:
            continue
        urls = asset_urls(cfgs[0])
        for kind, rel in urls:
            jobs.append((name, rel))
    print("asset files to download:", len(jobs))

    state = {"ok": 0, "fail": [], "skipped": 0}

    def work(job):
        name, rel = job
        dst = os.path.join(OUT_ROOT, "assets", name, rel.replace("/", os.sep))
        if os.path.exists(dst) and os.path.getsize(dst) > 0:
            return ("skip", name, rel)
        url = BASE + f"{name}/{rel}"
        try:
            raw = http_get(url)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            pt = decrypt(raw)
            open(dst, "wb").write(pt)
            return ("ok", name, rel)
        except Exception as e:
            return ("fail", name, rel, str(getattr(e, "code", e)))

    with ThreadPoolExecutor(max_workers=16) as ex:
        futs = [ex.submit(work, j) for j in jobs]
        done = 0
        for f in as_completed(futs):
            r = f.result()
            done += 1
            if r[0] == "ok":
                state["ok"] += 1
            elif r[0] == "fail":
                state["fail"].append(r)
            else:
                state["skipped"] += 1
            if done % 1000 == 0:
                print(f"progress {done}/{len(jobs)} ok={state['ok']} fail={len(state['fail'])}")

    print("done. ok:", state["ok"], "fail:", len(state["fail"]), "skip:", state["skipped"])
    from collections import Counter
    fc = Counter(r[3] for r in state["fail"])
    print("fail codes:", fc)
    with open(os.path.join(OUT_ROOT, "assets_report.json"), "w", encoding="utf-8") as f:
        json.dump({"ok": state["ok"], "fail": state["fail"][:500], "skipped": state["skipped"],
                   "fail_by_code": dict(fc)}, f, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
