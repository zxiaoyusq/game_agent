# -*- coding: utf-8 -*-
"""Extract deduped user messages from the codex dialogue MD."""
import re, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
SRC = r"E:/codex_apk_work/scripts/_codex_thread_01a03195_dialogue.md"
DST = r"E:/codex_apk_work/scripts/_codex_thread_01a03195_users.md"

with open(SRC, encoding='utf-8') as f:
    content = f.read()

blocks = re.split(r"\n={80}\n", content)
seen = set()
out = []
for b in blocks:
    m = re.match(r"### USER(?:\(evt\))? @ ([\dT:\-]+) \(line \d+\)\n", b)
    if not m:
        continue
    ts = m.group(1)
    body = b[m.end():].strip()
    # normalize for dedup (evt vs resp duplicates)
    key = re.sub(r"\s+", "", body)[:400]
    if key in seen:
        continue
    seen.add(key)
    out.append(f"\n\n===== USER @ {ts} =====\n{body}")

with open(DST, 'w', encoding='utf-8') as f:
    f.write("\n".join(out))
print(f"unique user messages: {len(out)} -> {DST}")
