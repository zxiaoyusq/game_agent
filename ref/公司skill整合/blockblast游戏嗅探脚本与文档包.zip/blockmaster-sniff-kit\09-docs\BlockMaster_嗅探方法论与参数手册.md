# BlockMaster / Block Blast 嗅探方法论与参数手册

> 生成时间：2026-08-20
> 用途：把此前 11 份结论文档背后的**嗅探方式、解密参数、工具链、证据路径**固化下来，使任何人事后可以**按图重跑**同一条嗅探路径，复现结论而不必重新摸索。
> 配套文档（本文的产出对象）：
> `两层全量美术资源统计.md`、`BlockMaster_SDK与联网拉取盘点.md`、`BlockMaster_广告QA验证手册.md`、`BlockMaster_广告策略全解.md`、`BlockMaster_Android_SDK接入分析.md`、`BlockMaster_v7_满配置包资源缺口清单.md`、`BlockMaster_v7_低端机专用包资源剔除清单.md`、`美术表现规则文档.md`、`BlockMaster_V34_埋点事件与网络上报审计.md`、`BlockMaster_原版广告策略还原_展示时机与瀑布.md`、`低端机适配6.5详解.md`
> 符号：✅=实测确认；⚠️=推断/待验证；🔑=可复现的关键参数

---

## 0. 环境前置（必须先过这一关，否则后面全是假失败）

| 项 | 值 | 说明 |
|---|---|---|
| 工作根 | `E:\codex_apk_work` | 全部相对路径基于此 |
| Shell | Windows PowerShell（**无 pwsh**，用 `powershell -File`） | 本机 `pwsh` 不存在 |
| 🔑 Python 真实路径 | `C:\Program Files\Python312\python.exe`（`py -V:3.12`） | PATH 上的 `python` 是 **Windows Store 占位程序**，调用即报 `The file cannot be accessed by the system`。**所有脚本必须用绝对路径调用** |
| 中文脚本编码 | PowerShell 5 脚本须存为 **UTF-8 with BOM** | 否则中文注释导致 `ParserError` / 乱码 |
| 引号陷阱 | 避免 `"$var:"`（被当驱动器名）→ 用 `("...{0}..." -f $var)` | |
| 文件策略 | danger-full-access，无审批弹窗 | 不要设置 `sandbox_permissions` |

**统一调用模板**
```powershell
cd E:\codex_apk_work
& 'C:\Program Files\Python312\python.exe' -X utf8 <script.py> [args]
```

⚠️ **递归扫描大目录会超时**：`work\` 树极大，`Get-ChildItem -Recurse` 全树扫描会 120s 超时。**先限定子目录**，或改用 `resindex` 索引（见 §2）。

---

## 1. 加密体系（嗅探的第一性原理）

这是整套嗅探的关键：**加密层决定了"能不能直接读"，读不到就必须先解密再分析**。

### 1.1 三层格式总览

| 格式 | 头部特征 | 算法 | 用途 |
|---|---|---|---|
| `HEK:` **v03** | `HEK:` + 4 字节版本 | **XOR** 流密钥 | 资源（.png/.json/.atlas） |
| `HEK:` **v01** | `HEK:` + `0x01` | **XXTEA** | `.jsc` / 部分资源 |
| `AFFA` | 解密后出现 `\xaf\xfa` magic | 内层容器 | XXTEA 解出后的二次包装 |

### 1.2 🔑 HEK:XOR v03 参数（资源用）

```python
KEY   = b"65485d8a-8161-4c"          # 16 字节 ASCII，循环异或
head  = data[:4] == b"HEK:"          # 版本在 data[4:8]
body  = data[8:]                     # 从第 8 字节开始异或
pt[i] = body[i] ^ KEY[i % 16]
# 明文可能是 gzip（magic 1F 8B）→ 需再解压
```

- ✅ **`HEK:XOR` 同时作用于 `.json` 和 `.png`**（这是最容易踩的坑：直接读 PNG 的 IHDR 会报"非PNG"，其实要先解密）
- 脚本：`scripts\decrypt_resources.py`（`SRC`/`DST` 在文件头部常量，按需改）
- 输出 `_manifest.json` 记录每文件 `hek`/`gzip`/`sha1`，可核对覆盖率

### 1.3 🔑 HEK:XXTEA v01 参数（JS 用）

```python
KEY   = b"65485d8a-8161-4c"   # 同一把密钥，但走 XXTEA
DELTA = 0x9E3779B9
MASK  = 0xFFFFFFFF
# xxtea_decrypt(body, KEY) → 可能再 gzip（可能多成员 gzip，需循环解）
```
- 脚本：`scripts\decrypt_jsc.py`（`XXTEA → gunzip 多成员 → JS`）
- 变体排查：`scripts\xxtea_test.py`、`xxtea_variants.py`、`enc_test*.py`

### 1.4 AFFA 内层

`scripts\affa_survey.py` 会遍历所有 `HEK:` + `raw[4]==1` 的文件，XXTEA 解密后检查 `pt[:2] == b"\xaf\xfa"`，统计版本字节、`meta8`、payload 长度。
- 相关：`affa_bruteforce.py`、`affa_final_test.py`、`affa_meta_test.py`
- ⚠️ **不要把 AFFA 当成 XOR**：必须先读头 + 版本字节，再选解密链。保留原始密文副本。

### 1.5 🔑 运行时取明文（绕过静态解密的万能后门）

即使静态解密失败，还有一条**已验证**的通路：游戏引擎自己会解密，用 JSB 读回来即可：

```
jsb.fileUtils.getStringFromFile()   # 返回解密后明文 → 一次性导出全部游戏 JS
```

热更通道（同样已验证）：引擎优先读 `/data/user/0/<pkg>/files/patch/`，顺序 `main.jsc` → `main.js` → 回退 APK assets。放**明文 JS** 也能被接受并执行，无需重新加密。写标记文件可验证热更是否生效。

> 出处：`blockblast_规范文档\08_加密与工程安全说明.md` §1

---

## 2. 资源嗅探：resindex 索引（**硬规则：先查索引，禁止 grep 扫文件找图片**）

### 2.1 为什么必须用索引

图像在 APK 内是 **HEK 加密 + uuid/哈希命名**，"用文件名 grep 图片"必然失败。必须走：

```
cc.config(索引) → uuid → import/native 文件 → 解密 → 真图
```

### 2.2 🔑 命令清单

```powershell
cd E:\codex_apk_work
# 建库（约 30 秒；资源变动后重建）
& 'C:\Program Files\Python312\python.exe' -X utf8 resindex\build_index.py

.\resindex\ri.cmd where                       # 新鲜度
.\resindex\ri.cmd zh 结算背景                  # 中文词 → 英文资源名
.\resindex\ri.cmd find backgroundbg --ext .png
.\resindex\ri.cmd get <id>                    # src/bundle/kind/uuid/file/native/enc
.\resindex\ri.cmd uuid fdAGs8iGpMAKZx3GbUaVkY@f9941
.\resindex\ri.cmd extract <关键词> -o out       # 导出真图（自动 HEK 解密/APK 解包）
.\resindex\ri.cmd cheat                       # 命名约定对照表
.\resindex\ri.cmd sql "select ... from assets where ..."   # 逃生舱
.\resindex\ri.cmd stats
```

### 2.3 ⚠️ 已知故障：索引"假新鲜"

- **症状**：`ri.cmd find/zh` 全部返回 `0 条`，但 `where` 报"新鲜"。
- **根因**：`resindex.db` 是空壳（8192 字节、`assets` 表 0 行），而 `index_meta.json` 仍记录旧行数（如 81464）。
- **排查**：
  ```powershell
  Get-ChildItem resindex\resindex.db | Select-Object Length   # 8192 = 坏
  & 'C:\Program Files\Python312\python.exe' -X utf8 -c "import sqlite3;print(sqlite3.connect(r'E:\codex_apk_work\resindex\resindex.db').execute('select count(*) from assets').fetchone())"
  ```
- **修复**：重跑 `build_index.py`（实测约 30s；行数随资源增删变化，**以 `where` 输出的 `rows` 为准**，不要硬编码）。
- 📌 **健康基线（每次开查前的 3 秒冒烟测试）**：
  ```powershell
  .\resindex\ri.cmd where                                  # 看 rows 是否非零
  (.\resindex\ri.cmd find backgroundbg --ext .png | Measure-Object -Line).Lines   # 应非零（本文档落笔时 63）
  .\resindex\ri.cmd zh 结算背景                              # 应回出词表 + 条数
  ```
  `rows` 很大但 `find` 恒为 `0 条` ⇒ 库坏，重建。**先跑冒烟测试再下任何"资源不存在"的结论**，否则会把索引故障误判成资源缺失。

### 2.4 索引来源（`build_index.py` 顶部软配置，缺则跳过）

| 源 | 路径常量 | 内容 |
|---|---|---|
| cocos-bundle | `E:\codex_apk_work\blockmaster_apk\apk\assets\assets` | `cc.config.json` → uuid/paths/packs + native |
| ui-manifest | `...\blast-block-extra\ui_manifest.json` | 图集子图/prefab/scene/纹理/字体/音频/lottie |
| skins | 皮肤包 `skins_report.json` + `named/` 树 | 每个远程皮肤每个资源 |
| apk | `bb_1047_base.apk`、`com.block.juggle.base.apk`、`apks\com.block.juggle\base.apk` | zip 条目 |
| files | `E:\参考图` 全局 manifest.csv | 参考素材盘点 |
| docs | `E:\codex_apk_work`、`blockblast_规范文档`、全量包、`_索引` | `*.md` 结论文档 |

### 2.5 经典坑位

- **"结算背景"≠`settlement_bg`**，实际是 `backgroundbg` / `backgroundbg_material_<皮肤ID>`（用 `zh` 映射）。
  📌 实测 `zh 结算背景` 的行为是：先回出一串**关联关键词**（`UIResultView2`、`GameWinUI`、`BestScoreUI`、`prefabs/win/`、`result_` …），再回出匹配条数 —— 它是**线索展开器**，不是"一个中文词换一个资源名"。拿到词表后要再 `find` 逐项收敛。
- **全屏背景是整张竖版渐变 PNG**（960×1707 / 656×1456），**不是纯色、不是 shader**。
- ⚠️ `res-game :: images/ui/common/BG_01` 只有 **87×87 纯色 #7B4DCF**，别和渐变背景混为一谈。
- 有些皮肤背景是 **1~36 px 宽的竖向色带**（运行时横向拉伸），所以按文件名/体积判断"是不是真图"会误判。
- **皮肤资源不在 APK 里**：`Remote_Skin_Material_<id>` 是 CDN 远程 bundle。
- 文案搜不到时**可能是贴图**：转去图集子图按 rect 找（`ui_manifest.json → sprite_atlases.subimages`）。

---

## 3. JS 逻辑嗅探（Trait / 广告 / 埋点）

### 3.1 🔑 主包明文位置（17MB，最核心的取证对象）

| 文件 | 说明 |
|---|---|
| `blockmaster_pro_swap\work\diagnostics\v30_main_decrypted_probe\index.7d3cd.js` | 主包明文（17019492 字节） |
| `...\work\js_dumps\assets_main_index.75e4e.js` | 主包变体（11689130 字节） |
| `...\work\js_dumps\remote_seed_patch_assets_main_index.7b71a.js` | 远程 seed patch 主包（17367479 字节） |
| `...\work\js_dumps\remote_seed_patch_assets_mainTraits_index.6eb04.js` | **mainTraits**（Trait 实现，2.2MB） |
| `...\work\js_dumps\remote_seed_patch_assets_chapter_index.3d73a.js` | chapter 包（含 `AdLevelTrait`） |
| `...\work\js_dumps\remote_seed_patch_assets_mergeBlocks_index.ba457.js` | mergeBlocks 包 |
| `...\work\diagnostics\v32_r3_settings.5731e.js` | settings 配置（Trait → bundle 哈希映射） |

> ⚠️ 主包有**多个副本**（base/patch/seed），哈希与标记不同。**先用哈希和标记确认当前实际入口**，再下结论。

### 3.2 🔑 定点取证手法（避免全文件正则扫到超时）

```powershell
$f = 'E:\codex_apk_work\blockmaster_pro_swap\work\diagnostics\v30_main_decrypted_probe\index.7d3cd.js'
$c = Get-Content $f -Raw
$i = $c.IndexOf('目标符号')                       # 先定位
$c.Substring([Math]::Max(0,$i-500), 2000)         # 再取上下文窗口
```
- **模块实现体**用 `IndexOf("XxxTrait: [ function")` 定位（比正则快且准）。
- 装饰器**挂载点**（"谁装饰了谁"）用注册表反查：`XxxTrait:` 后跟 hook 名列表。
- `trait_id_map.json` / `trait_decorator_registry.json` 是现成的映射表，先查表再搜代码。

### 3.3 Trait 机制取证三件套

| 产物 | 路径 | 内容 |
|---|---|---|
| Trait 目录验收 | `main_algo_extract\trait_dir_acceptance.json`（273KB） | 逐 trait 验收 |
| Trait↔目录关联 | `main_algo_extract\trait_dir_association.json`（43KB） | 本地目录 ↔ 远程 bundle |
| Trait 证据 | `main_algo_extract\trait_dir_evidence.json`（56KB） | 逐 trait 证据 |
| feature id 映射 | `main_algo_extract\trait_id_map.json`（422KB） | Trait → feature id |
| 类清单 | `main_algo_extract\trait_classes.json`、`class_ids_all.json` | |
| 远程全量清单 | `main_algo_extract\remote_manifest_full.json`（209KB，4885 项） | 服务端全量远程 bundle |

生成脚本：`scripts\extract_algo_traits.py`、`associate_trait_dirs.py`、`trait_dir_evidence.py`、`build_trait_acceptance.py`、`download_remote_trait_bundles.py`
（⚠️ `trait_decorator_registry.json` / `remote_manifest_full.json` 的**生成脚本未保留**，JSON 本身已在仓库中）

### 3.4 ⚠️ 代码窗口法（`code_windows.json`）

`main_algo_extract\code_windows.json`（2.5MB）保存了逐 Trait 的**代码窗口**（如 `FrameRateStatLowDevicesTrait` 的 `_fpsHistory`/`onCollectFPS`/`_gcd`），这是在**主包加密未解密时**仍能拿到片段的方法。用它做交叉验证。

### 3.5 局限：Trait 实现体常不在本地

- 单个 Trait 的实现体在**远程热更 trait bundle**（settings 里的哈希，如 `Remote_LikeEffectOptimization: "2a534"`）。
- 本地 `gamecaches` 只有 98 个 trait 目录，且**内层仍是加密**（HEK 解完仍乱码 ⇒ 存在第二层）。
- **结论纪律**：只确认到"挂载点 + 钩子名 + 谓词"时，必须标注 ⚠️ 推断，不得当成实现事实。

---

## 4. 远程包嗅探（CDN）

### 4.1 远程内容三层

| 层 | 命名 | 内容 |
|---|---|---|
| 皮肤 | `Remote_Skin_Material_<id>`（+ `_Atlas` 高清） | 方块贴图/背景/动效/字体/音效 |
| Trait | trait 同名 bundle | 机制插件 + 专属美术 |
| JS 库 | `remoteRes/0/jsList/` | 远程 JS 库（9 个） |

### 4.2 🔑 清单与下载

```powershell
& 'C:\Program Files\Python312\python.exe' -X utf8 scripts\download_remote_skin_bundles.py
& 'C:\Program Files\Python312\python.exe' -X utf8 scripts\download_remote_trait_bundles.py
& 'C:\Program Files\Python312\python.exe' -X utf8 scripts\download_trait_assets.py
```
- 组织产物：`organize_remote_skins.py`
- ⚠️ **`main_algo_extract\remote_manifest_full.json`（4885 项）与 `trait_decorator_registry.json` 的生成脚本未随仓库保留**（当时是临时脚本）。这两个 JSON **已在仓库中**，可直接当输入用；若需重新生成，须按 §3.2 的定点取证手法自行重写。
- 皮肤解密产物落在 `E:\参考图\...\材质皮肤-远程bundle-20260810\{raw,dec,named}\`（`named` 才是按资源名整理的）
- ⚠️ **`dec` 是原始 bundle 结构（`import/<uuid前缀>/...`）**，按名字找资源要去 `named\`

### 4.3 皮肤包结构（`named\Remote_Skin_Material_<id>\`）

```
res/     game_cube_1~7_material_<id>、backgroundbg_material_<id>、
         backgroundkuai-8x8_*、die_quan_bg_*、set_bg_*、crown …
effect/  gameplay_eliminate_<id>、gameplay_combo_<id>、comb_<id>_ske/tex、
         comnb_<id>、encourage_<id>、xc_<id>、revive_countdown_<id>、fuhuoshuzi_<id>
font/    combo_fnt_material_<id>、playgame_num_*_material_<id>
sound/   <材质英文>_streak
misc/
```

### 4.4 皮肤主题配置（代码侧）

每个皮肤在 `SkinThreeConfig_<id>` 里是一张 `键 → {assetPath, platform, bundleName}` 表：

```js
game_bg: { assetPath: "res/backgroundbg_material_035",
           platform: "gp",
           bundleName: "Remote_Skin_Material_2035" }
```
资产键枚举在 `SkinThreeAssetKey`（`GameBg = "game_bg"` 等）。
取用：`skinInfo.gameBgSkinInfo` → `SkinThreeConfigMap[currentSkinId].game_bg`。

> 实证补充（2026-08-20 结算背景排查）：背景渲染由 `modules/skin/components/gameBg/SkinGameBgComponent` 负责，是**双通道**——
> `normalSprite.spriteFrame`（普通精灵） + `customMaterial`（`setMaterial()` / `setAllParams(color)` / `opacity`）。
> 所以**屏幕上的颜色 ≠ 原图像素色**，比原图更亮/更饱和属正常（运行时材质调色）。据此定位到 `Remote_Skin_Material_2033\res\backgroundbg_material_033.png`（36×1707 竖版渐变）。

---

## 5. 配置与运行时数据库嗅探

| 证据 | 路径 | 用途 |
|---|---|---|
| 🔑 原厂实验配置 | `work\v27_exact_mumu_clean\runtime_layers_extracted\databases\jsb.sqlite` | 主键 `block-blast-server_experiment_config`，**保存原厂实际下发的实验参数**（比 APK 里"存在但未启用"的 Trait 更有价值） |
| 云控快照 | `work\BlockMaster_v35_palm_full.apk!/assets/mediation.json` | Hisavana 云控（`cloudControlVersion=50`） |
| 云控对照 | `work\stage2_sdk\assets\mediation.json` | 当前版本快照 |
| 远程内容快照 | `work\bb1047_remote_content\gamecaches\gamecaches\` | 98 个 trait 目录 + 皮肤 |
| settings | `work\diagnostics\v32_r3_settings.5731e.js` | Trait → bundle 哈希 |

⚠️ **`jsb.sqlite` 的 SHA256 与被查文件的哈希都要记录**，否则无法证明"读的是哪一版现场"。
⚠️ 读 `jsb.sqlite` 用只读方式打开，**不要原库直改**。

---

## 6. 网络与埋点嗅探（真机）

### 6.1 🔑 四层证据组合（缺一不可）

| 层级 | 工具 | 能证明 | 不能证明 |
|---|---|---|---|
| 业务桥接 | logcat `BMAthenaBridge` | JS 事件进入 Athena 桥 | 是否真发到服务器 |
| Athena 队列 | logcat `save event to DB` | 已入本地队列 | 网络成功 |
| Athena HTTP | logcat `upload`/`success` | 发往哪个 host、服务端 `code=0` | 其他 SDK 是否另有连接 |
| 全量网络 | PCAPdroid / tcpdump + Wireshark | DNS、TLS SNI、HTTP Host 全目的地 | TLS 加密后正文 |
| 后台核对 | Athena 控制台 | appId/TID 可查询 | 设备是否还访问其他域名 |

⚠️ **Charles/mitmproxy"没看到请求"不能作为零联网证明**（证书锁定、QUIC、原生 libcurl、不走系统代理都会漏包）。

### 6.2 🔑 实操命令

```powershell
# （a）PCAPdroid：捕获范围只选目标包名，关闭其他 VPN，不要求 TLS 解密也能看 DNS/SNI
# （b）MuMu/root tcpdump
adb -s 127.0.0.1:16384 shell su -c "tcpdump -i any -s 0 -w /sdcard/bm.pcap"
adb -s 127.0.0.1:16384 pull /sdcard/bm.pcap E:\codex_apk_work\bm.pcap

# （c）Athena 四级日志
adb -s <serial> shell setprop log.tag.Athena DEBUG
adb -s <serial> shell setprop debug.athena.test_mode false
adb -s <serial> logcat -c
adb -s <serial> logcat -d -v threadtime > E:\codex_apk_work\bm_network_logcat.txt

# （d）tshark 提取主机
tshark -r bm.pcap -Y "dns.qry.name" -T fields -e dns.qry.name
tshark -r bm.pcap -Y "tls.handshake.extensions_server_name" -T fields -e tls.handshake.extensions_server_name
tshark -r bm.pcap -Y "http.host" -T fields -e http.host
```

### 6.3 🔑 Athena 四级正向证据（必须同一事件全出现）

```text
BMAthenaBridge ... ui_setting_button_click
track event: appid=5943 event=Drift_Sand _customTrackName=ui_setting_button_click
save event to DB: tid=594360000015
--> upload: host=...shalltry.com/.../athena/checkpoint/v3/upload
<-- upload success: code=0 message=suc
```

### 6.4 🔑 原厂零命中过滤器（负向门禁）

```text
dns.qry.name contains "afafb.com" || tls.handshake.extensions_server_name contains "afafb.com"
|| http.host contains "afafb.com"
|| dns.qry.name contains "blockblast.com" || tls.handshake.extensions_server_name contains "blockblast.com"
|| dns.qry.name contains "hungrystudio.com"
```
Athena 正向：`dns.qry.name contains "shalltry.com" || tls.handshake.extensions_server_name contains "shalltry.com"`

### 6.5 🔑 测试矩阵（覆盖不足则零命中不算通过）

3 次冷启动（清数据）· 完整一局 · 进大厅 · 广告 load/show · 无广告返回 · 前后台切换 · 设置开关 · 第二日条件。

### 6.6 ⚠️ 已知漏网：downloader guard 不覆盖自有 HTTP

```text
assets/main.js  guard 只重写：cc.assetManager.downloader.download   # 只挡资源下载
TraitServer 走的是：        Multilink → Http/requestAsync/XHR → 目标域名   # 绕过 guard
```
所以"远程资源下载被拦住"≠"零联网"。静态扫描在两个 main JS 中发现 **34 个原厂样式主机 / 1465 个 URL 引用**（存在不等于运行）。

### 6.7 埋点链路（JS → 原生）

```text
DS(name, params)  → NativeDot.callNativeDataUpload   → JsCallJava / AppActivity → BMAthenaBridge → Athena.track
DC(name, params)  → 30% 抽样 + sendState 门禁后同上
DP(name, params)  → NativeDot.callNativeBBPublish     → 同上（BBPublish 通道）
```
- appId 归属：5943=业务 `Drift_Sand`；4987=归因注册；8661/8765/1814/2411=Hisavana 各子模块；1044=Palm；9999=Athena 自诊断。
- ⚠️ **不要把第三方 SDK 中未初始化、未调用的常量误算成业务埋点**。

---

## 7. 静态嗅探的取证手法（APK / dex / so）

| 手段 | 工具/脚本 | 说明 |
|---|---|---|
| 反编译 | `tools\apktool_2.9.3.jar` | `apktool d` 出 smali + assets + Manifest |
| dex 类检查 | `scripts\dex_class_check.py`、`work\tools\*.py` | 定位类/方法 |
| so 字符串 | `scripts\grep_so.py`、`grep_all_so.py`、`list_so.py` | 找 SDK 特征 |
| 字符串定位 | `scripts\locate_string.py`、`show_ctx.py`、`string_bounds.py` | 上下文取证 |
| heap 提取 | `scripts\extract_js_from_heap.py`、`search_heap.py` | 运行时内存取明文 |
| Frida | `tools\frida-server-*`、`scripts\frida_*.py`（dump/scan/exports/modules） | 动态挂钩 |
| 清单/属性 | `work\tools\filter_manifest_moregames.py`、`patch_*`、`verify_*` | Manifest 过滤与校验 |
| PKM→PNG | `scripts\pkm_to_png.py` | ETC1 贴图转换（ETC2 明确报错） |

🔑 **`AndroidManifest.xml` 是 SDK 盘点的第一证据**（provider/service/so 三件套）。
📌 `/data/user/0/<pkg>/files/patch/` 是热更实际执行副本，与 APK assets 可能不同。

---

## 8. 文档 ↔ 嗅探路径对照表

| 结论文档 | 主要嗅探路径 | 关键参数/证据 |
|---|---|---|
| `两层全量美术资源统计.md` | 三块全量 **SHA1 精确哈希**（非估算），跨块共享按扩展名扣减 | `_full_art_scan.json`、`_duplicates/dedup_scan_all_layers.json`；本体/皮肤/Trait 三层 |
| `美术表现规则文档.md` | 解包产物 + Trait 命名 + `code_windows.json` | 120 皮肤、56 Spine、473 DB 骨架、7 个 LowDevice Trait |
| `低端机适配6.5详解.md` | 主包明文 + mainTraits + settings 三源交叉 | 装饰器挂载点、hook 名、feature id |
| `BlockMaster_SDK与联网拉取盘点.md` | Manifest + lib + assets 三处 | 9 广告 + 5 统计 + 4 渠道 + 基座组件 |
| `BlockMaster_V34_埋点事件与网络上报审计.md` | logcat 四级 + PCAP + 静态 URL 扫描 | 114 业务事件、34 主机、Firebase 状态 |
| `BlockMaster_原版广告策略还原_展示时机与瀑布.md` | `jsb.sqlite` 现场 + APK 云控 + 主包链路 + 真机日志 | `strategyEnable=111111`、`adLevel={noAd:1,end:10}` |
| `BlockMaster_广告策略全解.md` | 主逻辑明文（广告 Proxy 源码 + 装饰器注册表） | 预热 30s 延迟、冷启动保护链 |
| `BlockMaster_广告QA验证手册.md` | logcat 三组过滤 + hisavana 后台 | 广告位 ID、错误码 70011/204/429 |
| `BlockMaster_Android_SDK接入分析.md` | 源工程 `E:\blockh5\build\android_ps\proj` | PS/GP flavor、包名、版本 |
| `BlockMaster_v7_满配置包资源缺口清单.md` | v7 实包逐项 + base 对照 + 远程全量清单 | 缺口：远程 JS 9、皮肤 ~100、Trait ~4600 |
| `BlockMaster_v7_低端机专用包资源剔除清单.md` | v7 实包分层体积统计 | 剔除：小游戏、Lottie 458、皮肤、patch |

---

## 9. 复现清单（Checklist：重跑一次完整嗅探）

```
[ ] 0. 确认 python 用绝对路径；脚本存 UTF-8 BOM；避免 pwsh
[ ] 1. resindex where → 若 find 返回 0 条但报新鲜 ⇒ 重建 build_index.py
[ ] 2. 明细第三方工程：blockmaster_apk / bb_1047_base.apk / com.block.juggle.base.apk / 全量解包
[ ] 3. 读头判加密：HEK:v03→XOR ｜ HEK:v01→XXTEA ｜ AFFA→内层；保留密文副本
[ ] 4. 解密资源 decrypt_resources.py；解密 JS decrypt_jsc.py（多成员 gzip 循环）
[ ] 5. 静态解密失败 ⇒ 走 jsb.fileUtils.getStringFromFile() 运行时导出 / files/patch 热更通道
[ ] 6. JS 取证用 IndexOf + Substring 定点窗口；先查 trait_id_map / decorator_registry
[ ] 7. 远程包：download_remote_* → 在 named\ 而非 dec\ 找资源（清单 JSON 已在仓库中，生成脚本未保留）
[ ] 8. 配置取现场：jsb.sqlite（只读）+ mediation.json，记录所有 SHA256
[ ] 9. 网络：PCAPdroid/tcpdump + logcat 四级 + tshark 主机提取 + 测试矩阵
[ ] 10. 结论标注证据等级：✅实测 / ⚠️推断 / 🔑可复现参数；分区"能证明"与"不能证明"
```

---

## 10. 纪律与红线（比工具更重要）

1. **先找真实执行路径**：APK 中存在文件/字符串 ≠ 运行时使用它；桥接调用 ≠ 广告/埋点真正成功。
2. **分清证据等级**：静态结构 < 脚本测试 < 模拟器 < 真机画面/日志 < 网络抓包 < 平台后台确认。**不得互相替代**。
3. **分清版本角色**：当前直接重打包基底优先决定行为；旧 APK、历史抓包只作对照，不能混称"当前原版"。
4. **保留原版单一所有者**：视觉/输入/广告结算类问题，先找到原版负责 show/hide/restore/commit 的唯一 owner，禁止全局扫节点/清空对象池等覆盖式修补。
5. **低端机降级应减粒子/并发/时长/分辨率**，不得直接关闭整组 Trait，也不得把加载放进触摸/清屏热路径。
6. **不重新分发无授权的原始游戏资产、密钥或用户数据**；交付以脚本、映射、差异、验证报告、可复现步骤为主。
7. **Git 只纳入**源码/生成器/测试/配置快照/报告；**排除** APK、密钥、反编译树、缓存、临时文件、设备日志与截图（除非明确要求）。

---

## 附：本文档自身的不确定性

- ⚠️ 各 trait 的**实现体**多数在远程热更 bundle（本地未拉全，部分内层二次加密），本文只固化"怎么拿到"的路径，不断言具体实现值。
- ⚠️ 低端机判定的**具体阈值**（帧率线/内存/CPU/机型）在主包加密代码中；`memoryInfo.totalRAM > 4` 一例来自 mainTraits 明文，属孤证，不可外推为全部门槛。
- ⚠️ 广告侧"原厂服务器私有算法、账号历史学习、最终结算规则"客户端不可见，本文只覆盖"客户端可见策略 + 当时已缓存云控"。
- 🔑 命令中的 adb serial（`127.0.0.1:16384`、`1291437488049244`）与版本号均为**当时现场值**，重跑时须先实时发现当前设备与包版本。
