import glob
import os
import re
import zipfile

PATS = [b"65485d8a-8161-4c", b"93274615-a57e-4d", b"HEK:", b"\xaf\xfa\x00", b"xxtea", b"atomengine"]

so_dir = r"E:\codex_apk_work\libs_x86_64\lib\x86_64"
for p in sorted(glob.glob(os.path.join(so_dir, "*.so"))):
    try:
        data = open(p, "rb").read()
    except OSError:
        continue
    hits = []
    for pat in PATS:
        if pat in data:
            hits.append(pat.hex())
    if hits:
        print(os.path.basename(p), hits)
