# -*- coding: utf-8 -*-
"""Build/sign the V37 arm64 release from the formally signed V36 baseline."""
from __future__ import annotations

import os
import sys
import time
import zipfile

import build_v34_palm as base


W = base.W
STAGE = base.STAGE
OUT = os.path.abspath(os.environ.get("BLOCKMASTER_OUTPUT_DIR", W))
os.makedirs(OUT, exist_ok=True)

base.BASELINE = os.path.join(W, "BlockMaster_v36_palm_full.apk")
base.APKTOOL_ATTEMPT = os.path.join(OUT, "stage2_sdk_unsigned_v37_arm64.apk")
base.MERGED = os.path.join(OUT, "stage2_v37_arm64_merged.apk")
base.ALIGNED = os.path.join(OUT, "stage2_v37_arm64_aligned.apk")
base.FINAL = os.path.join(OUT, "BlockMaster_v37_palm_full_arm64.apk")
base.DEX_VERIFY = os.path.join(OUT, "tmp", "v37_verify_classes15")


def dex_path(number: int) -> str:
    return os.path.join(STAGE, "build", "apk", f"classes{number}.dex")


DEX_MARKERS = {
    4: b"BMAppsFlyerDisabled",
    8: b"BMVendorGuard",
    9: b"BMVendorGuard",
    13: b"BM_V36_ORIGINAL_ADX_DISABLED",
    14: b"26042852QVdSm3",
    15: b"FirebaseAnalytics",
}

base.DEX15 = dex_path(15)
base.REPLACEMENTS = {
    **{f"classes{number}.dex": dex_path(number) for number in DEX_MARKERS},
    "assets/mediation.json": os.path.join(STAGE, "assets", "mediation.json"),
    "assets/main.js": os.path.join(STAGE, "assets", "main.js"),
    "assets/assets/main/index.7d3cd.js": os.path.join(
        STAGE, "assets", "assets", "main", "index.7d3cd.js"),
    "assets/remote_seed/patch/patch/assets/main/index.146a7.js": os.path.join(
        STAGE, "assets", "remote_seed", "patch", "patch", "assets", "main", "index.146a7.js"),
}


def compile_all_changed_dex() -> None:
    for number in DEX_MARKERS:
        path = dex_path(number)
        if os.path.exists(path):
            os.remove(path)
    started = time.time()
    base.compile_and_verify_classes15()
    for number, marker in DEX_MARKERS.items():
        path = dex_path(number)
        if not os.path.isfile(path) or os.path.getmtime(path) < started:
            raise RuntimeError(f"classes{number}.dex was not freshly assembled")
        data = open(path, "rb").read()
        if marker not in data:
            raise RuntimeError(f"classes{number}.dex marker missing: {marker!r}")
        print(f"VERIFIED classes{number} marker={marker.decode('ascii')}")


def verify_final() -> None:
    base.verify_final_entries()
    with zipfile.ZipFile(base.FINAL, "r") as archive:
        names = archive.namelist()
        abis = sorted({name.split("/")[1] for name in names if name.startswith("lib/")})
        if abis != ["arm64-v8a"]:
            raise RuntimeError(f"unexpected ABI set: {abis}")
        for domain in (b"afafb.com", b"hungrystudio.com", b"blockblast.com"):
            if domain not in archive.read("classes8.dex") and domain not in archive.read("classes9.dex"):
                raise RuntimeError(f"runtime guard domain marker missing: {domain!r}")
        if b"BMAppsFlyerDisabled" not in archive.read("classes4.dex"):
            raise RuntimeError("AppsFlyer runtime guard missing from final APK")

    dump = base.run(f'"{base.BT}\\aapt2.exe" dump badging "{base.FINAL}"', 120)
    badging = (dump.stdout or "") + (dump.stderr or "")
    if "versionCode='1019'" not in badging or "versionName='1.0.1.9'" not in badging:
        raise RuntimeError("final version mismatch")
    if "native-code: 'arm64-v8a'" not in badging:
        raise RuntimeError("final APK is not arm64-only")


def main() -> None:
    base.run(f'"{sys.executable}" "{os.path.join(W, "verify_v37_transsion_only.py")}"', 120)
    compile_all_changed_dex()
    base.overlay_baseline()
    verify_final()


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("BUILD FAILED:", error, file=sys.stderr)
        sys.exit(1)
