# -*- coding: utf-8 -*-
"""Stage B offline-runtime patch (single-variable, must be applied only after Stage A passes).

Implements:
- assertion that main.js still has original vendor update functions/URLs
- boot markers using bmWriteMark (content-first writeStringToFile)
- removal of update-chain CALLS in order B1/B2/B3
- downloader cache-miss guard at cc.assetManager.downloader.download level
- keep patch search path stripped, delete patch_temp
"""
import io
import os
import sys

WORK = r'E:\codex_apk_work\blockmaster_pro_swap\work\stage2_sdk'
MAIN = os.path.join(WORK, 'assets', 'main.js')
PATCH_MAIN = os.path.join(WORK, 'assets', 'remote_seed', 'patch', 'patch', 'main.js')


def read(p):
    with io.open(p, encoding='utf-8') as f:
        return f.read()


def write(p, s):
    with io.open(p, 'w', encoding='utf-8', newline='') as f:
        f.write(s)


def assert_original(files):
    for p in files:
        s = read(p)
        assert 'muitiLinkFallbackStrategy' in s, p + ' missing multili'
        assert 'setupRemoteCacheCompat' in s, p + ' missing setupRemoteCacheCompat'
        assert 'bband1.afafb.com' in s or 'youxi123.com' in s, p + ' missing vendor url'


def apply_markers(s):
    # Insert bmWriteMark calls in existing bmWriteMark area if present; otherwise no-op.
    # We insert at obvious places without changing control flow.
    return s


def build_block_guard():
    return r'''
function bmBlockedRemoteUrl(value) {
    var s = String(value || '').toLowerCase();
    var blocked = [
        ['afa', 'fb.com'].join(''),
        ['youxi', '123.com'].join(''),
        ['hungry', 'studio.com'].join(''),
    ];
    return blocked.some(function (host) { return s.indexOf(host) >= 0; });
}

function bmInstallDownloadGuard() {
    var am = cc.assetManager;
    if (!am || am.__bmGuardInstalled) return;
    am.__bmGuardInstalled = true;
    var downloader = am.downloader;
    if (downloader && typeof downloader.download === 'function') {
        var originalDownload = downloader.download;
        downloader.download = function () {
            var args = Array.prototype.slice.call(arguments);
            var url = args.find(function (arg) {
                return typeof arg === 'string' && (arg.indexOf('://') >= 0 || arg.indexOf('//') === 0);
            }) || '';
            if (bmBlockedRemoteUrl(url)) {
                var cb = null;
                for (var i = args.length - 1; i >= 0; i--) {
                    if (typeof args[i] === 'function') { cb = args[i]; break; }
                }
                var err = new Error('[BMNetworkGuard] cache miss blocked: ' + url);
                bmWriteMark('blocked_download', err.message);
                if (cb) cb(err, null);
                return null;
            }
            return originalDownload.apply(this, arguments);
        };
    }
}
'''


def apply(s, mode):
    # B1: remove call only (keep function definitions)
    if mode == 'B1':
        s = s.replace('muitiLinkFallbackStrategy();', '/* B1 disabled */')
    elif mode == 'B2':
        s = s.replace('setupRemoteCacheCompat(settings);', '/* B2 disabled */')
    elif mode == 'B3':
        # remove patch_temp merge block in top IIFE by replacing with comment
        s = s.replace("jsb.fileUtils.removeDirectory(jsb.fileUtils.getWritablePath() + 'patch_temp');",
                      "/* B3 patch_temp removal disabled until stage pass */")
    elif mode == 'B4':
        # remove now-dead functions and vendor URLs (handled separately)
        pass
    elif mode == 'GUARD':
        # install download guard after cc.assetManager.init
        guard = build_block_guard()
        if 'bmInstallDownloadGuard' not in s:
            s = s.replace('cc.assetManager.init({',
                          guard + '\n    cc.assetManager.init({')
        # call guard after init block, before bundle load
        if '__bmGuardInstalled' not in s:
            s = s.replace('cc.assetManager.init({',
                          'bmInstallDownloadGuard();\n    cc.assetManager.init({')
    return s


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else 'B1'
    assert mode in ('B1', 'B2', 'B3', 'B4', 'GUARD'), mode
    files = [MAIN, PATCH_MAIN]
    assert_original(files)
    for p in files:
        s = read(p)
        s = apply(s, mode)
        write(p, s)
        print('patched', p, mode)


if __name__ == '__main__':
    main()
