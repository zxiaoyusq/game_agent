#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Convert blocklogo (Spine 3.8 JSON) -> DragonBones 5.5 JSON + atlas for in-place
replacement of the Block Blast chapter settlement skeleton (XCfive).

Animation names are kept as the game expects: HS_1..HS_5 (blocklogo) and
SO_1..SO_5 (blocklogo_master).  The armature is named "Armature" like the
original XCfive asset so the prefab needs no changes.
"""

import json
import math
import os

from PIL import Image

SPINE_JSON = r"C:\Users\nenghong.zhao\Downloads\blocklogo\blocklogo\blocklogo.json"
IMAGES_DIR = r"C:\Users\nenghong.zhao\Downloads\blocklogo\images"
OUT_DIR = r"E:\codex_apk_work\blockmaster_pro_swap\work\blocklogo_db"

FRAME_RATE = 30

# target DB animation name -> source Spine animation name
ANIM_MAP = {}
for i in range(1, 6):
    ANIM_MAP["HS_%d" % i] = "blocklogo"
    ANIM_MAP["SO_%d" % i] = "blocklogo_master"


def find_image(name):
    """Locate the source PNG for a spine region/attachment name."""
    # names may carry a subdir prefix like "tx/logo_sg_00000"
    rel = name.replace("\\", "/")
    cand = os.path.join(IMAGES_DIR, *rel.split("/")) + ".png"
    if os.path.exists(cand):
        return cand
    # Mojibake fallback: match by ascii prefix (e.g. image_text_锛? -> image_text_！.png)
    ascii_pre = "".join(c for c in name if ord(c) < 128)
    if ascii_pre:
        for root, _dirs, files in os.walk(IMAGES_DIR):
            for f in files:
                if f.endswith(".png"):
                    base = f[:-4]
                    if "".join(c for c in base if ord(c) < 128) == ascii_pre:
                        return os.path.join(root, f)
    raise FileNotFoundError("no image for %r" % name)


def pack_images(items):
    """items: list of (name, PIL.Image, w, h).  Shelf-pack into a square atlas."""
    # sort by height desc for a decent shelf packing
    items = sorted(items, key=lambda it: -it[2])
    total_area = sum(w * h for _n, _im, w, h in items)
    width = 256
    while width * width < total_area * 1.5:
        width *= 2
    canvas = Image.new("RGBA", (width, width), (0, 0, 0, 0))
    rects = {}
    x = y = 0
    row_h = 0
    for name, im, w, h in items:
        if x + w > width:
            x = 0
            y += row_h
            row_h = 0
        if y + h > width:
            width *= 2
            new_canvas = Image.new("RGBA", (width, width), (0, 0, 0, 0))
            new_canvas.paste(canvas, (0, 0))
            canvas = new_canvas
        canvas.paste(im, (x, y))
        rects[name] = (x, y, w, h)
        x += w + 1
        row_h = max(row_h, h)
    # trim canvas to content
    bbox = canvas.getbbox()
    if bbox:
        canvas = canvas.crop(bbox)
        # shift rects
        ox, oy = bbox[0], bbox[1]
        rects = {n: (rx - ox, ry - oy, w, h) for n, (rx, ry, w, h) in rects.items()}
    return canvas, rects


def sp_to_db_transform(att):
    t = {}
    if att.get("x"):
        t["x"] = round(att["x"], 4)
    if att.get("y"):
        t["y"] = round(att["y"], 4)
    rot = att.get("rotation") or 0
    if rot:
        t["skX"] = round(rot, 4)
        t["skY"] = round(rot, 4)
    sx = att.get("scaleX")
    sy = att.get("scaleY")
    if sx is not None and sx != 1:
        t["scX"] = round(sx, 4)
    if sy is not None and sy != 1:
        t["scY"] = round(sy, 4)
    return t


def main():
    sp = json.load(open(SPINE_JSON, encoding="utf-8"))
    skel = sp["skeleton"]

    # ---------- bones ----------
    db_bones = []
    for b in sp["bones"]:
        db = {"name": b["name"]}
        if b.get("parent"):
            db["parent"] = b["parent"]
        if b.get("length"):
            db["length"] = round(b["length"], 4)
        t = {}
        if b.get("x"):
            t["x"] = round(b["x"], 4)
        if b.get("y"):
            t["y"] = round(b["y"], 4)
        rot = b.get("rotation") or 0
        if rot:
            t["skX"] = round(rot, 4)
            t["skY"] = round(rot, 4)
        sx = b.get("scaleX")
        sy = b.get("scaleY")
        if sx is not None and sx != 1:
            t["scX"] = round(sx, 4)
        if sy is not None and sy != 1:
            t["scY"] = round(sy, 4)
        if t:
            db["transform"] = t
        db_bones.append(db)

    # ---------- skins / per-slot display lists ----------
    # collect attachments (ordered) for each slot from the default skin
    skin_data = sp["skins"][0]["attachments"] if sp.get("skins") else {}
    slot_displays = {}          # slot -> [(attName, attData)]
    default_att = {}            # slot -> default attachment name
    for s in sp["slots"]:
        slot_displays[s["name"]] = []
        default_att[s["name"]] = s.get("attachment")
    for slot_name, atts in skin_data.items():
        lst = slot_displays.setdefault(slot_name, [])
        for att_name, att in atts.items():
            lst.append((att_name, att))

    # ---------- slots ----------
    db_slots = []
    for s in sp["slots"]:
        db = {"name": s["name"], "parent": s["bone"]}
        displays = slot_displays.get(s["name"], [])
        if displays:
            names = [n for n, _a in displays]
            def_idx = names.index(default_att[s["name"]]) if default_att.get(s["name"]) in names else -1
            db["displayIndex"] = def_idx
        else:
            db["displayIndex"] = -1
        if s.get("color"):
            db["color"] = s["color"]
        if s.get("blend") and s["blend"] != "normal":
            db["blendMode"] = "add" if s["blend"] == "additive" else s["blend"]
        db_slots.append(db)

    # ---------- skin entries ----------
    skin_slots = []
    for slot_name, displays in slot_displays.items():
        if not displays:
            continue
        ds = []
        for att_name, att in displays:
            if att.get("type") == "mesh":
                # approximate mesh with plain image display (skip deform)
                d = {"name": att_name}
            else:
                d = {"name": att_name}
                t = sp_to_db_transform(att)
                if t:
                    d["transform"] = t
            ds.append(d)
        skin_slots.append({"name": slot_name, "display": ds})
    skin = [{"name": "default", "slot": skin_slots}]

    # ---------- animations ----------
    spine_anims = sp.get("animations", {})
    db_anims = []

    def frames_from_keys(keys, total_frames):
        """Convert spine key list [{time, ...}] to DB frames [{duration, ...}]."""
        out = []
        for i, k in enumerate(keys[:-1]):
            t0 = k.get("time", 0)
            t1 = keys[i + 1].get("time", 0)
            dur = max(1, round((t1 - t0) * FRAME_RATE))
            out.append((dur, k))
        used = sum(d for d, _ in out)
        if used < total_frames:
            out.append((total_frames - used, keys[-1]))
        return out

    for db_name, spine_name in ANIM_MAP.items():
        anim = spine_anims.get(spine_name)
        if not anim:
            print("WARN missing spine animation:", spine_name)
            continue
        # total duration: last key time across all timelines
        max_t = 0.0
        for group in (anim.get("bones", {}), anim.get("slots", {})):
            for _k, tl in group.items():
                if isinstance(tl, dict):
                    for sub in tl.values():
                        if isinstance(sub, list):
                            for k in sub:
                                max_t = max(max_t, k.get("time", 0))
                elif isinstance(tl, list):
                    for k in tl:
                        max_t = max(max_t, k.get("time", 0))
        for entry in anim.get("drawOrder", []):
            if isinstance(entry, dict):
                max_t = max(max_t, entry.get("time", 0))
        total_frames = max(1, round(max_t * FRAME_RATE))

        db_bone_anims = []
        for bone_name, tls in anim.get("bones", {}).items():
            entry = {"name": bone_name}
            tl = tls.get("translate")
            if tl:
                frames = []
                for dur, k in frames_from_keys(tl, total_frames):
                    fr = {"duration": dur}
                    if k.get("x") is not None:
                        fr["x"] = round(k["x"], 4)
                    if k.get("y") is not None:
                        fr["y"] = round(k["y"], 4)
                    curve = k.get("curve")
                    if curve == "stepped":
                        fr["tweenEasing"] = 0
                    elif isinstance(curve, list):
                        fr["curve"] = [round(v, 4) for v in curve]
                    frames.append(fr)
                entry["translateFrame"] = frames
            tl = tls.get("rotate")
            if tl:
                frames = []
                for dur, k in frames_from_keys(tl, total_frames):
                    fr = {"duration": dur}
                    if k.get("angle") is not None:
                        fr["rotate"] = round(k["angle"], 4)
                    curve = k.get("curve")
                    if curve == "stepped":
                        fr["tweenEasing"] = 0
                    elif isinstance(curve, list):
                        fr["curve"] = [round(v, 4) for v in curve]
                    frames.append(fr)
                entry["rotateFrame"] = frames
            tl = tls.get("scale")
            if tl:
                frames = []
                for dur, k in frames_from_keys(tl, total_frames):
                    fr = {"duration": dur}
                    if k.get("x") is not None:
                        fr["x"] = round(k["x"], 4)
                    if k.get("y") is not None:
                        fr["y"] = round(k["y"], 4)
                    curve = k.get("curve")
                    if curve == "stepped":
                        fr["tweenEasing"] = 0
                    elif isinstance(curve, list):
                        fr["curve"] = [round(v, 4) for v in curve]
                    frames.append(fr)
                entry["scaleFrame"] = frames
            if len(entry) > 1:
                db_bone_anims.append(entry)

        db_slot_anims = []
        for slot_name, tls in anim.get("slots", {}).items():
            entry = {"name": slot_name}
            tl = tls.get("attachment")
            if tl:
                names = [n for n, _a in slot_displays.get(slot_name, [])]
                frames = []
                for dur, k in frames_from_keys(tl, total_frames):
                    fr = {"duration": dur}
                    an = k.get("name")
                    fr["value"] = names.index(an) if an in names else -1
                    frames.append(fr)
                entry["displayFrame"] = frames
            tl = tls.get("color")
            if tl:
                frames = []
                for dur, k in frames_from_keys(tl, total_frames):
                    fr = {"duration": dur}
                    c = k.get("color", "ffffffff")
                    a = int(c[6:8], 16) if len(c) == 8 else 255
                    fr["value"] = {"aM": round(a / 255.0, 4)}
                    curve = k.get("curve")
                    if curve == "stepped":
                        fr["tweenEasing"] = 0
                    elif isinstance(curve, list):
                        fr["curve"] = [round(v, 4) for v in curve]
                    frames.append(fr)
                entry["colorFrame"] = frames
            if len(entry) > 1:
                db_slot_anims.append(entry)

        db_anims.append(
            {
                "duration": total_frames,
                "playTimes": 0,
                "name": db_name,
                "bone": db_bone_anims,
                "slot": db_slot_anims,
                "ffd": [],
            }
        )

    armature = {
        "type": "Armature",
        "frameRate": FRAME_RATE,
        "name": "Armature",
        "aabb": {
            "x": round(skel.get("x", -248.69), 4),
            "y": round(skel.get("y", -253.27), 4),
            "width": round(skel.get("width", 499.47), 4),
            "height": round(skel.get("height", 505.23), 4),
        },
        "bone": db_bones,
        "slot": db_slots,
        "skin": skin,
        "animation": db_anims,
        "defaultActions": [{"gotoAndPlay": "HS_4"}],
    }

    db = {
        "frameRate": FRAME_RATE,
        "name": "XCfive",
        "version": "5.5",
        "compatibleVersion": "5.5",
        "armature": [armature],
        "textureAtlas": [],
    }

    # ---------- atlas packing ----------
    used = set()
    for _slot, lst in slot_displays.items():
        for n, _a in lst:
            used.add(n)
    for _an, data in spine_anims.items():
        for _slot, tls in data.get("slots", {}).items():
            tl = tls.get("attachment")
            if tl:
                for k in tl:
                    if k.get("name"):
                        used.add(k["name"])

    items = []
    for name in sorted(used):
        p = find_image(name)
        im = Image.open(p).convert("RGBA")
        items.append((name, im, im.width, im.height))
    canvas, rects = pack_images(items)
    os.makedirs(OUT_DIR, exist_ok=True)
    atlas_png = os.path.join(OUT_DIR, "blocklogo_atlas.png")
    canvas.save(atlas_png)

    sub = [
        {"name": n, "x": x, "y": y, "width": w, "height": h}
        for n, (x, y, w, h) in sorted(rects.items())
    ]
    atlas = {
        "name": "XCfive",
        "imagePath": "XCfive_tex.png",
        "width": canvas.width,
        "height": canvas.height,
        "SubTexture": sub,
    }

    with open(os.path.join(OUT_DIR, "blocklogo_ske.json"), "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, separators=(",", ":"))
    with open(os.path.join(OUT_DIR, "blocklogo_atlas.json"), "w", encoding="utf-8") as f:
        json.dump(atlas, f, ensure_ascii=False, separators=(",", ":"))

    print("skeleton:", len(db_bones), "bones,", len(db_slots), "slots,", len(db_anims), "anims")
    print("atlas:", canvas.width, "x", canvas.height, "regions:", len(sub))
    print("OUT:", OUT_DIR)


if __name__ == "__main__":
    main()
