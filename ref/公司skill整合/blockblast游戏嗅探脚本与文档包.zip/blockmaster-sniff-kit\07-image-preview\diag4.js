﻿'use strict';
const fs = require('fs');
const vm = require('vm');

const HTML = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810/spine-preview/preview.html';
const SPINE_LIB = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/blast-block-spine/lib/spine-player.js';
const html = fs.readFileSync(HTML, 'utf8');
const m = html.match(/const DATA = (\[[\s\S]*?\]);\r?\nlet cur = -1;/);
const DATA = JSON.parse(m[1]);

const spineSrc = fs.readFileSync(SPINE_LIB, 'utf8');
const sandbox = {
  console, setTimeout, clearTimeout, setInterval, clearInterval,
  window: {}, document: {}, navigator: { userAgent: 'node' },
  atob: (b64) => Buffer.from(b64, 'base64').toString('latin1'),
  btoa: (s) => Buffer.from(s, 'latin1').toString('base64'),
  TextEncoder, TextDecoder,
  ArrayBuffer, DataView, Uint8Array, Uint16Array, Uint32Array,
  Int8Array, Int16Array, Int32Array, Float32Array, Float64Array,
  Math, JSON, Object, Array, Date, String, Number, Boolean,
  Error, TypeError, RangeError, Map, Set, parseFloat, parseInt, isNaN, isFinite,
};
vm.createContext(sandbox);
vm.runInContext(spineSrc, sandbox, { filename: 'spine-player.js' });
sandbox.DATA = DATA;

const sim = `
(function(){
  function b64ToU8(b64){ var bin=atob(b64); var u=new Uint8Array(bin.length);
    for(var i=0;i<bin.length;i++) u[i]=bin.charCodeAt(i); return u; }
  function decodeText(b64){ try { return decodeURIComponent(b64ToU8(b64).reduce(function(s,b){ return s+String.fromCharCode(b); }, '')); } catch(e){ return ''; } }
  function byteMap(s){ // proper -> 0xFF00+byte mojibake
    var bytes = new TextEncoder().encode(s);
    var out = '';
    for (var i=0;i<bytes.length;i++) {
      var b = bytes[i];
      out += b < 0x80 ? String.fromCharCode(b) : String.fromCharCode(0xFF00 + b);
    }
    return out;
  }
  function addAliases(atlas){
    var originals = atlas.regions.slice();
    for (var i=0;i<originals.length;i++){
      var r = originals[i];
      var alt = byteMap(r.name);
      if (alt !== r.name && !atlas.findRegion(alt)){
        var a = new spine.TextureAtlasRegion();
        a.name = alt; a.page = r.page; a.degrees = r.degrees; a.rotate = r.rotate;
        a.u = r.u; a.v = r.v; a.u2 = r.u2; a.v2 = r.v2;
        a.x = r.x; a.y = r.y; a.width = r.width; a.height = r.height;
        a.originalWidth = r.originalWidth; a.originalHeight = r.originalHeight;
        a.offsetX = r.offsetX; a.offsetY = r.offsetY; a.index = r.index;
        a.texture = r.texture;
        atlas.regions.push(a);
      }
    }
    return atlas;
  }
  function fakeTexture(){ return { setFilters:function(){}, setWraps:function(){}, getImage:function(){ return {width:2048,height:2048}; }, dispose:function(){} }; }
  var fails = [];
  var fixedAlias = 0;
  for (var i=0;i<DATA.length;i++){
    var it = DATA[i];
    var atlasText = decodeText(it.atlasUrl.split(',')[1]);
    var atlas = new spine.TextureAtlas(atlasText, function(p){ return fakeTexture(); });
    var before = atlas.regions.length;
    addAliases(atlas);
    fixedAlias += atlas.regions.length - before;
    try {
      var loader = new spine.AtlasAttachmentLoader(atlas);
      if (it.fmt === 'json') {
        var jsonText = decodeText(it.skelUrl.split(',')[1]);
        new spine.SkeletonJson(loader).readSkeletonData(JSON.parse(jsonText));
      } else {
        new spine.SkeletonBinary(loader).readSkeletonData(b64ToU8(it.skelUrl.split(',')[1]));
      }
    } catch(e) {
      fails.push({ name: it.name, bundle: it.bundle, err: (e && e.message) || String(e) });
    }
  }
  return { fails: fails, aliasesAdded: fixedAlias };
})();
`;
const out = vm.runInContext(sim, sandbox);
console.log('aliases added:', out.aliasesAdded);
console.log('remaining failures:', out.fails.length);
for (const f of out.fails) console.log(' ', f.bundle + '/' + f.name, '->', f.err);
