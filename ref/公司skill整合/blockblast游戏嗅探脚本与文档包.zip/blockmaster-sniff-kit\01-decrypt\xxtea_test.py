#!/usr/bin/env python3
"""Test XXTEA decryption of Block Blast v01 JS payloads."""
import struct
import sys

KEY = b"65485d8a-8161-4c"
DELTA = 0x9E3779B9
MASK = 0xFFFFFFFF


def _mx(y, z, sum_, p, e, k):
    return (((z >> 5) ^ (y << 2)) + ((y >> 3) ^ (z << 4))) ^ ((sum_ ^ y) + (k[(p & 3) ^ e] ^ z))


def xxtea_decrypt(data: bytes, key: bytes) -> bytes:
    if len(data) < 8:
        return data
    n = len(data) // 4
    v = list(struct.unpack("<%dI" % n, data[: n * 4]))
    k = list(struct.unpack("<4I", key[:16]))
    y = v[0]
    q = 6 + 52 // n
    s = (q * DELTA) & MASK
    while s:
        e = (s >> 2) & 3
        for p in range(n - 1, 0, -1):
            z = v[p - 1]
            v[p] = (v[p] - _mx(y, z, s, p, e, k)) & MASK
            y = v[p]
        z = v[n - 1]
        v[0] = (v[0] - _mx(y, z, s, 0, e, k)) & MASK
        y = v[0]
        s = (s - DELTA) & MASK
    return struct.pack("<%dI" % n, *v)


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else r"E:\codex_apk_work\blockblast_extracted\assets\main.js"
    data = open(path, "rb").read()
    print("file:", path, "len:", len(data))
    assert data[:4] == b"HEK:"
    ver = data[4]
    body = data[8:]
    pt = xxtea_decrypt(body, KEY)
    print("version:", ver, "body len:", len(body), "pt len:", len(pt))
    print("pt head:", pt[:64].hex(" "))
    print("pt head ascii:", repr(pt[:64]))
    if pt[:4] == b"\xaf\xfa\x00\x00":
        print("AFFA container:")
        print("  bytes 4..12:", pt[4:12].hex(" "))
        print("  u32le @4:", struct.unpack("<I", pt[4:8])[0])
        print("  u32le @8:", struct.unpack("<I", pt[8:12])[0])
        print("  payload[12:32]:", pt[12:32].hex(" "))


if __name__ == "__main__":
    main()
