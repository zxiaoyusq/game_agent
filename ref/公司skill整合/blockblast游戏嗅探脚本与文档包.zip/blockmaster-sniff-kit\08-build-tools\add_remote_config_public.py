# -*- coding: utf-8 -*-
import io
p = r'E:\codex_apk_work\blockmaster_pro_swap\work\stage2_sdk\res\values\public.xml'
with io.open(p, encoding='utf-8') as f:
    s = f.read()
if 'name="remote_config_defaults"' not in s:
    line = '    <public type="xml" name="remote_config_defaults" id="0x7f17000e" />\n'
    idx = s.rstrip().rfind('</resources>')
    s = s[:idx].rstrip() + '\n' + line + s[idx:]
    with io.open(p, 'w', encoding='utf-8', newline='') as f:
        f.write(s)
    print('added')
else:
    print('already present')
