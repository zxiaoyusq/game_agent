# -*- coding: utf-8 -*-
"""Merge missing com.transsion.upgradesdk resources into stage2_sdk and generate R overrides."""
import io
import json
import os
import re
import shutil
import sys

WORK = r'E:\codex_apk_work\blockmaster_pro_swap\work'
REF = os.path.join(WORK, 'blockmaster_apktool')
DST = os.path.join(WORK, 'stage2_sdk')
R_SMALI_DIR = os.path.join(WORK, '_bm_smali', 'smali_classes4', 'com', 'transsion', 'upgradesdk')
OUT_SMALI_DIR = os.path.join(DST, 'smali_classes14', 'com', 'transsion', 'upgradesdk')
OUT_JSON = os.path.join(WORK, 'upgradesdk_id_map.json')

# New ID starts (same as Hisavana merge, continue from current max)
NEW_ID_START = {
    'color': 0x7f060402,
    'dimen': 0x7f070514,
    'drawable': 0x7f0803c0,
    'mipmap': 0x7f100030,
    'id': 0x7f0a05f2,
    'layout': 0x7f0d01f9,
    'string': 0x7f14037d,
    'style': 0x7f15053a,
    'attr': 0x7f04061c,
}
VALUE_TYPES = {'color', 'dimen', 'string', 'style', 'id', 'attr', 'integer', 'bool'}


def parse_public(path):
    by_name = {}
    with io.open(path, encoding='utf-8') as f:
        txt = f.read()
    for m in re.finditer(r'<public type="([^"]+)" name="([^"]+)" id="(0x[0-9a-fA-F]+)"', txt):
        by_name[(m.group(1), m.group(2))] = int(m.group(3), 16)
    return by_name


def read_xml_entries(path):
    if not os.path.exists(path):
        return []
    with io.open(path, encoding='utf-8') as f:
        txt = f.read()
    entries = []
    tags = ('color', 'dimen', 'string', 'item', 'style', 'attr')
    for m in re.finditer(r'<(color|dimen|string|item|style|attr)\b', txt):
        start = m.start(); tag = m.group(1)
        i = m.end(); in_quote = False
        while i < len(txt):
            ch = txt[i]
            if ch == '"':
                in_quote = not in_quote
            elif ch == '>' and not in_quote:
                break
            i += 1
        if i >= len(txt):
            continue
        open_tag_end = i + 1
        open_tag = txt[start:open_tag_end]
        if open_tag.rstrip().endswith('/>'):
            element = open_tag
        else:
            close_tag = '</' + tag + '>'
            close_idx = txt.find(close_tag, open_tag_end)
            if close_idx == -1:
                continue
            element = txt[start:close_idx + len(close_tag)]
        nm = re.search(r'name="([^"]+)"', open_tag)
        if nm:
            entries.append((nm.group(1), element))
    return entries


def value_entry_matches(typ, name, xml):
    if typ == 'string' and '<string' in xml: return True
    if typ == 'color' and '<color' in xml: return True
    if typ == 'dimen' and '<dimen' in xml: return True
    if typ == 'style' and '<style' in xml: return True
    if typ == 'attr' and '<attr' in xml: return True
    if '<item' in xml and ('type="%s"' % typ) in xml: return True
    return False


def find_value_entry(ref, typ, name):
    vals_dir = os.path.join(ref, 'res', 'values')
    if not os.path.isdir(vals_dir):
        return None
    for fn in os.listdir(vals_dir):
        if not fn.endswith('.xml'):
            continue
        fp = os.path.join(vals_dir, fn)
        for nm, xml in read_xml_entries(fp):
            if nm == name and value_entry_matches(typ, name, xml):
                return xml
    return None


def value_file_for_type(typ):
    return {
        'color': 'colors.xml',
        'dimen': 'dimens.xml',
        'string': 'strings.xml',
        'style': 'styles.xml',
        'attr': 'attrs.xml',
        'id': 'ids.xml',
        'integer': 'integers.xml',
        'bool': 'bools.xml',
    }.get(typ, 'values.xml')


def append_to_values(dst_dir, typ, name, xml):
    fn = value_file_for_type(typ)
    os.makedirs(dst_dir, exist_ok=True)
    path = os.path.join(dst_dir, fn)
    if not os.path.exists(path):
        with io.open(path, 'w', encoding='utf-8') as f:
            f.write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n</resources>\n')
    with io.open(path, encoding='utf-8') as f:
        txt = f.read()
    if ('name="%s"' % name) in txt:
        return False
    idx = txt.rfind('</resources>')
    if idx == -1:
        raise RuntimeError('No </resources> in ' + path)
    txt = txt[:idx].rstrip() + '\n    ' + xml + '\n' + txt[idx:]
    with io.open(path, 'w', encoding='utf-8') as f:
        f.write(txt)
    return True


def copy_file_resources(ref, dst, typ, name):
    copied = []
    ref_res = os.path.join(ref, 'res')
    dst_res = os.path.join(dst, 'res')
    for dirpath, dirnames, filenames in os.walk(ref_res):
        rel = os.path.relpath(dirpath, ref_res)
        base = rel.split('-')[0] if rel != '.' else ''
        if base != typ:
            continue
        for fn in filenames:
            if fn == name or fn.startswith(name + '.'):
                src = os.path.join(dirpath, fn)
                dst_dir = os.path.join(dst_res, rel)
                os.makedirs(dst_dir, exist_ok=True)
                dst_file = os.path.join(dst_dir, fn)
                if not os.path.exists(dst_file):
                    shutil.copy2(src, dst_file)
                    copied.append(os.path.join(rel, fn))
    return copied


def main():
    dst_public = parse_public(os.path.join(DST, 'res', 'values', 'public.xml'))
    counters = {typ: start for typ, start in NEW_ID_START.items()}
    id_map = []
    public_entries = []

    for fn in sorted(os.listdir(R_SMALI_DIR)):
        if not fn.startswith('R$') or not fn.endswith('.smali'):
            continue
        typ = fn[2:-6]
        if typ == 'styleable':
            continue
        with io.open(os.path.join(R_SMALI_DIR, fn), encoding='utf-8') as f:
            txt = f.read()
        fields = []
        for m in re.finditer(r'\.field public static (\w+):I = 0x([0-9a-fA-F]+)', txt):
            fields.append((m.group(1), int(m.group(2), 16)))
        new_lines = []
        for name, old_id in fields:
            if (typ, name) in dst_public:
                new_id = dst_public[(typ, name)]
            else:
                # allocate new id
                new_id = counters[typ]
                counters[typ] += 1
                # add resource source
                added = False
                if typ in VALUE_TYPES:
                    xml = find_value_entry(REF, typ, name)
                    if xml is None and typ == 'id':
                        xml = '<item type="id" name="%s"/>' % name
                    if xml:
                        added = append_to_values(os.path.join(DST, 'res', 'values'), typ, name, xml)
                else:
                    copied = copy_file_resources(REF, DST, typ, name)
                    added = bool(copied)
                if not added:
                    print('WARN missing source', typ, name)
                    # still emit with allocated id? better skip? For safety, skip field.
                    continue
                public_entries.append((typ, name, new_id))
                dst_public[(typ, name)] = new_id
            id_map.append({'class': 'com.transsion.upgradesdk.R$' + typ, 'type': typ, 'name': name, 'old_id': old_id, 'new_id': new_id})
            new_lines.append('.field public static %s:I = 0x%08x\n' % (name, new_id))

        if new_lines:
            os.makedirs(OUT_SMALI_DIR, exist_ok=True)
            out_path = os.path.join(OUT_SMALI_DIR, fn)
            header = '.class public final Lcom/transsion/upgradesdk/R$%s;\n.super Ljava/lang/Object;\n\n# static fields\n' % typ
            with io.open(out_path, 'w', encoding='utf-8') as f:
                f.write(header)
                f.writelines(new_lines)
            print('generated', out_path)

    if public_entries:
        pub_path = os.path.join(DST, 'res', 'values', 'public.xml')
        with io.open(pub_path, encoding='utf-8') as f:
            txt = f.read()
        block = []
        for typ, name, new_id in sorted(public_entries, key=lambda x: (x[0], x[2])):
            block.append('    <public type="%s" name="%s" id="0x%08x" />' % (typ, name, new_id))
        idx = txt.rfind('</resources>')
        txt = txt[:idx].rstrip() + '\n' + '\n'.join(block) + '\n' + txt[idx:]
        with io.open(pub_path, 'w', encoding='utf-8') as f:
            f.write(txt)

    with io.open(OUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(id_map, f, ensure_ascii=False, indent=2)
    print('public_entries', len(public_entries))
    print('id_map', len(id_map))


if __name__ == '__main__':
    main()
