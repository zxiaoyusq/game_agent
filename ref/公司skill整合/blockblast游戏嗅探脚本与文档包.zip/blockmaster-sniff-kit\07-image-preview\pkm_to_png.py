#!/usr/bin/env python3
"""Convert ETC1 .pkm files (Cocos Creator 2.x) to .png.

PKM header observed (16 bytes):
    b"PKM 10" + 4 unknown bytes + u16 width + u16 height + u16 origW + u16 origH
Then ETC1 data: ceil(w/4)*ceil(h/4) * 8 bytes.
"""
import glob
import os
import struct
import sys

try:
    from PIL import Image
except ImportError:
    Image = None

MOD_TABLES = [
    [2, 8, -2, -8],
    [5, 17, -5, -17],
    [9, 29, -9, -29],
    [13, 42, -13, -42],
    [18, 60, -18, -60],
    [24, 80, -24, -80],
    [33, 106, -33, -106],
    [47, 183, -47, -183],
]


def expand5(v):
    return (v << 3) | (v >> 2)


def decode_block(blk):
    """Decode one 8-byte ETC1 block -> 4x4 RGB list (row-major)."""
    d = int.from_bytes(blk, "big")
    diff = (d >> 33) & 1
    flip = (d >> 32) & 1
    tbl = (d >> 29) & 7
    r1 = (d >> 59) & 0x1F
    g1 = (d >> 51) & 0x1F
    b1 = (d >> 43) & 0x1F
    if diff:
        # R1/G1/B1 are 5-bit; R2 = R1 + signed 3-bit delta
        def d3(v):
            return v - 8 if v & 8 else v

        r2 = (r1 + d3((d >> 56) & 7)) & 0x1F
        g2 = (g1 + d3((d >> 48) & 7)) & 0x1F
        b2 = (b1 + d3((d >> 40) & 7)) & 0x1F
        c1 = (expand5(r1), expand5(g1), expand5(b1))
        c2 = (expand5(r2), expand5(g2), expand5(b2))
    else:
        # 4-bit each, expanded by replication
        def e4(v):
            return v * 17

        c1 = (e4((d >> 60) & 0xF), e4((d >> 52) & 0xF), e4((d >> 44) & 0xF))
        c2 = (e4((d >> 56) & 0xF), e4((d >> 48) & 0xF), e4((d >> 40) & 0xF))

    mods = MOD_TABLES[tbl]
    idx_bits = d & 0xFFFFFFFF
    pix = [[0, 0, 0] for _ in range(16)]
    for py in range(4):
        for px in range(4):
            p = py * 4 + px
            shift = 30 - (p * 2)
            mi = (idx_bits >> shift) & 3
            # sub-block selection
            if flip:
                sb = 0 if px < 2 else 1
            else:
                sb = 0 if py < 2 else 1
            base = c1 if sb == 0 else c2
            m = mods[mi]
            pix[p] = [
                max(0, min(255, base[0] + m)),
                max(0, min(255, base[1] + m)),
                max(0, min(255, base[2] + m)),
            ]
    return pix


def decode_pkm(data):
    if data[:6] != b"PKM 10":
        raise ValueError("not ETC1 PKM")
    w, h, ow = struct.unpack(">HHH", data[10:16])
    oh = 0
    bw, bh = (w + 3) // 4, (h + 3) // 4
    body = data[16:]
    rgb = bytearray(w * h * 3)
    for by in range(bh):
        for bx in range(bw):
            off = (by * bw + bx) * 8
            pix = decode_block(body[off:off + 8])
            for py in range(4):
                for px in range(4):
                    x, y = bx * 4 + px, by * 4 + py
                    if x < w and y < h:
                        o = (y * w + x) * 3
                        rgb[o:o + 3] = bytes(pix[py * 4 + px])
    return w, h, ow, oh, bytes(rgb)


def main():
    if Image is None:
        print("Pillow missing; writing raw RGB only")
    roots = sys.argv[1:] or [r"E:\codex_apk_work\blockblast_decrypted"]
    total = 0
    for root in roots:
        for p in glob.glob(os.path.join(root, "**", "*.pkm"), recursive=True):
            with open(p, "rb") as f:
                data = f.read()
            w, h, ow, oh, rgb = decode_pkm(data)
            out = os.path.splitext(p)[0] + ".png"
            if Image is not None:
                img = Image.frombytes("RGB", (w, h), rgb)
                img.save(out, "PNG")
            else:
                with open(out, "wb") as f:
                    f.write(rgb)
            total += 1
            print(f"{os.path.basename(p):45s} {w}x{h} (orig {ow}x{oh}) -> {out}")
    print("converted", total, "pkm files")


if __name__ == "__main__":
    main()
