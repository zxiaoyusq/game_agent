﻿'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/材质皮肤-远程bundle-20260810';
const NAMED = path.join(ROOT, 'named');
const SPINE_LIB = 'E:/参考图/block录屏/解包素材/BlastBlock-美术资源全量-20260810/blast-block-spine/lib/spine-player.js';

const spineSrc = fs.readFileSync(SPINE_LIB, 'utf8');
const sandbox = {
  console, setTimeout, clearTimeout, setInterval, clearInterval,
  window: {}, document: {}, navigator: { userAgent: 'node' },
  atob: (b64) => Buffer.from(b64, 'base64').toString('latin1'),
  btoa: (s) => Buffer.from(s, 'latin1').toString('base64'),
  ArrayBuffer, DataView, Uint8Array, Uint16Array, Uint32Array,
  Int8Array, Int16Array, Int32Array, Float32Array, Float64Array,
  Math, JSON, Object, Array, Date, String, Number, Boolean,
  Error, TypeError, RangeError, Map, Set, parseFloat, parseInt, isNaN, isFinite,
};
vm.createContext(sandbox);
vm.runInContext(spineSrc, sandbox, { filename: 'spine-player.js' });

const cases = [
  ['Remote_Skin_Material_3017', 'revive_countdown_017'],
  ['Remote_Skin_Material_4007', 'gameplay_comboTips_4007'],
  ['Remote_Skin_Material_4078', 'gameplay_word_078'],
  ['Remote_Skin_Material_4081', 'revive_num_xin'],
];

for (const [bundle, stem] of cases) {
  const dir = path.join(NAMED, bundle);
  let binPath = null, atlasPath = null;
  (function walk(d) {
    for (const de of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, de.name);
      if (de.isDirectory()) walk(p);
      else if (de.name === stem + '.bin') binPath = p;
      else if (de.name === stem + '.atlas') atlasPath = p;
    }
  })(dir);
  if (!fs.existsSync(binPath) || !fs.existsSync(atlasPath)) { console.log('MISSING', bundle, stem); continue; }
  const atlasRaw = fs.readFileSync(atlasPath);
  const atlasTextUtf8 = atlasRaw.toString('utf8');
  const atlasTextGbk = Buffer.from(atlasRaw.toString('latin1'), 'latin1').toString('utf8'); // no-op, placeholder
  sandbox.atlasRaw = atlasRaw;
  sandbox.binB64 = fs.readFileSync(binPath).toString('base64');
  const res = vm.runInContext(`
    (function(){
      function b64ToU8(b64){ var bin=atob(b64); var u=new Uint8Array(bin.length);
        for(var i=0;i<bin.length;i++) u[i]=bin.charCodeAt(i); return u; }
      var out = {};
      var decoders = { utf8: (function(){ try { return new TextDecoder('utf-8').decode(new Uint8Array(atlasRaw)); } catch(e){ return ''; } })(), raw: (function(){ var u=new Uint8Array(atlasRaw); var s=''; for(var i=0;i<Math.min(u.length,40);i++) s+=String.fromCharCode(u[i]); return s; })() };
      out.atlasHeadHex = Array.prototype.slice.call(new Uint8Array(atlasRaw).subarray(0, 80)).map(function(b){ return b.toString(16).padStart(2,'0'); }).join(' ');
      // try decode atlas as utf8 and as latin1->gbk bytes passthrough
      function decodeUtf8(u){ var s=''; for(var i=0;i<u.length;){ var c=u[i]; var n=1; if(c>=0xF0){n=4;} else if(c>=0xE0){n=3;} else if(c>=0xC0){n=2;}
        if(n>1){ var cp=0; if(n===2) cp=((c&0x1F)<<6)|(u[i+1]&0x3F); else if(n===3) cp=((c&0x0F)<<12)|((u[i+1]&0x3F)<<6)|(u[i+2]&0x3F); else cp=((c&0x07)<<18)|((u[i+1]&0x3F)<<12)|((u[i+2]&0x3F)<<6)|(u[i+3]&0x3F);
          s+=String.fromCodePoint(cp); i+=n; } else { s+=String.fromCharCode(c); i+=1; } } return s; }
      var u8 = new Uint8Array(atlasRaw);
      out.atlasAsUtf8 = decodeUtf8(u8);
      out.atlasAsLatin1 = (function(){ var s=''; for(var i=0;i<u8.length;i++) s+=String.fromCharCode(u8[i]); return s; })();
      // parse atlas regions with utf8-decoded text
      var atlas = null;
      try { atlas = new spine.TextureAtlas(out.atlasAsUtf8, function(p){ return { setFilters:function(){}, setWraps:function(){}, getImage:function(){ return {width:2048,height:2048}; }, dispose:function(){} }; }); } catch(e){ out.atlasErr = e.message; }
      if (atlas) out.regionNames = atlas.regions.map(function(r){ return r.name; });
      // collect attachment paths requested by the skeleton
      var requested = [];
      var loader = {
        newRegionAttachment: function(skin,name,p){ requested.push('R:'+p); var a=new spine.RegionAttachment(p||name); a.region={u:0,v:0,u2:1,v2:1,originalWidth:1,originalHeight:1,offsetX:0,offsetY:0,width:1,height:1,rotate:false}; return a; },
        newMeshAttachment: function(skin,name,p){ requested.push('M:'+p); var a=new spine.MeshAttachment(p||name); a.region={u:0,v:0,u2:1,v2:1,originalWidth:1,originalHeight:1,offsetX:0,offsetY:0,width:1,height:1,rotate:false}; return a; },
        newBoundingBoxAttachment: function(skin,name){ return new spine.BoundingBoxAttachment(name); },
        newClippingAttachment: function(skin,name){ return new spine.ClippingAttachment(name); },
        newPathAttachment: function(skin,name){ return new spine.PathAttachment(name); },
        newPointAttachment: function(skin,name){ return new spine.PointAttachment(name); }
      };
      try { new spine.SkeletonBinary(loader).readSkeletonData(b64ToU8(binB64)); out.requested = requested; }
      catch(e){ out.binErr = (e && e.message) || String(e); }
      return out;
    })();
  `, sandbox);
  console.log('=== ' + bundle + '/' + stem + ' ===');
  console.log('atlas head hex:', res.atlasHeadHex);
  console.log('atlas utf8 first lines:', res.atlasAsUtf8.split('\n').slice(0, 10).join(' | '));
  console.log('atlas latin1 first lines:', res.atlasAsLatin1.split('\n').slice(0, 10).join(' | '));
  console.log('regions (first 12):', res.regionNames ? res.regionNames.slice(0, 12) : res.atlasErr);
  console.log('requested (first 12):', res.requested ? res.requested.slice(0, 12) : res.binErr);
  console.log('requested count:', res.requested ? res.requested.length : 0);
}
