﻿# Block Master V34 埋点事件与网络上报审计

> 生成时间：2026-08-19 19:11:23（Asia/Shanghai）  
> 审计对象：`stage2_sdk`、`BlockMaster_v34_palm_full.apk`、`diagnostics/v34_mumu` 的 5 份日志。  
> 版本：`1.0.1.7 / 1017`。本报告不把第三方 SDK 中未初始化、未调用的常量误算成业务埋点。

## 结论先行

1. **V34 的 BBPublish 业务调用已经改道到 Athena。** 显式 `DP` 事件经 `BMAthenaBridge.callNativeBBPublish` 最终调用 `AthenaSDK.track`，使用 appId `5943`、顶层事件 `Drift_Sand`。
2. **V34 目前不能认定为“与 Block Blast 原厂完全断网”。** 5 份启动日志都记录了 `https://gametester.afafb.com/game_init` 的真实请求和 HTTP 200 返回。
3. **现有下载 guard 只包住 `cc.assetManager.downloader.download`。** 它不覆盖游戏自己的 `Http/requestAsync/XMLHttpRequest`、WebView、libcurl 或原生 SDK 网络，所以会漏掉 `game_init` 这类请求。
4. **严格的“埋点只到 Athena”目前也尚未完成。** `FirebaseBridge` 每次启动都初始化 Firebase Analytics；即使没有发现自定义 `logEvent` 调用，自动采集仍可能向 Google 发送会话类事件。若最新要求以 Athena-only 为准，应关闭 Firebase Analytics collection。
5. V34 日志已经具备 Athena 四级正向证据：`track event`、`save event to DB`、`--> upload`、`<-- upload success code=0`。但负向的“其他域名为零”必须靠按应用抓包证明，不能只看 logcat。

## 1. BBPublish 是做什么的

BBPublish 不是一个固定服务器地址，而是 Block Blast 原业务埋点体系中的**一条发布侧路由/语义通道**。可以把它理解为同一批事件进入统计仓库前的“第三个投递口”：

| JS 入口 | 原始语义 | V34 当前去向 |
|---|---|---|
| `DS(name, params)` | 主业务事件 | `callNativeDataUpload` → Athena 5943 |
| `DC(name, params)` | 抽样/旧采集事件 | 30% 本地抽样及 sendState 门禁后 → Athena 5943 |
| `DP(name, params)` | BBPublish 显式发布事件 | `callNativeBBPublish` → Athena 5943 |

原代码还维护了 `BB_PUBLISH_EVENT_KEYS` 白名单，原意是让部分 DS/DC 事件再复制一份到 BBPublish。V34 已把 `uploadDotBBPublishIfNeeded()` 改成直接 `return`，因此这条**补充复制链路被关闭**，避免同一业务事件重复上报。当前仍保留的显式 DP 事件是 `g_game_server_data`。

BBPublish 原设计会把事件分为 `NORMAL / ERROR / OTHER`，错误类包括 `cocos_log_reporter`、`jsb_err_report`、`cocos_res_reporter`；同时过滤已知噪声错误，并准备附加 `res_version_v2`、`mult_game_version`。但 V34 的补丁虽然仍计算这份扩展对象，实际反射调用发送的是原始 `[event, params]`，扩展变量没有参与传输。

V34 的真实链路如下：

```text
DP('g_game_server_data', params)
  -> DotUploadType.BBPUBLISH
  -> NativeDot.callNativeBBPublish
  -> com/blockmaster/sdk/BMAthenaBridge.callNativeBBPublish
  -> AthenaSDK.track(name, params, '')
  -> appid=5943, event=Drift_Sand
  -> _customTrackName=g_game_server_data, _param=<原参数>
  -> *.shalltry.com/athena/checkpoint/v3/upload
```

因此，**在 V34 里 BBPublish 已不代表另一套原厂上传服务器，只是 Athena 的一个兼容入口**。

## 2. 当前是否只上传到 Athena

| 检查项 | 当前判定 | 证据 |
|---|---|---|
| DS/DC/DP 业务事件最终去向 | 通过 | 三条桥接均进入 `BMAthenaBridge`，再调用 `AthenaSDK.track` |
| BBPublish 补充重复上报 | 通过 | `uploadDotBBPublishIfNeeded()` 直接返回 |
| Athena 5943 落库和上传 | 通过 | 5 份日志存在 DB、upload、`code=0` |
| 原厂 Block Blast 网络为 0 | **失败** | 5 次 `gametester.afafb.com/game_init`，HTTP 200 |
| Firebase Analytics 为 0 | **未满足/需关闭** | 5 次 `FirebaseAnalytics initialized`；无自定义事件日志不等于无自动事件 |
| 4987 只注册归因且不产生事件 | **语义上未完全满足** | 自有代码只注册 referrer，但 Athena 仍为 4987 自动产生 `app_launch/page_enter` |

### 为什么 downloader guard 没挡住原厂请求

`assets/main.js` 的 guard 只重写了 Cocos 资源下载器：

```text
cc.assetManager.downloader.download -> 检查 afafb/hungrystudio -> 阻断
```

而启动 TraitServer 使用的是主包里的 HTTP 请求链，不经过 asset downloader：

```text
Multilink/TraitServer -> Http/requestAsync/XHR -> gametester.afafb.com/game_init
```

所以现象是：远程资源下载能被 guard 拦住，但原厂配置、算法、得分、活动、模型请求仍可能绕过。静态扫描在两份 main JS 中发现 34 个原厂样式主机、共 1465 个 URL 引用；静态存在不代表全部会运行，但说明仅靠 downloader guard 不足以给出零联网保证。

### 要达到 Athena-only 需要的改造边界

- 保留 DS/DC/DP → `BMAthenaBridge` → Athena 5943。
- 关闭 Firebase Analytics collection；如果仍需 Crashlytics，需单独确认是否保留，不能把 Firebase Analytics 与 Crashlytics 混为一项。
- 对 `gametester.afafb.com/game_init`、TraitServer、模型/得分/活动请求逐入口替换为本地 Seed 或确定性的本地回退；不能只在最外层粗暴断网，否则可能再次卡 Loading。
- guard 至少覆盖游戏自有 `Http/requestAsync/XMLHttpRequest` 与资源 downloader；原生 SDK 网络保持独立允许列表，避免误伤 Hisavana/Palm。
- 最终必须用抓包做负向门禁：原厂域名 DNS/TLS/HTTP 尝试数均为 0。

## 3. 网络请求分析与验收方法

### 3.1 推荐证据组合

| 层级 | 工具 | 能证明什么 | 不能单独证明什么 |
|---|---|---|---|
| 业务桥接 | logcat：BMAthenaBridge | JS 事件进入 Athena 桥 | 是否真正发到服务器 |
| Athena 队列 | logcat：save event to DB | 事件已入本地队列 | 网络是否成功 |
| Athena HTTP | logcat：upload/success | 发往哪个 Athena host、服务端是否 code=0 | 其他 SDK 是否另有连接 |
| 全量网络 | PCAPdroid/tcpdump + Wireshark | DNS、TLS SNI、HTTP Host 的完整目的地主机 | TLS 加密后的事件正文 |
| 后台核对 | Athena 控制台 | appId/TID/事件最终可查询 | 设备是否还访问其他域名 |

必须四层合并；Charles/mitmproxy 中“没看到请求”不能作为零联网证明，因为证书锁定、QUIC、原生 libcurl 或未走系统代理都会漏包。

### 3.2 真机无 root：PCAPdroid

1. 安装 PCAPdroid，捕获范围只选 `com.driftsand.game.blockmaster`。
2. 关闭其他 VPN，开始 PCAP 捕获；不要求 TLS 解密也能分析 DNS、IP、TLS SNI。
3. 清数据/清装后冷启动 3 次；每次进入大厅并完成一局。
4. 覆盖设置开关、前后台切换、广告 load/show、无广告返回、第二日条件等路径。
5. 停止捕获，导出 `bm_v34.pcap`，同时导出完整 logcat。

### 3.3 MuMu/root：tcpdump

```powershell
adb -s 127.0.0.1:16384 shell su -c "tcpdump -i any -s 0 -w /sdcard/bm_v34.pcap"
# 完成冷启动、实玩、广告、前后台测试后终止 tcpdump
adb -s 127.0.0.1:16384 pull /sdcard/bm_v34.pcap E:\codex_apk_work\bm_v34.pcap
```

如果 MuMu 镜像没有 tcpdump，优先使用 PCAPdroid；不要因为系统代理抓不到就判定没有请求。

### 3.4 Athena 四级日志

```powershell
adb -s 1291437488049244 shell setprop log.tag.Athena DEBUG
adb -s 1291437488049244 shell setprop debug.athena.test_mode false
adb -s 1291437488049244 logcat -c
# 启动游戏并触发一个容易识别的事件，例如 ui_setting_button_click
adb -s 1291437488049244 logcat -d -v threadtime > E:\codex_apk_work\bm_v34_network_logcat.txt
```

验收同一事件必须同时出现：

```text
BMAthenaBridge ... ui_setting_button_click
track event: appid=5943 event=Drift_Sand _customTrackName=ui_setting_button_click
save event to DB: tid=594360000015
--> upload: host=...shalltry.com/.../athena/checkpoint/v3/upload
<-- upload success: code=0 message=suc
```

### 3.5 Wireshark/tshark 主机提取

```powershell
tshark -r E:\codex_apk_work\bm_v34.pcap -Y "dns.qry.name" -T fields -e dns.qry.name
tshark -r E:\codex_apk_work\bm_v34.pcap -Y "tls.handshake.extensions_server_name" -T fields -e tls.handshake.extensions_server_name
tshark -r E:\codex_apk_work\bm_v34.pcap -Y "http.host" -T fields -e http.host
```

原厂零命中过滤器：

```text
dns.qry.name contains "afafb.com" ||
tls.handshake.extensions_server_name contains "afafb.com" ||
http.host contains "afafb.com" ||
dns.qry.name contains "blockblast.com" ||
tls.handshake.extensions_server_name contains "blockblast.com" ||
dns.qry.name contains "hungrystudio.com"
```

Athena 正向过滤器：

```text
dns.qry.name contains "shalltry.com" ||
tls.handshake.extensions_server_name contains "shalltry.com"
```

### 3.6 最终通过标准

- `afafb.com / blockblast.com / hungrystudio.com` 的 DNS、TLS SNI、HTTP Host 均为 0。
- 5943 业务事件具备创建、落库、上传、服务端成功四级证据。
- PCAP 中允许出现 Hisavana/Palm/广告供应商的功能请求，但它们必须单列，不能误称为 Athena。
- 若严格要求所有分析数据只到 Athena，PCAP 中不得出现 Firebase/Google Analytics、AppsFlyer、ThinkingData 等分析端点。
- 网络断开时仍能启动、进大厅、完成至少一局；联网时不依赖恢复原厂服务器。
- 仅 PCAP 零命中但游戏未覆盖实际场景，不算通过；测试矩阵必须覆盖 3 次冷启动、完整一局、广告、前后台、第二日条件。

## 4. 业务埋点事件清单

静态字面量、AtomEngine 动态适配、运行时动态事件和原生启动事件合计 **114 个已知业务事件名**。`实测命中` 是 5 份 V34 MuMu 日志中的匹配行数；部分日志时间段重叠，不能当成生产事件次数。

| 类别 | 事件名 | 通道与最终原理 | 触发条件 | 源位置 | 实测命中 |
|---|---|---|---|---|---:|
| UI | `ui_achievement_award_click` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 点击领取成就奖励时。 | `Achievement_Awards_Item.prototype.onAwardClick (index.7d3cd.js:5268)` | 0 |
| UI | `ui_marketing_activity_button_click` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 点击营销活动按钮或打开活动链接时。 | `AddActivityCommonBtn.prototype.onClick (index.7d3cd.js:6942)；AddActivityCommonStart.prototype.onOpenUrl (index.7d3cd.js:7030)` | 0 |
| UI | `ui_marketing_activity_png_click` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 点击营销活动图片/分页入口时。 | `AddActivityCommonStart.prototype.onPageOne (index.7d3cd.js:7019)；AddActivityCommonStart.prototype.onPage (index.7d3cd.js:7024)` | 0 |
| UI | `ui_setting_bgm_button_click` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 设置页点击背景音乐开关时。 | `Setup_Proxy.prototype.onClick_BGM (index.7d3cd.js:142242)` | 0 |
| UI | `ui_setting_button_click` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 主页点击设置按钮时。 | `HomePageAccountUI.prototype.onSettingBtnClick (index.7d3cd.js:80530)` | 0 |
| UI | `ui_setting_button_close` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 设置面板关闭或组件 onDisable 时。 | `SetupIos.prototype.onDisable (index.7d3cd.js:141400)；Setup.prototype.onDisable (index.7d3cd.js:143037)` | 0 |
| UI | `ui_setting_feedback_click` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 反馈面板点击关闭/反馈动作时。 | `NewFeedbackView.prototype.clickPoint (index.7d3cd.js:120557)；NewFeedbackView.prototype.clickPoint (index.7d3cd.js:120566)` | 0 |
| UI | `ui_setting_feedback_show` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 反馈面板显示时。 | `NewFeedbackView.prototype.clickPoint (index.7d3cd.js:120554)` | 0 |
| UI | `ui_setting_home_button_click` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 设置页点击返回主页时。 | `Setup_Proxy.prototype.onClick_home (index.7d3cd.js:142205)` | 0 |
| UI | `ui_setting_moresetting_contactus` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | More Settings 中确认联系/反馈时。 | `CommentSkin_proxy.prototype.onConfirmClickFeedback (index.7d3cd.js:42853)` | 0 |
| UI | `ui_setting_replay_button_click` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 设置页点击重新开始时。 | `Setup_Proxy.prototype.onClick_replay (index.7d3cd.js:142235)` | 0 |
| UI | `ui_setting_show` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 设置面板完成显示时。 | `Setup_Proxy.prototype.onSetupShow (index.7d3cd.js:142146)` | 0 |
| UI | `ui_setting_sound_button_click` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 设置页点击音效开关时。 | `Setup_Proxy.prototype.onClick_sound (index.7d3cd.js:142249)` | 0 |
| UI | `ui_setting_vibration_button_click` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 设置页点击振动开关时。 | `Setup_Proxy.prototype.onClick_vibration (index.7d3cd.js:142255)` | 0 |
| UI | `ui_theme_achievement_click` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 点击成就入口时。 | `Achievement_Entrance.prototype.btnClickDsUp (index.7d3cd.js:5594)` | 0 |
| UI | `ui_theme_classic_click` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 点击经典模式入口时。 | `HomePage_Game_Proxy.prototype.onEnterClass (index.7d3cd.js:82427)` | 5 |
| UI | `ui_theme_icon_click` | DC → 30% 本地抽样 + sendState 门禁 → hsEventTrack → Athena 5943/Drift_Sand | 点击主题/模式/MoreGames/合并方块等图标入口时；多个 UI 组件共用。 | `Achievement_Entrance.prototype.onClick (index.7d3cd.js:5587)；GameLobbyGameLobbyNewEntry.prototype.onClick (index.7d3cd.js:67504)；GameLobbyGlhallMoreGamesPopupItem.prototype.onClickedItem (index.7d3cd.js:67748)；HomePageGameListItem.prototype.onClick (index.7d3cd.js:80651)；HomePageSectionBottomTabDefault.prototype.onClickTab (index.7d3cd.js:81237)；HomePageSectionChapterBtnDefault.prototype.doEnterChapter (index.7d3cd.js:81409)；HomePageSectionClassBtnDefault.prototype.onClick (index.7d3cd.js:81504)；HomePageSectionMoreGameBtnDefault.prototype.onMoreGameClick (index.7d3cd.js:82032)；HomePage_Game_Proxy.prototype.onEnterMergeBlocks (index.7d3cd.js:82434)` | 0 |
| UI | `ui_theme_moregame_button_click` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 点击 MoreGames 主入口时。 | `GameLobbyGameLobbyNewEntry.prototype.onClick (index.7d3cd.js:67495)` | 0 |
| UI | `ui_theme_sand_click` | DC → 30% 本地抽样 + sendState 门禁 → hsEventTrack → Athena 5943/Drift_Sand | 点击 Sand 模式入口时。 | `Sand_Proxy.prototype.onSandClick (index.7d3cd.js:138111)` | 0 |
| UI | `ui_theme_show` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 主题主页/主题入口完成曝光时。 | `HomePage_Proxy.prototype.onThemeShowDot (index.7d3cd.js:83083)` | 0 |
| UI | `ui_theme_travel_click_button` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 点击 Journey/Travel 模式入口时。 | `HomePage_Game_Proxy.prototype.enterChapterScene (index.7d3cd.js:82562)` | 0 |
| 原生启动 | `game_logo_ga` | Native → AthenaSDK.trackCommon；顶层事件为 game_logo_ga | AppActivity 首次创建且 savedInstanceState 为空时；调用发生在 DStudio/Athena 初始化之前。 | `AppActivity.onCreate → AthenaSDK.trackCommon` | 0 |
| 启动/生命周期 | `g_game_reinstall_success` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 安装判定流程识别为重装时。 | `Launch_Dot_Proxy.prototype.onInstallDot (index.7d3cd.js:90138)` | 3 |
| 启动/生命周期 | `game_launch` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 启动性能数据就绪并生成游戏启动快照时。 | `Device_Score_Proxy.prototype.reportGameLaunchData (index.7d3cd.js:50995)` | 0 |
| 启动/生命周期 | `usr_data_enter_bg` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 游戏切入后台时。 | `Game_Proxy.prototype.onGameHideDot (index.7d3cd.js:75405)` | 0 |
| 启动/生命周期 | `usr_data_enter_first` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 每次启动流程开始时。 | `Launch_Dot_Proxy.prototype.onLaunchStart (index.7d3cd.js:90117)` | 5 |
| 启动/生命周期 | `usr_data_enter_game` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 游戏回到前台/进入游戏可见态时。 | `Game_Proxy.prototype.onGameShowDot (index.7d3cd.js:75400)` | 0 |
| 启动/生命周期 | `usr_data_install` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 首次安装记录写入时。 | `Launch_Dot_Proxy.prototype.onInstallDot (index.7d3cd.js:90135)` | 3 |
| 小游戏/AtomEngine | `atomengine_game_common_execution_failed` | DC → 30% 本地抽样 + sendState 门禁 → hsEventTrack → Athena 5943/Drift_Sand | AtomEngine 通用执行动作失败时。 | `AtomEngineReportAdapterInfo.report(eventName, data)` | 0 |
| 小游戏/AtomEngine | `lightweight_adventure_enter_gamebox_failed` | DC → 30% 本地抽样 + sendState 门禁 → hsEventTrack → Athena 5943/Drift_Sand | 进入轻量冒险 GameBox 失败时。 | `AtomEngineReportAdapterInfo.report(eventName, data)` | 0 |
| 小游戏/AtomEngine | `lightweight_adventure_entrance_click` | DC → 30% 本地抽样 + sendState 门禁 → hsEventTrack → Athena 5943/Drift_Sand | 轻量冒险入口被点击时。 | `AtomEngineReportAdapterInfo.report(eventName, data)` | 0 |
| 小游戏/AtomEngine | `lightweight_adventure_entrance_show` | DC → 30% 本地抽样 + sendState 门禁 → hsEventTrack → Athena 5943/Drift_Sand | 轻量冒险入口首次曝光；按入口类型做本地去重。 | `AtomEngineReportAdapterInfo.report(eventName, data)` | 0 |
| 小游戏/AtomEngine | `mini_game_entrance_click` | DC → 30% 本地抽样 + sendState 门禁 → hsEventTrack → Athena 5943/Drift_Sand | 小游戏入口被点击时。 | `AtomEngineReportAdapterInfo.report(eventName, data)` | 0 |
| 小游戏/AtomEngine | `mini_game_start_download` | DC → 30% 本地抽样 + sendState 门禁 → hsEventTrack → Athena 5943/Drift_Sand | 小游戏开始下载时。 | `AtomEngineReportAdapterInfo.report(eventName, data)` | 0 |
| 小游戏/AtomEngine | `mini_game_stop_download` | DC → 30% 本地抽样 + sendState 门禁 → hsEventTrack → Athena 5943/Drift_Sand | 小游戏下载停止、超时或失败时。 | `AtomEngineReportAdapterInfo.report(eventName, data)` | 0 |
| 广告/归因 | `ad_lowecpm_sub` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 低 eCPM 广告替代/订阅策略生成上报数据时。 | `AdxModelReplaceAdCtrl.prototype.sendAdLowEcpmSubEvent (index.7d3cd.js:9863)` | 0 |
| 广告/归因 | `g_game_attribution_all_requestresult` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | AppsFlyer/归因汇总结果回调完成时。 | `Attribution_Dot_Proxy.prototype.onAppsflyerResult (index.7d3cd.js:25737)` | 0 |
| 广告/归因 | `g_game_attribution_experiment_request` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 带归因条件的实验请求发出时。 | `TraitServerCampaign_Dot_Proxy.prototype.handleRequest (index.7d3cd.js:208152)` | 0 |
| 广告/归因 | `g_game_attribution_experiment_requestresult` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 归因实验请求返回时。 | `TraitServerCampaign_Dot_Proxy.prototype.handleResponse (index.7d3cd.js:208160)` | 0 |
| 广告/归因 | `g_game_attribution_gad_abtest_request` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 检测到 Google Ads campaign id 后发起 AB 请求时。 | `TraitServerCampaign_Dot_Proxy.prototype.onTraitServerState (index.7d3cd.js:208124)；TraitServerCampaign_Dot_Proxy.prototype.handleRequest (index.7d3cd.js:208146)` | 0 |
| 广告/归因 | `g_game_attribution_gad_native_initiative_requestresult` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 原生主动读取 Google Ads campaign 结果成功时。 | `NativeAttribution.e.getCampaignInfo (index.7d3cd.js:118208)` | 0 |
| 广告/归因 | `g_game_attribution_gad_native_request` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 开始向原生层读取 Google Ads campaign 信息时。 | `NativeAttribution.e.getCampaignInfo (index.7d3cd.js:118203)` | 0 |
| 广告/归因 | `g_game_attribution_gad_native_requestresult` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 原生 Google Ads campaign 结果回调时。 | `Attribution_Dot_Proxy.prototype.onGadResult (index.7d3cd.js:25748)` | 0 |
| 广告/归因 | `g_game_attribution_preinstalledsources_requestresult` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 归因结果包含预装来源信息时。 | `Attribution_Dot_Proxy.prototype.onAppsflyerResult (index.7d3cd.js:25741)` | 0 |
| 广告/归因 | `g_game_attribution_requestresult` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 归因信息发生变化并被业务层接收时。 | `TraitServerCampaign_Dot_Proxy.prototype.handleAttributionChanged (index.7d3cd.js:208168)` | 0 |
| 广告/归因 | `g_game_native_push_attribution_before_ab_request_arrive` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 原生 Google Ads 归因先于 AB 请求结果到达时。 | `TraitServerCampaign_Dot_Proxy.prototype.handleNativePushBeforeAbRequest (index.7d3cd.js:208132)；TraitServerCampaign_Dot_Proxy.prototype.handleNativePushBeforeAbRequest (index.7d3cd.js:208136)` | 0 |
| 广告/归因 | `moregame_hall_download_success` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | MoreGames/小游戏 bundle 预加载成功时。 | `GameLobby_DataInfo.prototype.preLoadMiniGameByBundleName (index.7d3cd.js:68382)` | 0 |
| 广告/归因 | `usr_data_ad_preload` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 广告预加载流程或 Sand 广告预加载桥接启动时。 | `Advertisement_Load_Proxy.prototype.onDot (index.7d3cd.js:9222)；SandBridge.sand.BBA_ClickDeviceModele_usr_data_ad_preload (index.7d3cd.js:137093)` | 0 |
| 广告/归因 | `usr_data_ad_show` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 原生广告展示结果回调时。 | `AdvertisementNativeInfo.prototype.onDot (index.7d3cd.js:8683)` | 0 |
| 服务端/AB | `abtest_version_comparison` | DC → 30% 本地抽样 + sendState 门禁 → hsEventTrack → Athena 5943/Drift_Sand | 本地与服务端 AB/trait 版本完成比较时。 | `TraitServer_ToNative_Proxy.prototype.trackAbtestVersionComparison (index.7d3cd.js:212932)` | 0 |
| 服务端/AB | `abtest_wudiban_change_success` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 无底板方案触发回退并成功切换配置时。 | `TraitServer_Dot_Proxy.prototype.handleNoButtomPlateFallback (index.7d3cd.js:211039)` | 0 |
| 服务端/AB | `g_game_abtest_flow_result_request_success` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | TraitServer AB 请求开始并形成请求阶段快照时。 | `TraitServerABTestFlowDotInfo.prototype.reportRequestStart (index.7d3cd.js:207539)` | 5 |
| 服务端/AB | `g_game_abtest_flow_result_response_success` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | TraitServer AB 请求收到有效响应时。 | `TraitServerABTestFlowDotInfo.prototype.reportResponseSuccess (index.7d3cd.js:207548)` | 5 |
| 服务端/AB | `g_game_abtest_flow_result_settings_end` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | TraitServer AB 配置落地阶段结束时。 | `TraitServerABTestFlowDotInfo.prototype.reportSettingsEnd (index.7d3cd.js:207564)` | 5 |
| 服务端/AB | `g_game_apply_trait_ids_arrive` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | Seed 版本的 TraitConfig 收到并应用 trait IDs 时。 | `TraitConfig_Dot_Proxy.prototype.handleTraitIdsArrive (index.146a7.js:204638)` | 0 |
| 服务端/AB | `g_game_server_data` | DP → callNativeBBPublish → BMAthenaBridge → Athena 5943/Drift_Sand | TraitServer 配置成功应用后，通过显式 DP/BBPublish 通道上报服务端数据摘要。 | `TraitServer_Dot_Proxy.prototype.handleApplyConfigSuccess (index.7d3cd.js:210990)` | 3 |
| 服务端/AB | `g_login_trait_ids_arrive` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 登录启动阶段收到 trait IDs 时。 | `TraitServer_Dot_Proxy.prototype.handleTraitIdsArrive (index.7d3cd.js:211082)` | 2 |
| 服务端/AB | `trait_server_outer_boundary_fallback` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | TraitServer 触发外边界回退策略时。 | `TraitServer_OuterBoundaryFallback_Proxy.prototype.reportOuterBoundaryFallbackDot (index.7d3cd.js:211467)` | 0 |
| 服务端/AB | `updateflow` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 热更新、多链路或性能指标模块报告更新阶段变化时。 | `HotUpdate_Proxy.prototype.dotUpdateFlow (index.7d3cd.js:83971)；MetricReporter.a.reportMetric (index.7d3cd.js:113516)；Multilink_Dot_Proxy.prototype.onUpdateFlow (index.7d3cd.js:116751)` | 10 |
| 服务端/AB | `usr_data_AB` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 游戏玩法 AB 方案进入/生效时。 | `GameWay_Dot_Proxy.prototype.onDot (index.7d3cd.js:75109)；GameWay_Dot_Proxy.prototype.onDot (index.7d3cd.js:75116)` | 2 |
| 服务端/AB | `usr_data_AB_quit` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 离开当前玩法 AB 方案时。 | `GameWay_Dot_Proxy.prototype.onDot (index.7d3cd.js:75113)` | 0 |
| 服务端/AB | `usr_data_AB_quit_server` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | TraitServer 活跃实验变化并退出旧方案时。 | `TraitServer_Dot_Proxy.prototype.handleActiveChanged (index.7d3cd.js:211012)` | 0 |
| 服务端/AB | `usr_data_AB_server` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | TraitServer 活跃实验保持或切换后形成 AB 快照时。 | `TraitServer_Dot_Proxy.prototype.handleActiveRemainUnChanged (index.7d3cd.js:211004)；TraitServer_Dot_Proxy.prototype.handleActiveChanged (index.7d3cd.js:211016)` | 0 |
| 服务端/AB | `usr_data_login_server_apply_fail_old` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 旧 TraitServer 配置应用失败时。 | `TraitServer_Dot_Proxy.prototype.handleServerApplyConfigFail (index.7d3cd.js:210967)` | 0 |
| 服务端/AB | `usr_data_login_server_hot_result` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 热更新/登录服务器结果回调时。 | `HotUpdate_Proxy.prototype.dotServer (index.7d3cd.js:83948)` | 0 |
| 服务端/AB | `usr_data_server_1` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | TraitServer 纯桶就绪或开始请求时。 | `TraitServer_Dot_Proxy.prototype.handlePureBucketReady (index.7d3cd.js:210870)；TraitServer_Dot_Proxy.prototype.handleRequest (index.7d3cd.js:210891)` | 5 |
| 服务端/AB | `usr_data_server_1new` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 与 usr_data_server_1 同阶段的新结构版本。 | `TraitServer_Dot_Proxy.prototype.handlePureBucketReady (index.7d3cd.js:210875)；TraitServer_Dot_Proxy.prototype.handleRequest (index.7d3cd.js:210892)` | 5 |
| 服务端/AB | `usr_data_server_2` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | TraitServer 收到响应时。 | `TraitServer_Dot_Proxy.prototype.handleResponse (index.7d3cd.js:210896)` | 5 |
| 服务端/AB | `usr_data_server_2new` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 与 usr_data_server_2 同阶段的新结构版本。 | `TraitServer_Dot_Proxy.prototype.handleResponse (index.7d3cd.js:210901)` | 5 |
| 服务端/AB | `usr_data_server_3` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | TraitServer 配置为空、不可用或本地保存结果形成时。 | `TraitServer_Dot_Proxy.prototype.handleExperimentDataNULL (index.7d3cd.js:210931)；TraitServer_Dot_Proxy.prototype.handleConfigNULL (index.7d3cd.js:210941)；TraitServer_Dot_Proxy.prototype.handleCanNotUseConfig (index.7d3cd.js:210951)；TraitServer_Dot_Proxy.prototype.handleSaveConfigSuccess (index.7d3cd.js:210962)` | 5 |
| 服务端/AB | `usr_data_server_3new` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 与 usr_data_server_3 同阶段、去除 traceId 的新结构版本。 | `TraitServer_Dot_Proxy.prototype.handleExperimentDataNULL (index.7d3cd.js:210932)；TraitServer_Dot_Proxy.prototype.handleConfigNULL (index.7d3cd.js:210942)；TraitServer_Dot_Proxy.prototype.handleCanNotUseConfig (index.7d3cd.js:210952)；TraitServer_Dot_Proxy.prototype.handleSaveConfigSuccess (index.7d3cd.js:210963)` | 5 |
| 服务端/AB | `usr_data_server_4` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | TraitServer 配置成功应用时。 | `TraitServer_Dot_Proxy.prototype.handleApplyConfigSuccess (index.7d3cd.js:210985)` | 5 |
| 服务端/AB | `usr_data_server_4new` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 与 usr_data_server_4 同阶段、去除 traceId 的新结构版本。 | `TraitServer_Dot_Proxy.prototype.handleApplyConfigSuccess (index.7d3cd.js:210986)` | 5 |
| 玩法/用户 | `app_setting_humansound_success` | DC → 30% 本地抽样 + sendState 门禁 → hsEventTrack → Athena 5943/Drift_Sand | 无网络提示场景的人声/提示音成功播放时。 | `NoSignal_Dot_Proxy.prototype.onPlayAudio (index.7d3cd.js:124517)` | 0 |
| 玩法/用户 | `app_setting_nonetwork_click` | DC → 30% 本地抽样 + sendState 门禁 → hsEventTrack → Athena 5943/Drift_Sand | 无网络界面点击重试，或持续网络检查发现可重试时。 | `NoSignal_Dot_Proxy.prototype.onRetryClick (index.7d3cd.js:124526)；NoSignal_Dot_Proxy.prototype.checkNetworkForever (index.7d3cd.js:124550)` | 0 |
| 玩法/用户 | `app_setting_nonetwork_show` | DC → 30% 本地抽样 + sendState 门禁 → hsEventTrack → Athena 5943/Drift_Sand | 无网络界面显示，或持续网络检查进入该状态时。 | `NoSignal_Dot_Proxy.prototype.onShow (index.7d3cd.js:124535)；NoSignal_Dot_Proxy.prototype.checkNetworkForever (index.7d3cd.js:124553)` | 0 |
| 玩法/用户 | `g_game_backstop_fail` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | TraitServer 兜底方案执行失败时。 | `TraitServer_Dot_Proxy.prototype.handleBackstopFailDot (index.7d3cd.js:211058)` | 0 |
| 玩法/用户 | `g_game_cold_start_skin_start` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 冷启动选择的 skinId 有效并开始应用皮肤时。 | `Skin_Proxy.prototype.onSkinDot (index.7d3cd.js:200751)` | 5 |
| 玩法/用户 | `g_game_language_download` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 语言 bundle 预加载完成或失败回调时。 | `MultiLangVersionInfo.prototype.preLoadLangByBundleName (index.7d3cd.js:116249)；MultiLangVersionInfo.prototype.preLoadLangByBundleName (index.7d3cd.js:116297)` | 0 |
| 玩法/用户 | `g_game_language_replace_success` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 新旧语言不同且语言替换完成时。 | `MultiLangInfo.prototype.changeLanguage (index.7d3cd.js:115483)` | 0 |
| 玩法/用户 | `g_game_show_action_requestresult` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 广告 show action 请求得到结果时。 | `AdvertisementGameInfo.prototype.reportShowActionRequestResult (index.7d3cd.js:8431)` | 0 |
| 玩法/用户 | `g_game_skin_change_success` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 清屏前后的 skinId 不同且皮肤切换完成时。 | `Skin_Change_Dot_Proxy.prototype.onSkinDataUpdateCompleted (index.7d3cd.js:199887)` | 0 |
| 玩法/用户 | `g_game_solution_apply_success` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 归因/实验解决方案替换 traits 完成时。 | `TraitServerCampaign_Dot_Proxy.prototype.handleReplaceTraitsComplete (index.7d3cd.js:208192)` | 0 |
| 玩法/用户 | `g_login_account_entry_view` | DC → 30% 本地抽样 + sendState 门禁 → hsEventTrack → Athena 5943/Drift_Sand | 账号入口显示并执行入口曝光上报时。 | `AccountDot.e.doReportLoginAccountEntryView (index.7d3cd.js:1681)` | 0 |
| 玩法/用户 | `gameLaunchProcess` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 算法底板保底检查或保存底板关键阶段执行时。 | `AlgorithmIOSBottomInfo.prototype.checkGuaranteedBlock (index.7d3cd.js:12622)；AlgorithmIOSBottomInfo.prototype.checkGuaranteedBlock (index.7d3cd.js:12629)；AlgorithmIOS_Proxy.prototype.onSaveBottom (index.7d3cd.js:13698)；AlgorithmIOS_Proxy.prototype.onSaveBottom (index.7d3cd.js:13713)` | 0 |
| 玩法/用户 | `gameServerTraitActiveList` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | TraitServer 生成当前生效 trait 列表快照时。 | `TraitServerStartContinueInfo.prototype.sendActiveListDot (index.7d3cd.js:210274)` | 5 |
| 玩法/用户 | `game_get_model_result` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 游戏模型 HTTP 请求返回并整理结果时。 | `HttpDot_Proxy.prototype.onGameModelRequest (index.7d3cd.js:84914)` | 0 |
| 玩法/用户 | `game_popup_done` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 复活弹窗被禁用/关闭时。 | `Revive.prototype.onDisable (index.7d3cd.js:136127)` | 0 |
| 玩法/用户 | `game_popup_start` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 复活弹窗启用/显示时。 | `Revive.prototype.onEnable (index.7d3cd.js:136124)` | 0 |
| 玩法/用户 | `jsb_err_report` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | JSB、棋盘、CDN、localStorage 或 trait 参数处理捕获异常时。 | `AlgorithmInfo.prototype.getMappingKeyByValue (index.7d3cd.js:14026)；BlocksProducerTouch.prototype.onTouchStart (index.7d3cd.js:32037)；Board.prototype.render (index.7d3cd.js:37362)；CdnSpeedTracker.prototype.flush (index.7d3cd.js:38748)；Dot.a.createDotData (index.7d3cd.js:51648)；Multilink_Proxy.t.customCanHotUpdate (index.7d3cd.js:117006)；arrays.localStorage.clear (index.7d3cd.js:423637)；arrays.localStorage.clear (index.7d3cd.js:423645)` | 0 |
| 玩法/用户 | `lightgbm_zxh_user_churn_pred` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | LightGBM 用户流失预测产生结果时。 | `GBMChurnRateInfo.prototype.lightGetInfoDC (index.7d3cd.js:65607)` | 0 |
| 玩法/用户 | `usr_data_achieve` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 成就进度或奖励数据被更新时。 | `AchievementInfo.prototype.updataAchievementAwardData (index.7d3cd.js:4514)` | 2 |
| 玩法/用户 | `usr_data_catch_addloading` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 原生广告加载超过限定时间时。 | `NativeAd.e.longTimeLoadAd (index.7d3cd.js:117790)` | 0 |
| 玩法/用户 | `usr_data_comment_state` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 评分/评论流程状态发生变化时。 | `CommentSkin_proxy.prototype.dot (index.7d3cd.js:42896)` | 0 |
| 玩法/用户 | `usr_data_game_start` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 经典或 Jewel 对局正式创建并提交初始棋盘时。 | `GameLobby_DataInfo.prototype.JewelStartSubmit (index.7d3cd.js:68531)；GameLobby_DataInfo.prototype.JewelStartSubmit (index.7d3cd.js:68547)` | 2 |
| 玩法/用户 | `usr_data_guide_3_end` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | ChapterGame 第三段新手引导结束时。 | `Advertisement_Load_Proxy.prototype.addEventListener (index.7d3cd.js:9111)` | 1 |
| 玩法/用户 | `usr_data_migration_achieve_info` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 仅 VN 国家条件满足时迁移成就信息。 | `Achievement_Proxy.prototype.achieveDs (index.7d3cd.js:6257)` | 0 |
| 玩法/用户 | `usr_data_non_new_architecture_exp_success` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 非新架构实验兼容检查成功时。 | `TraitServerTraitCheckInfo.prototype.checkFeatureIos (index.7d3cd.js:210431)` | 0 |
| 玩法/用户 | `usr_data_replay_click` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 回放界面点击 Replay 时。 | `PlaybackGamePreComponent.prototype.onClickReplay (index.7d3cd.js:126642)` | 0 |
| 玩法/用户 | `usr_data_replay_interface_return_click` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 回放界面点击返回/关闭时。 | `PlaybackGamePreComponent.prototype.closeHandler (index.7d3cd.js:126785)` | 0 |
| 玩法/用户 | `usr_data_replay_progress_click` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 点击回放进度条时。 | `PlaybackGamePreComponent.prototype.sliderStartHandler (index.7d3cd.js:126474)` | 0 |
| 玩法/用户 | `usr_data_replay_progress_drag` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 拖动回放进度条结束时。 | `PlaybackGamePreComponent.prototype.handleSliderEnd (index.7d3cd.js:126493)` | 0 |
| 玩法/用户 | `usr_data_send_comment` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 提交评分/评论动作时。 | `CommentSkin_proxy.prototype.dot (index.7d3cd.js:42893)` | 0 |
| 玩法/用户 | `usr_data_show_comment` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 评分/评论弹窗打开时。 | `CommentSkin_proxy.prototype.dotOnOpen (index.7d3cd.js:42902)` | 0 |
| 玩法/用户 | `usr_data_type` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 启动阶段生成用户类型、设备内存、皮肤数量等快照时。 | `Launch_Dot_Proxy.prototype.onStartDataDot (index.7d3cd.js:90127)` | 5 |
| 运行时动态 | `ui_battle_show` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 动态事件对象的 name 为 ui_battle_show；游戏战斗/棋盘界面显示时。 | `DS(e.name, e) 动态转发；字面量未出现在 main JS` | 5 |
| 运行时动态 | `usr_data_guide_3_start` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 动态事件对象的 name 为 usr_data_guide_3_start；第三段新手引导开始时。 | `DS(e.name, e) 动态转发；字面量未出现在 main JS` | 2 |
| 错误/性能 | `cocos_log_reporter` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | Cocos 全局错误处理器捕获未被忽略的 JS 异常时。 | `Errors.window.__errorHandler (index.7d3cd.js:64959)` | 5 |
| 错误/性能 | `cocos_lose_reporter` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 数组/棋盘数据丢失诊断命中时。 | `arrays.n (index.7d3cd.js:423532)` | 0 |
| 错误/性能 | `cocos_res_reporter` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 章节资源异常、console.error 或 assertError 捕获资源错误时。 | `ChapterConfig_Proxy.prototype.reportChapterTravelStageIssue (index.7d3cd.js:40095)；Errors.console.error (index.7d3cd.js:64942)；Errors.a.assertError (index.7d3cd.js:64977)` | 0 |
| 错误/性能 | `s_tech_request_init_success` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 启动初始化请求完成时；V34 实测对应 gametester.afafb.com/game_init HTTP 200。 | `Multilink_Dot_Proxy.prototype.onReqInitSuccess (index.7d3cd.js:116771)；TraitServer_Dot_Proxy.prototype.handleResponse (index.7d3cd.js:210921)` | 5 |
| 错误/性能 | `usr_data_startup_time` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 启动耗时统计完成时。 | `Device_Score_Proxy.prototype.reportStartupTimeData (index.7d3cd.js:50978)` | 0 |
| 错误/性能 | `usr_data_tech_algo_sdk_errmsg` | DS → callNativeDataUpload → BMAthenaBridge → Athena 5943/Drift_Sand | 算法 SDK 出题/生成题目返回错误时。 | `PuzzleUtil.e.offerTopic (index.7d3cd.js:131647)` | 0 |
| 错误/性能 | `usr_data_tech_compatibility_error` | DC → 30% 本地抽样 + sendState 门禁 → hsEventTrack → Athena 5943/Drift_Sand | 旧版或新版数据兼容初始化检查发现错误时。 | `DataCompatibilityIos_Dot_Proxy.prototype.onInit (index.7d3cd.js:45610)；DataCompatibilityIos_Dot_Proxy.prototype.onInit (index.7d3cd.js:45614)；DataCompatibilityNew_Dot_proxy.prototype.onInit (index.7d3cd.js:48353)；DataCompatibilityNew_Dot_proxy.prototype.onInit (index.7d3cd.js:48357)` | 0 |

### 动态事件边界

代码还存在 `DS(e.name, e)`、`DC(e.eventName, e.data)`、Sand/Multilink 动态转发。上表已列出静态可解析、AtomEngine 固定 eventName 以及本次日志实际出现的动态事件；如果线上 trait/小游戏未来传入新的 name，事件集合仍可扩展。要做发布前冻结，需在离线 Seed 上禁用新增动态配置，并用运行时白名单记录未知事件。

## 5. Athena/Hisavana/Palm SDK 自动事件（V34 实测）

| appId | 事件名 | 触发原理 | 5 份日志命中 |
|---:|---|---|---:|
| 1044 | `app_launch` | Athena SDK 为已注册 appId 自动记录应用启动/前台会话。 | 5 |
| 1044 | `page_enter` | Athena SDK 生命周期监听记录页面进入；部分 appId 日志显示未注册拒绝。 | 3 |
| 1044 | `ps_upgrade_sdk_event` | Palm Store 升级 SDK 初始化、检查或返回阶段变化时。 | 10 |
| 1814 | `app_launch` | Athena SDK 为已注册 appId 自动记录应用启动/前台会话。 | 5 |
| 1814 | `monitor_init` | Hisavana 网络监控器初始化时。 | 5 |
| 1814 | `process` | Hisavana 网络请求完成后记录 DNS/TCP/TLS/HTTP 耗时与结果。 | 20 |
| 2411 | `app_launch` | Athena SDK 为已注册 appId 自动记录应用启动/前台会话。 | 5 |
| 4987 | `app_launch` | Athena SDK 为已注册 appId 自动记录应用启动/前台会话。 | 5 |
| 4987 | `page_enter` | Athena SDK 生命周期监听记录页面进入；部分 appId 日志显示未注册拒绝。 | 3 |
| 5943 | `Drift_Sand` | 业务层 DS/DC/DP 事件进入 BMAthenaBridge 后，由 AthenaSDK.track 封装。 | 125 |
| 5943 | `app_launch` | Athena SDK 为已注册 appId 自动记录应用启动/前台会话。 | 5 |
| 5943 | `page_enter` | Athena SDK 生命周期监听记录页面进入；部分 appId 日志显示未注册拒绝。 | 3 |
| 8661 | `ad_cld_request` | Hisavana 开始请求广告云控时。 | 2 |
| 8661 | `ad_cld_return` | Hisavana 广告云控返回时。 | 2 |
| 8661 | `ad_filling` | Hisavana 结束填充并给出成功/失败、缓存和错误码时。 | 6 |
| 8661 | `ad_trigger` | 业务触发某个 Hisavana 广告位 load/show 时。 | 6 |
| 8661 | `app_init` | Hisavana 广告 SDK 初始化时。 | 5 |
| 8661 | `app_launch` | Athena SDK 为已注册 appId 自动记录应用启动/前台会话。 | 5 |
| 8661 | `page_enter` | Athena SDK 生命周期监听记录页面进入；部分 appId 日志显示未注册拒绝。 | 3 |
| 8765 | `ad_filter` | Hisavana 对候选广告素材执行过滤时。 | 2 |
| 8765 | `ad_ssp_request` | Hisavana SSP 发起广告请求时。 | 14 |
| 8765 | `ad_ssp_return` | Hisavana SSP 广告请求返回时。 | 14 |
| 8765 | `app_launch` | Athena SDK 为已注册 appId 自动记录应用启动/前台会话。 | 5 |
| 8765 | `page_enter` | Athena SDK 生命周期监听记录页面进入；部分 appId 日志显示未注册拒绝。 | 3 |
| 8765 | `sdk_initalize` | Hisavana SSP/离线广告子模块初始化时。 | 5 |
| 8765 | `ssp_ad_request_default` | Hisavana SSP 请求默认广告配置时。 | 5 |
| 8765 | `ssp_ad_return_default` | Hisavana SSP 默认广告配置返回时。 | 5 |
| 8765 | `track_cloud_request` | Hisavana SSP 云控请求发出或返回时；参数中的事件类型区分阶段。 | 4 |
| 8765 | `track_offline_request` | Hisavana 离线广告请求发出或返回时。 | 100 |
| 9999 | `app_cfg_log` | Athena 为某个 appId 加载/刷新上传配置与 GSLB 数据时。 | 12 |
| 9999 | `device` | Athena 采集一次设备诊断快照时。 | 5 |

appId 归属：5943=Drift Sand 业务；4987=SnowBall/referrer 注册（但 Athena 自动生命周期事件仍出现）；8661=Hisavana core；8765=Hisavana SSP/离线广告；1814=Hisavana 网络监控；2411=Hisavana common tracker；1044=Palm 升级 SDK；9999=Athena 自诊断。

## 6. Firebase 状态

- 当前 Firebase app id：`1:638272297170:android:ab8c495238a3d5b85fb50b`。
- `AppActivity.onCreate` 每次调用 `FirebaseBridge.init`；5 份日志均出现初始化成功。
- 未发现 Cocos/Java 对 `FirebaseBridge.logEvent` 或 `logEventWithParams` 的实际调用，因此当前没有可列出的项目自定义 Firebase 事件名。
- Firebase Measurement 内部具备 `first_open`、`session_start`、`user_engagement`、`screen_view`、`app_update`、`app_remove`、`session_start_with_rollout` 等自动事件能力。本轮没有启用 FA DebugView，未把它们标记为实测上传；严格 Athena-only 时仍应关闭 collection，而不是依赖“日志没打印”。

## 7. 原厂域名静态风险清单

以下是两份 main JS 中出现的原厂样式主机。引用次数是两份 bundle 的合计字面量数量，不代表运行次数。

| 主机 | 静态引用数 |
|---|---:|
| `ai-commom-model.afafb.com` | 80 |
| `ai-robot-hub.afafb.com` | 134 |
| `ai-server-commerce.afafb.com` | 22 |
| `ai-server-product-wx.afafb.com` | 2 |
| `ai-server.afafb.com` | 6 |
| `ali-minos.afafb.com` | 9 |
| `bband1.afafb.com` | 236 |
| `bbios1.afafb.com` | 71 |
| `block-alg-recom.afafb.com` | 2 |
| `block-algo-online.afafb.com` | 8 |
| `block-data-service.afafb.com` | 2 |
| `block-hard-recom.afafb.com` | 94 |
| `block-rank-target.afafb.com` | 10 |
| `block-ucb.afafb.com` | 18 |
| `gametester.afafb.com` | 4 |
| `hella-game-gateway-server-test.afafb.com` | 10 |
| `hella-game-gateway-server.afafb.com` | 32 |
| `hella-ping-test.afafb.com` | 4 |
| `hella-ping.afafb.com` | 2 |
| `horizon-dev.afafb.com` | 156 |
| `horizon-prepub.afafb.com` | 28 |
| `horizon.afafb.com` | 100 |
| `infer-hub-test.afafb.com` | 2 |
| `middle-backend-test.afafb.com` | 6 |
| `middle-inference-gateway.afafb.com` | 4 |
| `middle-inference-platform-bb-gp-user-growth.afafb.com` | 13 |
| `middle-inference-platform-bb-ios-user-growth.afafb.com` | 2 |
| `session-control.afafb.com` | 2 |
| `share-prepub.blockblast.com` | 98 |
| `share.blockblast.com` | 250 |
| `subscribes.afafb.com` | 2 |
| `subscribes_try.afafb.com` | 2 |
| `ucw.afafb.com` | 28 |
| `user-skill-eval.afafb.com` | 26 |

## 8. 关键证据文件

- `stage2_sdk/assets/main.js`：当前资源 downloader guard，只覆盖资源下载。
- `stage2_sdk/assets/assets/main/index.7d3cd.js` 与 Seed `index.146a7.js`：DS/DC/DP、BBPublish、TraitServer 与原厂 URL。
- `stage2_sdk/smali_classes14/com/blockmaster/sdk/BMAthenaBridge.smali`：三条业务桥统一转 Athena。
- `stage2_sdk/smali_classes15/com/driftsand/game/athena/AthenaSDK.smali`：5943/Drift_Sand 封装。
- `diagnostics/v34_mumu/*.txt`：Athena 四级证据、Firebase 初始化、gametester.afafb.com 实际请求。
